import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import 'turso_native_service.dart';

class ReferFeeReportRow {
  const ReferFeeReportRow({
    required this.sampleId,
    required this.patientName,
    required this.subCenterId,
    required this.referredPerson,
    required this.tests,
    required this.amount,
    this.date,
  });

  final String sampleId;
  final String patientName;
  final String subCenterId;
  final String referredPerson;
  final String tests;
  final double amount;
  final DateTime? date;
}

class ReferFeeReportHeaderSettings {
  const ReferFeeReportHeaderSettings({
    required this.scopeType,
    required this.subCenterId,
    required this.hospitalName,
    required this.departmentName,
    required this.township,
    required this.ministryName,
    required this.reportTitle,
    required this.accentColor,
    required this.footerText,
  });

  final String scopeType;
  final String subCenterId;
  final String hospitalName;
  final String departmentName;
  final String township;
  final String ministryName;
  final String reportTitle;
  final String accentColor;
  final String footerText;

  factory ReferFeeReportHeaderSettings.defaults({String scopeType = 'GLOBAL', String subCenterId = 'GLOBAL'}) {
    return ReferFeeReportHeaderSettings(
      scopeType: scopeType,
      subCenterId: subCenterId,
      hospitalName: 'AungMyin Lab',
      departmentName: 'Laboratory Department',
      township: 'Kyouttaga Township',
      ministryName: 'Ministry of Health',
      reportTitle: 'LAB REPORT',
      accentColor: '#1D4ED8',
      footerText: '',
    );
  }

  factory ReferFeeReportHeaderSettings.fromMap(
    Map<String, String> map, {
    required ReferFeeReportHeaderSettings fallback,
  }) {
    String pick(String key, String fallbackValue) {
      final value = map[key]?.trim() ?? '';
      return value.isEmpty ? fallbackValue : value;
    }

    return ReferFeeReportHeaderSettings(
      scopeType: pick('scopetype', fallback.scopeType),
      subCenterId: pick('subcenterid', fallback.subCenterId),
      hospitalName: pick('hospitalname', fallback.hospitalName),
      departmentName: pick('departmentname', fallback.departmentName),
      township: pick('township', fallback.township),
      ministryName: pick('ministryname', fallback.ministryName),
      reportTitle: pick('reporttitle', fallback.reportTitle),
      accentColor: pick('accentcolor', fallback.accentColor),
      footerText: pick('footertext', fallback.footerText),
    );
  }
}

class ReferFeeReportService {
  const ReferFeeReportService._();

  static Future<void> printReport({
    required String title,
    required String periodLabel,
    required String scopeLabel,
    required List<ReferFeeReportRow> rows,
    String generatedBy = '',
    String headerScopeType = 'GLOBAL',
    String headerSubCenterId = 'GLOBAL',
  }) async {
    final baseFont = await _loadFont('assets/fonts/DejaVuSans.ttf');
    final boldFont = await _loadFont('assets/fonts/DejaVuSans-Bold.ttf');
    final doc = pw.Document();
    final pageTheme = _pageTheme(baseFont, boldFont);
    final header = await _loadReportHeaderSettings(
      scopeType: headerScopeType,
      subCenterId: headerSubCenterId,
    );
    final accent = _pdfColorFromHex(header.accentColor);

    final sortedRows = [...rows]
      ..sort((a, b) {
        final byPerson = a.referredPerson.toLowerCase().compareTo(b.referredPerson.toLowerCase());
        if (byPerson != 0) return byPerson;
        return (a.date ?? DateTime(1900)).compareTo(b.date ?? DateTime(1900));
      });
    final totalFee = sortedRows.fold<double>(0, (sum, row) => sum + row.amount);
    final totalSamples = sortedRows.length;
    final totalTests = sortedRows.fold<int>(0, (sum, row) => sum + _testCount(row.tests));
    final personSummaries = _personSummaries(sortedRows);
    final monthlySummaries = _periodSummaries(sortedRows, monthly: true);
    final yearlySummaries = _periodSummaries(sortedRows, monthly: false);

    doc.addPage(
      pw.MultiPage(
        pageTheme: pageTheme,
        footer: (context) => _reportFooter(header),
        build: (context) => [
          _customReportHeader(header, accent),
          pw.SizedBox(height: 12),
          _reportTitleBlock(title, periodLabel, scopeLabel, generatedBy, accent),
          pw.SizedBox(height: 12),
          pw.Row(
            children: [
              _summaryBox('Total referral fee', _money(totalFee), accent),
              pw.SizedBox(width: 8),
              _summaryBox('Samples', '$totalSamples', accent),
              pw.SizedBox(width: 8),
              _summaryBox('Tests', '$totalTests', accent),
            ],
          ),
          pw.SizedBox(height: 14),
          _sectionTitle('Referral person summary', accent),
          pw.SizedBox(height: 7),
          if (personSummaries.isEmpty)
            pw.Text('No referral fee data for this period.', style: const pw.TextStyle(fontSize: 9))
          else
            _personSummaryTable(personSummaries, accent),
          pw.SizedBox(height: 14),
          _sectionTitle('Person by month summary', accent),
          pw.SizedBox(height: 7),
          if (monthlySummaries.isEmpty)
            pw.Text('No month summary rows to show.', style: const pw.TextStyle(fontSize: 9))
          else
            _periodSummaryTable(monthlySummaries, accent),
          pw.SizedBox(height: 14),
          _sectionTitle('Person by year summary', accent),
          pw.SizedBox(height: 7),
          if (yearlySummaries.isEmpty)
            pw.Text('No year summary rows to show.', style: const pw.TextStyle(fontSize: 9))
          else
            _periodSummaryTable(yearlySummaries, accent),
          pw.SizedBox(height: 14),
          _sectionTitle('Referral sample details', accent),
          pw.SizedBox(height: 7),
          if (sortedRows.isEmpty)
            pw.Text('No sample rows to show.', style: const pw.TextStyle(fontSize: 9))
          else
            _sampleDetailTable(sortedRows),
          if (personSummaries.length > 1) ...[
            pw.SizedBox(height: 16),
            _sectionTitle('Details grouped by referral person', accent),
            pw.SizedBox(height: 8),
            ..._personDetailSections(sortedRows, accent),
          ],
        ],
      ),
    );

    await Printing.layoutPdf(
      onLayout: (format) async => doc.save(),
      name: '${_slug(title)}_${_slug(periodLabel)}.pdf',
    );
  }

  static Future<pw.Font?> _loadFont(String assetPath) async {
    try {
      final data = await rootBundle.load(assetPath);
      return pw.Font.ttf(data);
    } catch (_) {
      return null;
    }
  }

  static pw.PageTheme _pageTheme(pw.Font? baseFont, pw.Font? boldFont) {
    const margin = pw.EdgeInsets.fromLTRB(28, 30, 28, 26);
    if (baseFont == null) {
      return pw.PageTheme(pageFormat: PdfPageFormat.a4, margin: margin);
    }
    return pw.PageTheme(
      pageFormat: PdfPageFormat.a4,
      margin: margin,
      theme: pw.ThemeData.withFont(base: baseFont, bold: boldFont ?? baseFont),
    );
  }

  static Future<ReferFeeReportHeaderSettings> _loadReportHeaderSettings({required String scopeType, required String subCenterId}) async {
    final fallback = ReferFeeReportHeaderSettings.defaults(scopeType: scopeType, subCenterId: subCenterId);
    TursoNativeService? service;
    try {
      service = TursoNativeService(applicationName: 'aungmyin_lab');
      final rows = await service.fetchRows(range: 'ReportHeaderSettings!A:K');
      if (rows.length < 2) return fallback;
      final headers = rows.first.map(_normalize).toList();
      final records = <Map<String, String>>[];
      for (final row in rows.skip(1)) {
        final map = <String, String>{};
        for (var i = 0; i < headers.length; i++) {
          map[headers[i]] = i < row.length ? row[i].trim() : '';
        }
        records.add(map);
      }

      Map<String, String>? match(String targetScope, String targetCenter) {
        for (final record in records) {
          if (_normalize(record['scopetype'] ?? '') == _normalize(targetScope) &&
              _normalize(record['subcenterid'] ?? '') == _normalize(targetCenter)) {
            return record;
          }
        }
        return null;
      }

      final requested = match(scopeType, subCenterId);
      if (requested != null) {
        return ReferFeeReportHeaderSettings.fromMap(requested, fallback: fallback);
      }

      final globalFallback = ReferFeeReportHeaderSettings.defaults(scopeType: 'GLOBAL', subCenterId: 'GLOBAL');
      final global = match('GLOBAL', 'GLOBAL');
      if (global != null) {
        return ReferFeeReportHeaderSettings.fromMap(global, fallback: globalFallback).copyForScope(scopeType: scopeType, subCenterId: subCenterId);
      }
      return fallback;
    } catch (_) {
      return fallback;
    } finally {
      await service?.close();
    }
  }

  static pw.Widget _customReportHeader(ReferFeeReportHeaderSettings settings, PdfColor accent) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: pw.BoxDecoration(
        color: PdfColor.fromHex('#EFF6FF'),
        borderRadius: pw.BorderRadius.circular(10),
        border: pw.Border.all(color: PdfColor.fromHex('#BFDBFE'), width: 0.7),
      ),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.center,
        children: [
          pw.Container(
            width: 42,
            height: 42,
            alignment: pw.Alignment.center,
            decoration: pw.BoxDecoration(
              shape: pw.BoxShape.circle,
              color: PdfColors.white,
              border: pw.Border.all(color: accent, width: 1.2),
            ),
            child: pw.Text('AM', style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold, color: accent)),
          ),
          pw.SizedBox(width: 10),
          pw.Expanded(
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  settings.hospitalName.trim().isEmpty ? 'AungMyin Lab' : settings.hospitalName.trim(),
                  maxLines: 1,
                  style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold, color: PdfColor.fromHex('#0F172A')),
                ),
                pw.SizedBox(height: 2),
                pw.Text(settings.departmentName.trim(), maxLines: 1, style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold, color: accent)),
                pw.Text(
                  [settings.township.trim(), settings.ministryName.trim()].where((item) => item.isNotEmpty).join(' • '),
                  maxLines: 1,
                  style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700),
                ),
              ],
            ),
          ),
          pw.SizedBox(width: 8),
          pw.Container(
            padding: const pw.EdgeInsets.symmetric(horizontal: 9, vertical: 5),
            decoration: pw.BoxDecoration(color: accent, borderRadius: pw.BorderRadius.circular(12)),
            child: pw.Text(
              settings.reportTitle.trim().isEmpty ? 'LAB REPORT' : settings.reportTitle.trim(),
              maxLines: 1,
              style: pw.TextStyle(fontSize: 7, fontWeight: pw.FontWeight.bold, color: PdfColors.white),
            ),
          ),
        ],
      ),
    );
  }

  static pw.Widget _reportTitleBlock(String title, String periodLabel, String scopeLabel, String generatedBy, PdfColor accent) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(12),
      decoration: pw.BoxDecoration(
        color: PdfColors.white,
        border: pw.Border.all(color: PdfColor.fromHex('#CBD5E1'), width: 0.7),
        borderRadius: pw.BorderRadius.circular(10),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(title, style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold, color: PdfColor.fromHex('#0F172A'))),
          pw.SizedBox(height: 7),
          pw.Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              _metaPill('Period', periodLabel, accent),
              _metaPill('Scope', scopeLabel, accent),
              if (generatedBy.trim().isNotEmpty) _metaPill('Generated by', generatedBy.trim(), accent),
            ],
          ),
        ],
      ),
    );
  }

  static pw.Widget _metaPill(String label, String value, PdfColor accent) {
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: pw.BoxDecoration(
        color: PdfColor.fromHex('#F8FAFC'),
        borderRadius: pw.BorderRadius.circular(99),
        border: pw.Border.all(color: PdfColor.fromHex('#CBD5E1'), width: 0.5),
      ),
      child: pw.RichText(
        text: pw.TextSpan(
          children: [
            pw.TextSpan(text: '$label: ', style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold, color: accent)),
            pw.TextSpan(text: value, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey800)),
          ],
        ),
      ),
    );
  }

  static pw.Widget _sectionTitle(String title, PdfColor accent) {
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: pw.BoxDecoration(color: PdfColor.fromHex('#EFF6FF'), borderRadius: pw.BorderRadius.circular(7)),
      child: pw.Text(title, style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold, color: accent)),
    );
  }

  static pw.Widget _reportFooter(ReferFeeReportHeaderSettings settings) {
    final footer = settings.footerText.trim();
    final center = settings.subCenterId.trim().toLowerCase();
    if (footer.isEmpty || center.isEmpty || center == 'global') return pw.SizedBox.shrink();
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.only(top: 6),
      decoration: const pw.BoxDecoration(border: pw.Border(top: pw.BorderSide(color: PdfColors.grey400, width: 0.4))),
      child: pw.Text(
        footer,
        textAlign: pw.TextAlign.center,
        style: const pw.TextStyle(fontSize: 7.5, color: PdfColors.grey700),
      ),
    );
  }

  static pw.Widget _summaryBox(String label, String value, PdfColor accent) {
    return pw.Expanded(
      child: pw.Container(
        padding: const pw.EdgeInsets.all(9),
        decoration: pw.BoxDecoration(
          color: PdfColor.fromHex('#F8FAFC'),
          border: pw.Border.all(color: PdfColor.fromHex('#CBD5E1'), width: 0.6),
          borderRadius: pw.BorderRadius.circular(9),
        ),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(label, style: const pw.TextStyle(color: PdfColors.grey700, fontSize: 8)),
            pw.SizedBox(height: 4),
            pw.Text(value, style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold, color: accent)),
          ],
        ),
      ),
    );
  }

  static pw.Widget _personSummaryTable(List<_PersonSummary> summaries, PdfColor accent) {
    return pw.TableHelper.fromTextArray(
      headers: const ['Referred person', 'Samples', 'Tests', 'Referral fee'],
      data: [for (final item in summaries) [item.person, item.samples.toString(), item.tests.toString(), _money(item.fee)]],
      headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white, fontSize: 8.5),
      headerDecoration: pw.BoxDecoration(color: accent),
      cellStyle: const pw.TextStyle(fontSize: 8),
      cellAlignment: pw.Alignment.centerLeft,
      border: pw.TableBorder.all(color: PdfColor.fromHex('#CBD5E1'), width: 0.45),
      columnWidths: const {0: pw.FlexColumnWidth(3), 1: pw.FlexColumnWidth(1), 2: pw.FlexColumnWidth(1), 3: pw.FlexColumnWidth(1.5)},
    );
  }

  static pw.Widget _periodSummaryTable(List<_PeriodSummary> summaries, PdfColor accent) {
    return pw.TableHelper.fromTextArray(
      headers: const ['Referred person', 'Period', 'Samples', 'Tests', 'Referral fee'],
      data: [for (final item in summaries) [item.person, item.period, item.samples.toString(), item.tests.toString(), _money(item.fee)]],
      headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white, fontSize: 8.5),
      headerDecoration: pw.BoxDecoration(color: accent),
      cellStyle: const pw.TextStyle(fontSize: 7.8),
      cellAlignment: pw.Alignment.centerLeft,
      border: pw.TableBorder.all(color: PdfColor.fromHex('#CBD5E1'), width: 0.45),
      columnWidths: const {0: pw.FlexColumnWidth(2.6), 1: pw.FlexColumnWidth(1.4), 2: pw.FlexColumnWidth(0.9), 3: pw.FlexColumnWidth(0.9), 4: pw.FlexColumnWidth(1.4)},
    );
  }

  static pw.Widget _sampleDetailTable(List<ReferFeeReportRow> rows) {
    return pw.TableHelper.fromTextArray(
      headers: const ['Date', 'Sample', 'Patient', 'Center', 'Referred person', 'Tests', 'Fee'],
      data: [
        for (final row in rows)
          [
            _date(row.date),
            row.sampleId,
            row.patientName,
            row.subCenterId,
            row.referredPerson,
            row.tests,
            _money(row.amount),
          ],
      ],
      headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white, fontSize: 7.8),
      headerDecoration: pw.BoxDecoration(color: PdfColor.fromHex('#0F172A')),
      cellStyle: const pw.TextStyle(fontSize: 7),
      cellAlignment: pw.Alignment.centerLeft,
      border: pw.TableBorder.all(color: PdfColor.fromHex('#CBD5E1'), width: 0.4),
      columnWidths: const {
        0: pw.FlexColumnWidth(1.05),
        1: pw.FlexColumnWidth(1.15),
        2: pw.FlexColumnWidth(1.6),
        3: pw.FlexColumnWidth(0.9),
        4: pw.FlexColumnWidth(1.6),
        5: pw.FlexColumnWidth(1.7),
        6: pw.FlexColumnWidth(1.0),
      },
    );
  }

  static List<pw.Widget> _personDetailSections(List<ReferFeeReportRow> rows, PdfColor accent) {
    final grouped = <String, List<ReferFeeReportRow>>{};
    for (final row in rows) {
      final person = row.referredPerson.trim().isEmpty ? 'Unknown referral' : row.referredPerson.trim();
      grouped.putIfAbsent(person, () => <ReferFeeReportRow>[]).add(row);
    }
    final people = grouped.keys.toList()..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    return [
      for (final person in people) ...[
        pw.Container(
          width: double.infinity,
          padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 5),
          decoration: pw.BoxDecoration(border: pw.Border(left: pw.BorderSide(color: accent, width: 3))),
          child: pw.Text(person, style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold)),
        ),
        pw.SizedBox(height: 5),
        _sampleDetailTable(grouped[person]!),
        pw.SizedBox(height: 10),
      ],
    ];
  }

  static List<_PersonSummary> _personSummaries(List<ReferFeeReportRow> rows) {
    final totals = <String, _PersonSummary>{};
    for (final row in rows) {
      final person = row.referredPerson.trim().isEmpty ? 'Unknown referral' : row.referredPerson.trim();
      final current = totals[person] ?? _PersonSummary(person: person);
      current.samples += 1;
      current.tests += _testCount(row.tests);
      current.fee += row.amount;
      totals[person] = current;
    }
    final values = totals.values.toList()
      ..sort((a, b) {
        final fee = b.fee.compareTo(a.fee);
        if (fee != 0) return fee;
        return a.person.toLowerCase().compareTo(b.person.toLowerCase());
      });
    return values;
  }

  static List<_PeriodSummary> _periodSummaries(List<ReferFeeReportRow> rows, {required bool monthly}) {
    final totals = <String, _PeriodSummary>{};
    for (final row in rows) {
      final date = row.date?.toLocal();
      if (date == null) continue;
      final person = row.referredPerson.trim().isEmpty ? 'Unknown referral' : row.referredPerson.trim();
      final period = monthly ? '${date.year}-${date.month.toString().padLeft(2, '0')}' : date.year.toString();
      final key = '$person|$period';
      final current = totals[key] ?? _PeriodSummary(person: person, period: period);
      current.samples += 1;
      current.tests += _testCount(row.tests);
      current.fee += row.amount;
      totals[key] = current;
    }
    final values = totals.values.toList()
      ..sort((a, b) {
        final byPerson = a.person.toLowerCase().compareTo(b.person.toLowerCase());
        if (byPerson != 0) return byPerson;
        return b.period.compareTo(a.period);
      });
    return values;
  }

  static int _testCount(String tests) {
    final count = tests.split(',').map((item) => item.trim()).where((item) => item.isNotEmpty).length;
    return count == 0 ? 1 : count;
  }

  static PdfColor _pdfColorFromHex(String raw) {
    final cleaned = raw.trim().replaceAll('#', '');
    if (!RegExp(r'^[0-9a-fA-F]{6}$').hasMatch(cleaned)) return PdfColor(0.114, 0.306, 0.847);
    final value = int.parse(cleaned, radix: 16);
    final r = ((value >> 16) & 0xFF) / 255.0;
    final g = ((value >> 8) & 0xFF) / 255.0;
    final b = (value & 0xFF) / 255.0;
    return PdfColor(r, g, b);
  }

  static String _date(DateTime? value) {
    if (value == null) return '-';
    final local = value.toLocal();
    return '${local.year}-${local.month.toString().padLeft(2, '0')}-${local.day.toString().padLeft(2, '0')}';
  }

  static String _money(num value) => 'Ks ${_number(value.round())}';

  static String _number(num value) {
    final raw = value.abs().round().toString();
    final buffer = StringBuffer(value < 0 ? '-' : '');
    for (var i = 0; i < raw.length; i++) {
      final remaining = raw.length - i;
      buffer.write(raw[i]);
      if (remaining > 1 && remaining % 3 == 1) buffer.write(',');
    }
    return buffer.toString();
  }

  static String _slug(String value) {
    final cleaned = value.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '_').replaceAll(RegExp(r'^_+|_+$'), '');
    return cleaned.isEmpty ? 'referral_report' : cleaned;
  }

  static String _normalize(String raw) => raw.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
}

class _PersonSummary {
  _PersonSummary({required this.person});
  final String person;
  int samples = 0;
  int tests = 0;
  double fee = 0;
}

class _PeriodSummary {
  _PeriodSummary({required this.person, required this.period});
  final String person;
  final String period;
  int samples = 0;
  int tests = 0;
  double fee = 0;
}

extension _ReferFeeReportHeaderScopeCopy on ReferFeeReportHeaderSettings {
  ReferFeeReportHeaderSettings copyForScope({required String scopeType, required String subCenterId}) {
    return ReferFeeReportHeaderSettings(
      scopeType: scopeType,
      subCenterId: subCenterId,
      hospitalName: hospitalName,
      departmentName: departmentName,
      township: township,
      ministryName: ministryName,
      reportTitle: reportTitle,
      accentColor: accentColor,
      footerText: footerText,
    );
  }
}
