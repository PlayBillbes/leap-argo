import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../models/app_user.dart';
import '../providers/auth_notifier.dart';
import '../providers/alert_provider.dart';
import '../providers/sync_queue_provider.dart';
import 'sync_now_button.dart';


class AppScaffold extends ConsumerStatefulWidget {
  const AppScaffold({
    super.key,
    required this.title,
    required this.selectedRoute,
    required this.user,
    required this.body,
    this.actions = const [],
  });

  final String title;
  final String selectedRoute;
  final AppUser? user;
  final Widget body;
  final List<Widget> actions;

  @override
  ConsumerState<AppScaffold> createState() => _AppScaffoldState();
}

class _AppScaffoldState extends ConsumerState<AppScaffold> {
  bool _expanded = true;
  Timer? _automaticSyncTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) ref.read(syncQueueProvider.notifier).syncNow(silent: true);
    });
    _automaticSyncTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) ref.read(syncQueueProvider.notifier).syncNow(silent: true);
    });
  }

  @override
  void dispose() {
    _automaticSyncTimer?.cancel();
    super.dispose();
  }

  List<Widget> _mobileActions() {
    final filtered = widget.actions.where((action) {
      if (action is IconButton) {
        final tooltip = action.tooltip?.toLowerCase() ?? '';
        return !(tooltip.contains('refresh') || tooltip.contains('reload'));
      }
      if (action is TextButton) return false;
      return true;
    }).toList();
    if (filtered.isEmpty) return const <Widget>[];
    return <Widget>[...filtered, const SizedBox(width: 6)];
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isMobile = constraints.maxWidth < 760;
        final entries = _navigationEntries(widget.user, widget.selectedRoute);
        final pageBody = Container(
          color: const Color(0xFFF6F8FC),
          child: SafeArea(
            top: false,
            child: _GlobalLoginAlertGate(user: widget.user, child: widget.body),
          ),
        );

        if (isMobile) {
          return Scaffold(
            appBar: AppBar(
              toolbarHeight: 64,
              centerTitle: false,
              titleSpacing: 0,
              title: Text(widget.title, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              elevation: 0,
              scrolledUnderElevation: 0,
              backgroundColor: const Color(0xFF0B57B7),
              foregroundColor: Colors.white,
              leading: Builder(
                builder: (context) => IconButton(
                  tooltip: 'Open menu',
                  icon: const Icon(Icons.menu_rounded, size: 32),
                  onPressed: () => Scaffold.of(context).openDrawer(),
                ),
              ),
              actions: widget.user == null ? _mobileActions() : <Widget>[..._mobileActions(), const SyncNowButton(), const SizedBox(width: 6)],
            ),
            drawer: _MobileNavigationDrawer(user: widget.user, entries: entries),
            bottomNavigationBar: _MobileBottomNavigation(entries: entries, selectedRoute: widget.selectedRoute),
            body: pageBody,
          );
        }

        return Scaffold(
          appBar: AppBar(
            title: Text(widget.title),
            elevation: 0,
            scrolledUnderElevation: 0,
            backgroundColor: const Color(0xFF0B57B7),
            foregroundColor: Colors.white,
            actions: widget.user == null ? [...widget.actions, const SizedBox(width: 12)] : <Widget>[const SyncNowButton(), ...widget.actions, const SizedBox(width: 12)],
          ),
          body: Container(
            color: const Color(0xFFF6F8FC),
            child: Row(
              children: [
                _CollapsibleSidebar(
                  user: widget.user,
                  selectedRoute: widget.selectedRoute,
                  expanded: _expanded,
                  canToggle: true,
                  onToggle: () => setState(() => _expanded = !_expanded),
                ),
                Expanded(child: _GlobalLoginAlertGate(user: widget.user, child: widget.body)),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _NavigationEntry {
  const _NavigationEntry({required this.icon, required this.label, required this.route, required this.selected});
  final IconData icon;
  final String label;
  final String route;
  final bool selected;
}

List<_NavigationEntry> _navigationEntries(AppUser? user, String selectedRoute) {
  final entries = <_NavigationEntry>[
    _NavigationEntry(icon: Icons.dashboard_rounded, label: 'Dashboard', route: '/', selected: selectedRoute == '/'),
    _NavigationEntry(icon: Icons.manage_search_rounded, label: 'Search', route: '/search', selected: selectedRoute == '/search'),
  ];
  if (user?.role == AppUserRole.staff || user?.role == AppUserRole.admin || user?.role == AppUserRole.superadmin || user?.role == AppUserRole.lab_tech) {
    entries.add(_NavigationEntry(icon: Icons.addchart_rounded, label: 'Register Sample', route: '/register-sample', selected: selectedRoute == '/register-sample'));
  }
  if (user?.role == AppUserRole.referred_person) {
    entries.add(_NavigationEntry(icon: Icons.person_pin_circle_rounded, label: 'Referral Report', route: '/referred-person-report', selected: selectedRoute == '/referred-person-report'));
  }
  entries.add(_NavigationEntry(icon: Icons.account_circle_rounded, label: 'Profile', route: '/profile', selected: selectedRoute == '/profile'));
  if (user?.role == AppUserRole.superadmin || user?.role == AppUserRole.admin) {
    entries.add(_NavigationEntry(icon: Icons.branding_watermark_rounded, label: 'Report Header', route: '/report-header', selected: selectedRoute == '/report-header'));
  }
  if (user?.role == AppUserRole.lab_tech || user?.role == AppUserRole.superadmin) {
    entries.addAll([
      _NavigationEntry(icon: Icons.fact_check_rounded, label: 'Test Requirements', route: '/test-requirements', selected: selectedRoute == '/test-requirements'),
      _NavigationEntry(icon: Icons.bloodtype_rounded, label: 'CBC / CP Result', route: '/cbc-cp-result', selected: selectedRoute == '/cbc-cp-result'),
      _NavigationEntry(icon: Icons.summarize_rounded, label: 'Lab Tech Report', route: '/lab-tech-report', selected: selectedRoute == '/lab-tech-report'),
    ]);
  }
  if (user?.role == AppUserRole.superadmin) {
    entries.addAll([
      _NavigationEntry(icon: Icons.rule_rounded, label: 'CBC Ref. Ranges', route: '/cbc-reference-ranges', selected: selectedRoute == '/cbc-reference-ranges'),
      _NavigationEntry(icon: Icons.group_rounded, label: 'Users', route: '/users', selected: selectedRoute == '/users'),
      _NavigationEntry(icon: Icons.price_change_rounded, label: 'Global Pricing', route: '/global-pricing', selected: selectedRoute == '/global-pricing'),
      _NavigationEntry(icon: Icons.analytics_rounded, label: 'Advanced Analytics', route: '/advanced-analytics', selected: selectedRoute == '/advanced-analytics'),
      _NavigationEntry(icon: Icons.campaign_rounded, label: 'Alerts', route: '/alerts', selected: selectedRoute == '/alerts'),
    ]);
  }
  if (user?.role == AppUserRole.staff) {
    entries.add(_NavigationEntry(icon: Icons.person_pin_rounded, label: 'Referred Persons', route: '/users', selected: selectedRoute == '/users'));
  }
  if (user?.role == AppUserRole.admin) {
    entries.addAll([
      _NavigationEntry(icon: Icons.group_rounded, label: 'Staff Accounts', route: '/users', selected: selectedRoute == '/users'),
      _NavigationEntry(icon: Icons.storefront_rounded, label: 'Sub-center Pricing', route: '/sub-center-pricing', selected: selectedRoute == '/sub-center-pricing'),
      _NavigationEntry(icon: Icons.query_stats_rounded, label: 'Admin Analytics', route: '/admin-analytics', selected: selectedRoute == '/admin-analytics'),
    ]);
  }
  return entries;
}

class _MobileNavigationDrawer extends ConsumerWidget {
  const _MobileNavigationDrawer({required this.user, required this.entries});
  final AppUser? user;
  final List<_NavigationEntry> entries;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    return Drawer(
      backgroundColor: Colors.white,
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 10),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'AungMyin Lab',
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w900,
                        color: const Color(0xFF0F172A),
                      ),
                    ),
                  ),
                  Container(
                    width: 42,
                    height: 42,
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFFEFF6FF),
                      border: Border.all(color: const Color(0xFFBFDBFE)),
                    ),
                    child: Image.asset('assets/images/moh.png', fit: BoxFit.contain),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: const Color(0xFFE2E8F0)),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 22,
                      backgroundColor: const Color(0xFFEFF6FF),
                      foregroundColor: const Color(0xFF0B57B7),
                      child: Text((user?.name.trim().isNotEmpty == true ? user!.name.trim().characters.first : 'U').toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w900)),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(user?.name.trim().isNotEmpty == true ? user!.name.trim() : 'User', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF0F172A))),
                          const SizedBox(height: 2),
                          Text('${user?.role.name.replaceAll('_', ' ') ?? 'guest'} • ${(user?.subCenterId ?? 'GLOBAL').trim().isEmpty ? 'GLOBAL' : user!.subCenterId!.trim()}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Color(0xFF64748B), fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                children: [
                  for (final entry in entries)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: ListTile(
                        leading: Icon(entry.icon),
                        title: Text(entry.label, style: const TextStyle(fontWeight: FontWeight.w700)),
                        selected: entry.selected,
                        selectedColor: const Color(0xFF0B57B7),
                        iconColor: const Color(0xFF64748B),
                        textColor: const Color(0xFF334155),
                        selectedTileColor: const Color(0xFFEFF6FF),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        onTap: () {
                          Navigator.of(context).pop();
                          if (!entry.selected) context.go(entry.route);
                        },
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFFDC2626),
                    side: const BorderSide(color: Color(0xFFFECACA)),
                    backgroundColor: const Color(0xFFFFFBFB),
                  ),
                  onPressed: () {
                    _GlobalLoginAlertGateState.clearShownAlerts();
                    ref.read(authNotifierProvider.notifier).clearUser();
                    context.go('/login');
                  },
                  icon: const Icon(Icons.logout_rounded),
                  label: const Text('Logout'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MobileBottomNavigation extends StatelessWidget {
  const _MobileBottomNavigation({required this.entries, required this.selectedRoute});
  final List<_NavigationEntry> entries;
  final String selectedRoute;

  @override
  Widget build(BuildContext context) {
    final hasAdminDashboard = entries.any((entry) => entry.route == '/admin-analytics');
    final preferredRoutes = hasAdminDashboard
        ? <String>['/', '/admin-analytics', '/sub-center-pricing', '/users', '/profile']
        : <String>['/', '/search', '/referred-person-report', '/register-sample', '/profile'];
    final items = <_NavigationEntry>[];
    for (final route in preferredRoutes) {
      final match = entries.where((entry) => entry.route == route);
      if (match.isNotEmpty && !items.any((item) => item.route == route)) items.add(match.first);
    }
    for (final entry in entries) {
      if (items.length >= 5) break;
      if (!items.any((item) => item.route == entry.route)) items.add(entry);
    }
    if (items.length < 2) return const SizedBox.shrink();
    final index = items.indexWhere((entry) => entry.route == selectedRoute);
    return NavigationBar(
      backgroundColor: Colors.white,
      indicatorColor: const Color(0xFFEFF6FF),
      selectedIndex: index >= 0 ? index : 0,
      onDestinationSelected: (i) {
        final destination = items[i];
        if (destination.route != selectedRoute) context.go(destination.route);
      },
      destinations: [
        for (final entry in items)
          NavigationDestination(icon: Icon(_mobileNavIcon(entry)), label: _mobileNavLabel(entry)),
      ],
    );
  }
}

IconData _mobileNavIcon(_NavigationEntry entry) {
  if (entry.route == '/profile') return Icons.more_horiz_rounded;
  if (entry.route == '/admin-analytics') return Icons.bar_chart_rounded;
  if (entry.route == '/referred-person-report') return Icons.person_pin_circle_rounded;
  if (entry.route == '/sub-center-pricing' || entry.route == '/global-pricing') return Icons.receipt_long_rounded;
  return entry.icon;
}

String _mobileNavLabel(_NavigationEntry entry) {
  if (entry.route == '/admin-analytics') return 'Analytics';
  if (entry.route == '/sub-center-pricing' || entry.route == '/global-pricing') return 'Pricing';
  if (entry.route == '/profile') return 'More';
  if (entry.route == '/users') return 'Users';
  if (entry.route == '/referred-person-report') return 'Report';
  return entry.label.length > 14 ? entry.label.split(' ').first : entry.label;
}


class _CollapsibleSidebar extends StatelessWidget {
  const _CollapsibleSidebar({
    required this.user,
    required this.selectedRoute,
    required this.expanded,
    required this.canToggle,
    required this.onToggle,
  });

  final AppUser? user;
  final String selectedRoute;
  final bool expanded;
  final bool canToggle;
  final VoidCallback onToggle;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      width: expanded ? 270 : 84,
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        color: Colors.white,
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 30, offset: const Offset(0, 16)),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: theme.colorScheme.primary,
                foregroundColor: theme.colorScheme.onPrimary,
                child: const Icon(Icons.local_hospital_rounded),
              ),
              if (expanded) ...[
                const SizedBox(width: 12),
                Expanded(child: Text('AungMyin Lab', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900))),
              ],
              if (canToggle)
                IconButton(
                  tooltip: expanded ? 'Collapse sidebar' : 'Expand sidebar',
                  onPressed: onToggle,
                  icon: Icon(expanded ? Icons.chevron_left_rounded : Icons.chevron_right_rounded),
                ),
            ],
          ),
          const SizedBox(height: 12),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: _items(),
            ),
          ),
          const SizedBox(height: 10),
          if (expanded)
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), color: theme.colorScheme.primaryContainer),
              child: Row(
                children: [
                  CircleAvatar(child: Text((user?.name ?? 'U').characters.first)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(user?.name ?? 'User', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
                        Text(user?.role.name ?? 'guest'),
                      ],
                    ),
                  ),
                ],
              ),
            )
          else
            Tooltip(message: '${user?.name ?? 'User'} • ${user?.role.name ?? 'guest'}', child: CircleAvatar(child: Text((user?.name ?? 'U').characters.first))),
          const SizedBox(height: 10),
          _SidebarLogoutButton(expanded: expanded),
        ],
      ),
    );
  }

  List<Widget> _items() {
    return [
      for (final entry in _navigationEntries(user, selectedRoute))
        _CollapsibleSidebarItem(icon: entry.icon, label: entry.label, route: entry.route, selected: entry.selected, expanded: expanded),
    ];
  }
}

class _CollapsibleSidebarItem extends StatelessWidget {
  const _CollapsibleSidebarItem({required this.icon, required this.label, required this.route, required this.selected, required this.expanded});
  final IconData icon;
  final String label;
  final String route;
  final bool selected;
  final bool expanded;
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Tooltip(
      message: label,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: selected ? theme.colorScheme.primary.withValues(alpha: 0.14) : Colors.transparent,
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => context.go(route),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: expanded ? 12 : 10, vertical: 11),
            child: Row(
              mainAxisAlignment: expanded ? MainAxisAlignment.start : MainAxisAlignment.center,
              children: [
                Icon(icon, color: selected ? theme.colorScheme.primary : null),
                if (expanded) ...[
                  const SizedBox(width: 12),
                  Expanded(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: selected ? FontWeight.w800 : FontWeight.w600))),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SidebarLogoutButton extends ConsumerWidget {
  const _SidebarLogoutButton({required this.expanded});
  final bool expanded;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final button = FilledButton.tonalIcon(
      style: FilledButton.styleFrom(
        foregroundColor: theme.colorScheme.error,
        backgroundColor: theme.colorScheme.errorContainer.withValues(alpha: 0.45),
        minimumSize: expanded ? const Size.fromHeight(46) : const Size(46, 46),
        padding: expanded ? null : EdgeInsets.zero,
      ),
      onPressed: () async {
        final shouldLogout = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Log out?'),
            content: const Text('You will return to the sign-in screen.'),
            actions: [
              TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Cancel')),
              FilledButton.icon(onPressed: () => Navigator.of(context).pop(true), icon: const Icon(Icons.logout_rounded), label: const Text('Log out')),
            ],
          ),
        );
        if (shouldLogout != true) return;
        _GlobalLoginAlertGateState.clearShownAlerts();
        ref.read(authNotifierProvider.notifier).clearUser();
        if (context.mounted) context.go('/login');
      },
      icon: const Icon(Icons.logout_rounded),
      label: expanded ? const Text('Log out') : const SizedBox.shrink(),
    );
    return Tooltip(message: 'Log out', child: expanded ? SizedBox(width: double.infinity, child: button) : button);
  }
}

class _GlobalLoginAlertGate extends ConsumerStatefulWidget {
  const _GlobalLoginAlertGate({required this.user, required this.child});

  final AppUser? user;
  final Widget child;

  @override
  ConsumerState<_GlobalLoginAlertGate> createState() => _GlobalLoginAlertGateState();
}

class _GlobalLoginAlertGateState extends ConsumerState<_GlobalLoginAlertGate> {
  static final Set<String> _shownAlertKeys = <String>{};
  String? _lastUserId;

  static void clearShownAlerts() {
    _shownAlertKeys.clear();
  }

  @override
  void initState() {
    super.initState();
    _lastUserId = widget.user?.id;
  }

  @override
  void didUpdateWidget(covariant _GlobalLoginAlertGate oldWidget) {
    super.didUpdateWidget(oldWidget);
    final currentUserId = widget.user?.id;
    if (currentUserId != _lastUserId) {
      _lastUserId = currentUserId;
      ref.invalidate(alertMessageProvider);
    }
  }

  void _maybeShowAlert(String? message) {
    final alert = message?.trim() ?? '';
    final user = widget.user;
    if (alert.isEmpty || user == null) return;

    final key = '${user.id}::$alert';
    if (_shownAlertKeys.contains(key)) return;
    _shownAlertKeys.add(key);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          title: const Text('Alert'),
          content: Text(alert),
          actions: [
            FilledButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final alertAsync = ref.watch(alertMessageProvider);
    _maybeShowAlert(alertAsync.valueOrNull);
    return widget.child;
  }
}
