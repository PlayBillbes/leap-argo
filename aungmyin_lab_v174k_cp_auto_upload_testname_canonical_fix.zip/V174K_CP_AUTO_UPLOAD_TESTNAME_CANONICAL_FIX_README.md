### v174k CP Auto upload testName canonical fix

This patch starts from the v174j current workspace.

Issue:
- When a lab tech uploaded a single CP Auto analyzer ZIP result from the dashboard, the saved CBCResults `testName` could become `CP Auto` because it used the selected sample test label.

Fix:
- Dashboard CP Auto/CBC analyzer uploads now always save CBCResults `testName` as `CBC / CP(Auto)`.
- This applies to analyzer ZIP/CSV result saving through the dashboard review popup.

Updated file:
- lib/views/dashboard_view.dart

Base version:
- v174j name, age, address row cards.
