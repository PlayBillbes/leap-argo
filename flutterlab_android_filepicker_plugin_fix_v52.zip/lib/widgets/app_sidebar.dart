import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../models/app_user.dart';
import '../providers/auth_notifier.dart';
import '../providers/alert_provider.dart';

class AppScaffold extends StatelessWidget {
  const AppScaffold({
    super.key,
    required this.title,
    required this.selectedRoute,
    required this.user,
    required this.body,
    this.actions = const [],
  });

  final String title;
  final String selectedRoute;
  final AppUser? user;
  final Widget body;
  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: Colors.transparent,
        actions: [
          ...actions,
          const SizedBox(width: 12),
        ],
      ),
      drawer: AppSidebarDrawer(user: user, selectedRoute: selectedRoute),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final showSidebar = constraints.maxWidth >= 980;
          return Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Theme.of(context).colorScheme.surface,
                  Theme.of(context).colorScheme.primaryContainer.withValues(
                    alpha: 0.20,
                  ),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Row(
              children: [
                if (showSidebar)
                  AppSidebar(user: user, selectedRoute: selectedRoute),
                Expanded(child: _GlobalLoginAlertGate(user: user, child: body)),
              ],
            ),
          );
        },
      ),
    );
  }
}


class _GlobalLoginAlertGate extends ConsumerStatefulWidget {
  const _GlobalLoginAlertGate({required this.user, required this.child});

  final AppUser? user;
  final Widget child;

  @override
  ConsumerState<_GlobalLoginAlertGate> createState() => _GlobalLoginAlertGateState();
}

class _GlobalLoginAlertGateState extends ConsumerState<_GlobalLoginAlertGate> {
  String? _shownKey;
  String? _lastUserId;

  @override
  void initState() {
    super.initState();
    _lastUserId = widget.user?.id;
  }

  @override
  void didUpdateWidget(covariant _GlobalLoginAlertGate oldWidget) {
    super.didUpdateWidget(oldWidget);
    final currentUserId = widget.user?.id;
    if (currentUserId != _lastUserId) {
      _lastUserId = currentUserId;
      _shownKey = null;
      ref.invalidate(alertMessageProvider);
    }
  }

  void _maybeShowAlert(String? message) {
    final alert = message?.trim() ?? '';
    if (alert.isEmpty || widget.user == null) return;
    final key = '${widget.user!.id}::$alert';
    if (_shownKey == key) return;
    _shownKey = key;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Alert'),
          content: Text(alert),
          actions: [
            FilledButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final alertAsync = ref.watch(alertMessageProvider);
    _maybeShowAlert(alertAsync.valueOrNull);
    return widget.child;
  }
}

class AppSidebar extends StatelessWidget {
  const AppSidebar({super.key, required this.user, required this.selectedRoute});

  final AppUser? user;
  final String selectedRoute;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: 270,
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        color: theme.colorScheme.surface.withValues(alpha: 0.88),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 30,
            offset: const Offset(0, 16),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: theme.colorScheme.primary,
                foregroundColor: theme.colorScheme.onPrimary,
                child: const Icon(Icons.local_hospital_rounded),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'LabOps',
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 22),
          AppSidebarItem(
            icon: Icons.dashboard_rounded,
            label: 'Dashboard',
            route: '/',
            selected: selectedRoute == '/',
          ),
          AppSidebarItem(
            icon: Icons.manage_search_rounded,
            label: 'Search',
            route: '/search',
            selected: selectedRoute == '/search',
          ),
          if (user?.role == AppUserRole.staff || user?.role == AppUserRole.admin || user?.role == AppUserRole.superadmin)
            AppSidebarItem(
              icon: Icons.addchart_rounded,
              label: 'Register Sample',
              route: '/register-sample',
              selected: selectedRoute == '/register-sample',
            ),
          AppSidebarItem(
            icon: Icons.account_circle_rounded,
            label: 'Profile',
            route: '/profile',
            selected: selectedRoute == '/profile',
          ),
          if (user?.role == AppUserRole.lab_tech || user?.role == AppUserRole.superadmin)
            AppSidebarItem(
              icon: Icons.fact_check_rounded,
              label: 'Test Requirements',
              route: '/test-requirements',
              selected: selectedRoute == '/test-requirements',
            ),
          if (user?.role == AppUserRole.lab_tech || user?.role == AppUserRole.superadmin)
            AppSidebarItem(
              icon: Icons.bloodtype_rounded,
              label: 'CBC / CP Result',
              route: '/cbc-cp-result',
              selected: selectedRoute == '/cbc-cp-result',
            ),
          if (user?.role == AppUserRole.superadmin)
            AppSidebarItem(
              icon: Icons.rule_rounded,
              label: 'CBC Ref. Ranges',
              route: '/cbc-reference-ranges',
              selected: selectedRoute == '/cbc-reference-ranges',
            ),
          if (user?.role == AppUserRole.superadmin || user?.role == AppUserRole.admin)
            AppSidebarItem(
              icon: Icons.group_rounded,
              label: user?.role == AppUserRole.admin ? 'Staff Accounts' : 'Users',
              route: '/users',
              selected: selectedRoute == '/users',
            ),
          if (user?.role == AppUserRole.superadmin)
            if (user?.role == AppUserRole.superadmin)
              AppSidebarItem(
                icon: Icons.price_change_rounded,
                label: 'Global Pricing',
                route: '/global-pricing',
                selected: selectedRoute == '/global-pricing',
              ),
          if (user?.role == AppUserRole.superadmin)
            AppSidebarItem(
              icon: Icons.analytics_rounded,
              label: 'Advanced Analytics',
              route: '/advanced-analytics',
              selected: selectedRoute == '/advanced-analytics',
            ),
          if (user?.role == AppUserRole.superadmin)
            AppSidebarItem(
              icon: Icons.campaign_rounded,
              label: 'Alerts',
              route: '/alerts',
              selected: selectedRoute == '/alerts',
            ),
          if (user?.role == AppUserRole.admin)
            if (user?.role == AppUserRole.admin)
              AppSidebarItem(
                icon: Icons.storefront_rounded,
                label: 'Sub-center Pricing',
                route: '/sub-center-pricing',
                selected: selectedRoute == '/sub-center-pricing',
              ),
          if (user?.role == AppUserRole.admin)
            AppSidebarItem(
              icon: Icons.query_stats_rounded,
              label: 'Admin Analytics',
              route: '/admin-analytics',
              selected: selectedRoute == '/admin-analytics',
            ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              color: theme.colorScheme.primaryContainer,
            ),
            child: Row(
              children: [
                CircleAvatar(child: Text((user?.name ?? 'U').characters.first)),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user?.name ?? 'User',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      Text(user?.role.name ?? 'guest'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          const _LogoutButton(expanded: true),
        ],
      ),
    );
  }
}

class AppSidebarDrawer extends StatelessWidget {
  const AppSidebarDrawer({
    super.key,
    required this.user,
    required this.selectedRoute,
  });

  final AppUser? user;
  final String selectedRoute;

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            ListTile(
              leading: const CircleAvatar(
                child: Icon(Icons.local_hospital_rounded),
              ),
              title: const Text(
                'LabOps',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
              subtitle: Text(user?.role.name ?? 'guest'),
            ),
            const SizedBox(height: 16),
            AppSidebarItem(
              icon: Icons.dashboard_rounded,
              label: 'Dashboard',
              route: '/',
              selected: selectedRoute == '/',
            ),
            AppSidebarItem(
              icon: Icons.manage_search_rounded,
              label: 'Search',
              route: '/search',
              selected: selectedRoute == '/search',
            ),
            if (user?.role == AppUserRole.staff || user?.role == AppUserRole.admin || user?.role == AppUserRole.superadmin)
              AppSidebarItem(
                icon: Icons.addchart_rounded,
                label: 'Register Sample',
                route: '/register-sample',
                selected: selectedRoute == '/register-sample',
              ),
            AppSidebarItem(
              icon: Icons.account_circle_rounded,
              label: 'Profile',
              route: '/profile',
              selected: selectedRoute == '/profile',
            ),
            if (user?.role == AppUserRole.lab_tech || user?.role == AppUserRole.superadmin)
              AppSidebarItem(
                icon: Icons.fact_check_rounded,
                label: 'Test Requirements',
                route: '/test-requirements',
                selected: selectedRoute == '/test-requirements',
              ),
            if (user?.role == AppUserRole.lab_tech || user?.role == AppUserRole.superadmin)
              AppSidebarItem(
                icon: Icons.bloodtype_rounded,
                label: 'CBC / CP Result',
                route: '/cbc-cp-result',
                selected: selectedRoute == '/cbc-cp-result',
              ),
            if (user?.role == AppUserRole.superadmin)
              AppSidebarItem(
                icon: Icons.rule_rounded,
                label: 'CBC Ref. Ranges',
                route: '/cbc-reference-ranges',
                selected: selectedRoute == '/cbc-reference-ranges',
              ),
            if (user?.role == AppUserRole.superadmin || user?.role == AppUserRole.admin)
              AppSidebarItem(
                icon: Icons.group_rounded,
                label: user?.role == AppUserRole.admin ? 'Staff Accounts' : 'Users',
                route: '/users',
                selected: selectedRoute == '/users',
              ),
            AppSidebarItem(
              icon: Icons.price_change_rounded,
              label: 'Global Pricing',
              route: '/global-pricing',
              selected: selectedRoute == '/global-pricing',
            ),
            if (user?.role == AppUserRole.superadmin)
              AppSidebarItem(
                icon: Icons.analytics_rounded,
                label: 'Advanced Analytics',
                route: '/advanced-analytics',
                selected: selectedRoute == '/advanced-analytics',
              ),
            if (user?.role == AppUserRole.superadmin)
              AppSidebarItem(
                icon: Icons.campaign_rounded,
                label: 'Alerts',
                route: '/alerts',
                selected: selectedRoute == '/alerts',
              ),
            AppSidebarItem(
              icon: Icons.storefront_rounded,
              label: 'Sub-center Pricing',
              route: '/sub-center-pricing',
              selected: selectedRoute == '/sub-center-pricing',
            ),
            if (user?.role == AppUserRole.admin)
              AppSidebarItem(
                icon: Icons.query_stats_rounded,
                label: 'Admin Analytics',
                route: '/admin-analytics',
                selected: selectedRoute == '/admin-analytics',
              ),
            const Divider(height: 28),
            const _LogoutButton(expanded: false),
          ],
        ),
      ),
    );
  }
}

class AppSidebarItem extends StatelessWidget {
  const AppSidebarItem({
    super.key,
    required this.icon,
    required this.label,
    required this.route,
    required this.selected,
  });

  final IconData icon;
  final String label;
  final String route;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => context.go(route),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            color: selected ? theme.colorScheme.primaryContainer : null,
          ),
          child: Row(
            children: [
              Icon(
                icon,
                color: selected
                    ? theme.colorScheme.primary
                    : theme.colorScheme.onSurfaceVariant,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class _LogoutButton extends ConsumerWidget {
  const _LogoutButton({required this.expanded});

  final bool expanded;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final button = FilledButton.tonalIcon(
      style: FilledButton.styleFrom(
        foregroundColor: theme.colorScheme.error,
        backgroundColor: theme.colorScheme.errorContainer.withValues(alpha: 0.45),
        minimumSize: expanded ? const Size.fromHeight(46) : null,
      ),
      onPressed: () async {
        final shouldLogout = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Log out?'),
            content: const Text('You will return to the sign-in screen.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('Cancel'),
              ),
              FilledButton.icon(
                onPressed: () => Navigator.of(context).pop(true),
                icon: const Icon(Icons.logout_rounded),
                label: const Text('Log out'),
              ),
            ],
          ),
        );

        if (shouldLogout != true) return;
        ref.read(authNotifierProvider.notifier).clearUser();
        if (context.mounted) {
          context.go('/login');
        }
      },
      icon: const Icon(Icons.logout_rounded),
      label: const Text('Logout'),
    );

    return expanded ? SizedBox(width: double.infinity, child: button) : button;
  }
}
