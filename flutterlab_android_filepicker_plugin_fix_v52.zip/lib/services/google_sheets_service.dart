import 'dart:convert';
import 'dart:io';

import 'package:googleapis/sheets/v4.dart' as sheets;
import 'package:googleapis_auth/auth_io.dart' as auth;

class GoogleSheetsService {
  GoogleSheetsService({
    required String serviceAccountJson,
    required this.applicationName,
    this.maxRetries = 3,
    this.initialDelayMs = 500,
  }) : _serviceAccountJson = serviceAccountJson;

  final String _serviceAccountJson;
  final String applicationName;
  final int maxRetries;
  final int initialDelayMs;

  auth.AuthClient? _client;
  sheets.SheetsApi? _sheetsApi;

  Future<sheets.SheetsApi> _getSheetsApi() async {
    if (_sheetsApi != null) {
      return _sheetsApi!;
    }

    final credentials = auth.ServiceAccountCredentials.fromJson(
      jsonDecode(_serviceAccountJson),
    );

    _client = await auth.clientViaServiceAccount(credentials, [
      sheets.SheetsApi.spreadsheetsScope,
    ]);

    _sheetsApi = sheets.SheetsApi(_client!);
    return _sheetsApi!;
  }

  Future<List<List<String>>> fetchRows({
    required String spreadsheetId,
    required String range,
  }) async {
    return _executeWithRetry(
      action: () async {
        final api = await _getSheetsApi();
        final response = await api.spreadsheets.values.get(
          spreadsheetId,
          range,
        );

        if (response.values == null || response.values!.isEmpty) {
          return <List<String>>[];
        }

        return response.values!
            .map((row) => row.map((cell) => cell?.toString() ?? '').toList())
            .toList();
      },
      spreadsheetId: spreadsheetId,
      range: range,
    );
  }

  Future<void> insertRow({
    required String spreadsheetId,
    required String range,
    required List<String> values,
    String valueInputOption = 'USER_ENTERED',
  }) async {
    await _executeWithRetry(
      action: () async {
        final api = await _getSheetsApi();
        final valueRange = sheets.ValueRange(values: [values]);
        await api.spreadsheets.values.append(
          valueRange,
          spreadsheetId,
          range,
          valueInputOption: valueInputOption,
        );
      },
      spreadsheetId: spreadsheetId,
      range: range,
    );
  }

  Future<void> updateRow({
    required String spreadsheetId,
    required String range,
    required List<String> values,
  }) async {
    await _executeWithRetry(
      action: () async {
        final api = await _getSheetsApi();
        final valueRange = sheets.ValueRange(values: [values]);
        await api.spreadsheets.values.update(
          valueRange,
          spreadsheetId,
          range,
          valueInputOption: 'USER_ENTERED',
        );
      },
      spreadsheetId: spreadsheetId,
      range: range,
    );
  }

  Future<void> ensureSheet({
    required String spreadsheetId,
    required String sheetName,
  }) async {
    await _executeWithRetry(
      action: () async {
        final api = await _getSheetsApi();
        final spreadsheet = await api.spreadsheets.get(spreadsheetId);
        final exists = spreadsheet.sheets?.any(
              (sheet) => sheet.properties?.title == sheetName,
            ) ??
            false;
        if (exists) return;

        final request = sheets.BatchUpdateSpreadsheetRequest(
          requests: [
            sheets.Request(
              addSheet: sheets.AddSheetRequest(
                properties: sheets.SheetProperties(title: sheetName),
              ),
            ),
          ],
        );
        await api.spreadsheets.batchUpdate(request, spreadsheetId);
      },
      spreadsheetId: spreadsheetId,
      range: '$sheetName!A:A',
    );
  }


  Future<void> deleteRow({
    required String spreadsheetId,
    required String sheetName,
    required int rowIndexOneBased,
  }) async {
    await _executeWithRetry(
      action: () async {
        final api = await _getSheetsApi();
        final spreadsheet = await api.spreadsheets.get(spreadsheetId);
        final sheet = spreadsheet.sheets?.firstWhere(
          (s) => s.properties?.title == sheetName,
          orElse: () => throw StateError('Sheet "$sheetName" was not found.'),
        );
        final sheetId = sheet?.properties?.sheetId;
        if (sheetId == null) {
          throw StateError('Sheet "$sheetName" has no sheetId.');
        }

        final request = sheets.BatchUpdateSpreadsheetRequest(
          requests: [
            sheets.Request(
              deleteDimension: sheets.DeleteDimensionRequest(
                range: sheets.DimensionRange(
                  sheetId: sheetId,
                  dimension: 'ROWS',
                  startIndex: rowIndexOneBased - 1,
                  endIndex: rowIndexOneBased,
                ),
              ),
            ),
          ],
        );

        await api.spreadsheets.batchUpdate(request, spreadsheetId);
      },
      spreadsheetId: spreadsheetId,
      range: '$sheetName!$rowIndexOneBased:$rowIndexOneBased',
    );
  }
  Future<T> _executeWithRetry<T>({
    required Future<T> Function() action,
    required String spreadsheetId,
    required String range,
  }) async {
    Object? lastError;

    for (var attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        return await action();
      } on sheets.DetailedApiRequestError catch (error) {
        lastError = error;
        final isRateLimit =
            error.status == 429 ||
            (error.message?.toLowerCase().contains('rate limit') ?? false);

        if (!isRateLimit || attempt == maxRetries) {
          throw GoogleSheetsException(
            message: 'Google Sheets request failed for $spreadsheetId:$range',
            cause: error,
          );
        }

        await Future.delayed(Duration(milliseconds: initialDelayMs * attempt));
      } on SocketException catch (error) {
        lastError = error;
        if (attempt == maxRetries) {
          throw GoogleSheetsException(
            message: 'Network error while accessing $spreadsheetId:$range',
            cause: error,
          );
        }

        await Future.delayed(Duration(milliseconds: initialDelayMs * attempt));
      } catch (error) {
        lastError = error;
        throw GoogleSheetsException(
          message: 'Unexpected Google Sheets error for $spreadsheetId:$range',
          cause: error,
        );
      }
    }

    throw GoogleSheetsException(
      message:
          'Google Sheets request exhausted retries for $spreadsheetId:$range',
      cause: lastError,
    );
  }

  Future<void> close() async {
    _client?.close();
    _client = null;
    _sheetsApi = null;
  }
}

class GoogleSheetsException implements Exception {
  GoogleSheetsException({required this.message, this.cause});

  final String message;
  final Object? cause;

  @override
  String toString() =>
      'GoogleSheetsException: $message${cause == null ? '' : ' ($cause)'}';
}
