import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../config/google_config.dart';
import '../models/app_user.dart';
import '../models/lab_test.dart';
import '../models/sub_center_pricing.dart';
import '../providers/auth_notifier.dart';
import '../providers/sample_dashboard_controller.dart';
import '../providers/tests_provider.dart';
import '../services/google_sheets_service.dart';
import '../widgets/app_sidebar.dart';

class RegisterSamplePage extends ConsumerStatefulWidget {
  const RegisterSamplePage({super.key});

  @override
  ConsumerState<RegisterSamplePage> createState() => _RegisterSamplePageState();
}

class _RegisterSamplePageState extends ConsumerState<RegisterSamplePage> {
  final _formKey = GlobalKey<FormState>();
  final _patientNameController = TextEditingController();
  final _patientAgeController = TextEditingController();
  final _patientAddressController = TextEditingController();
  final _testSearchController = TextEditingController();
  String? _selectedSex;
  final Set<String> _selectedTestKeys = <String>{};
  bool _saving = false;

  @override
  void dispose() {
    _patientNameController.dispose();
    _patientAgeController.dispose();
    _patientAddressController.dispose();
    _testSearchController.dispose();
    super.dispose();
  }

  String _testKey(LabTest test) => test.id.trim().isNotEmpty ? test.id.trim() : test.testName.trim();

  String _normalize(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  String _subCenterIdFor(AppUser user) {
    final raw = user.subCenterId?.trim() ?? '';
    return raw.isEmpty ? 'GLOBAL' : raw;
  }

  String _sampleIdPart(String value, {String fallback = 'X'}) {
    final cleaned = value.trim().toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
    return cleaned.isEmpty ? fallback : cleaned;
  }

  String _sampleIdFor({
    required LabTest test,
    required AppUser user,
    required DateTime createdAt,
    required int index,
  }) {
    final testPrefix = _sampleIdPart(
      test.testName.trim().isNotEmpty ? test.testName : test.id,
      fallback: 'TEST',
    );
    final centerPrefix = _sampleIdPart(_subCenterIdFor(user), fallback: 'CENTER');
    final numeric = ((createdAt.millisecondsSinceEpoch + index) % 10000)
        .toString()
        .padLeft(4, '0');
    return '$testPrefix-$centerPrefix-$numeric';
  }

  double _customerPriceFor(AppUser user, LabTest test, List<SubCenterPricing> pricings) {
    final normalizedCenter = _normalize(_subCenterIdFor(user));
    final normalizedTestId = _normalize(test.id);
    final normalizedTestName = _normalize(test.testName);

    for (final pricing in pricings) {
      if (_normalize(pricing.subCenterId) != normalizedCenter) continue;
      final pricingTest = _normalize(pricing.testId);
      if (pricingTest == normalizedTestId || pricingTest == normalizedTestName) {
        return pricing.customPrice > 0 ? pricing.customPrice : test.defaultPrice;
      }
    }
    return test.defaultPrice;
  }

  List<LabTest> _selectedTests(List<LabTest> tests) {
    return tests.where((test) => _selectedTestKeys.contains(_testKey(test))).toList();
  }

  double _selectedTotal(AppUser user, List<LabTest> tests, List<SubCenterPricing> pricings) {
    return _selectedTests(tests).fold<double>(0, (sum, test) => sum + _customerPriceFor(user, test, pricings));
  }

  Future<List<String>> _buildBloodSampleInsertRow(
    GoogleSheetsService service, {
    required String registrationId,
    required String sampleId,
    required String patientName,
    required String patientAge,
    required String patientSex,
    required String patientAddress,
    required String status,
    required String testId,
    required String testName,
    required String registeredByUserId,
    required String subCenterId,
    required String resultUrl,
    required String createdAt,
    required String updatedAt,
    required String testPrice,
    required String totalAmount,
  }) async {
    final desiredHeaders = <String>[
      'id',
      'registrationId',
      'patientName',
      'status',
      'testIds',
      'testId',
      'registeredByUserId',
      'subCenterId',
      'resultUrl',
      'createdAt',
      'updatedAt',
      'patientAge',
      'patientSex',
      'patientAddress',
      'testPrice',
      'totalAmount',
    ];

    final rows = await service.fetchRows(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'BloodSamples!A1:Z1',
    );

    var displayHeaders = rows.isEmpty || rows.first.isEmpty
        ? <String>[]
        : rows.first.map((header) => header.trim()).where((header) => header.isNotEmpty).toList();

    if (displayHeaders.isEmpty) {
      displayHeaders = List<String>.from(desiredHeaders);
    } else {
      final normalized = displayHeaders
          .map((header) => header.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
          .toSet();
      for (final header in desiredHeaders) {
        final key = header.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
        if (!normalized.contains(key)) {
          displayHeaders.add(header);
          normalized.add(key);
        }
      }
    }

    await service.updateRow(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'BloodSamples!A1:Z1',
      values: displayHeaders,
    );

    final headerMap = <String, String>{
      'id': sampleId,
      'sampleid': sampleId,
      'registrationid': registrationId,
      'patientname': patientName,
      'patient': patientName,
      'name': patientName,
      'patientage': patientAge,
      'age': patientAge,
      'patientsex': patientSex,
      'sex': patientSex,
      'gender': patientSex,
      'patientaddress': patientAddress,
      'address': patientAddress,
      'status': status,
      'testids': testName,
      'tests': testName,
      'testid': testId,
      'registeredbyuserid': registeredByUserId,
      'registeredby': registeredByUserId,
      'subcenterid': subCenterId,
      'center': subCenterId,
      'subcenter': subCenterId,
      'resulturl': resultUrl,
      'result': resultUrl,
      'createdat': createdAt,
      'created': createdAt,
      'updatedat': updatedAt,
      'updated': updatedAt,
      'testprice': testPrice,
      'price': testPrice,
      'totalamount': totalAmount,
      'amount': totalAmount,
    };

    final headers = displayHeaders
        .map((header) => header.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();

    return [for (final header in headers) headerMap[header] ?? ''];
  }

  Future<void> _registerSamples(AppUser user, List<LabTest> tests, List<SubCenterPricing> pricings) async {
    if (!_formKey.currentState!.validate()) return;
    final selectedTests = _selectedTests(tests);
    if (selectedTests.isEmpty) {
      _showToast('Please select at least one blood test.', isError: true);
      return;
    }

    setState(() => _saving = true);
    GoogleSheetsService? service;
    try {
      final now = DateTime.now();
      final timestamp = now.toUtc().toIso8601String();
      final registrationId = 'reg-${now.millisecondsSinceEpoch}';
      final totalAmount = _selectedTotal(user, tests, pricings).toStringAsFixed(0);
      final subCenterId = _subCenterIdFor(user);
      final serviceAccountJson = await rootBundle.loadString('assets/service-account.json');
      service = GoogleSheetsService(
        serviceAccountJson: serviceAccountJson,
        applicationName: 'flutterlab',
      );

      for (var i = 0; i < selectedTests.length; i++) {
        final test = selectedTests[i];
        final testPrice = _customerPriceFor(user, test, pricings).toStringAsFixed(0);
        final rowValues = await _buildBloodSampleInsertRow(
          service,
          registrationId: registrationId,
          sampleId: _sampleIdFor(test: test, user: user, createdAt: now, index: i),
          patientName: _patientNameController.text.trim(),
          patientAge: _patientAgeController.text.trim(),
          patientSex: _selectedSex ?? '',
          patientAddress: _patientAddressController.text.trim(),
          status: 'pending',
          testId: test.id.trim().isNotEmpty ? test.id.trim() : test.testName.trim(),
          testName: test.testName.trim(),
          registeredByUserId: user.id,
          subCenterId: subCenterId,
          resultUrl: '',
          createdAt: timestamp,
          updatedAt: timestamp,
          testPrice: testPrice,
          totalAmount: totalAmount,
        );

        await service.insertRow(
          spreadsheetId: GoogleConfig.spreadsheetId,
          range: 'BloodSamples!A:Z',
          values: rowValues,
          valueInputOption: 'RAW',
        );
      }

      _patientNameController.clear();
      _patientAgeController.clear();
      _patientAddressController.clear();
      _testSearchController.clear();
      _selectedSex = null;
      _selectedTestKeys.clear();
      ref.invalidate(sampleDashboardControllerProvider);
      _showToast('Registered ${selectedTests.length} row(s). Total amount: $totalAmount');
      if (mounted) setState(() {});
    } catch (error) {
      _showToast('Register failed: $error', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  void _showToast(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    final testsAsync = ref.watch(testsProvider);
    final pricingsAsync = ref.watch(pricingsProvider);
    final theme = Theme.of(context);

    return AppScaffold(
      title: 'Register Sample',
      selectedRoute: '/register-sample',
      user: user,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Refresh tests',
          onPressed: _saving
              ? null
              : () {
                  ref.invalidate(testsProvider);
                  ref.invalidate(pricingsProvider);
                },
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        child: user == null
            ? const Center(child: Text('Please sign in.'))
            : testsAsync.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (error, _) => Center(child: Text('Tests load failed: $error')),
                data: (tests) {
                  final pricings = pricingsAsync.maybeWhen(
                    data: (value) => value,
                    orElse: () => const <SubCenterPricing>[],
                  );
                  return _buildContent(context, user, tests, pricings, theme);
                },
              ),
      ),
    );
  }

  Widget _buildContent(BuildContext context, AppUser user, List<LabTest> tests, List<SubCenterPricing> pricings, ThemeData theme) {
    final query = _normalize(_testSearchController.text);
    final filteredTests = query.isEmpty
        ? tests
        : tests.where((test) {
            return _normalize(test.testName).contains(query) || _normalize(test.id).contains(query);
          }).toList();
    final selectedTests = _selectedTests(tests);
    final total = _selectedTotal(user, tests, pricings);
    final subCenterId = _subCenterIdFor(user);

    return SingleChildScrollView(
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                gradient: const LinearGradient(colors: [Color(0xFF0F766E), Color(0xFF2563EB), Color(0xFF7C3AED)]),
                boxShadow: [
                  BoxShadow(color: theme.colorScheme.primary.withValues(alpha: 0.22), blurRadius: 26, offset: const Offset(0, 15)),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(24)),
                    child: const Icon(Icons.addchart_rounded, color: Colors.white, size: 36),
                  ),
                  const SizedBox(width: 18),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Register Blood Sample', style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 6),
                        Text('Sub-center: $subCenterId. Select one or more tests. Each selected test creates its own row in BloodSamples.', style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white.withValues(alpha: 0.88))),
                      ],
                    ),
                  ),
                  Chip(
                    avatar: const Icon(Icons.payments_rounded, size: 18),
                    label: Text('Total: ${total.toStringAsFixed(0)}'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            Card(
              elevation: 0,
              color: theme.colorScheme.surface.withValues(alpha: 0.94),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Patient Information', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 16),
                    LayoutBuilder(builder: (context, constraints) {
                      final compact = constraints.maxWidth < 760;
                      final nameField = TextFormField(
                        controller: _patientNameController,
                        decoration: const InputDecoration(labelText: 'Patient name', prefixIcon: Icon(Icons.person_rounded), border: OutlineInputBorder()),
                        validator: (value) => value == null || value.trim().isEmpty ? 'Enter patient name' : null,
                      );
                      final ageField = TextFormField(
                        controller: _patientAgeController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Age', prefixIcon: Icon(Icons.cake_rounded), border: OutlineInputBorder()),
                        validator: (value) => value == null || value.trim().isEmpty ? 'Enter age' : null,
                      );
                      final sexField = DropdownButtonFormField<String>(
                        value: _selectedSex,
                        decoration: const InputDecoration(labelText: 'Sex', prefixIcon: Icon(Icons.wc_rounded), border: OutlineInputBorder()),
                        items: const [
                          DropdownMenuItem(value: 'Male', child: Text('Male')),
                          DropdownMenuItem(value: 'Female', child: Text('Female')),
                          DropdownMenuItem(value: 'Other', child: Text('Other')),
                        ],
                        validator: (value) => value == null || value.trim().isEmpty ? 'Select sex' : null,
                        onChanged: _saving ? null : (value) => setState(() => _selectedSex = value),
                      );
                      if (compact) {
                        return Column(
                          children: [
                            nameField,
                            const SizedBox(height: 12),
                            Row(children: [Expanded(child: ageField), const SizedBox(width: 12), Expanded(child: sexField)]),
                          ],
                        );
                      }
                      return Row(
                        children: [
                          Expanded(flex: 3, child: nameField),
                          const SizedBox(width: 12),
                          Expanded(child: ageField),
                          const SizedBox(width: 12),
                          Expanded(child: sexField),
                        ],
                      );
                    }),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _patientAddressController,
                      minLines: 2,
                      maxLines: 3,
                      decoration: const InputDecoration(labelText: 'Address', prefixIcon: Icon(Icons.home_rounded), border: OutlineInputBorder()),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            Card(
              elevation: 0,
              color: theme.colorScheme.surface.withValues(alpha: 0.94),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(child: Text('Searchable Blood Tests', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900))),
                        Chip(label: Text('${selectedTests.length} selected')),
                        const SizedBox(width: 8),
                        Chip(label: Text('Total ${total.toStringAsFixed(0)}')),
                      ],
                    ),
                    const SizedBox(height: 14),
                    TextField(
                      controller: _testSearchController,
                      onChanged: (_) => setState(() {}),
                      decoration: InputDecoration(
                        hintText: 'Search blood test, e.g. CBC, ESR...',
                        prefixIcon: const Icon(Icons.search_rounded),
                        suffixIcon: _testSearchController.text.isEmpty
                            ? null
                            : IconButton(
                                onPressed: () {
                                  _testSearchController.clear();
                                  setState(() {});
                                },
                                icon: const Icon(Icons.clear_rounded),
                              ),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                      ),
                    ),
                    const SizedBox(height: 14),
                    if (tests.isEmpty)
                      const Text('No tests found. Please add tests first.')
                    else if (filteredTests.isEmpty)
                      const Text('No tests match the search.')
                    else
                      Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        children: [
                          for (final test in filteredTests)
                            FilterChip(
                              selected: _selectedTestKeys.contains(_testKey(test)),
                              label: Text('${test.testName} (${_customerPriceFor(user, test, pricings).toStringAsFixed(0)})'),
                              onSelected: _saving
                                  ? null
                                  : (selected) {
                                      setState(() {
                                        final key = _testKey(test);
                                        if (selected) {
                                          _selectedTestKeys.add(key);
                                        } else {
                                          _selectedTestKeys.remove(key);
                                        }
                                      });
                                    },
                            ),
                        ],
                      ),
                    if (selectedTests.isNotEmpty) ...[
                      const SizedBox(height: 18),
                      Text('Selected tests will be saved as separate BloodSamples rows:', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          for (final test in selectedTests)
                            Chip(
                              avatar: const Icon(Icons.biotech_rounded, size: 18),
                              label: Text('${test.testName}: ${_customerPriceFor(user, test, pricings).toStringAsFixed(0)}'),
                              onDeleted: _saving ? null : () => setState(() => _selectedTestKeys.remove(_testKey(test))),
                            ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            Align(
              alignment: Alignment.centerRight,
              child: FilledButton.icon(
                onPressed: _saving || tests.isEmpty ? null : () => _registerSamples(user, tests, pricings),
                icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_rounded),
                label: Text(_saving ? 'Registering...' : 'Register ${selectedTests.length} Sample Row(s)'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
