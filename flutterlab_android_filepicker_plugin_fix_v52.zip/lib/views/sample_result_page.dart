import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config/google_config.dart';
import '../providers/auth_notifier.dart';
import '../services/google_sheets_service.dart';
import '../widgets/app_sidebar.dart';

class SampleResultPage extends ConsumerStatefulWidget {
  const SampleResultPage({super.key, required this.sampleId});

  final String sampleId;

  @override
  ConsumerState<SampleResultPage> createState() => _SampleResultPageState();
}

class _SampleResultPageState extends ConsumerState<SampleResultPage> {
  late Future<_SampleResultBundle> _future;

  @override
  void initState() {
    super.initState();
    _future = _loadResults();
  }

  Future<_SampleResultBundle> _loadResults() async {
    final serviceAccountJson = await rootBundle.loadString('assets/service-account.json');
    final service = GoogleSheetsService(
      serviceAccountJson: serviceAccountJson,
      applicationName: 'flutterlab',
    );
    try {
      final sampleInfo = await _fetchBloodSampleInfo(service);
      final referenceRanges = await _fetchCbcReferenceRanges(service);
      final manual = await _fetchRowsBySampleId(
        service: service,
        range: 'TestResults!A:Z',
      );
      final cbc = await _fetchRowsBySampleId(
        service: service,
        range: 'CBCResults!A:BB',
      );
      final ageGroup = _ageGroupFor(sampleInfo['patientAge'] ?? '');
      return _SampleResultBundle(
        sampleInfo: sampleInfo,
        ageGroup: ageGroup,
        referenceRanges: referenceRanges,
        manualResults: manual,
        cbcResults: cbc,
      );
    } finally {
      await service.close();
    }
  }

  Future<Map<String, String>> _fetchBloodSampleInfo(GoogleSheetsService service) async {
    final rows = await service.fetchRows(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'BloodSamples!A:Z',
    );
    if (rows.length < 2) return const <String, String>{};

    final normalizedHeaders = rows.first
        .map((header) => header.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();

    int indexOfAny(List<String> keys) {
      for (final key in keys) {
        final index = normalizedHeaders.indexOf(key);
        if (index >= 0) return index;
      }
      return -1;
    }

    final idIndex = indexOfAny(['id', 'sampleid']);
    if (idIndex < 0) return const <String, String>{};
    final targetId = widget.sampleId.trim().toLowerCase();

    for (final row in rows.skip(1)) {
      final rowId = idIndex < row.length ? row[idIndex].trim().toLowerCase() : '';
      if (rowId != targetId) continue;

      String valueOf(List<String> keys) {
        final index = indexOfAny(keys);
        return index >= 0 && index < row.length ? row[index].trim() : '';
      }

      return <String, String>{
        'sampleId': widget.sampleId,
        'patientName': valueOf(['patientname', 'patient', 'name']),
        'patientAge': valueOf(['patientage', 'age']),
        'patientSex': valueOf(['patientsex', 'sex', 'gender']),
        'patientAddress': valueOf(['patientaddress', 'address']),
        'createdAt': valueOf(['createdat', 'created']),
        'updatedAt': valueOf(['updatedat', 'updated']),
      };
    }
    return const <String, String>{};
  }

  String _ageGroupFor(String rawAge) {
    final normalized = rawAge.trim().toLowerCase();
    final numberMatch = RegExp(r'(\d+(?:\.\d+)?)').firstMatch(normalized);
    final value = double.tryParse(numberMatch?.group(1) ?? '');
    if (value == null) return 'adult';
    final isDayValue = normalized.contains('day') || normalized.endsWith('d');
    final isMonthValue = normalized.contains('month') || normalized.endsWith('m');
    final isYearValue = normalized.contains('year') || normalized.endsWith('y');
    if (isDayValue && value < 28) return 'neonate';
    if (isMonthValue) return 'child';
    if (isYearValue) return value < 18 ? 'child' : 'adult';
    return value < 18 ? 'child' : 'adult';
  }

  Future<Map<String, Map<String, _CbcReferenceRange>>> _fetchCbcReferenceRanges(
    GoogleSheetsService service,
  ) async {
    final rows = await service.fetchRows(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'CbcReferenceRanges!A:D',
    );
    if (rows.length < 2) return const <String, Map<String, _CbcReferenceRange>>{};
    final headers = rows.first
        .map((header) => header.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();
    final ageIndex = headers.indexOf('agegroup');
    final parameterIndex = headers.indexOf('parameter');
    final refIndex = headers.indexOf('refrange');
    final unitIndex = headers.indexOf('unit');
    if (ageIndex < 0 || parameterIndex < 0 || refIndex < 0) {
      return const <String, Map<String, _CbcReferenceRange>>{};
    }

    final result = <String, Map<String, _CbcReferenceRange>>{};
    for (final row in rows.skip(1)) {
      final ageGroup = ageIndex < row.length ? row[ageIndex].trim().toLowerCase() : '';
      final parameter = parameterIndex < row.length ? row[parameterIndex].trim() : '';
      final refRange = refIndex < row.length ? row[refIndex].trim() : '';
      final unit = unitIndex >= 0 && unitIndex < row.length ? row[unitIndex].trim() : '';
      if (ageGroup.isEmpty || parameter.isEmpty) continue;
      result.putIfAbsent(ageGroup, () => <String, _CbcReferenceRange>{});
      result[ageGroup]![parameter] = _CbcReferenceRange(refRange: refRange, unit: unit);
    }
    return result;
  }

  Future<List<Map<String, String>>> _fetchRowsBySampleId({
    required GoogleSheetsService service,
    required String range,
  }) async {
    final rows = await service.fetchRows(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: range,
    );
    if (rows.length < 2) return const <Map<String, String>>[];

    final headers = rows.first
        .map((header) => header.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();
    final sampleIdIndex = headers.indexOf('sampleid');
    if (sampleIdIndex < 0) return const <Map<String, String>>[];

    final displayHeaders = rows.first.map((header) => header.trim()).toList();
    final normalizedTarget = widget.sampleId.trim().toLowerCase();
    final matches = <Map<String, String>>[];
    for (final row in rows.skip(1)) {
      final sampleId = sampleIdIndex < row.length ? row[sampleIdIndex].trim().toLowerCase() : '';
      if (sampleId != normalizedTarget) continue;
      final map = <String, String>{};
      for (var i = 0; i < displayHeaders.length; i++) {
        final key = displayHeaders[i].isEmpty ? 'column$i' : displayHeaders[i];
        map[key] = i < row.length ? row[i].trim() : '';
      }
      matches.add(map);
    }
    return matches;
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.tryParse(url.trim());
    if (uri == null) return;
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    final theme = Theme.of(context);
    return AppScaffold(
      title: 'Sample Result',
      selectedRoute: '/',
      user: user,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Refresh result',
          onPressed: () => setState(() => _future = _loadResults()),
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        child: FutureBuilder<_SampleResultBundle>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return Center(child: Text('Result load failed: ${snapshot.error}'));
            }
            final bundle = snapshot.data ?? const _SampleResultBundle();
            final hasResults = bundle.manualResults.isNotEmpty || bundle.cbcResults.isNotEmpty;
            return SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      gradient: LinearGradient(colors: [theme.colorScheme.primary, theme.colorScheme.tertiary]),
                      boxShadow: [
                        BoxShadow(color: theme.colorScheme.primary.withValues(alpha: 0.22), blurRadius: 26, offset: const Offset(0, 15)),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(24)),
                          child: const Icon(Icons.assignment_turned_in_rounded, color: Colors.white, size: 36),
                        ),
                        const SizedBox(width: 18),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Generated Result', style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w900)),
                              const SizedBox(height: 6),
                              Text('Sample ID: ${widget.sampleId}', style: theme.textTheme.bodyLarge?.copyWith(color: Colors.white.withValues(alpha: 0.9))),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  if (!hasResults)
                    Card(
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                      child: const Padding(
                        padding: EdgeInsets.all(24),
                        child: Text('No generated result was found for this completed sample.'),
                      ),
                    ),
                  if (bundle.manualResults.isNotEmpty)
                    _ResultSection(
                      title: 'Manual Test Result',
                      rows: bundle.manualResults,
                      sampleInfo: bundle.sampleInfo,
                      ageGroup: bundle.ageGroup,
                      referenceRanges: bundle.referenceRanges,
                      onOpenUrl: _openUrl,
                    ),
                  if (bundle.cbcResults.isNotEmpty)
                    _ResultSection(
                      title: 'CBC / CP(Auto) Result',
                      rows: bundle.cbcResults,
                      sampleInfo: bundle.sampleInfo,
                      ageGroup: bundle.ageGroup,
                      referenceRanges: bundle.referenceRanges,
                      onOpenUrl: _openUrl,
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _SampleResultBundle {
  const _SampleResultBundle({
    this.sampleInfo = const {},
    this.ageGroup = 'adult',
    this.referenceRanges = const {},
    this.manualResults = const [],
    this.cbcResults = const [],
  });

  final Map<String, String> sampleInfo;
  final String ageGroup;
  final Map<String, Map<String, _CbcReferenceRange>> referenceRanges;
  final List<Map<String, String>> manualResults;
  final List<Map<String, String>> cbcResults;
}

class _ResultSection extends StatelessWidget {
  const _ResultSection({
    required this.title,
    required this.rows,
    required this.sampleInfo,
    required this.ageGroup,
    required this.referenceRanges,
    required this.onOpenUrl,
  });

  final String title;
  final List<Map<String, String>> rows;
  final Map<String, String> sampleInfo;
  final String ageGroup;
  final Map<String, Map<String, _CbcReferenceRange>> referenceRanges;
  final ValueChanged<String> onOpenUrl;

  bool _looksLikeUrl(String value) {
    final lower = value.trim().toLowerCase();
    return lower.startsWith('http://') || lower.startsWith('https://');
  }

  @override
  Widget build(BuildContext context) {
    if (title.toLowerCase().contains('cbc')) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (var index = 0; index < rows.length; index++) ...[
            if (index > 0) const SizedBox(height: 18),
            _CbcReportCard(row: rows[index], sampleInfo: sampleInfo, ageGroup: ageGroup, referenceRanges: referenceRanges, onOpenUrl: onOpenUrl),
          ],
        ],
      );
    }

    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.94),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 14),
            for (var rowIndex = 0; rowIndex < rows.length; rowIndex++) ...[
              if (rowIndex > 0) const Divider(height: 28),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: rows[rowIndex].entries.where((entry) => entry.value.trim().isNotEmpty).map((entry) {
                  final value = entry.value.trim();
                  if (_looksLikeUrl(value)) {
                    return ActionChip(
                      avatar: const Icon(Icons.open_in_new_rounded, size: 18),
                      label: Text(entry.key),
                      onPressed: () => onOpenUrl(value),
                    );
                  }
                  return Chip(label: Text('${entry.key}: $value'));
                }).toList(),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _CbcReportCard extends StatelessWidget {
  const _CbcReportCard({
    required this.row,
    required this.sampleInfo,
    required this.ageGroup,
    required this.referenceRanges,
    required this.onOpenUrl,
  });

  final Map<String, String> row;
  final Map<String, String> sampleInfo;
  final String ageGroup;
  final Map<String, Map<String, _CbcReferenceRange>> referenceRanges;
  final ValueChanged<String> onOpenUrl;

  String _value(String key) => row[key]?.trim() ?? '';
  String _sampleValue(String key) => sampleInfo[key]?.trim() ?? '';

  String _nameValue() {
    final fromSample = _sampleValue('patientName');
    if (fromSample.isNotEmpty) return fromSample;
    final first = _value('firstName');
    final last = _value('lastName');
    return [first, last].where((part) => part.isNotEmpty).join(' ');
  }

  String _ageValue() => _sampleValue('patientAge').isNotEmpty ? _sampleValue('patientAge') : _value('age');
  String _sexValue() => _sampleValue('patientSex').isNotEmpty ? _sampleValue('patientSex') : _value('gender');

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final parameters = _cbcParameterRows(row, referenceRanges[ageGroup] ?? const <String, _CbcReferenceRange>{});
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.96),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(child: _ReportInfoBlock(title: 'Name', value: _nameValue().isEmpty ? '-' : _nameValue())),
                Expanded(child: _ReportInfoBlock(title: 'Age', value: _ageValue().isEmpty ? '-' : _ageValue())),
                Expanded(child: _ReportInfoBlock(title: 'Sample ID', value: _value('sampleId'))),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(child: _ReportInfoBlock(title: 'Gender', value: _sexValue().isEmpty ? '-' : _sexValue())),
                Expanded(child: _ReportInfoBlock(title: 'Refer Dr.', value: '-')),
                Expanded(child: _ReportInfoBlock(title: 'Run Time', value: _value('runTime').isEmpty ? _value('createdAt') : _value('runTime'))),
              ],
            ),
            const SizedBox(height: 8),
            _ReportInfoBlock(title: 'Reference Group', value: ageGroup.toUpperCase()),
            const Divider(height: 26),
            LayoutBuilder(
              builder: (context, constraints) {
                final compact = constraints.maxWidth < 900;
                final table = _CbcParameterTable(rows: parameters);
                final charts = _CbcChartLinks(row: row, onOpenUrl: onOpenUrl);
                if (compact) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [table, const SizedBox(height: 16), charts],
                  );
                }
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(flex: 3, child: table),
                    const SizedBox(width: 18),
                    Expanded(child: charts),
                  ],
                );
              },
            ),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(child: _MessageBox(title: 'WBC Message', value: _value('WBCFlag'))),
                const SizedBox(width: 8),
                Expanded(child: _MessageBox(title: 'RBC Message', value: _value('RBCFlag'))),
                const SizedBox(width: 8),
                Expanded(child: _MessageBox(title: 'PLT Message', value: _value('PLTFlag'))),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ReportInfoBlock extends StatelessWidget {
  const _ReportInfoBlock({required this.title, required this.value});
  final String title;
  final String value;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 12, bottom: 4),
      child: RichText(
        text: TextSpan(
          style: DefaultTextStyle.of(context).style,
          children: [
            TextSpan(text: '$title: ', style: const TextStyle(fontWeight: FontWeight.w800)),
            TextSpan(text: value.isEmpty ? '-' : value),
          ],
        ),
      ),
    );
  }
}

class _CbcParameterTable extends StatelessWidget {
  const _CbcParameterTable({required this.rows});
  final List<_CbcParameterDisplayRow> rows;
  @override
  Widget build(BuildContext context) {
    return DataTable(
      headingRowHeight: 34,
      dataRowMinHeight: 30,
      dataRowMaxHeight: 36,
      columnSpacing: 18,
      columns: const [
        DataColumn(label: Text('Parameter')),
        DataColumn(label: Text('Result')),
        DataColumn(label: Text('Ref. Range')),
        DataColumn(label: Text('Unit')),
      ],
      rows: [
        for (final item in rows)
          DataRow(cells: [
            DataCell(Text(item.parameter, style: const TextStyle(fontWeight: FontWeight.w700))),
            DataCell(Text(item.result.isEmpty ? '-' : item.result)),
            DataCell(Text(item.referenceRange)),
            DataCell(Text(item.unit)),
          ]),
      ],
    );
  }
}

class _CbcChartLinks extends StatelessWidget {
  const _CbcChartLinks({required this.row, required this.onOpenUrl});
  final Map<String, String> row;
  final ValueChanged<String> onOpenUrl;
  String _value(String key) => row[key]?.trim() ?? '';
  @override
  Widget build(BuildContext context) {
    final diff = _value('diffHsmsImageUrl');
    final plt = _value('pltImageUrl');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _ChartLinkBox(title: 'DIFF Scattergram', url: diff, onOpenUrl: onOpenUrl),
        const SizedBox(height: 12),
        _ChartLinkBox(title: 'PLT Histogram', url: plt, onOpenUrl: onOpenUrl),
      ],
    );
  }
}

class _ChartLinkBox extends StatelessWidget {
  const _ChartLinkBox({required this.title, required this.url, required this.onOpenUrl});
  final String title;
  final String url;
  final ValueChanged<String> onOpenUrl;
  @override
  Widget build(BuildContext context) {
    final hasUrl = url.trim().isNotEmpty;
    return Container(
      height: 120,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          const Spacer(),
          Align(
            alignment: Alignment.centerRight,
            child: FilledButton.tonalIcon(
              onPressed: hasUrl ? () => onOpenUrl(url) : null,
              icon: const Icon(Icons.open_in_new_rounded),
              label: Text(hasUrl ? 'Open image' : 'No image'),
            ),
          ),
        ],
      ),
    );
  }
}

class _MessageBox extends StatelessWidget {
  const _MessageBox({required this.title, required this.value});
  final String title;
  final String value;
  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 92),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900))),
          const Divider(),
          Text(value.trim().isEmpty ? '-' : value.trim()),
        ],
      ),
    );
  }
}

class _CbcReferenceRange {
  const _CbcReferenceRange({required this.refRange, required this.unit});

  final String refRange;
  final String unit;
}

class _CbcParameterRow {
  const _CbcParameterRow(this.parameter, this.key, this.referenceRange, this.unit);
  final String parameter;
  final String key;
  final String referenceRange;
  final String unit;
}

class _CbcParameterDisplayRow {
  const _CbcParameterDisplayRow({required this.parameter, required this.result, required this.referenceRange, required this.unit});
  final String parameter;
  final String result;
  final String referenceRange;
  final String unit;
}

List<_CbcParameterDisplayRow> _cbcParameterRows(Map<String, String> row, Map<String, _CbcReferenceRange> configuredRanges) {
  String value(String key) => row[key]?.trim() ?? '';
  const defs = [
    _CbcParameterRow('WBC', 'WBC', '3.50-9.50', '10^3/uL'),
    _CbcParameterRow('Neu%', 'NeuPercent', '40.0-75.0', '%'),
    _CbcParameterRow('Lym%', 'LymPercent', '20.0-50.0', '%'),
    _CbcParameterRow('Mon%', 'MonPercent', '3.0-10.0', '%'),
    _CbcParameterRow('Eos%', 'EosPercent', '0.4-8.0', '%'),
    _CbcParameterRow('Bas%', 'BasPercent', '0.0-1.0', '%'),
    _CbcParameterRow('Neu#', 'NeuCount', '1.80-6.30', '10^3/uL'),
    _CbcParameterRow('Lym#', 'LymCount', '1.10-3.20', '10^3/uL'),
    _CbcParameterRow('Mon#', 'MonCount', '0.10-0.60', '10^3/uL'),
    _CbcParameterRow('Eos#', 'EosCount', '0.02-0.52', '10^3/uL'),
    _CbcParameterRow('Bas#', 'BasCount', '0.00-0.06', '10^3/uL'),
    _CbcParameterRow('ALY#', 'ALYCount', '0.00-0.20', '10^3/uL'),
    _CbcParameterRow('ALY%', 'ALYPercent', '0.0-2.0', '%'),
    _CbcParameterRow('LIC#', 'LICCount', '0.00-0.20', '10^3/uL'),
    _CbcParameterRow('LIC%', 'LICPercent', '0.0-2.5', '%'),
    _CbcParameterRow('NRBC#', 'NRBCCount', '0.000-9999.999', '10^9/L'),
    _CbcParameterRow('NRBC%', 'NRBCPercent', '0.00-9999.99', '%'),
    _CbcParameterRow('RBC', 'RBC', '3.80-5.80', '10^6/uL'),
    _CbcParameterRow('HGB', 'HGB', '11.5-17.5', 'g/dL'),
    _CbcParameterRow('HCT', 'HCT', '35.0-50.0', '%'),
    _CbcParameterRow('MCV', 'MCV', '82.0-100.0', 'fL'),
    _CbcParameterRow('MCH', 'MCH', '27.0-34.0', 'pg'),
    _CbcParameterRow('MCHC', 'MCHC', '31.6-35.4', 'g/dL'),
    _CbcParameterRow('RDW-CV', 'RDWCV', '11.0-16.0', '%'),
    _CbcParameterRow('RDW-SD', 'RDWSD', '35.0-56.0', 'fL'),
    _CbcParameterRow('PLT', 'PLT', '125-350', '10^3/uL'),
    _CbcParameterRow('MPV', 'MPV', '6.5-12.0', 'fL'),
    _CbcParameterRow('PDW', 'PDW', '9.0-17.0', 'fL'),
    _CbcParameterRow('PCT', 'PCT', '0.108-0.282', '%'),
    _CbcParameterRow('P-LCR', 'PLCR', '11.0-45.0', '%'),
    _CbcParameterRow('P-LCC', 'PLCC', '30-90', '10^9/L'),
  ];
  return [
    for (final def in defs)
      _CbcParameterDisplayRow(
        parameter: def.parameter,
        result: value(def.key),
        referenceRange: configuredRanges[def.parameter]?.refRange.trim().isNotEmpty == true
            ? configuredRanges[def.parameter]!.refRange
            : def.referenceRange,
        unit: configuredRanges[def.parameter]?.unit.trim().isNotEmpty == true
            ? configuredRanges[def.parameter]!.unit
            : def.unit,
      ),
  ];
}
