import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../config/google_config.dart';
import '../models/app_user.dart';
import '../models/lab_test.dart';
import '../providers/auth_notifier.dart';
import '../providers/tests_provider.dart';
import '../services/google_sheets_service.dart';
import '../widgets/app_sidebar.dart';

class GlobalPricingPage extends ConsumerStatefulWidget {
  const GlobalPricingPage({super.key});

  @override
  ConsumerState<GlobalPricingPage> createState() => _GlobalPricingPageState();
}

class _GlobalPricingPageState extends ConsumerState<GlobalPricingPage> {
  static const _sheetName = 'Tests';
  static const _testsRange = 'Tests!A:C';

  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _priceController = TextEditingController();
  final _searchController = TextEditingController();

  bool _saving = false;
  String? _editingId;

  bool get _isEditing => _editingId != null;

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<GoogleSheetsService> _newSheetsService() async {
    final serviceAccountJson = await rootBundle.loadString(
      'assets/service-account.json',
    );
    return GoogleSheetsService(
      serviceAccountJson: serviceAccountJson,
      applicationName: 'flutterlab',
    );
  }

  Future<int> _findSheetRowByTestId(
    GoogleSheetsService service,
    String testId,
  ) async {
    final rows = await service.fetchRows(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: _testsRange,
    );

    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      if (row.isNotEmpty && row.first == testId) {
        return i + 1; // Google Sheets rows are 1-based. Header row is row 1.
      }
    }

    throw StateError('Test row was not found. Please refresh and try again.');
  }

  Future<void> _saveTest() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _saving = true);

    GoogleSheetsService? service;
    try {
      service = await _newSheetsService();
      final name = _nameController.text.trim();
      final price = double.tryParse(_priceController.text.trim()) ?? 0.0;

      if (_isEditing) {
        final rowNumber = await _findSheetRowByTestId(service, _editingId!);
        await service.updateRow(
          spreadsheetId: GoogleConfig.spreadsheetId,
          range: 'Tests!A$rowNumber:C$rowNumber',
          values: [_editingId!, name, price.toStringAsFixed(2)],
        );
        _showSnackBar('Test updated successfully');
      } else {
        final id = DateTime.now().millisecondsSinceEpoch.toString();
        await service.insertRow(
          spreadsheetId: GoogleConfig.spreadsheetId,
          range: _testsRange,
          values: [id, name, price.toStringAsFixed(2)],
        );
        _showSnackBar('Test added successfully');
      }

      _clearForm();
      ref.invalidate(testsProvider);
    } catch (e) {
      _showSnackBar('Save failed: $e', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _deleteTest(LabTest test) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete test?'),
        content: Text(
          'This will remove "${test.testName}" from the global pricing list.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
              foregroundColor: Theme.of(context).colorScheme.onError,
            ),
            onPressed: () => Navigator.of(context).pop(true),
            icon: const Icon(Icons.delete_outline_rounded),
            label: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    setState(() => _saving = true);

    GoogleSheetsService? service;
    try {
      service = await _newSheetsService();
      final rowNumber = await _findSheetRowByTestId(service, test.id);
      await service.deleteRow(
        spreadsheetId: GoogleConfig.spreadsheetId,
        sheetName: _sheetName,
        rowIndexOneBased: rowNumber,
      );

      if (_editingId == test.id) _clearForm();
      ref.invalidate(testsProvider);
      _showSnackBar('Test deleted successfully');
    } catch (e) {
      _showSnackBar('Delete failed: $e', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  void _startEdit(LabTest test) {
    setState(() {
      _editingId = test.id;
      _nameController.text = test.testName;
      _priceController.text = test.defaultPrice.toStringAsFixed(2);
    });
  }

  void _clearForm() {
    setState(() {
      _editingId = null;
      _nameController.clear();
      _priceController.clear();
    });
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final testsAsync = ref.watch(testsProvider);
    final user = ref.watch(authNotifierProvider);

    return AppScaffold(
      title: 'Global Pricing',
      selectedRoute: '/global-pricing',
      user: user,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Refresh tests',
          onPressed: _saving ? null : () => ref.invalidate(testsProvider),
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHero(context),
            const SizedBox(height: 18),
            Expanded(
              child: testsAsync.when(
                data: (tests) => _buildPricingContent(context, tests),
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (error, stack) => _buildErrorState(
                  context,
                  error.toString(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHero(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: LinearGradient(
          colors: [
            theme.colorScheme.primary,
            theme.colorScheme.tertiary,
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: theme.colorScheme.primary.withValues(alpha: 0.24),
            blurRadius: 30,
            offset: const Offset(0, 18),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Icon(
              Icons.price_change_rounded,
              color: Colors.white,
              size: 34,
            ),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Global Test Pricing',
                  style: theme.textTheme.headlineSmall?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Create, edit, update, and delete lab tests with default prices.',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: Colors.white.withValues(alpha: 0.86),
                  ),
                ),
              ],
            ),
          ),
          if (_isEditing)
            FilledButton.tonalIcon(
              onPressed: _saving ? null : _clearForm,
              icon: const Icon(Icons.close_rounded),
              label: const Text('Cancel edit'),
            ),
        ],
      ),
    );
  }

  Widget _buildPricingContent(BuildContext context, List<LabTest> tests) {
    final query = _searchController.text.trim().toLowerCase();
    final filteredTests = query.isEmpty
        ? tests
        : tests
              .where(
                (test) =>
                    test.testName.toLowerCase().contains(query) ||
                    test.defaultPrice.toStringAsFixed(2).contains(query),
              )
              .toList();

    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 820;
        if (compact) {
          return Column(
            children: [
              _buildEditorCard(context, tests.length),
              const SizedBox(height: 16),
              Expanded(
                child: _buildTestsList(context, filteredTests, tests.length),
              ),
            ],
          );
        }

        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(width: 380, child: _buildEditorCard(context, tests.length)),
            const SizedBox(width: 18),
            Expanded(
              child: _buildTestsList(context, filteredTests, tests.length),
            ),
          ],
        );
      },
    );
  }

  Widget _buildEditorCard(BuildContext context, int totalTests) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    backgroundColor: theme.colorScheme.primaryContainer,
                    foregroundColor: theme.colorScheme.onPrimaryContainer,
                    child: Icon(
                      _isEditing
                          ? Icons.edit_note_rounded
                          : Icons.add_business_rounded,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _isEditing ? 'Update Test' : 'Add New Test',
                          style: theme.textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        Text('$totalTests tests in global price list'),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              TextFormField(
                controller: _nameController,
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'Test name',
                  hintText: 'Example: CBC',
                  prefixIcon: Icon(Icons.biotech_rounded),
                  border: OutlineInputBorder(),
                ),
                validator: (value) => (value == null || value.trim().isEmpty)
                    ? 'Enter test name'
                    : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _priceController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'Default price',
                  hintText: 'Example: 1500',
                  prefixIcon: Icon(Icons.payments_rounded),
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    (value == null || double.tryParse(value.trim()) == null)
                    ? 'Enter valid price'
                    : null,
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _saving ? null : _saveTest,
                  icon: _saving
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Icon(
                          _isEditing
                              ? Icons.save_as_rounded
                              : Icons.add_rounded,
                        ),
                  label: Text(_isEditing ? 'Update Test' : 'Add Test'),
                ),
              ),
              if (_isEditing) ...[
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: _saving ? null : _clearForm,
                    icon: const Icon(Icons.close_rounded),
                    label: const Text('Cancel Edit'),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTestsList(
    BuildContext context,
    List<LabTest> tests,
    int totalTests,
  ) {
    final theme = Theme.of(context);
    final totalValue = tests.fold<double>(
      0,
      (sum, test) => sum + test.defaultPrice,
    );

    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 12,
              runSpacing: 12,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                _StatChip(
                  icon: Icons.science_rounded,
                  label: 'Tests',
                  value: '$totalTests',
                ),
                _StatChip(
                  icon: Icons.account_balance_wallet_rounded,
                  label: 'Shown total',
                  value: totalValue.toStringAsFixed(2),
                ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _searchController,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'Search tests or price...',
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: _searchController.text.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          _searchController.clear();
                          setState(() {});
                        },
                        icon: const Icon(Icons.clear_rounded),
                      ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: tests.isEmpty
                  ? _buildEmptyState(context)
                  : ListView.separated(
                      itemCount: tests.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (context, index) {
                        final test = tests[index];
                        return _TestPriceTile(
                          test: test,
                          selected: test.id == _editingId,
                          onEdit: () => _startEdit(test),
                          onDelete: _saving ? null : () => _deleteTest(test),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.inventory_2_outlined,
            size: 52,
            color: Theme.of(context).colorScheme.outline,
          ),
          const SizedBox(height: 12),
          Text(
            'No tests found',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 4),
          const Text('Add a new test or change your search keyword.'),
        ],
      ),
    );
  }

  Widget _buildErrorState(BuildContext context, String message) {
    return Center(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.error_outline_rounded,
                size: 48,
                color: Theme.of(context).colorScheme.error,
              ),
              const SizedBox(height: 12),
              const Text('Failed to load tests'),
              const SizedBox(height: 8),
              Text(message, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () => ref.invalidate(testsProvider),
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Try again'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PricingSidebar extends StatelessWidget {
  const _PricingSidebar({required this.user});

  final AppUser? user;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: 270,
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        color: theme.colorScheme.surface.withValues(alpha: 0.86),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 30,
            offset: const Offset(0, 16),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: theme.colorScheme.primary,
                foregroundColor: theme.colorScheme.onPrimary,
                child: const Icon(Icons.local_hospital_rounded),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'LabOps',
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 22),
          _PricingNavItem(
            icon: Icons.dashboard_rounded,
            label: 'Dashboard',
            route: '/',
            selected: false,
          ),
          _PricingNavItem(
            icon: Icons.group_rounded,
            label: 'Users',
            route: '/users',
            selected: false,
          ),
          _PricingNavItem(
            icon: Icons.price_change_rounded,
            label: 'Global Pricing',
            route: '/global-pricing',
            selected: true,
          ),
          _PricingNavItem(
            icon: Icons.storefront_rounded,
            label: 'Sub-center Pricing',
            route: '/sub-center-pricing',
            selected: false,
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              color: theme.colorScheme.primaryContainer,
            ),
            child: Row(
              children: [
                CircleAvatar(
                  child: Text((user?.name ?? 'U').characters.first),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user?.name ?? 'User',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      Text(user?.role.name ?? 'guest'),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PricingDrawer extends StatelessWidget {
  const _PricingDrawer({required this.user});

  final AppUser? user;

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            ListTile(
              leading: const CircleAvatar(
                child: Icon(Icons.local_hospital_rounded),
              ),
              title: const Text(
                'LabOps',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
              subtitle: Text(user?.role.name ?? 'guest'),
            ),
            const SizedBox(height: 16),
            _PricingNavItem(
              icon: Icons.dashboard_rounded,
              label: 'Dashboard',
              route: '/',
              selected: false,
            ),
            _PricingNavItem(
              icon: Icons.group_rounded,
              label: 'Users',
              route: '/users',
              selected: false,
            ),
            _PricingNavItem(
              icon: Icons.price_change_rounded,
              label: 'Global Pricing',
              route: '/global-pricing',
              selected: true,
            ),
            _PricingNavItem(
              icon: Icons.storefront_rounded,
              label: 'Sub-center Pricing',
              route: '/sub-center-pricing',
              selected: false,
            ),
          ],
        ),
      ),
    );
  }
}

class _PricingNavItem extends StatelessWidget {
  const _PricingNavItem({
    required this.icon,
    required this.label,
    required this.route,
    required this.selected,
  });

  final IconData icon;
  final String label;
  final String route;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => context.go(route),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            color: selected ? theme.colorScheme.primaryContainer : null,
          ),
          child: Row(
            children: [
              Icon(
                icon,
                color: selected
                    ? theme.colorScheme.primary
                    : theme.colorScheme.onSurfaceVariant,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  const _StatChip({
    required this.icon,
    required this.label,
    required this.value,
  });

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: theme.colorScheme.secondaryContainer.withValues(alpha: 0.72),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 20),
          const SizedBox(width: 8),
          Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w700)),
          Text(value),
        ],
      ),
    );
  }
}

class _TestPriceTile extends StatelessWidget {
  const _TestPriceTile({
    required this.test,
    required this.selected,
    required this.onEdit,
    required this.onDelete,
  });

  final LabTest test;
  final bool selected;
  final VoidCallback onEdit;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: selected
            ? theme.colorScheme.primaryContainer
            : theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.52),
        border: Border.all(
          color: selected
              ? theme.colorScheme.primary
              : theme.colorScheme.outlineVariant.withValues(alpha: 0.35),
        ),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: selected
                ? theme.colorScheme.primary
                : theme.colorScheme.surface,
            foregroundColor: selected
                ? theme.colorScheme.onPrimary
                : theme.colorScheme.primary,
            child: const Icon(Icons.science_rounded),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  test.testName,
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text('ID: ${test.id}'),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: theme.colorScheme.primary.withValues(alpha: 0.10),
            ),
            child: Text(
              test.defaultPrice.toStringAsFixed(2),
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w900,
                color: theme.colorScheme.primary,
              ),
            ),
          ),
          const SizedBox(width: 8),
          IconButton.filledTonal(
            tooltip: 'Edit test',
            onPressed: onEdit,
            icon: const Icon(Icons.edit_rounded),
          ),
          const SizedBox(width: 4),
          IconButton.filledTonal(
            tooltip: 'Delete test',
            onPressed: onDelete,
            icon: Icon(
              Icons.delete_outline_rounded,
              color: theme.colorScheme.error,
            ),
          ),
        ],
      ),
    );
  }
}
