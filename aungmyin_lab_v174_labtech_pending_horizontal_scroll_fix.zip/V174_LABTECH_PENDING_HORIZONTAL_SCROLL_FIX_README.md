### v174 lab tech pending horizontal scroll fix

This build fixes the lab tech Blood Samples table horizontal scrolling when pending samples are visible.

Changes:
- The desktop/tablet Blood Samples table now uses a minimum-width `ConstrainedBox` instead of a fixed-width `SizedBox`, so the table can grow when pending review actions need more space and the horizontal scroll range stays accurate.
- Lab tech desktop/tablet tables get a wider minimum table width when pending samples are present.
- Long ID, patient, center, tests, and referral cells are constrained with ellipsis so they do not destabilize the table width.
- The lab tech action cell has a stable width, so pending `Start Review` rows do not interfere with horizontal drag scrolling.
- The non-completed result button keeps a compact width.

Updated file:
- lib/views/dashboard_view.dart

Preserved:
- v173 TestResults delete fix.
- v172 superadmin related results delete flow.
- v171 all-role desktop/tablet Blood Samples scrolling behavior.
