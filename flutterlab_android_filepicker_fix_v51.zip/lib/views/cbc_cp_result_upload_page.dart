import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../config/google_config.dart';
import '../models/app_user.dart';
import '../providers/auth_notifier.dart';
import '../providers/sample_dashboard_controller.dart';
import '../services/google_drive_service.dart';
import '../services/google_sheets_service.dart';
import '../widgets/app_sidebar.dart';

const _cbcSheetName = 'CBCResults';
const _cbcRange = 'CBCResults!A:BB';

const _cbcHeaders = <String>[
  'id',
  'testName',
  'sampleId',
  'medRecNo',
  'firstName',
  'lastName',
  'gender',
  'age',
  'ageUnit',
  'sampleType',
  'samplingTime',
  'deliveryTime',
  'reportTime',
  'runTime',
  'mode',
  'WBC',
  'NeuPercent',
  'LymPercent',
  'MonPercent',
  'EosPercent',
  'BasPercent',
  'NeuCount',
  'LymCount',
  'MonCount',
  'EosCount',
  'BasCount',
  'ALYCount',
  'ALYPercent',
  'LICCount',
  'LICPercent',
  'NRBCCount',
  'NRBCPercent',
  'RBC',
  'HGB',
  'HCT',
  'MCV',
  'MCH',
  'MCHC',
  'RDWCV',
  'RDWSD',
  'PLT',
  'MPV',
  'PDW',
  'PCT',
  'PLCR',
  'PLCC',
  'WBCFlag',
  'RBCFlag',
  'PLTFlag',
  'CRPFlag',
  'diffHsmsImageUrl',
  'pltImageUrl',
  'createdAt',
  'uploadedByUserId',
];

class CbcCpResultUploadPage extends ConsumerStatefulWidget {
  const CbcCpResultUploadPage({super.key});

  @override
  ConsumerState<CbcCpResultUploadPage> createState() => _CbcCpResultUploadPageState();
}

class _CbcCpResultUploadPageState extends ConsumerState<CbcCpResultUploadPage> {
  PlatformFile? _csvFile;
  PlatformFile? _diffImage;
  PlatformFile? _pltImage;
  Map<String, String>? _preview;
  bool _saving = false;
  String? _statusMessage;

  Future<void> _pickCsv() async {
    final result = await FilePicker.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['csv'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final file = result.files.single;
    final bytes = file.bytes;
    if (bytes == null || bytes.isEmpty) {
      _showSnackBar('Selected CSV is empty or cannot be read.', isError: true);
      return;
    }
    try {
      final csvText = utf8.decode(bytes, allowMalformed: true);
      final parsed = _parseCbcCsv(csvText);
      setState(() {
        _csvFile = file;
        _preview = parsed;
        _statusMessage = 'CSV loaded: ${file.name}';
      });
    } catch (error) {
      _showSnackBar('CSV parse failed: $error', isError: true);
    }
  }

  Future<void> _pickImage({required bool isDiff}) async {
    final result = await FilePicker.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['png', 'jpg', 'jpeg'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    setState(() {
      if (isDiff) {
        _diffImage = result.files.single;
      } else {
        _pltImage = result.files.single;
      }
    });
  }

  Map<String, String> _parseCbcCsv(String csvText) {
    final rows = _parseCsvRows(csvText)
        .where((row) => row.any((cell) => cell.trim().isNotEmpty))
        .toList();
    if (rows.length < 2) throw StateError('CSV must contain header row and one data row.');

    final headers = rows.first.map((value) => value.trim().toLowerCase()).toList();
    final row = rows[1];
    final source = <String, String>{};
    for (var i = 0; i < headers.length; i++) {
      source[headers[i]] = i < row.length ? row[i].trim() : '';
    }

    String get(List<String> keys) {
      for (final key in keys) {
        final value = source[key.toLowerCase()]?.trim() ?? '';
        if (value.isNotEmpty) return value;
      }
      return '';
    }

    final sampleId = get(['Sample ID']);
    final now = DateTime.now().toIso8601String();
    return <String, String>{
      'id': 'CBC-${sampleId.isEmpty ? DateTime.now().microsecondsSinceEpoch : sampleId}-${DateTime.now().millisecondsSinceEpoch}',
      'testName': 'CBC / CP(Auto)',
      'sampleId': sampleId,
      'medRecNo': get(['Med Rec. No.']),
      'firstName': get(['First Name']),
      'lastName': get(['Last Name']),
      'gender': get(['Gender']),
      'age': get(['Age']),
      'ageUnit': get(['Age Unit']),
      'sampleType': get(['Sample Type']),
      'samplingTime': get(['Sampling Time']),
      'deliveryTime': get(['Delivery Time']),
      'reportTime': get(['Report Time']),
      'runTime': get(['Run Time']),
      'mode': get(['Mode']),
      'WBC': get(['WBC']),
      'NeuPercent': get(['Neu%']),
      'LymPercent': get(['Lym%']),
      'MonPercent': get(['Mon%']),
      'EosPercent': get(['Eos%']),
      'BasPercent': get(['Bas%']),
      'NeuCount': get(['Neu#']),
      'LymCount': get(['Lym#']),
      'MonCount': get(['Mon#']),
      'EosCount': get(['Eos#']),
      'BasCount': get(['Bas#']),
      'ALYCount': get(['ALY#']),
      'ALYPercent': get(['ALY%']),
      'LICCount': get(['LIC#']),
      'LICPercent': get(['LIC%']),
      'NRBCCount': get(['NRBC#']),
      'NRBCPercent': get(['NRBC%']),
      'RBC': get(['RBC']),
      'HGB': get(['HGB']),
      'HCT': get(['HCT']),
      'MCV': get(['MCV']),
      'MCH': get(['MCH']),
      'MCHC': get(['MCHC']),
      'RDWCV': get(['RDW-CV']),
      'RDWSD': get(['RDW-SD']),
      'PLT': get(['PLT']),
      'MPV': get(['MPV']),
      'PDW': get(['PDW']),
      'PCT': get(['PCT']),
      'PLCR': get(['P-LCR']),
      'PLCC': get(['P-LCC']),
      'WBCFlag': get(['WBC Flag']),
      'RBCFlag': get(['RBC Flag']),
      'PLTFlag': get(['PLT Flag']),
      'CRPFlag': get(['CRP Flag']),
      'diffHsmsImageUrl': '',
      'pltImageUrl': '',
      'createdAt': now,
      'uploadedByUserId': '',
    };
  }

  List<List<String>> _parseCsvRows(String text) {
    final rows = <List<String>>[];
    final currentRow = <String>[];
    final currentCell = StringBuffer();
    var inQuotes = false;

    for (var i = 0; i < text.length; i++) {
      final char = text[i];
      final next = i + 1 < text.length ? text[i + 1] : '';
      if (char == '"') {
        if (inQuotes && next == '"') {
          currentCell.write('"');
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char == ',' && !inQuotes) {
        currentRow.add(currentCell.toString().replaceAll('\t', '').trim());
        currentCell.clear();
      } else if ((char == '\n' || char == '\r') && !inQuotes) {
        if (char == '\r' && next == '\n') i++;
        currentRow.add(currentCell.toString().replaceAll('\t', '').trim());
        currentCell.clear();
        rows.add(List<String>.from(currentRow));
        currentRow.clear();
      } else {
        currentCell.write(char);
      }
    }

    if (currentCell.isNotEmpty || currentRow.isNotEmpty) {
      currentRow.add(currentCell.toString().replaceAll('\t', '').trim());
      rows.add(List<String>.from(currentRow));
    }
    return rows;
  }

  Future<void> _saveToGoogleSheets() async {
    final preview = _preview;
    final user = ref.read(authNotifierProvider);
    if (preview == null) {
      _showSnackBar('Please choose the CBC/CP(Auto) CSV file first.', isError: true);
      return;
    }
    if (_diffImage?.bytes == null) {
      _showSnackBar('Please choose the DIFF image.', isError: true);
      return;
    }
    if (_pltImage?.bytes == null) {
      _showSnackBar('Please choose the PLT image.', isError: true);
      return;
    }

    setState(() {
      _saving = true;
      _statusMessage = 'Saving CBC / CP(Auto) result...';
    });

    GoogleSheetsService? sheetsService;
    GoogleDriveService? driveService;
    try {
      final serviceAccountJson = await rootBundle.loadString('assets/service-account.json');
      sheetsService = GoogleSheetsService(
        serviceAccountJson: serviceAccountJson,
        applicationName: 'flutterlab',
      );
      driveService = GoogleDriveService(
        serviceAccountJson: serviceAccountJson,
        applicationName: 'flutterlab',
      );

      await sheetsService.ensureSheet(
        spreadsheetId: GoogleConfig.spreadsheetId,
        sheetName: _cbcSheetName,
      );
      await sheetsService.updateRow(
        spreadsheetId: GoogleConfig.spreadsheetId,
        range: '$_cbcSheetName!A1:BB1',
        values: _cbcHeaders,
      );

      final row = Map<String, String>.from(preview);
      row['uploadedByUserId'] = user?.id ?? '';
      setState(() => _statusMessage = 'Uploading DIFF image...');
      row['diffHsmsImageUrl'] = await driveService.uploadBytesToSharedFolder(
        bytes: _diffImage!.bytes!,
        parentFolderId: GoogleConfig.driveFolderId,
        fileName: _diffImage!.name,
        mimeType: _mimeTypeFor(_diffImage!.name),
      );

      setState(() => _statusMessage = 'Uploading PLT image...');
      row['pltImageUrl'] = await driveService.uploadBytesToSharedFolder(
        bytes: _pltImage!.bytes!,
        parentFolderId: GoogleConfig.driveFolderId,
        fileName: _pltImage!.name,
        mimeType: _mimeTypeFor(_pltImage!.name),
      );

      await sheetsService.insertRow(
        spreadsheetId: GoogleConfig.spreadsheetId,
        range: _cbcRange,
        values: _cbcHeaders.map((header) => row[header] ?? '').toList(),
        valueInputOption: 'RAW',
      );

      ref.invalidate(sampleDashboardControllerProvider);
      setState(() {
        _statusMessage = 'CBC / CP(Auto) result saved to Google Sheets.';
        _csvFile = null;
        _diffImage = null;
        _pltImage = null;
        _preview = null;
      });
      _showSnackBar('CBC / CP(Auto) result saved successfully.');
    } catch (error) {
      _showSnackBar('Save failed: $error', isError: true);
    } finally {
      await sheetsService?.close();
      await driveService?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  String _mimeTypeFor(String fileName) {
    final lower = fileName.toLowerCase();
    if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
    return 'image/png';
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    final theme = Theme.of(context);
    return AppScaffold(
      title: 'CBC / CP(Auto) Result',
      selectedRoute: '/cbc-cp-result',
      user: user,
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _HeroCard(theme: theme),
              const SizedBox(height: 18),
              _FilePickerCard(
                csvFile: _csvFile,
                diffImage: _diffImage,
                pltImage: _pltImage,
                saving: _saving,
                statusMessage: _statusMessage,
                onPickCsv: _pickCsv,
                onPickDiff: () => _pickImage(isDiff: true),
                onPickPlt: () => _pickImage(isDiff: false),
              ),
              const SizedBox(height: 18),
              if (_preview != null) _PreviewCard(data: _preview!),
              const SizedBox(height: 18),
              Align(
                alignment: Alignment.centerRight,
                child: FilledButton.icon(
                  onPressed: _saving ? null : _saveToGoogleSheets,
                  icon: _saving
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.save_rounded),
                  label: Text(_saving ? 'Saving...' : 'Save Result'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard({required this.theme});

  final ThemeData theme;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(colors: [Color(0xFF0F766E), Color(0xFF2563EB), Color(0xFF7C3AED)]),
        boxShadow: [BoxShadow(color: theme.colorScheme.primary.withValues(alpha: 0.22), blurRadius: 26, offset: const Offset(0, 15))],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(24)),
            child: const Icon(Icons.bloodtype_rounded, color: Colors.white, size: 36),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('CBC / CP(Auto) Result Upload', style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text('Upload the analyzer CSV plus DIFF and PLT images. Values and image links are stored in CBCResults.', style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white.withValues(alpha: 0.88))),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FilePickerCard extends StatelessWidget {
  const _FilePickerCard({
    required this.csvFile,
    required this.diffImage,
    required this.pltImage,
    required this.saving,
    required this.statusMessage,
    required this.onPickCsv,
    required this.onPickDiff,
    required this.onPickPlt,
  });

  final PlatformFile? csvFile;
  final PlatformFile? diffImage;
  final PlatformFile? pltImage;
  final bool saving;
  final String? statusMessage;
  final VoidCallback onPickCsv;
  final VoidCallback onPickDiff;
  final VoidCallback onPickPlt;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.94),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Result Files', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 14),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                FilledButton.tonalIcon(
                  onPressed: saving ? null : onPickCsv,
                  icon: const Icon(Icons.table_chart_rounded),
                  label: Text(csvFile == null ? 'Choose SampleExport CSV' : csvFile!.name),
                ),
                FilledButton.tonalIcon(
                  onPressed: saving ? null : onPickDiff,
                  icon: const Icon(Icons.scatter_plot_rounded),
                  label: Text(diffImage == null ? 'Choose DIFF Image' : diffImage!.name),
                ),
                FilledButton.tonalIcon(
                  onPressed: saving ? null : onPickPlt,
                  icon: const Icon(Icons.area_chart_rounded),
                  label: Text(pltImage == null ? 'Choose PLT Image' : pltImage!.name),
                ),
              ],
            ),
            if (statusMessage != null) ...[
              const SizedBox(height: 12),
              Text(statusMessage!),
            ],
          ],
        ),
      ),
    );
  }
}

class _PreviewCard extends StatelessWidget {
  const _PreviewCard({required this.data});

  final Map<String, String> data;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final important = <String>[
      'testName',
      'sampleId',
      'firstName',
      'gender',
      'age',
      'mode',
      'WBC',
      'RBC',
      'HGB',
      'HCT',
      'PLT',
      'WBCFlag',
      'RBCFlag',
      'PLTFlag',
    ];
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.94),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Parsed Preview', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: important.map((key) => Chip(label: Text('$key: ${data[key] ?? '-'}'))).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
