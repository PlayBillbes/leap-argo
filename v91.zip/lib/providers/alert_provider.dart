import 'dart:async';

import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../config/google_config.dart';
import '../services/turso_native_service.dart';

final alertMessageProvider = AsyncNotifierProvider<AlertMessageNotifier, String?>(
  AlertMessageNotifier.new,
);

class AlertMessageNotifier extends AsyncNotifier<String?> {
  TursoNativeService? _service;
  static const _sheetName = 'Alert';
  static const _range = 'Alert!A:Z';

  @override
  FutureOr<String?> build() async => fetchAlert();

  Future<TursoNativeService> _getService() async {
    _service ??= TursoNativeService(
      serviceAccountJson: await rootBundle.loadString('assets/service-account.json'),
      applicationName: 'flutterlab',
    );
    return _service!;
  }

  Future<String?> fetchAlert() async {
    try {
      final service = await _getService();
      final rows = await service.fetchRows(
        spreadsheetId: GoogleConfig.spreadsheetId,
        range: _range,
      );
      if (rows.isEmpty) return null;

      // Preferred layout:
      // Header row contains a column named "alert". The first non-empty value
      // under that column is the active login alert.
      final headers = rows.first
          .map((header) => header.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
          .toList();
      final alertColumnIndex = headers.indexOf('alert');
      if (alertColumnIndex >= 0) {
        for (final row in rows.skip(1)) {
          if (alertColumnIndex >= row.length) continue;
          final alert = row[alertColumnIndex].trim();
          if (alert.isNotEmpty) return alert;
        }
        return null;
      }

      // Fallback: if there is no header row, first non-empty cell can be alert.
      for (final row in rows) {
        for (final cell in row) {
          final value = cell.trim();
          if (value.isEmpty || value.toLowerCase() == 'alert') continue;
          return value;
        }
      }
      return null;
    } catch (_) {
      // If Alert sheet does not exist or network fails, app should continue login.
      return null;
    }
  }

  Future<void> saveAlert(String message) async {
    final service = await _getService();
    await service.ensureSheet(
      spreadsheetId: GoogleConfig.spreadsheetId,
      sheetName: _sheetName,
    );
    await service.updateRow(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'Alert!A1:A1',
      values: const ['alert'],
    );
    await service.updateRow(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'Alert!A2:A2',
      values: [message.trim()],
    );
    state = AsyncValue.data(message.trim().isEmpty ? null : message.trim());
  }

  Future<void> deleteAlert() async {
    final service = await _getService();
    await service.ensureSheet(
      spreadsheetId: GoogleConfig.spreadsheetId,
      sheetName: _sheetName,
    );
    await service.updateRow(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'Alert!A1:A1',
      values: const ['alert'],
    );
    await service.updateRow(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'Alert!A2:A2',
      values: const [''],
    );
    state = const AsyncValue.data(null);
  }
}
