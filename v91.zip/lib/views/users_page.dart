import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../config/google_config.dart';
import '../models/app_user.dart';
import '../providers/auth_notifier.dart';
import '../services/turso_native_service.dart';
import '../widgets/app_sidebar.dart';

final usersProvider = AsyncNotifierProvider<UsersNotifier, List<SheetUser>>(
  UsersNotifier.new,
);

class SheetUser {
  const SheetUser({
    required this.id,
    required this.username,
    required this.passwordHash,
    required this.name,
    required this.role,
    required this.subCenterId,
  });

  final String id;
  final String username;
  final String passwordHash;
  final String name;
  final AppUserRole role;
  final String subCenterId;
}

class UsersNotifier extends AsyncNotifier<List<SheetUser>> {
  TursoNativeService? _service;
  static const _range = 'Users!A:F';

  @override
  Future<List<SheetUser>> build() async => fetchUsers();

  Future<TursoNativeService> _getService() async {
    _service ??= TursoNativeService(
      serviceAccountJson: await rootBundle.loadString('assets/service-account.json'),
      applicationName: 'flutterlab',
    );
    return _service!;
  }

  Future<List<SheetUser>> fetchUsers() async {
    state = const AsyncValue.loading();
    final service = await _getService();
    final rows = await service.fetchRows(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: _range,
    );

    if (rows.isEmpty) {
      state = const AsyncValue.data(<SheetUser>[]);
      return <SheetUser>[];
    }

    final headers = rows.first
        .map((h) => h.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();

    final users = rows.skip(1).map((row) {
      final map = <String, String>{};
      for (var i = 0; i < headers.length; i++) {
        map[headers[i]] = i < row.length ? row[i].toString() : '';
      }

      return SheetUser(
        id: map['id'] ?? '',
        username: map['username'] ?? '',
        passwordHash: map['passwordhash'] ?? '',
        name: map['name'] ?? '',
        role: AppUserRole.values.firstWhere(
          (role) => role.name == (map['role'] ?? 'staff').trim().toLowerCase(),
          orElse: () => AppUserRole.staff,
        ),
        subCenterId: map['subcenterid'] ?? 'GLOBAL',
      );
    }).where((user) => user.id.isNotEmpty || user.username.isNotEmpty).toList();

    state = AsyncValue.data(users);
    return users;
  }
}

class UsersPage extends ConsumerStatefulWidget {
  const UsersPage({super.key});

  @override
  ConsumerState<UsersPage> createState() => _UsersPageState();
}

class _UsersPageState extends ConsumerState<UsersPage> {
  static const _sheetName = 'Users';
  static const _usersRange = 'Users!A:F';

  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController(text: '123456');
  final _subCenterController = TextEditingController(text: 'GLOBAL');
  final _searchController = TextEditingController();

  AppUserRole _selectedRole = AppUserRole.staff;
  bool _saving = false;
  String? _editingId;
  String? _editingPasswordHash;

  bool get _isEditing => _editingId != null;

  AppUser? get _activeUser => ref.read(authNotifierProvider);
  bool get _isAdminManager => _activeUser?.role == AppUserRole.admin || _activeUser?.role == AppUserRole.staff;

  String _adminCenter() {
    final raw = _activeUser?.subCenterId?.trim() ?? '';
    return raw.isEmpty ? 'GLOBAL' : raw;
  }

  List<AppUserRole> get _manageableRoles {
    final role = _activeUser?.role;
    if (role == AppUserRole.staff) return const [AppUserRole.referred_person];
    if (role == AppUserRole.admin) return const [AppUserRole.staff, AppUserRole.referred_person];
    return AppUserRole.values;
  }

  AppUserRole get _defaultManagedRole =>
      _manageableRoles.contains(AppUserRole.staff) ? AppUserRole.staff : AppUserRole.referred_person;

  String _roleLabel(AppUserRole role) => role.name.replaceAll('_', ' ');

  String _normalizeCenter(String value) =>
      value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  bool _canManageUser(SheetUser user) {
    if (!_isAdminManager) return true;
    return _manageableRoles.contains(user.role) &&
        _normalizeCenter(user.subCenterId) == _normalizeCenter(_adminCenter());
  }

  @override
  void dispose() {
    _nameController.dispose();
    _usernameController.dispose();
    _passwordController.dispose();
    _subCenterController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<TursoNativeService> _newSheetsService() async {
    return TursoNativeService(
      serviceAccountJson: await rootBundle.loadString('assets/service-account.json'),
      applicationName: 'flutterlab',
    );
  }

  String _hashPassword(String password) => sha256.convert(utf8.encode(password)).toString();

  Future<int> _findSheetRowByUserId(TursoNativeService service, String userId) async {
    final rows = await service.fetchRows(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: _usersRange,
    );

    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      if (row.isNotEmpty && row.first == userId) return i + 1;
    }

    throw StateError('User row was not found. Please refresh and try again.');
  }

  Future<void> _saveUser() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _saving = true);
    TursoNativeService? service;

    try {
      service = await _newSheetsService();
      final name = _nameController.text.trim();
      final username = _usernameController.text.trim().toLowerCase();
      final subCenter = _isAdminManager
          ? _adminCenter()
          : (_subCenterController.text.trim().isEmpty
              ? 'GLOBAL'
              : _subCenterController.text.trim());
      final roleToSave = _manageableRoles.contains(_selectedRole) ? _selectedRole : _defaultManagedRole;
      final passwordHash = _passwordController.text.trim().isNotEmpty
          ? _hashPassword(_passwordController.text.trim())
          : (_editingPasswordHash ?? _hashPassword('123456'));

      if (_isEditing) {
        if (_isAdminManager) {
          final existingUsers = await ref.read(usersProvider.future);
          SheetUser? existing;
          for (final candidate in existingUsers) {
            if (candidate.id == _editingId) {
              existing = candidate;
              break;
            }
          }
          if (existing == null || !_canManageUser(existing)) {
            throw StateError('You can only update allowed accounts from your own center.');
          }
        }
        final rowNumber = await _findSheetRowByUserId(service, _editingId!);
        await service.updateRow(
          spreadsheetId: GoogleConfig.spreadsheetId,
          range: 'Users!A$rowNumber:F$rowNumber',
          values: [_editingId!, username, passwordHash, name, roleToSave.name, subCenter],
        );
        _showSnackBar('User updated successfully');
      } else {
        final id = 'user-${DateTime.now().millisecondsSinceEpoch}';
        await service.insertRow(
          spreadsheetId: GoogleConfig.spreadsheetId,
          range: _usersRange,
          values: [id, username, passwordHash, name, roleToSave.name, subCenter],
        );
        _showSnackBar('User added. Default password: ${_passwordController.text.trim()}');
      }

      _clearForm();
      ref.invalidate(usersProvider);
    } catch (e) {
      _showSnackBar('Save failed: $e', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _deleteUser(SheetUser user) async {
    final activeUser = ref.read(authNotifierProvider);
    if (!_canManageUser(user)) {
      _showSnackBar('You can only delete allowed accounts from your own center.', isError: true);
      return;
    }
    if (activeUser?.id == user.id) {
      _showSnackBar('You cannot delete the currently signed-in user.', isError: true);
      return;
    }

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete user?'),
        content: Text('This will remove "${user.name}" (${user.username}) from the Users sheet.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
              foregroundColor: Theme.of(context).colorScheme.onError,
            ),
            onPressed: () => Navigator.of(context).pop(true),
            icon: const Icon(Icons.delete_outline_rounded),
            label: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    setState(() => _saving = true);
    TursoNativeService? service;

    try {
      service = await _newSheetsService();
      final rowNumber = await _findSheetRowByUserId(service, user.id);
      await service.deleteRow(
        spreadsheetId: GoogleConfig.spreadsheetId,
        sheetName: _sheetName,
        rowIndexOneBased: rowNumber,
      );
      if (_editingId == user.id) _clearForm();
      ref.invalidate(usersProvider);
      _showSnackBar('User deleted successfully');
    } catch (e) {
      _showSnackBar('Delete failed: $e', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  void _startEdit(SheetUser user) {
    if (!_canManageUser(user)) {
      _showSnackBar('You can only edit allowed accounts from your own center.', isError: true);
      return;
    }
    setState(() {
      _editingId = user.id;
      _editingPasswordHash = user.passwordHash;
      _nameController.text = user.name;
      _usernameController.text = user.username;
      _passwordController.clear();
      _subCenterController.text = _isAdminManager ? _adminCenter() : user.subCenterId;
      _selectedRole = _manageableRoles.contains(user.role) ? user.role : _defaultManagedRole;
    });
  }

  void _clearForm() {
    setState(() {
      _editingId = null;
      _editingPasswordHash = null;
      _nameController.clear();
      _usernameController.clear();
      _passwordController.text = '123456';
      _subCenterController.text = _isAdminManager ? _adminCenter() : 'GLOBAL';
      _selectedRole = _defaultManagedRole;
    });
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final activeUser = ref.watch(authNotifierProvider);
    final usersAsync = ref.watch(usersProvider);

    return AppScaffold(
      title: _isAdminManager ? 'Staff Accounts' : 'Users',
      selectedRoute: '/users',
      user: activeUser,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Refresh users',
          onPressed: _saving ? null : () => ref.invalidate(usersProvider),
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHero(context),
            const SizedBox(height: 18),
            Expanded(
              child: usersAsync.when(
                data: (users) => _buildUsersContent(context, users),
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (error, stack) => _buildErrorState(context, error.toString()),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHero(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: LinearGradient(colors: [theme.colorScheme.primary, theme.colorScheme.tertiary]),
        boxShadow: [
          BoxShadow(
            color: theme.colorScheme.primary.withValues(alpha: 0.24),
            blurRadius: 30,
            offset: const Offset(0, 18),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Icon(Icons.admin_panel_settings_rounded, color: Colors.white, size: 34),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _isAdminManager ? 'Staff Account Management' : 'User Management',
                  style: theme.textTheme.headlineSmall?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  _isAdminManager
                      ? 'Admins can create and manage staff accounts for their own sub-center.'
                      : 'Superadmin can add users, assign roles, reset passwords, update profiles, and delete accounts.',
                  style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white.withValues(alpha: 0.86)),
                ),
              ],
            ),
          ),
          if (_isEditing)
            FilledButton.tonalIcon(
              onPressed: _saving ? null : _clearForm,
              icon: const Icon(Icons.close_rounded),
              label: const Text('Cancel edit'),
            ),
        ],
      ),
    );
  }

  Widget _buildUsersContent(BuildContext context, List<SheetUser> users) {
    final visibleUsers = _isAdminManager
        ? users.where(_canManageUser).toList()
        : users;
    final query = _searchController.text.trim().toLowerCase();
    final filteredUsers = query.isEmpty
        ? visibleUsers
        : visibleUsers.where((user) {
            return user.name.toLowerCase().contains(query) ||
                user.username.toLowerCase().contains(query) ||
                user.role.name.toLowerCase().contains(query) ||
                user.subCenterId.toLowerCase().contains(query);
          }).toList();

    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 870;
        if (compact) {
          return Column(
            children: [
              _buildEditorCard(context, visibleUsers.length),
              const SizedBox(height: 16),
              Expanded(child: _buildUsersList(context, filteredUsers, visibleUsers.length)),
            ],
          );
        }

        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(width: 400, child: _buildEditorCard(context, visibleUsers.length)),
            const SizedBox(width: 18),
            Expanded(child: _buildUsersList(context, filteredUsers, visibleUsers.length)),
          ],
        );
      },
    );
  }

  Widget _buildEditorCard(BuildContext context, int totalUsers) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: theme.colorScheme.primaryContainer,
                      foregroundColor: theme.colorScheme.onPrimaryContainer,
                      child: Icon(_isEditing ? Icons.manage_accounts_rounded : Icons.person_add_alt_rounded),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _isEditing
                                ? (_isAdminManager ? 'Update Staff' : 'Update User')
                                : (_isAdminManager ? 'Add New Staff' : 'Add New User'),
                            style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
                          ),
                          Text(_isAdminManager
                              ? '$totalUsers staff accounts in your center'
                              : '$totalUsers users in Users sheet'),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 22),
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Full name',
                    prefixIcon: Icon(Icons.badge_rounded),
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value == null || value.trim().isEmpty ? 'Enter full name' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _usernameController,
                  decoration: const InputDecoration(
                    labelText: 'Username',
                    prefixIcon: Icon(Icons.alternate_email_rounded),
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value == null || value.trim().isEmpty ? 'Enter username' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: _isEditing ? 'New password optional' : 'Default password',
                    helperText: _isEditing ? 'Leave empty to keep current password.' : 'This password will be hashed in the sheet.',
                    prefixIcon: const Icon(Icons.lock_rounded),
                    border: const OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (!_isEditing && (value == null || value.trim().isEmpty)) {
                      return 'Enter default password';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<AppUserRole>(
                  value: _manageableRoles.contains(_selectedRole) ? _selectedRole : _defaultManagedRole,
                  decoration: const InputDecoration(
                    labelText: 'Role',
                    prefixIcon: Icon(Icons.security_rounded),
                    border: OutlineInputBorder(),
                  ),
                  items: _manageableRoles
                      .map((role) => DropdownMenuItem(value: role, child: Text(_roleLabel(role))))
                      .toList(),
                  onChanged: _saving || _manageableRoles.length == 1
                      ? null
                      : (role) => setState(() => _selectedRole = role ?? _defaultManagedRole),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _subCenterController,
                  readOnly: _isAdminManager,
                  decoration: const InputDecoration(
                    labelText: 'Sub-center ID',
                    prefixIcon: Icon(Icons.storefront_rounded),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _saving ? null : _saveUser,
                    icon: _saving
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                        : Icon(_isEditing ? Icons.save_as_rounded : Icons.person_add_rounded),
                    label: Text(_isEditing
                        ? (_isAdminManager ? 'Update Staff' : 'Update User')
                        : (_isAdminManager ? 'Add Staff' : 'Add User')),
                  ),
                ),
                if (_isEditing) ...[
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _saving ? null : _clearForm,
                      icon: const Icon(Icons.close_rounded),
                      label: const Text('Cancel Edit'),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildUsersList(BuildContext context, List<SheetUser> users, int totalUsers) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                _StatChip(icon: Icons.people_alt_rounded, label: 'Total users', value: '$totalUsers'),
                _StatChip(icon: Icons.admin_panel_settings_rounded, label: 'Superadmins', value: '${users.where((u) => u.role == AppUserRole.superadmin).length}'),
                _StatChip(icon: Icons.biotech_rounded, label: 'Lab techs', value: '${users.where((u) => u.role == AppUserRole.lab_tech).length}'),
                _StatChip(icon: Icons.person_pin_rounded, label: 'Referred persons', value: '${users.where((u) => u.role == AppUserRole.referred_person).length}'),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _searchController,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'Search name, username, role or center...',
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: _searchController.text.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          _searchController.clear();
                          setState(() {});
                        },
                        icon: const Icon(Icons.clear_rounded),
                      ),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: users.isEmpty
                  ? _buildEmptyState(context)
                  : ListView.separated(
                      itemCount: users.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (context, index) {
                        final user = users[index];
                        return _UserTile(
                          user: user,
                          selected: user.id == _editingId,
                          onEdit: () => _startEdit(user),
                          onDelete: _saving ? null : () => _deleteUser(user),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.people_outline_rounded, size: 52, color: Theme.of(context).colorScheme.outline),
          const SizedBox(height: 12),
          Text('No users found', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          const Text('Add a new user or change your search keyword.'),
        ],
      ),
    );
  }

  Widget _buildErrorState(BuildContext context, String message) {
    return Center(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.error_outline_rounded, size: 48, color: Theme.of(context).colorScheme.error),
              const SizedBox(height: 12),
              const Text('Failed to load users'),
              const SizedBox(height: 8),
              Text(message, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () => ref.invalidate(usersProvider),
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Try again'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _UserTile extends StatelessWidget {
  const _UserTile({
    required this.user,
    required this.selected,
    required this.onEdit,
    required this.onDelete,
  });

  final SheetUser user;
  final bool selected;
  final VoidCallback onEdit;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: selected ? theme.colorScheme.primaryContainer : theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.52),
        border: Border.all(
          color: selected ? theme.colorScheme.primary : theme.colorScheme.outlineVariant.withValues(alpha: 0.35),
        ),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: selected ? theme.colorScheme.primary : theme.colorScheme.surface,
            foregroundColor: selected ? theme.colorScheme.onPrimary : theme.colorScheme.primary,
            child: Text(user.name.isNotEmpty ? user.name.characters.first.toUpperCase() : 'U'),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user.name, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text('${user.username} • ${user.subCenterId}'),
              ],
            ),
          ),
          _RolePill(role: user.role),
          const SizedBox(width: 8),
          IconButton.filledTonal(
            tooltip: 'Edit user',
            onPressed: onEdit,
            icon: const Icon(Icons.edit_rounded),
          ),
          const SizedBox(width: 4),
          IconButton.filledTonal(
            tooltip: 'Delete user',
            onPressed: onDelete,
            icon: Icon(Icons.delete_outline_rounded, color: theme.colorScheme.error),
          ),
        ],
      ),
    );
  }
}

class _RolePill extends StatelessWidget {
  const _RolePill({required this.role});

  final AppUserRole role;

  @override
  Widget build(BuildContext context) {
    final color = switch (role) {
      AppUserRole.superadmin => Colors.purple,
      AppUserRole.admin => Colors.blue,
      AppUserRole.lab_tech => Colors.teal,
      AppUserRole.staff => Colors.orange,
      AppUserRole.referred_person => Colors.indigo,
    };

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: color.withValues(alpha: 0.12),
      ),
      child: Text(role.name.replaceAll('_', ' '), style: TextStyle(color: color, fontWeight: FontWeight.w900)),
    );
  }
}

class _StatChip extends StatelessWidget {
  const _StatChip({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: theme.colorScheme.secondaryContainer.withValues(alpha: 0.72),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 20),
          const SizedBox(width: 8),
          Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w700)),
          Text(value),
        ],
      ),
    );
  }
}
