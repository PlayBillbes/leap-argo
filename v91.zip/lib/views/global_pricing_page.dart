import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../config/google_config.dart';
import '../models/app_user.dart';
import '../models/lab_test.dart';
import '../providers/auth_notifier.dart';
import '../providers/tests_provider.dart';
import '../services/turso_native_service.dart';
import '../widgets/app_sidebar.dart';

class GlobalPricingPage extends ConsumerStatefulWidget {
  const GlobalPricingPage({super.key});

  @override
  ConsumerState<GlobalPricingPage> createState() => _GlobalPricingPageState();
}

class _GlobalPricingPageState extends ConsumerState<GlobalPricingPage> {
  static const _sheetName = 'Tests';
  static const _testsRange = 'Tests!A:C';
  static const _manualDefaultsSheetName = 'ManualTestDefaults';
  static const _manualDefaultsRange = 'ManualTestDefaults!A:G';
  static const _manualDefaultsHeaders = <String>[
    'testId',
    'testName',
    'parameter',
    'unit',
    'referenceRange',
    'note',
    'sortOrder',
  ];

  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _priceController = TextEditingController();
  final _manualDefaultsController = TextEditingController();
  final _searchController = TextEditingController();

  bool _saving = false;
  String? _editingId;

  bool get _isEditing => _editingId != null;

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    _manualDefaultsController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<TursoNativeService> _newSheetsService() async {
    final serviceAccountJson = await rootBundle.loadString(
      'assets/service-account.json',
    );
    return TursoNativeService(
      serviceAccountJson: serviceAccountJson,
      applicationName: 'flutterlab',
    );
  }

  Future<int> _findSheetRowByTestId(
    TursoNativeService service,
    String testId,
  ) async {
    final rows = await service.fetchRows(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: _testsRange,
    );

    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      if (row.isNotEmpty && row.first == testId) {
        return i + 1; // Google Sheets rows are 1-based. Header row is row 1.
      }
    }

    throw StateError('Test row was not found. Please refresh and try again.');
  }

  Future<void> _saveTest() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _saving = true);

    TursoNativeService? service;
    try {
      service = await _newSheetsService();
      final name = _nameController.text.trim();
      final price = double.tryParse(_priceController.text.trim()) ?? 0.0;
      late final LabTest savedTest;

      if (_isEditing) {
        final rowNumber = await _findSheetRowByTestId(service, _editingId!);
        await service.updateRow(
          spreadsheetId: GoogleConfig.spreadsheetId,
          range: 'Tests!A$rowNumber:C$rowNumber',
          values: [_editingId!, name, price.toStringAsFixed(2)],
        );
        savedTest = LabTest(id: _editingId!, testName: name, defaultPrice: price);
      } else {
        final id = DateTime.now().millisecondsSinceEpoch.toString();
        await service.insertRow(
          spreadsheetId: GoogleConfig.spreadsheetId,
          range: _testsRange,
          values: [id, name, price.toStringAsFixed(2)],
        );
        savedTest = LabTest(id: id, testName: name, defaultPrice: price);
      }

      final defaultLines = _parseManualDefaultLines(_manualDefaultsController.text);
      if (_isEditing || _manualDefaultsController.text.trim().isNotEmpty) {
        await _saveManualDefaultsForTest(savedTest, defaultLines, showMessage: false);
      }

      _showSnackBar(_isEditing ? 'Test and defaults updated successfully' : 'Test and defaults added successfully');
      _clearForm();
      ref.invalidate(testsProvider);
    } catch (e) {
      _showSnackBar('Save failed: $e', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  List<_ManualDefaultLine> _parseManualDefaultLines(String rawText) {
    return rawText
        .split('\n')
        .map((raw) {
          final parts = raw.split('|').map((part) => part.trim()).toList();
          return _ManualDefaultLine(
            parameter: parts.isNotEmpty ? parts[0] : '',
            unit: parts.length > 1 ? parts[1] : '',
            referenceRange: parts.length > 2 ? parts[2] : '',
            note: parts.length > 3 ? parts.sublist(3).join(' | ') : '',
          );
        })
        .where((line) => line.parameter.trim().isNotEmpty)
        .toList();
  }

  String _manualDefaultLinesText(List<_ManualDefaultLine> lines) {
    return lines
        .map((line) => '${line.parameter} | ${line.unit} | ${line.referenceRange} | ${line.note}')
        .join('\n');
  }

  String _normalizeManualKey(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  Future<List<_ManualDefaultLine>> _fetchManualDefaultsForTest(TursoNativeService service, LabTest test) async {
    await service.ensureSheet(
      spreadsheetId: GoogleConfig.spreadsheetId,
      sheetName: _manualDefaultsSheetName,
    );
    await service.updateRow(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'ManualTestDefaults!A1:G1',
      values: _manualDefaultsHeaders,
    );
    final rows = await service.fetchRows(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: _manualDefaultsRange,
    );
    if (rows.length < 2) return const <_ManualDefaultLine>[];
    final headers = rows.first.map((h) => _normalizeManualKey(h)).toList();
    int indexOf(String key) => headers.indexOf(key);
    final testIdIndex = indexOf('testid');
    final testNameIndex = indexOf('testname');
    final parameterIndex = indexOf('parameter');
    final unitIndex = indexOf('unit');
    final refIndex = indexOf('referencerange');
    final noteIndex = indexOf('note');
    final targetId = _normalizeManualKey(test.id);
    final targetName = _normalizeManualKey(test.testName);
    final defaults = <_ManualDefaultLine>[];
    for (final row in rows.skip(1)) {
      String cell(int index) => index >= 0 && index < row.length ? row[index].trim() : '';
      final rowTestId = cell(testIdIndex);
      final rowTestName = cell(testNameIndex);
      final matches = _normalizeManualKey(rowTestId) == targetId || _normalizeManualKey(rowTestName) == targetName;
      if (!matches) continue;
      defaults.add(
        _ManualDefaultLine(
          parameter: cell(parameterIndex),
          unit: cell(unitIndex),
          referenceRange: cell(refIndex),
          note: cell(noteIndex),
        ),
      );
    }
    return defaults;
  }

  Future<void> _saveManualDefaultsForTest(
    LabTest test,
    List<_ManualDefaultLine> lines, {
    bool showMessage = true,
  }) async {
    if (showMessage) setState(() => _saving = true);
    TursoNativeService? service;
    try {
      service = await _newSheetsService();
      await service.ensureSheet(
        spreadsheetId: GoogleConfig.spreadsheetId,
        sheetName: _manualDefaultsSheetName,
      );
      await service.updateRow(
        spreadsheetId: GoogleConfig.spreadsheetId,
        range: 'ManualTestDefaults!A1:G1',
        values: _manualDefaultsHeaders,
      );
      final rows = await service.fetchRows(
        spreadsheetId: GoogleConfig.spreadsheetId,
        range: _manualDefaultsRange,
      );
      if (rows.length > 1) {
        final headers = rows.first.map((h) => _normalizeManualKey(h)).toList();
        final testIdIndex = headers.indexOf('testid');
        final testNameIndex = headers.indexOf('testname');
        final targetId = _normalizeManualKey(test.id);
        final targetName = _normalizeManualKey(test.testName);
        for (var i = rows.length - 1; i >= 1; i--) {
          final row = rows[i];
          String cell(int index) => index >= 0 && index < row.length ? row[index].trim() : '';
          final matches = _normalizeManualKey(cell(testIdIndex)) == targetId || _normalizeManualKey(cell(testNameIndex)) == targetName;
          if (matches) {
            await service.deleteRow(
              spreadsheetId: GoogleConfig.spreadsheetId,
              sheetName: _manualDefaultsSheetName,
              rowIndexOneBased: i + 1,
            );
          }
        }
      }
      var order = 1;
      for (final line in lines.where((line) => line.parameter.trim().isNotEmpty)) {
        await service.insertRow(
          spreadsheetId: GoogleConfig.spreadsheetId,
          range: _manualDefaultsRange,
          values: [
            test.id,
            test.testName,
            line.parameter.trim(),
            line.unit.trim(),
            line.referenceRange.trim(),
            line.note.trim(),
            order.toString(),
          ],
          valueInputOption: 'RAW',
        );
        order++;
      }
      if (showMessage) {
        _showSnackBar('Manual result defaults saved for ${test.testName}');
      }
    } catch (error) {
      _showSnackBar('Default save failed: $error', isError: true);
      if (!showMessage) rethrow;
    } finally {
      await service?.close();
      if (showMessage && mounted) setState(() => _saving = false);
    }
  }

  Future<void> _openManualDefaultsDialog(LabTest test) async {
    setState(() => _saving = true);
    TursoNativeService? service;
    try {
      service = await _newSheetsService();
      final existing = await _fetchManualDefaultsForTest(service, test);
      if (!mounted) return;
      final result = await showDialog<List<_ManualDefaultLine>>(
        context: context,
        builder: (context) => _ManualDefaultsDialog(test: test, existing: existing),
      );
      if (result == null) return;
      await _saveManualDefaultsForTest(test, result);
    } catch (error) {
      _showSnackBar('Could not open defaults: $error', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _deleteTest(LabTest test) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete test?'),
        content: Text(
          'This will remove "${test.testName}" from the global pricing list.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
              foregroundColor: Theme.of(context).colorScheme.onError,
            ),
            onPressed: () => Navigator.of(context).pop(true),
            icon: const Icon(Icons.delete_outline_rounded),
            label: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    setState(() => _saving = true);

    TursoNativeService? service;
    try {
      service = await _newSheetsService();
      final rowNumber = await _findSheetRowByTestId(service, test.id);
      await service.deleteRow(
        spreadsheetId: GoogleConfig.spreadsheetId,
        sheetName: _sheetName,
        rowIndexOneBased: rowNumber,
      );

      if (_editingId == test.id) _clearForm();
      ref.invalidate(testsProvider);
      _showSnackBar('Test deleted successfully');
    } catch (e) {
      _showSnackBar('Delete failed: $e', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  void _startEdit(LabTest test) {
    setState(() {
      _editingId = test.id;
      _nameController.text = test.testName;
      _priceController.text = test.defaultPrice.toStringAsFixed(2);
      _manualDefaultsController.clear();
    });
    _loadManualDefaultsIntoEditor(test);
  }

  Future<void> _loadManualDefaultsIntoEditor(LabTest test) async {
    TursoNativeService? service;
    try {
      service = await _newSheetsService();
      final lines = await _fetchManualDefaultsForTest(service, test);
      if (!mounted || _editingId != test.id) return;
      setState(() {
        _manualDefaultsController.text = lines.isEmpty
            ? '${test.testName} |  |  | '
            : _manualDefaultLinesText(lines);
      });
    } catch (_) {
      if (!mounted || _editingId != test.id) return;
      setState(() {
        _manualDefaultsController.text = '${test.testName} |  |  | ';
      });
    } finally {
      await service?.close();
    }
  }

  void _clearForm() {
    setState(() {
      _editingId = null;
      _nameController.clear();
      _priceController.clear();
      _manualDefaultsController.clear();
    });
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final testsAsync = ref.watch(testsProvider);
    final user = ref.watch(authNotifierProvider);

    return AppScaffold(
      title: 'Global Pricing',
      selectedRoute: '/global-pricing',
      user: user,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Refresh tests',
          onPressed: _saving ? null : () => ref.invalidate(testsProvider),
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHero(context),
            const SizedBox(height: 18),
            Expanded(
              child: testsAsync.when(
                data: (tests) => _buildPricingContent(context, tests),
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (error, stack) => _buildErrorState(
                  context,
                  error.toString(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHero(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: LinearGradient(
          colors: [
            theme.colorScheme.primary,
            theme.colorScheme.tertiary,
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: theme.colorScheme.primary.withValues(alpha: 0.24),
            blurRadius: 30,
            offset: const Offset(0, 18),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Icon(
              Icons.price_change_rounded,
              color: Colors.white,
              size: 34,
            ),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Global Test Pricing',
                  style: theme.textTheme.headlineSmall?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Create, edit, update, and delete lab tests with default prices.',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: Colors.white.withValues(alpha: 0.86),
                  ),
                ),
              ],
            ),
          ),
          if (_isEditing)
            FilledButton.tonalIcon(
              onPressed: _saving ? null : _clearForm,
              icon: const Icon(Icons.close_rounded),
              label: const Text('Cancel edit'),
            ),
        ],
      ),
    );
  }

  Widget _buildPricingContent(BuildContext context, List<LabTest> tests) {
    final query = _searchController.text.trim().toLowerCase();
    final filteredTests = query.isEmpty
        ? tests
        : tests
              .where(
                (test) =>
                    test.testName.toLowerCase().contains(query) ||
                    test.defaultPrice.toStringAsFixed(2).contains(query),
              )
              .toList();

    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 820;
        if (compact) {
          return Column(
            children: [
              _buildEditorCard(context, tests.length),
              const SizedBox(height: 16),
              Expanded(
                child: _buildTestsList(context, filteredTests, tests.length),
              ),
            ],
          );
        }

        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(width: 380, child: _buildEditorCard(context, tests.length)),
            const SizedBox(width: 18),
            Expanded(
              child: _buildTestsList(context, filteredTests, tests.length),
            ),
          ],
        );
      },
    );
  }

  Widget _buildEditorCard(BuildContext context, int totalTests) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    backgroundColor: theme.colorScheme.primaryContainer,
                    foregroundColor: theme.colorScheme.onPrimaryContainer,
                    child: Icon(
                      _isEditing
                          ? Icons.edit_note_rounded
                          : Icons.add_business_rounded,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _isEditing ? 'Update Test' : 'Add New Test',
                          style: theme.textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        Text('$totalTests tests in global price list'),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              TextFormField(
                controller: _nameController,
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'Test name',
                  hintText: 'Example: CBC',
                  prefixIcon: Icon(Icons.biotech_rounded),
                  border: OutlineInputBorder(),
                ),
                validator: (value) => (value == null || value.trim().isEmpty)
                    ? 'Enter test name'
                    : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _priceController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'Default price',
                  hintText: 'Example: 1500',
                  prefixIcon: Icon(Icons.payments_rounded),
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    (value == null || double.tryParse(value.trim()) == null)
                    ? 'Enter valid price'
                    : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _manualDefaultsController,
                minLines: 4,
                maxLines: 8,
                decoration: const InputDecoration(
                  labelText: 'Manual result defaults',
                  helperText: 'One parameter per line: Parameter | Unit | Reference range | Default note',
                  hintText: 'ESR | mm/hr | 0-20 | Default ESR note\n'
                      'T3 | ng/dL | 80-200 | \n'
                      'T4 | ug/dL | 4.5-12.5 | \n'
                      'TSH | uIU/mL | 0.4-4.0 | ',
                  prefixIcon: Icon(Icons.fact_check_rounded),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _saving ? null : _saveTest,
                  icon: _saving
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Icon(
                          _isEditing
                              ? Icons.save_as_rounded
                              : Icons.add_rounded,
                        ),
                  label: Text(_isEditing ? 'Update Test' : 'Add Test'),
                ),
              ),
              if (_isEditing) ...[
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: _saving ? null : _clearForm,
                    icon: const Icon(Icons.close_rounded),
                    label: const Text('Cancel Edit'),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTestsList(
    BuildContext context,
    List<LabTest> tests,
    int totalTests,
  ) {
    final theme = Theme.of(context);
    final totalValue = tests.fold<double>(
      0,
      (sum, test) => sum + test.defaultPrice,
    );

    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 12,
              runSpacing: 12,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                _StatChip(
                  icon: Icons.science_rounded,
                  label: 'Tests',
                  value: '$totalTests',
                ),
                _StatChip(
                  icon: Icons.account_balance_wallet_rounded,
                  label: 'Shown total',
                  value: totalValue.toStringAsFixed(2),
                ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _searchController,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'Search tests or price...',
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: _searchController.text.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          _searchController.clear();
                          setState(() {});
                        },
                        icon: const Icon(Icons.clear_rounded),
                      ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: tests.isEmpty
                  ? _buildEmptyState(context)
                  : ListView.separated(
                      itemCount: tests.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (context, index) {
                        final test = tests[index];
                        return _TestPriceTile(
                          test: test,
                          selected: test.id == _editingId,
                          onEdit: () => _startEdit(test),
                          onDefaults: _saving ? null : () => _openManualDefaultsDialog(test),
                          onDelete: _saving ? null : () => _deleteTest(test),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.inventory_2_outlined,
            size: 52,
            color: Theme.of(context).colorScheme.outline,
          ),
          const SizedBox(height: 12),
          Text(
            'No tests found',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 4),
          const Text('Add a new test or change your search keyword.'),
        ],
      ),
    );
  }

  Widget _buildErrorState(BuildContext context, String message) {
    return Center(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.error_outline_rounded,
                size: 48,
                color: Theme.of(context).colorScheme.error,
              ),
              const SizedBox(height: 12),
              const Text('Failed to load tests'),
              const SizedBox(height: 8),
              Text(message, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () => ref.invalidate(testsProvider),
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Try again'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PricingSidebar extends StatelessWidget {
  const _PricingSidebar({required this.user});

  final AppUser? user;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: 270,
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        color: theme.colorScheme.surface.withValues(alpha: 0.86),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 30,
            offset: const Offset(0, 16),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: theme.colorScheme.primary,
                foregroundColor: theme.colorScheme.onPrimary,
                child: const Icon(Icons.local_hospital_rounded),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'LabOps',
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 22),
          _PricingNavItem(
            icon: Icons.dashboard_rounded,
            label: 'Dashboard',
            route: '/',
            selected: false,
          ),
          _PricingNavItem(
            icon: Icons.group_rounded,
            label: 'Users',
            route: '/users',
            selected: false,
          ),
          _PricingNavItem(
            icon: Icons.price_change_rounded,
            label: 'Global Pricing',
            route: '/global-pricing',
            selected: true,
          ),
          _PricingNavItem(
            icon: Icons.storefront_rounded,
            label: 'Sub-center Pricing',
            route: '/sub-center-pricing',
            selected: false,
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              color: theme.colorScheme.primaryContainer,
            ),
            child: Row(
              children: [
                CircleAvatar(
                  child: Text((user?.name ?? 'U').characters.first),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user?.name ?? 'User',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      Text(user?.role.name ?? 'guest'),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PricingDrawer extends StatelessWidget {
  const _PricingDrawer({required this.user});

  final AppUser? user;

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            ListTile(
              leading: const CircleAvatar(
                child: Icon(Icons.local_hospital_rounded),
              ),
              title: const Text(
                'LabOps',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
              subtitle: Text(user?.role.name ?? 'guest'),
            ),
            const SizedBox(height: 16),
            _PricingNavItem(
              icon: Icons.dashboard_rounded,
              label: 'Dashboard',
              route: '/',
              selected: false,
            ),
            _PricingNavItem(
              icon: Icons.group_rounded,
              label: 'Users',
              route: '/users',
              selected: false,
            ),
            _PricingNavItem(
              icon: Icons.price_change_rounded,
              label: 'Global Pricing',
              route: '/global-pricing',
              selected: true,
            ),
            _PricingNavItem(
              icon: Icons.storefront_rounded,
              label: 'Sub-center Pricing',
              route: '/sub-center-pricing',
              selected: false,
            ),
          ],
        ),
      ),
    );
  }
}

class _PricingNavItem extends StatelessWidget {
  const _PricingNavItem({
    required this.icon,
    required this.label,
    required this.route,
    required this.selected,
  });

  final IconData icon;
  final String label;
  final String route;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => context.go(route),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            color: selected ? theme.colorScheme.primaryContainer : null,
          ),
          child: Row(
            children: [
              Icon(
                icon,
                color: selected
                    ? theme.colorScheme.primary
                    : theme.colorScheme.onSurfaceVariant,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  const _StatChip({
    required this.icon,
    required this.label,
    required this.value,
  });

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: theme.colorScheme.secondaryContainer.withValues(alpha: 0.72),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 20),
          const SizedBox(width: 8),
          Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w700)),
          Text(value),
        ],
      ),
    );
  }
}

class _ManualDefaultLine {
  const _ManualDefaultLine({
    required this.parameter,
    required this.unit,
    required this.referenceRange,
    required this.note,
  });

  final String parameter;
  final String unit;
  final String referenceRange;
  final String note;
}

class _ManualDefaultsDialog extends StatefulWidget {
  const _ManualDefaultsDialog({required this.test, required this.existing});

  final LabTest test;
  final List<_ManualDefaultLine> existing;

  @override
  State<_ManualDefaultsDialog> createState() => _ManualDefaultsDialogState();
}

class _ManualDefaultsDialogState extends State<_ManualDefaultsDialog> {
  late final TextEditingController _linesController;

  @override
  void initState() {
    super.initState();
    final seed = widget.existing.isNotEmpty
        ? widget.existing
            .map((line) => '${line.parameter} | ${line.unit} | ${line.referenceRange} | ${line.note}')
            .join('\n')
        : widget.test.testName.toLowerCase().contains('thyroid')
            ? 'T3 |  |  | \nT4 |  |  | \nTSH |  |  | '
            : '${widget.test.testName} |  |  | ';
    _linesController = TextEditingController(text: seed);
  }

  @override
  void dispose() {
    _linesController.dispose();
    super.dispose();
  }

  List<_ManualDefaultLine> _parseLines() {
    return _linesController.text
        .split('\n')
        .map((raw) {
          final parts = raw.split('|').map((part) => part.trim()).toList();
          return _ManualDefaultLine(
            parameter: parts.isNotEmpty ? parts[0] : '',
            unit: parts.length > 1 ? parts[1] : '',
            referenceRange: parts.length > 2 ? parts[2] : '',
            note: parts.length > 3 ? parts.sublist(3).join(' | ') : '',
          );
        })
        .where((line) => line.parameter.trim().isNotEmpty)
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Manual defaults: ${widget.test.testName}'),
      content: SizedBox(
        width: 680,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Enter one parameter per line using: Parameter | Unit | Reference range | Default note'),
            const SizedBox(height: 10),
            TextField(
              controller: _linesController,
              minLines: 6,
              maxLines: 12,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'ESR | mm/hr | 0-20 | Default note\nT3 | ng/dL | 80-200 | ',
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
        FilledButton.icon(
          onPressed: () => Navigator.of(context).pop(_parseLines()),
          icon: const Icon(Icons.save_rounded),
          label: const Text('Save Defaults'),
        ),
      ],
    );
  }
}

class _TestPriceTile extends StatelessWidget {
  const _TestPriceTile({
    required this.test,
    required this.selected,
    required this.onEdit,
    required this.onDefaults,
    required this.onDelete,
  });

  final LabTest test;
  final bool selected;
  final VoidCallback onEdit;
  final VoidCallback? onDefaults;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: selected
            ? theme.colorScheme.primaryContainer
            : theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.52),
        border: Border.all(
          color: selected
              ? theme.colorScheme.primary
              : theme.colorScheme.outlineVariant.withValues(alpha: 0.35),
        ),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: selected
                ? theme.colorScheme.primary
                : theme.colorScheme.surface,
            foregroundColor: selected
                ? theme.colorScheme.onPrimary
                : theme.colorScheme.primary,
            child: const Icon(Icons.science_rounded),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  test.testName,
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text('ID: ${test.id}'),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: theme.colorScheme.primary.withValues(alpha: 0.10),
            ),
            child: Text(
              test.defaultPrice.toStringAsFixed(2),
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w900,
                color: theme.colorScheme.primary,
              ),
            ),
          ),
          const SizedBox(width: 8),
          IconButton.filledTonal(
            tooltip: 'Edit test',
            onPressed: onEdit,
            icon: const Icon(Icons.edit_rounded),
          ),
          const SizedBox(width: 4),
          IconButton.filledTonal(
            tooltip: 'Manual result defaults',
            onPressed: onDefaults,
            icon: const Icon(Icons.rule_folder_rounded),
          ),
          const SizedBox(width: 4),
          IconButton.filledTonal(
            tooltip: 'Delete test',
            onPressed: onDelete,
            icon: Icon(
              Icons.delete_outline_rounded,
              color: theme.colorScheme.error,
            ),
          ),
        ],
      ),
    );
  }
}
