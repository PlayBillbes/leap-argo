import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../models/app_user.dart';
import '../models/blood_sample.dart';
import '../models/lab_test.dart';
import '../models/sub_center_pricing.dart';
import '../providers/auth_notifier.dart';
import '../providers/sample_dashboard_controller.dart';
import '../providers/tests_provider.dart';
import '../config/google_config.dart';
import '../services/google_drive_service.dart';
import '../services/turso_native_service.dart';
import '../utils/report_generator.dart';
import '../widgets/app_sidebar.dart';

class DashboardView extends ConsumerWidget {
  const DashboardView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final user = ref.watch(authNotifierProvider);
    final samplesAsync = ref.watch(sampleDashboardControllerProvider);

    return AppScaffold(
      title: 'Lab Dashboard',
      selectedRoute: '/',
      user: user,
      actions: [
        FilledButton.icon(
          onPressed: () {
            ref.invalidate(sampleDashboardControllerProvider);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Refreshing samples...')),
            );
          },
          icon: const Icon(Icons.refresh_rounded),
          label: const Text('Refresh'),
        ),
      ],
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _HeroHeader(user: user),
            const SizedBox(height: 18),
            Expanded(
              child: samplesAsync.when(
                data: (samples) => _DashboardContent(samples: samples),
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (error, stack) => _ErrorCard(
                  message: 'Failed to load samples: $error',
                  onRetry: () => ref.invalidate(sampleDashboardControllerProvider),
                ),
              ),
            ),
            ],
          ),
        ),
    );
  }
}

class _HeroHeader extends StatelessWidget {
  const _HeroHeader({required this.user});

  final AppUser? user;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final roleLabel = user?.role.name ?? 'guest';
    final centerLabel = user?.subCenterId ?? 'Global Network';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: LinearGradient(
          colors: [theme.colorScheme.primary, theme.colorScheme.tertiary],
        ),
        boxShadow: [
          BoxShadow(
            color: theme.colorScheme.primary.withValues(alpha: 0.24),
            blurRadius: 30,
            offset: const Offset(0, 18),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Icon(
              Icons.monitor_heart_rounded,
              color: Colors.white,
              size: 36,
            ),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Welcome back, ${user?.name ?? 'User'}',
                  style: theme.textTheme.headlineSmall?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  user?.role == AppUserRole.staff
                      ? '$roleLabel • $centerLabel • Sample registration and cost overview'
                      : user?.role == AppUserRole.lab_tech
                          ? '$roleLabel • $centerLabel • Test review overview'
                          : '$roleLabel • $centerLabel • Live sample and revenue overview',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: Colors.white.withValues(alpha: 0.86),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              color: Colors.white.withValues(alpha: 0.16),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.verified_rounded, color: Colors.white),
                SizedBox(width: 8),
                Text('Online', style: TextStyle(color: Colors.white)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


class _DashboardContent extends ConsumerWidget {
  const _DashboardContent({required this.samples});

  final List<BloodSample> samples;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final user = ref.watch(authNotifierProvider);
    final testsAsync = ref.watch(testsProvider);
    final pricingsAsync = ref.watch(pricingsProvider);

    final tests = testsAsync.maybeWhen(
      data: (items) => items,
      orElse: () => const <LabTest>[],
    );
    final pricings = pricingsAsync.maybeWhen(
      data: (items) => items,
      orElse: () => const <SubCenterPricing>[],
    );

    final isStaff = user?.role == AppUserRole.staff;
    final isReferredPerson = user?.role == AppUserRole.referred_person;
    String normalizeReferral(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
    final dashboardSamples = isReferredPerson && user != null
        ? samples.where((sample) {
            final referredId = normalizeReferral(sample.referredPersonId ?? '');
            final referredName = normalizeReferral(sample.referredPersonName ?? '');
            final userId = normalizeReferral(user.id);
            final userName = normalizeReferral(user.name);
            return referredId.isNotEmpty && referredId != 'self' &&
                (referredId == userId || (userName.isNotEmpty && referredName == userName));
          }).toList()
        : samples;
    final report = ReportGenerator(
      samples: dashboardSamples,
      tests: tests,
      pricings: pricings,
      useCustomerPrices: user?.role != AppUserRole.superadmin,
    );
    final now = DateTime.now();
    final daily = report.totalDailyRevenue(now);
    final monthly = report.totalMonthlyRevenue(now);
    final yearly = report.totalYearlyRevenue(now);
    final dailyTests = report.totalDailyTests(now);
    final monthlyTests = report.totalMonthlyTests(now);
    final yearlyTests = report.totalYearlyTests(now);
    final monthlyProfit = report.totalMonthlyProfit(now);
    final dailyReferredFee = report.totalDailyReferredFee(now);
    final monthlyReferredFee = report.totalMonthlyReferredFee(now);
    final totalReferredFee = report.totalReferredFee();
    final isLabTech = user?.role == AppUserRole.lab_tech;
    final pendingTodayByTest = report.pendingTestCountByNameForDay(now);
    final labTechTodayTotal = report.totalDailyTests(now);
    final labTechMonthTotal = report.totalMonthlyTests(now);
    final labTechYearTotal = report.totalYearlyTests(now);
    final summary = report.groupedRevenueSummary(includeCounts: true);

    final pending = dashboardSamples
        .where((sample) => sample.status == BloodSampleStatus.pending)
        .length;
    final processing = dashboardSamples
        .where((sample) => sample.status == BloodSampleStatus.processing)
        .length;
    final completed = dashboardSamples
        .where((sample) => sample.status == BloodSampleStatus.completed)
        .length;

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 920;
              final cards = isReferredPerson
                  ? [
                      _MetricCard(
                        title: 'Tests Today',
                        value: dailyTests.toString(),
                        subtitle: 'Your referred tests today',
                        icon: Icons.today_rounded,
                        color: const Color(0xFF2563EB),
                      ),
                      _MetricCard(
                        title: 'Tests This Month',
                        value: monthlyTests.toString(),
                        subtitle: 'Your referred tests this month',
                        icon: Icons.calendar_month_rounded,
                        color: const Color(0xFF059669),
                      ),
                      _MetricCard(
                        title: 'Tests This Year',
                        value: yearlyTests.toString(),
                        subtitle: 'Your referred tests this year',
                        icon: Icons.auto_graph_rounded,
                        color: const Color(0xFF7C3AED),
                      ),
                      _MetricCard(
                        title: 'Today Refer Fee',
                        value: dailyReferredFee.toStringAsFixed(2),
                        subtitle: 'Refer fee earned today',
                        icon: Icons.person_pin_circle_rounded,
                        color: const Color(0xFFF59E0B),
                      ),
                      _MetricCard(
                        title: 'This Month Refer Fee',
                        value: monthlyReferredFee.toStringAsFixed(2),
                        subtitle: 'Refer fee earned this month',
                        icon: Icons.payments_rounded,
                        color: const Color(0xFFEA580C),
                      ),
                      _MetricCard(
                        title: 'Total Refer Fee',
                        value: totalReferredFee.toStringAsFixed(2),
                        subtitle: 'All referred tests shown below',
                        icon: Icons.savings_rounded,
                        color: const Color(0xFF0EA5E9),
                      ),
                    ]
                  : isLabTech
                  ? [
                      _MetricCard(
                        title: 'Tests / Today',
                        value: labTechTodayTotal.toString(),
                        subtitle: 'Total tests today',
                        icon: Icons.pending_actions_rounded,
                        color: const Color(0xFF2563EB),
                      ),
                      _MetricCard(
                        title: 'Tests / This Month',
                        value: labTechMonthTotal.toString(),
                        subtitle: 'Total tests this month',
                        icon: Icons.calendar_month_rounded,
                        color: const Color(0xFF059669),
                      ),
                      _MetricCard(
                        title: 'Tests / This Year',
                        value: labTechYearTotal.toString(),
                        subtitle: 'Total tests this year',
                        icon: Icons.auto_graph_rounded,
                        color: const Color(0xFF7C3AED),
                      ),
                      _MetricCard(
                        title: 'Pending Samples',
                        value: pending.toString(),
                        subtitle: 'Samples waiting review',
                        icon: Icons.science_rounded,
                        color: const Color(0xFFEA580C),
                      ),
                    ]
                  : isStaff
                  ? [
                      _MetricCard(
                        title: 'Today Tests',
                        value: dailyTests.toString(),
                        subtitle: 'Tests requested today',
                        icon: Icons.today_rounded,
                        color: const Color(0xFF2563EB),
                      ),
                      _MetricCard(
                        title: 'This Month Tests',
                        value: monthlyTests.toString(),
                        subtitle: 'Tests requested this month',
                        icon: Icons.calendar_month_rounded,
                        color: const Color(0xFF059669),
                      ),
                      _MetricCard(
                        title: 'This Year Tests',
                        value: yearlyTests.toString(),
                        subtitle: 'Tests requested this year',
                        icon: Icons.auto_graph_rounded,
                        color: const Color(0xFF7C3AED),
                      ),
                      _MetricCard(
                        title: 'This Month Cost',
                        value: monthly.toStringAsFixed(2),
                        subtitle: 'Cost by sub-center custom price',
                        icon: Icons.payments_rounded,
                        color: const Color(0xFFEA580C),
                      ),
                    ]
                  : [
                      _MetricCard(
                        title: 'Today',
                        value: daily.toStringAsFixed(2),
                        subtitle: 'Daily revenue',
                        icon: Icons.today_rounded,
                        color: const Color(0xFF2563EB),
                      ),
                      _MetricCard(
                        title: 'This Month',
                        value: monthly.toStringAsFixed(2),
                        subtitle: 'Monthly revenue',
                        icon: Icons.calendar_month_rounded,
                        color: const Color(0xFF059669),
                      ),
                      _MetricCard(
                        title: 'This Year',
                        value: yearly.toStringAsFixed(2),
                        subtitle: 'Yearly revenue',
                        icon: Icons.auto_graph_rounded,
                        color: const Color(0xFF7C3AED),
                      ),
                      _MetricCard(
                        title: 'This Month Profit',
                        value: monthlyProfit.toStringAsFixed(2),
                        subtitle: user?.role == AppUserRole.superadmin
                            ? 'Superadmin uses default price'
                            : 'Custom - global - refer fee',
                        icon: Icons.trending_up_rounded,
                        color: const Color(0xFFEA580C),
                      ),
                      if (user?.role != AppUserRole.superadmin)
                        _MetricCard(
                          title: 'This Month Refer Fee',
                          value: monthlyReferredFee.toStringAsFixed(2),
                          subtitle: 'Paid when referral is not Self',
                          icon: Icons.person_pin_circle_rounded,
                          color: const Color(0xFFF59E0B),
                        ),
                    ];

              if (compact) {
                return Column(
                  children: cards
                      .map(
                        (card) => Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: card,
                        ),
                      )
                      .toList(),
                );
              }

              return Row(
                children: [
                  for (var i = 0; i < cards.length; i++) ...[
                    Expanded(child: cards[i]),
                    if (i != cards.length - 1) const SizedBox(width: 14),
                  ],
                ],
              );
            },
          ),
          if (isLabTech || isStaff) ...[
            const SizedBox(height: 18),
            _TodayPendingTestsCard(counts: pendingTodayByTest),
          ],
          if (!isStaff && !isReferredPerson) ...[
            const SizedBox(height: 18),
            LayoutBuilder(
              builder: (context, constraints) {
                final compact = constraints.maxWidth < 920;
                final statusCard = _StatusOverviewCard(
                  pending: pending,
                  processing: processing,
                  completed: completed,
                  total: dashboardSamples.length,
                );
                final summaryCard = _SummaryCard(summary: summary, isStaff: isStaff);

                if (compact) {
                  return Column(
                    children: [
                      statusCard,
                      const SizedBox(height: 14),
                      summaryCard,
                    ],
                  );
                }

                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(child: statusCard),
                    const SizedBox(width: 14),
                    Expanded(child: summaryCard),
                  ],
                );
              },
            ),
          ],
          if (isStaff && user != null) ...[
            const SizedBox(height: 18),
            Card(
              elevation: 0,
              color: theme.colorScheme.surface.withValues(alpha: 0.92),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: theme.colorScheme.primaryContainer,
                      foregroundColor: theme.colorScheme.onPrimaryContainer,
                      child: const Icon(Icons.addchart_rounded),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Register Blood Sample', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
                          const Text('Open the dedicated registration page to select searchable tests and create one sheet row per test.'),
                        ],
                      ),
                    ),
                    FilledButton.icon(
                      onPressed: () => context.go('/register-sample'),
                      icon: const Icon(Icons.arrow_forward_rounded),
                      label: const Text('Open'),
                    ),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 18),
          _SampleTable(
            user: user,
            samples: dashboardSamples,
            tests: tests,
            pricings: pricings,
          ),
        ],
      ),
    );
  }
}



class _TodayPendingTestsCard extends StatelessWidget {
  const _TodayPendingTestsCard({required this.counts});

  final Map<String, int> counts;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Pending Tests / Today',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 6),
            const Text('Shows only today pending tests, grouped as count / test name.'),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.45),
                border: Border.all(color: theme.colorScheme.outlineVariant),
              ),
              child: counts.isEmpty
                  ? Text(
                      'No pending tests today',
                      style: TextStyle(color: theme.colorScheme.outline),
                    )
                  : Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final entry in counts.entries)
                          Chip(
                            avatar: CircleAvatar(child: Text(entry.value.toString())),
                            label: Text('${entry.value} / ${entry.key}'),
                            visualDensity: VisualDensity.compact,
                          ),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.title,
    required this.value,
    required this.subtitle,
    required this.icon,
    required this.color,
  });

  final String title;
  final String value;
  final String subtitle;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Icon(icon, color: color, size: 30),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: theme.textTheme.titleMedium),
                  const SizedBox(height: 6),
                  Text(
                    value,
                    style: theme.textTheme.headlineSmall?.copyWith(
                      color: color,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  Text(subtitle, style: theme.textTheme.bodySmall),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusOverviewCard extends StatelessWidget {
  const _StatusOverviewCard({
    required this.pending,
    required this.processing,
    required this.completed,
    required this.total,
  });

  final int pending;
  final int processing;
  final int completed;
  final int total;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Sample Status',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _CountPill(label: 'Pending', value: pending, color: Colors.orange),
                _CountPill(label: 'Processing', value: processing, color: Colors.blue),
                _CountPill(label: 'Completed', value: completed, color: Colors.green),
                _CountPill(label: 'Total', value: total, color: theme.colorScheme.primary),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.summary, required this.isStaff});

  final RevenueSummary summary;
  final bool isStaff;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isStaff ? 'Grouped Tests Summary' : 'Grouped Revenue and Profit Summary',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _CountPill(
                  label: 'Sub-centers',
                  value: summary.bySubCenter.length,
                  color: theme.colorScheme.primary,
                ),
                _CountPill(
                  label: 'Statuses',
                  value: summary.byStatus.length,
                  color: Colors.indigo,
                ),
                _CountPill(
                  label: 'Sub-center counts',
                  value: summary.countBySubCenter.length,
                  color: Colors.teal,
                ),
                _CountPill(
                  label: 'Status counts',
                  value: summary.countByStatus.length,
                  color: Colors.purple,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _CountPill extends StatelessWidget {
  const _CountPill({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final int value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: color.withValues(alpha: 0.12),
        border: Border.all(color: color.withValues(alpha: 0.22)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            '$value',
            style: TextStyle(color: color, fontWeight: FontWeight.w900),
          ),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}



class _StaffRegisterSampleCard extends ConsumerStatefulWidget {
  const _StaffRegisterSampleCard({
    required this.user,
    required this.tests,
    required this.pricings,
  });

  final AppUser user;
  final List<LabTest> tests;
  final List<SubCenterPricing> pricings;

  @override
  ConsumerState<_StaffRegisterSampleCard> createState() =>
      _StaffRegisterSampleCardState();
}

class _StaffRegisterSampleCardState extends ConsumerState<_StaffRegisterSampleCard> {
  final _formKey = GlobalKey<FormState>();
  final _patientNameController = TextEditingController();
  final _patientAgeController = TextEditingController();
  final _patientAddressController = TextEditingController();
  String? _selectedSex;
  final Set<String> _selectedTestKeys = <String>{};
  bool _saving = false;

  @override
  void dispose() {
    _patientNameController.dispose();
    _patientAgeController.dispose();
    _patientAddressController.dispose();
    super.dispose();
  }

  String get _subCenterId {
    final raw = widget.user.subCenterId?.trim() ?? '';
    return raw.isEmpty ? 'GLOBAL' : raw;
  }

  String _testKey(LabTest test) => test.id.trim().isNotEmpty ? test.id.trim() : test.testName.trim();

  String _normalize(String value) =>
      value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  String _sampleDatePrefix(DateTime createdAt) {
    final day = createdAt.day.toString().padLeft(2, '0');
    final month = createdAt.month.toString().padLeft(2, '0');
    final year = (createdAt.year % 100).toString().padLeft(2, '0');
    return '$day$month$year';
  }

  String _sampleIdFor(DateTime createdAt) {
    final sequence = (createdAt.microsecondsSinceEpoch % 10000)
        .toString()
        .padLeft(4, '0');
    return '${_sampleDatePrefix(createdAt)}-$sequence';
  }

  double _customerPriceFor(LabTest test) {
    final normalizedCenter = _normalize(_subCenterId);
    final normalizedTestId = _normalize(test.id);
    final normalizedTestName = _normalize(test.testName);

    for (final pricing in widget.pricings) {
      if (_normalize(pricing.subCenterId) != normalizedCenter) continue;
      final pricingTest = _normalize(pricing.testId);
      if (pricingTest == normalizedTestId || pricingTest == normalizedTestName) {
        return pricing.customPrice > 0 ? pricing.customPrice : test.defaultPrice;
      }
    }

    return test.defaultPrice;
  }

  double get _selectedTotalCost {
    return widget.tests
        .where((test) => _selectedTestKeys.contains(_testKey(test)))
        .fold<double>(0, (sum, test) => sum + _customerPriceFor(test));
  }


  Future<List<String>> _buildBloodSampleInsertRow(
    TursoNativeService service, {
    required String sampleId,
    required String patientName,
    required String patientAge,
    required String patientSex,
    required String patientAddress,
    required String status,
    required String testIds,
    required String registeredByUserId,
    required String subCenterId,
    required String resultUrl,
    required String createdAt,
    required String updatedAt,
  }) async {
    final desiredHeaders = <String>[
      'id',
      'patientName',
      'status',
      'testIds',
      'registeredByUserId',
      'subCenterId',
      'resultUrl',
      'createdAt',
      'updatedAt',
      'patientAge',
      'patientSex',
      'patientAddress',
    ];

    final rows = await service.fetchRows(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'BloodSamples!A1:Z1',
    );

    var displayHeaders = rows.isEmpty || rows.first.isEmpty
        ? <String>[]
        : rows.first.map((header) => header.trim()).where((header) => header.isNotEmpty).toList();

    if (displayHeaders.isEmpty) {
      displayHeaders = List<String>.from(desiredHeaders);
    } else {
      final normalized = displayHeaders
          .map((header) => header.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
          .toSet();
      for (final header in desiredHeaders) {
        final key = header.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
        if (!normalized.contains(key)) {
          displayHeaders.add(header);
          normalized.add(key);
        }
      }
    }

    await service.updateRow(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'BloodSamples!A1:Z1',
      values: displayHeaders,
    );

    final headerMap = <String, String>{
      'id': sampleId,
      'sampleid': sampleId,
      'patientname': patientName,
      'patient': patientName,
      'name': patientName,
      'patientage': patientAge,
      'age': patientAge,
      'patientsex': patientSex,
      'sex': patientSex,
      'gender': patientSex,
      'patientaddress': patientAddress,
      'address': patientAddress,
      'status': status,
      'testids': testIds,
      'tests': testIds,
      'registeredbyuserid': registeredByUserId,
      'registeredby': registeredByUserId,
      'subcenterid': subCenterId,
      'center': subCenterId,
      'subcenter': subCenterId,
      'resulturl': resultUrl,
      'result': resultUrl,
      'createdat': createdAt,
      'created': createdAt,
      'updatedat': updatedAt,
      'updated': updatedAt,
    };

    final headers = displayHeaders
        .map((header) => header.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();

    return [for (final header in headers) headerMap[header] ?? ''];
  }

  Future<void> _registerSample() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedTestKeys.isEmpty) {
      _showToast('Please select at least one test.', isError: true);
      return;
    }

    setState(() => _saving = true);
    TursoNativeService? service;
    try {
      final selectedTests = widget.tests
          .where((test) => _selectedTestKeys.contains(_testKey(test)))
          .toList();
      final now = DateTime.now();
      final serviceAccountJson = await rootBundle.loadString('assets/service-account.json');
      service = TursoNativeService(
        serviceAccountJson: serviceAccountJson,
        applicationName: 'flutterlab',
      );

      final timestamp = now.toUtc().toIso8601String();
      final rowValues = await _buildBloodSampleInsertRow(
        service,
        sampleId: _sampleIdFor(now),
        patientName: _patientNameController.text.trim(),
        patientAge: _patientAgeController.text.trim(),
        patientSex: _selectedSex ?? '',
        patientAddress: _patientAddressController.text.trim(),
        status: BloodSampleStatus.pending.name,
        testIds: selectedTests.map((test) => test.testName).join(', '),
        registeredByUserId: widget.user.id,
        subCenterId: _subCenterId,
        resultUrl: '',
        createdAt: timestamp,
        updatedAt: timestamp,
      );

      await service.insertRow(
        spreadsheetId: GoogleConfig.spreadsheetId,
        range: 'BloodSamples!A:Z',
        values: rowValues,
        valueInputOption: 'RAW',
      );

      _patientNameController.clear();
      _patientAgeController.clear();
      _patientAddressController.clear();
      _selectedSex = null;
      _selectedTestKeys.clear();
      ref.invalidate(sampleDashboardControllerProvider);
      _showToast('Blood sample registered successfully.');
      if (mounted) setState(() {});
    } catch (error) {
      _showToast('Register sample failed: $error', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  void _showToast(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    backgroundColor: theme.colorScheme.primaryContainer,
                    foregroundColor: theme.colorScheme.onPrimaryContainer,
                    child: const Icon(Icons.addchart_rounded),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Register Blood Sample',
                          style: theme.textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        Text('Sub-center: $_subCenterId • Select one or more test names'),
                      ],
                    ),
                  ),
                  _CountPill(
                    label: 'Selected cost',
                    value: _selectedTotalCost.round(),
                    color: theme.colorScheme.primary,
                  ),
                ],
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _patientNameController,
                enabled: !_saving,
                decoration: const InputDecoration(
                  labelText: 'Patient name',
                  prefixIcon: Icon(Icons.person_rounded),
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Enter patient name'
                    : null,
              ),
              const SizedBox(height: 12),
              LayoutBuilder(
                builder: (context, constraints) {
                  final compact = constraints.maxWidth < 720;
                  final ageField = TextFormField(
                    controller: _patientAgeController,
                    enabled: !_saving,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Age',
                      prefixIcon: Icon(Icons.cake_rounded),
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      final age = int.tryParse(value?.trim() ?? '');
                      if (age == null || age <= 0) return 'Enter valid age';
                      return null;
                    },
                  );
                  final sexField = DropdownButtonFormField<String>(
                    value: _selectedSex,
                    decoration: const InputDecoration(
                      labelText: 'Sex',
                      prefixIcon: Icon(Icons.wc_rounded),
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      DropdownMenuItem(value: 'Male', child: Text('Male')),
                      DropdownMenuItem(value: 'Female', child: Text('Female')),
                      DropdownMenuItem(value: 'Other', child: Text('Other')),
                    ],
                    onChanged: _saving ? null : (value) => setState(() => _selectedSex = value),
                    validator: (value) => value == null || value.trim().isEmpty
                        ? 'Select sex'
                        : null,
                  );

                  if (compact) {
                    return Column(
                      children: [ageField, const SizedBox(height: 12), sexField],
                    );
                  }
                  return Row(
                    children: [
                      Expanded(child: ageField),
                      const SizedBox(width: 12),
                      Expanded(child: sexField),
                    ],
                  );
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _patientAddressController,
                enabled: !_saving,
                minLines: 2,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Address',
                  prefixIcon: Icon(Icons.home_rounded),
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Enter patient address'
                    : null,
              ),
              const SizedBox(height: 16),
              if (widget.tests.isEmpty)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    color: theme.colorScheme.errorContainer,
                  ),
                  child: Text(
                    'No tests found. Please add tests in Global Pricing first.',
                    style: TextStyle(color: theme.colorScheme.onErrorContainer),
                  ),
                )
              else
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    for (final test in widget.tests)
                      FilterChip(
                        selected: _selectedTestKeys.contains(_testKey(test)),
                        label: Text(
                          '${test.testName} (${_customerPriceFor(test).toStringAsFixed(0)})',
                        ),
                        onSelected: _saving
                            ? null
                            : (selected) {
                                setState(() {
                                  final key = _testKey(test);
                                  if (selected) {
                                    _selectedTestKeys.add(key);
                                  } else {
                                    _selectedTestKeys.remove(key);
                                  }
                                });
                              },
                      ),
                  ],
                ),
              const SizedBox(height: 16),
              Align(
                alignment: Alignment.centerRight,
                child: FilledButton.icon(
                  onPressed: _saving || widget.tests.isEmpty ? null : _registerSample,
                  icon: _saving
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.save_rounded),
                  label: Text(_saving ? 'Registering...' : 'Register Sample'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SampleTable extends ConsumerStatefulWidget {
  const _SampleTable({
    required this.user,
    required this.samples,
    required this.tests,
    required this.pricings,
  });

  final AppUser? user;
  final List<BloodSample> samples;
  final List<LabTest> tests;
  final List<SubCenterPricing> pricings;

  @override
  ConsumerState<_SampleTable> createState() => _SampleTableState();
}

class _SampleTableState extends ConsumerState<_SampleTable> {
  String? _busySampleId;
  String? _busyMessage;
  double? _uploadProgress;
  final Set<String> _selectedSampleIds = <String>{};
  bool _printingSelected = false;

  bool get _isBusy => _busySampleId != null || _printingSelected;

  void _setBusy(String sampleId, String message, {double? progress}) {
    if (!mounted) return;
    setState(() {
      _busySampleId = sampleId;
      _busyMessage = message;
      _uploadProgress = progress;
    });
  }

  void _clearBusy() {
    if (!mounted) return;
    setState(() {
      _busySampleId = null;
      _busyMessage = null;
      _uploadProgress = null;
    });
  }

  void _showToast(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
      ),
    );
  }

  void _toggleSampleSelection(BloodSample sample, bool selected) {
    if (sample.status != BloodSampleStatus.completed) return;
    setState(() {
      if (selected) {
        _selectedSampleIds.add(sample.id);
      } else {
        _selectedSampleIds.remove(sample.id);
      }
    });
  }

  List<BloodSample> get _selectedCompletedSamples {
    return widget.samples
        .where((sample) => sample.status == BloodSampleStatus.completed && _selectedSampleIds.contains(sample.id))
        .toList();
  }

  Future<List<Map<String, String>>> _fetchRowsAsMaps(TursoNativeService service, String range) async {
    final rows = await service.fetchRows(spreadsheetId: GoogleConfig.spreadsheetId, range: range);
    if (rows.length < 2) return const <Map<String, String>>[];
    final headers = rows.first.map((header) => header.trim()).toList();
    return [
      for (final row in rows.skip(1))
        <String, String>{
          for (var i = 0; i < headers.length; i++)
            (headers[i].isEmpty ? 'column$i' : headers[i]): i < row.length ? row[i].trim() : '',
        },
    ];
  }

  String _normalizedId(String value) => value.trim().toLowerCase();

  Map<String, String> _sampleInfoForHeader(BloodSample sample, List<Map<String, String>> sampleRows) {
    final sampleId = _normalizedId(sample.id);
    Map<String, String> matched = const <String, String>{};
    for (final row in sampleRows) {
      if (_normalizedId(row['id'] ?? row['sampleId'] ?? '') == sampleId) {
        matched = row;
        break;
      }
    }

    String pick(List<String> keys, String fallback) {
      for (final key in keys) {
        final value = matched[key]?.trim() ?? '';
        if (value.isNotEmpty) return value;
      }
      return fallback;
    }

    return <String, String>{
      'patientName': pick(['patientName', 'patient', 'name'], sample.patientName),
      'patientAge': pick(['patientAge', 'age'], ''),
      'patientSex': pick(['patientSex', 'sex', 'gender'], ''),
      'referDr': pick(['referDr', 'referDoctor', 'doctor'], ''),
      'sampleId': sample.id,
      'runTime': pick(['runTime', 'updatedAt', 'createdAt', 'created'], sample.createdAt?.toIso8601String() ?? ''),
      'subCenterId': pick(['subCenterId', 'subcenter', 'center'], sample.subCenterId),
    };
  }

  Future<void> _printSelectedResults() async {
    final selected = _selectedCompletedSamples;
    if (selected.length < 2) {
      _showToast('Select at least 2 completed results to print together.', isError: true);
      return;
    }
    setState(() => _printingSelected = true);
    TursoNativeService? service;
    try {
      service = TursoNativeService(
        serviceAccountJson: await rootBundle.loadString('assets/service-account.json'),
        applicationName: 'flutterlab',
      );
      final sampleRows = await _fetchRowsAsMaps(service, 'BloodSamples!A:Z');
      final manualRows = await _fetchRowsAsMaps(service, 'TestResults!A:Z');
      final cbcRows = await _fetchRowsAsMaps(service, 'CBCResults!A:BZ');
      final printable = selected.map((sample) {
        final sampleId = _normalizedId(sample.id);
        final manualMatches = manualRows.where((row) => _normalizedId(row['sampleId'] ?? '') == sampleId).toList();
        final cbcMatches = cbcRows.where((row) => _normalizedId(row['sampleId'] ?? '') == sampleId).toList();
        return _PrintableSampleResult(
          sample: sample,
          manualRows: manualMatches,
          cbcRow: cbcMatches.isEmpty ? null : cbcMatches.first,
        );
      }).toList();
      final headerSample = printable.first.sample;
      final headerInfo = _sampleInfoForHeader(headerSample, sampleRows);
      final headerSettings = await _fetchMultiPrintHeaderSettings(service, headerSample.subCenterId);
      await Printing.layoutPdf(
        name: 'selected_results_${DateTime.now().millisecondsSinceEpoch}.pdf',
        onLayout: (format) => _buildSelectedResultsPdf(printable, format, headerSettings, headerInfo),
      );
    } catch (error) {
      _showToast('Print selected failed: $error', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _printingSelected = false);
    }
  }

  Future<Uint8List> _buildSelectedResultsPdf(
    List<_PrintableSampleResult> results,
    PdfPageFormat format,
    _MultiPrintHeaderSettings headerSettings,
    Map<String, String> headerInfo,
  ) async {
    final regularFont = pw.Font.ttf(await rootBundle.load('assets/fonts/DejaVuSans.ttf'));
    final boldFont = pw.Font.ttf(await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf'));
    final pdf = pw.Document(theme: pw.ThemeData.withFont(base: regularFont, bold: boldFont));
    final mohLogo = pw.MemoryImage((await rootBundle.load('assets/images/moh.png')).buffer.asUint8List());
    final generatedAt = DateTime.now().toLocal().toString().split('.').first;
    final headerSample = results.first.sample;
    final resultRows = _selectedResultRows(results);

    pdf.addPage(
      pw.MultiPage(
        pageFormat: format,
        margin: const pw.EdgeInsets.fromLTRB(28, 28, 28, 28),
        build: (context) => [
          _multiPrintCustomHeader(
            settings: headerSettings,
            sample: headerSample,
            sampleInfo: headerInfo,
            generatedAt: generatedAt,
            mohLogo: mohLogo,
          ),
          pw.SizedBox(height: 10),
          _selectedResultsTable(resultRows),
        ],
      ),
    );
    return pdf.save();
  }

  Future<_MultiPrintHeaderSettings> _fetchMultiPrintHeaderSettings(TursoNativeService service, String subCenterId) async {
    final defaults = _MultiPrintHeaderSettings.defaults(subCenterId: subCenterId);
    try {
      await service.ensureSheet(spreadsheetId: GoogleConfig.spreadsheetId, sheetName: 'ReportHeaderSettings');
      final rows = await service.fetchRows(spreadsheetId: GoogleConfig.spreadsheetId, range: 'ReportHeaderSettings!A:J');
      if (rows.length < 2) return defaults;
      final headers = rows.first.map((header) => _normalizeHeaderKey(header)).toList();
      Map<String, String>? global;
      Map<String, String>? matchedCenter;
      for (final row in rows.skip(1)) {
        final map = <String, String>{};
        for (var i = 0; i < headers.length; i++) {
          map[headers[i]] = i < row.length ? row[i].trim() : '';
        }
        final scope = _normalizeHeaderKey(map['scopetype'] ?? '');
        final center = _normalizeHeaderKey(map['subcenterid'] ?? '');
        if (scope == 'global' || center == 'global') global ??= map;
        if (subCenterId.trim().isNotEmpty && center == _normalizeHeaderKey(subCenterId)) matchedCenter = map;
      }
      final globalSettings = global == null ? defaults : _MultiPrintHeaderSettings.fromMap(global, fallback: defaults);
      return matchedCenter == null ? globalSettings : _MultiPrintHeaderSettings.fromMap(matchedCenter, fallback: globalSettings);
    } catch (_) {
      return defaults;
    }
  }

  String _normalizeHeaderKey(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  pw.Widget _multiPrintCustomHeader({
    required _MultiPrintHeaderSettings settings,
    required BloodSample sample,
    required Map<String, String> sampleInfo,
    required String generatedAt,
    required pw.MemoryImage mohLogo,
  }) {
    final accent = _pdfColorFromHex(settings.accentColor);
    final runTime = _formatMultiPrintDateTime(sampleInfo['runTime'] ?? '');
    String info(String key, String fallback) {
      final value = sampleInfo[key]?.trim() ?? '';
      return value.isEmpty ? fallback : value;
    }

    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.stretch,
      children: [
        pw.Container(
          padding: const pw.EdgeInsets.all(10),
          decoration: pw.BoxDecoration(
            border: pw.Border.all(color: PdfColor(0.576, 0.773, 0.992), width: 0.6),
            borderRadius: pw.BorderRadius.circular(8),
            color: PdfColor(0.937, 0.965, 1.0),
          ),
          child: pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.center,
            children: [
              pw.Container(
                width: 42,
                height: 42,
                padding: const pw.EdgeInsets.all(3),
                decoration: pw.BoxDecoration(
                  shape: pw.BoxShape.circle,
                  border: pw.Border.all(color: accent, width: 1.1),
                  color: PdfColors.white,
                ),
                child: pw.ClipOval(
                  child: pw.Image(mohLogo, fit: pw.BoxFit.contain),
                ),
              ),
              pw.SizedBox(width: 9),
              pw.Container(width: 0.8, height: 42, color: PdfColor(0.576, 0.773, 0.992)),
              pw.SizedBox(width: 9),
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text(settings.hospitalName.toUpperCase(), style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold, color: PdfColors.grey900)),
                    pw.SizedBox(height: 2),
                    pw.Text(settings.departmentName, style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold, color: accent)),
                    pw.Text(settings.township, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
                    pw.Text(settings.ministryName, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
                  ],
                ),
              ),
              pw.Container(
                padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: pw.BoxDecoration(color: accent, borderRadius: pw.BorderRadius.circular(12)),
                child: pw.Text(settings.reportTitle, style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold, color: PdfColors.white)),
              ),
            ],
          ),
        ),
        pw.SizedBox(height: 7),
        pw.Container(
          padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 7),
          decoration: pw.BoxDecoration(
            border: pw.Border.all(color: PdfColors.grey600, width: 0.6),
            color: PdfColors.grey100,
          ),
          child: pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Expanded(child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                _pdfInfoLine('Name', info('patientName', sample.patientName)),
                _pdfInfoLine('Gender', info('patientSex', '')),
              ])),
              pw.Expanded(child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                _pdfInfoLine('Age', info('patientAge', '')),
                _pdfInfoLine('Refer Dr.', info('referDr', '')),
              ])),
              pw.Expanded(child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                _pdfInfoLine('Sample ID', info('sampleId', sample.id)),
                _pdfInfoLine('Run Time', runTime.isEmpty ? generatedAt : runTime),
              ])),
            ],
          ),
        ),
        pw.SizedBox(height: 6),
        pw.Container(height: 0.7, color: PdfColors.grey700),
      ],
    );
  }

  String _formatMultiPrintDateTime(String value) {
    final raw = value.trim();
    if (raw.isEmpty) return '';
    final parsed = DateTime.tryParse(raw);
    if (parsed == null) return raw;
    final local = parsed.toLocal();
    final year = local.year.toString().padLeft(4, '0');
    final month = local.month.toString().padLeft(2, '0');
    final day = local.day.toString().padLeft(2, '0');
    final hour = local.hour.toString().padLeft(2, '0');
    final minute = local.minute.toString().padLeft(2, '0');
    return '$year-$month-$day $hour:$minute';
  }

  PdfColor _pdfColorFromHex(String raw) {
    final cleaned = raw.trim().replaceAll('#', '');
    if (!RegExp(r'^[0-9a-fA-F]{6}$').hasMatch(cleaned)) return PdfColor(0.114, 0.306, 0.847);
    final value = int.parse(cleaned, radix: 16);
    return PdfColor(((value >> 16) & 0xFF) / 255.0, ((value >> 8) & 0xFF) / 255.0, (value & 0xFF) / 255.0);
  }

  List<_PrintableResultRow> _selectedResultRows(List<_PrintableSampleResult> results) {
    return [
      for (final result in results) ..._rowsForPrintableSample(result),
    ];
  }

  List<_PrintableResultRow> _rowsForPrintableSample(_PrintableSampleResult result) {
    if (result.cbcRow != null) return _cbcPrintableRows(result);
    if (result.manualRows.isNotEmpty) return _manualPrintableRows(result);
    return [
      _PrintableResultRow(
        sampleId: result.sample.id,
        patientName: result.sample.patientName,
        testName: result.sample.testIds.join(', '),
        parameter: 'Result',
        result: 'No generated result rows found',
        unit: '',
        referenceRange: '',
        notes: '',
      ),
    ];
  }

  List<_PrintableResultRow> _cbcPrintableRows(_PrintableSampleResult printable) {
    final row = printable.cbcRow!;
    final testName = row['testName']?.trim().isNotEmpty == true ? row['testName']!.trim() : 'CBC / CP(Auto)';
    const fields = <List<String>>[
      ['WBC', '10^9/L'],
      ['RBC', '10^12/L'],
      ['HGB', 'g/dL'],
      ['HCT', '%'],
      ['MCV', 'fL'],
      ['MCH', 'pg'],
      ['MCHC', 'g/dL'],
      ['PLT', '10^9/L'],
      ['LymPercent', '%'],
      ['MidPercent', '%'],
      ['GranPercent', '%'],
      ['LymCount', '10^9/L'],
      ['MidCount', '10^9/L'],
      ['GranCount', '10^9/L'],
    ];
    final rows = <_PrintableResultRow>[];
    for (final field in fields) {
      final value = row[field[0]]?.trim() ?? '';
      if (value.isEmpty) continue;
      rows.add(_PrintableResultRow(
        sampleId: printable.sample.id,
        patientName: printable.sample.patientName,
        testName: testName,
        parameter: field[0],
        result: value,
        unit: field[1],
        referenceRange: '',
        notes: '',
      ));
    }
    if (rows.isEmpty) {
      rows.add(_PrintableResultRow(
        sampleId: printable.sample.id,
        patientName: printable.sample.patientName,
        testName: testName,
        parameter: 'CBC / CP(Auto)',
        result: 'Saved',
        unit: '',
        referenceRange: '',
        notes: '',
      ));
    }
    return rows;
  }

  List<_PrintableResultRow> _manualPrintableRows(_PrintableSampleResult printable) {
    return printable.manualRows.map((row) {
      final parameter = (row['parameter'] ?? '').trim().isEmpty ? (row['testName'] ?? 'Result') : row['parameter']!;
      return _PrintableResultRow(
        sampleId: printable.sample.id,
        patientName: printable.sample.patientName,
        testName: row['testName'] ?? printable.sample.testIds.join(', '),
        parameter: parameter,
        result: row['resultValue'] ?? '',
        unit: row['unit'] ?? '',
        referenceRange: row['referenceRange'] ?? '',
        notes: row['notes'] ?? '',
      );
    }).toList();
  }

  pw.Widget _selectedResultsTable(List<_PrintableResultRow> rows) {
    if (rows.isEmpty) {
      return pw.Text('No result rows found for the selected samples.', style: const pw.TextStyle(fontSize: 9));
    }
    final remarks = rows
        .map((row) => row.notes.trim())
        .where((note) => note.isNotEmpty)
        .toSet()
        .join('\n');
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.stretch,
      children: [
        pw.Table(
          border: const pw.TableBorder(
            top: pw.BorderSide(color: PdfColors.grey700, width: 0.5),
            bottom: pw.BorderSide(color: PdfColors.grey700, width: 0.5),
            horizontalInside: pw.BorderSide(color: PdfColors.grey300, width: 0.25),
          ),
          columnWidths: const <int, pw.TableColumnWidth>{
            0: pw.FixedColumnWidth(20),
            1: pw.FlexColumnWidth(1.55),
            2: pw.FlexColumnWidth(1.05),
            3: pw.FlexColumnWidth(1.28),
            4: pw.FlexColumnWidth(0.95),
          },
          children: [
            pw.TableRow(
              decoration: const pw.BoxDecoration(color: PdfColors.grey200),
              children: [
                _resultTableCell('', bold: true),
                _resultTableCell('Parameter', bold: true),
                _resultTableCell('Result', bold: true),
                _resultTableCell('Ref. Range', bold: true),
                _resultTableCell('Unit', bold: true),
              ],
            ),
            for (var index = 0; index < rows.length; index++)
              pw.TableRow(
                children: [
                  _resultTableCell('${index + 1}', align: pw.TextAlign.right),
                  _resultTableCell(rows[index].parameter, bold: true),
                  _resultTableCell(rows[index].result, bold: true),
                  _resultTableCell(rows[index].referenceRange),
                  _resultTableCell(rows[index].unit),
                ],
              ),
          ],
        ),
        pw.SizedBox(height: 10),
        pw.Container(
          width: double.infinity,
          padding: const pw.EdgeInsets.all(8),
          decoration: pw.BoxDecoration(
            border: pw.Border.all(color: PdfColors.grey600, width: 0.7),
            color: PdfColors.grey100,
          ),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('Remarks', style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 4),
              pw.Text(remarks.isEmpty ? '-' : remarks, style: const pw.TextStyle(fontSize: 8)),
            ],
          ),
        ),
      ],
    );
  }

  pw.Widget _resultTableCell(String value, {bool bold = false, pw.TextAlign align = pw.TextAlign.left}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 3, horizontal: 3),
      child: pw.Text(
        value.trim().isEmpty ? '-' : value.trim(),
        textAlign: align,
        style: pw.TextStyle(fontSize: 7.2, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal),
      ),
    );
  }

  pw.Widget _pdfInfoLine(String label, String value) {
    return pw.RichText(
      text: pw.TextSpan(
        children: [
          pw.TextSpan(text: '$label: ', style: pw.TextStyle(fontSize: 7.5, fontWeight: pw.FontWeight.bold)),
          pw.TextSpan(text: value.trim().isEmpty ? '-' : value.trim(), style: const pw.TextStyle(fontSize: 7.5)),
        ],
      ),
    );
  }

  pw.Widget _cbcSummaryTable(Map<String, String> row) {
    final items = <List<String>>[
      ['WBC', row['WBC'] ?? '', '10^9/L'],
      ['RBC', row['RBC'] ?? '', '10^12/L'],
      ['HGB', row['HGB'] ?? '', 'g/dL'],
      ['HCT', row['HCT'] ?? '', '%'],
      ['PLT', row['PLT'] ?? '', '10^9/L'],
    ].where((item) => item[1].trim().isNotEmpty).toList();
    return _miniResultTable(
      title: row['testName']?.trim().isNotEmpty == true ? row['testName']!.trim() : 'CBC / CP(Auto)',
      rows: items.isEmpty ? const <List<String>>[['CBC / CP(Auto)', 'Saved', '']] : items,
    );
  }

  pw.Widget _manualSummaryTable(List<Map<String, String>> rows) {
    final items = rows.take(8).map((row) {
      final parameter = (row['parameter'] ?? '').trim().isEmpty ? (row['testName'] ?? 'Result') : row['parameter']!;
      final value = row['resultValue'] ?? '';
      final unit = row['unit'] ?? '';
      return [parameter, value, unit];
    }).toList();
    return _miniResultTable(title: rows.first['testName'] ?? 'Manual result', rows: items);
  }

  pw.Widget _miniResultTable({required String title, required List<List<String>> rows}) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.stretch,
      children: [
        pw.Container(
          padding: const pw.EdgeInsets.symmetric(vertical: 3, horizontal: 4),
          color: PdfColors.grey300,
          child: pw.Text(title.trim().isEmpty ? 'Result' : title.trim(), style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold)),
        ),
        pw.Table(
          border: pw.TableBorder.all(color: PdfColors.grey500, width: 0.4),
          columnWidths: const <int, pw.TableColumnWidth>{0: pw.FlexColumnWidth(1.3), 1: pw.FlexColumnWidth(1), 2: pw.FlexColumnWidth(0.8)},
          children: [
            pw.TableRow(
              decoration: const pw.BoxDecoration(color: PdfColors.grey200),
              children: [_cell('Parameter', bold: true), _cell('Result', bold: true), _cell('Unit', bold: true)],
            ),
            for (final row in rows)
              pw.TableRow(children: [_cell(row[0]), _cell(row[1]), _cell(row[2])]),
          ],
        ),
      ],
    );
  }

  pw.Widget _cell(String value, {bool bold = false}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 2.5, horizontal: 3),
      child: pw.Text(value.trim().isEmpty ? '-' : value.trim(), style: pw.TextStyle(fontSize: 7, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isLabTech = widget.user?.role == AppUserRole.lab_tech;
    final isAdmin = widget.user?.role == AppUserRole.admin;
    final isStaff = widget.user?.role == AppUserRole.staff;
    final completedIds = widget.samples.where((sample) => sample.status == BloodSampleStatus.completed).map((sample) => sample.id).toSet();
    _selectedSampleIds.removeWhere((id) => !completedIds.contains(id));
    final selectedCompletedCount = _selectedCompletedSamples.length;
    final source = _SampleDataSource(
      widget.samples,
      isLabTech,
      isAdmin,
      isStaff,
      widget.tests,
      widget.pricings,
      selectedSampleIds: _selectedSampleIds,
      busySampleId: _busySampleId,
      onSelectSample: _toggleSampleSelection,
      onReview: (sample) => _reviewSample(sample),
      onViewResult: (sample) => context.go('/sample-result/${Uri.encodeComponent(sample.id)}'),
    );

    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Blood Samples',
                        style: theme.textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text('${widget.samples.length} sample records in this view'),
                    ],
                  ),
                ),
                FilledButton.icon(
                  onPressed: selectedCompletedCount >= 2 && !_isBusy ? _printSelectedResults : null,
                  icon: _printingSelected
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.print_rounded),
                  label: Text(selectedCompletedCount == 0 ? 'Print selected' : 'Print selected ($selectedCompletedCount)'),
                ),
                const SizedBox(width: 10),
                FilledButton.tonalIcon(
                  onPressed: _isBusy
                      ? null
                      : () => ref.invalidate(sampleDashboardControllerProvider),
                  icon: const Icon(Icons.refresh_rounded),
                  label: const Text('Refresh'),
                ),
              ],
            ),
            if (_isBusy) ...[
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  color: theme.colorScheme.primaryContainer.withValues(alpha: 0.45),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            _busyMessage ?? 'Processing sample...',
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    LinearProgressIndicator(value: _uploadProgress),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final tableWidth = constraints.maxWidth < 1220
                      ? 1220.0
                      : constraints.maxWidth;

                  return SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: SizedBox(
                      width: tableWidth,
                      child: PaginatedDataTable(
                        header: const Text('Samples'),
                        columns: [
                          const DataColumn(label: Text('ID')),
                          const DataColumn(label: Text('Patient')),
                          const DataColumn(label: Text('Center')),
                          const DataColumn(label: Text('Tests')),
                          if (isStaff)
                            const DataColumn(label: Text('Total Cost')),
                          const DataColumn(label: Text('Status')),
                          const DataColumn(label: Text('Date')),
                          const DataColumn(label: Text('Result')),
                          if (isLabTech || isAdmin)
                            const DataColumn(label: Text('Actions')),
                        ],
                        source: source,
                        rowsPerPage: 10,
                        columnSpacing: 20,
                        horizontalMargin: 10,
                        showFirstLastButtons: true,
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _reviewSample(BloodSample sample) async {
    if (_isBusy) return;

    final user = ref.read(authNotifierProvider);
    if (user?.role != AppUserRole.lab_tech) {
      _showToast('Only lab tech users can review samples.', isError: true);
      return;
    }

    var nextStatus = BloodSampleStatus.processing;
    String? resultUrl = sample.resultFileUrl;

    try {
      if (sample.status == BloodSampleStatus.pending) {
        _setBusy(sample.id, 'Updating ${sample.id} to processing...');
        nextStatus = BloodSampleStatus.processing;
      } else {
        nextStatus = BloodSampleStatus.completed;
        if (_isCbcOrCpAuto(sample)) {
          final result = await showDialog<_CbcCpUploadResult>(
            context: context,
            barrierDismissible: false,
            builder: (context) => _CbcCpUploadDialog(sample: sample),
          );
          if (result == null) return;
          resultUrl = await _saveCbcCpResult(sample: sample, result: result, user: user!);
        } else {
          final result = await showDialog<_ManualResultBatch>(
            context: context,
            barrierDismissible: false,
            builder: (context) => _ManualResultDialog(sample: sample),
          );
          if (result == null) return;
          await _saveManualResult(sample: sample, result: result, user: user!);
          // Manual results are stored in the TestResults sheet.
          // Do not write the manual result text into BloodSamples.resultUrl.
          resultUrl = sample.resultFileUrl;
        }
      }

      _setBusy(sample.id, 'Saving ${sample.id} status to ${nextStatus.name}...');
      final serviceAccountJson = await rootBundle.loadString('assets/service-account.json');
      final sheets = TursoNativeService(serviceAccountJson: serviceAccountJson, applicationName: 'flutterlab');
      try {
        await _updateBloodSampleRow(sheets, sample: sample, status: nextStatus, resultUrl: resultUrl);
        ref.invalidate(sampleDashboardControllerProvider);
        _showToast(nextStatus == BloodSampleStatus.processing
            ? '${sample.id} is now processing.'
            : '${sample.id} completed and result saved.');
      } finally {
        await sheets.close();
      }
    } catch (error) {
      _showToast('Review failed: $error', isError: true);
    } finally {
      _clearBusy();
    }
  }

  bool _isCbcOrCpAuto(BloodSample sample) {
    final joined = sample.testIds.join(' ').toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
    return joined.contains('cbc') || joined.contains('cpauto') || joined.contains('cp');
  }

  Future<String> _saveCbcCpResult({required BloodSample sample, required _CbcCpUploadResult result, required AppUser user}) async {
    final serviceAccountJson = await rootBundle.loadString('assets/service-account.json');
    final drive = GoogleDriveService(serviceAccountJson: serviceAccountJson, applicationName: 'flutterlab');
    final sheets = TursoNativeService(serviceAccountJson: serviceAccountJson, applicationName: 'flutterlab');
    try {
      final row = Map<String, String>.from(result.parsedValues);
      row['id'] = row['id']?.trim().isNotEmpty == true ? row['id']! : 'CBC-${sample.id}-${DateTime.now().millisecondsSinceEpoch}';
      row['testName'] = sample.testIds.isEmpty ? 'CBC / CP(Auto)' : sample.testIds.join(', ');
      row['sampleId'] = sample.id;
      row['createdAt'] = DateTime.now().toIso8601String();
      row['uploadedByUserId'] = user.id;
      row.addAll(result.graphBase64);

      if (result.diffImageBytes != null) {
        _setBusy(sample.id, 'Uploading DIFF image...');
        row['diffHsmsImageUrl'] = await drive.uploadBytesToSharedFolder(bytes: result.diffImageBytes!, parentFolderId: GoogleConfig.driveFolderId, fileName: result.diffImageName, mimeType: _mimeTypeFor(result.diffImageName));
      }
      if (result.pltImageBytes != null) {
        _setBusy(sample.id, 'Uploading PLT image...');
        row['pltImageUrl'] = await drive.uploadBytesToSharedFolder(bytes: result.pltImageBytes!, parentFolderId: GoogleConfig.driveFolderId, fileName: result.pltImageName, mimeType: _mimeTypeFor(result.pltImageName));
      }

      _setBusy(sample.id, 'Saving CBC / CP(Auto) result values...');
      await _ensureResultSheetHeaders(sheets: sheets, sheetName: 'CBCResults', range: 'CBCResults!A1:BH1', headers: _cbcResultHeaders);
      await sheets.insertRow(spreadsheetId: GoogleConfig.spreadsheetId, range: 'CBCResults!A:BH', values: _cbcResultHeaders.map((header) => row[header] ?? '').toList(), valueInputOption: 'RAW');
      // BloodSamples.resultUrl should contain a real URL, not summary text.
      return row['diffHsmsImageUrl']?.trim().isNotEmpty == true
          ? row['diffHsmsImageUrl']!
          : (row['pltImageUrl'] ?? '');
    } finally {
      await drive.close();
      await sheets.close();
    }
  }

  Future<String> _saveManualResult({required BloodSample sample, required _ManualResultBatch result, required AppUser user}) async {
    final serviceAccountJson = await rootBundle.loadString('assets/service-account.json');
    final sheets = TursoNativeService(serviceAccountJson: serviceAccountJson, applicationName: 'flutterlab');
    try {
      await _ensureResultSheetHeaders(sheets: sheets, sheetName: 'TestResults', range: 'TestResults!A1:K1', headers: _manualResultHeaders);
      final now = DateTime.now();
      var saved = 0;
      for (final entry in result.entries) {
        final id = 'RESULT-${sample.id}-${now.microsecondsSinceEpoch}-$saved';
        final row = <String, String>{
          'id': id,
          'sampleId': sample.id,
          'testName': entry.testName,
          'parameter': entry.parameter,
          'patientName': sample.patientName,
          'resultValue': entry.value,
          'unit': entry.unit,
          'referenceRange': entry.referenceRange,
          'notes': entry.notes,
          'createdAt': now.toIso8601String(),
          'uploadedByUserId': user.id,
        };
        await sheets.insertRow(
          spreadsheetId: GoogleConfig.spreadsheetId,
          range: 'TestResults!A:K',
          values: _manualResultHeaders.map((header) => row[header] ?? '').toList(),
          valueInputOption: 'RAW',
        );
        saved++;
      }
      return 'TestResults:${sample.id}\nManual result rows:$saved';
    } finally {
      await sheets.close();
    }
  }

  Future<void> _ensureResultSheetHeaders({required TursoNativeService sheets, required String sheetName, required String range, required List<String> headers}) async {
    await sheets.ensureSheet(spreadsheetId: GoogleConfig.spreadsheetId, sheetName: sheetName);
    await sheets.updateRow(spreadsheetId: GoogleConfig.spreadsheetId, range: range, values: headers);
  }

  String _mimeTypeFor(String fileName) {
    final lower = fileName.toLowerCase();
    if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
    return 'image/png';
  }

  Future<void> _updateBloodSampleRow(
    TursoNativeService service, {
    required BloodSample sample,
    required BloodSampleStatus status,
    String? resultUrl,
  }) async {
    final rows = await service.fetchRows(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'BloodSamples!A:Z',
    );
    if (rows.isEmpty) throw StateError('BloodSamples sheet is empty.');

    final headers = rows.first
        .map((h) => h.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();

    int indexOfAny(List<String> names, {int fallback = -1}) {
      for (final name in names) {
        final index = headers.indexOf(name);
        if (index >= 0) return index;
      }
      return fallback;
    }

    final idIndex = indexOfAny(['id', 'sampleid'], fallback: 0);
    var rowNumber = -1;
    var rowValues = <String>[];
    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      final id = idIndex < row.length ? row[idIndex].trim() : '';
      if (id == sample.id) {
        rowNumber = i + 1;
        rowValues = List<String>.from(row);
        break;
      }
    }
    if (rowNumber < 0) throw StateError('Sample row was not found.');

    final statusIndex = indexOfAny(['status'], fallback: 5);
    final resultIndex = indexOfAny(['resulturl', 'resultfileurl', 'result'], fallback: 6);
    final updatedAtIndex = indexOfAny(['updatedat', 'updated'], fallback: 8);
    var neededLength = statusIndex;
    if (resultIndex > neededLength) neededLength = resultIndex;
    if (updatedAtIndex > neededLength) neededLength = updatedAtIndex;
    while (rowValues.length <= neededLength) {
      rowValues.add('');
    }

    rowValues[statusIndex] = status.name;
    if (resultUrl != null && resultUrl.trim().isNotEmpty) {
      rowValues[resultIndex] = resultUrl.trim();
    }
    rowValues[updatedAtIndex] = DateTime.now().toIso8601String();

    await service.updateRow(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'BloodSamples!A$rowNumber:Z$rowNumber',
      values: rowValues,
    );
  }

}


const _cbcResultHeaders = <String>[
  'id',
  'testName',
  'sampleId',
  'medRecNo',
  'firstName',
  'lastName',
  'gender',
  'age',
  'ageUnit',
  'sampleType',
  'samplingTime',
  'deliveryTime',
  'reportTime',
  'runTime',
  'mode',
  'WBC',
  'NeuPercent',
  'LymPercent',
  'MonPercent',
  'EosPercent',
  'BasPercent',
  'NeuCount',
  'LymCount',
  'MonCount',
  'EosCount',
  'BasCount',
  'ALYCount',
  'ALYPercent',
  'LICCount',
  'LICPercent',
  'NRBCCount',
  'NRBCPercent',
  'RBC',
  'HGB',
  'HCT',
  'MCV',
  'MCH',
  'MCHC',
  'RDWCV',
  'RDWSD',
  'PLT',
  'MPV',
  'PDW',
  'PCT',
  'PLCR',
  'PLCC',
  'WBCFlag',
  'RBCFlag',
  'PLTFlag',
  'CRPFlag',
  'diffHsmsImageUrl',
  'pltImageUrl',
  'wbcGraphBase64',
  'rbcGraphBase64',
  'pltGraphBase64',
  'diffHsmsBase64',
  'diffLshsBase64',
  'diffLsmsBase64',
  'createdAt',
  'uploadedByUserId',
];

const _manualResultHeaders = <String>[
  'id',
  'sampleId',
  'testName',
  'parameter',
  'patientName',
  'resultValue',
  'unit',
  'referenceRange',
  'notes',
  'createdAt',
  'uploadedByUserId',
];

class _AnalyzerExportData {
  const _AnalyzerExportData({required this.parsedValues, required this.graphBase64});

  final Map<String, String> parsedValues;
  final Map<String, String> graphBase64;
}

class _CbcCpUploadResult {
  const _CbcCpUploadResult({
    required this.parsedValues,
    required this.diffImageBytes,
    required this.diffImageName,
    required this.pltImageBytes,
    required this.pltImageName,
    required this.graphBase64,
  });

  final Map<String, String> parsedValues;
  final Uint8List? diffImageBytes;
  final String diffImageName;
  final Uint8List? pltImageBytes;
  final String pltImageName;
  final Map<String, String> graphBase64;
}

class _ManualResultBatch {
  const _ManualResultBatch({required this.entries});

  final List<_ManualResultEntry> entries;
}

class _ManualResultEntry {
  const _ManualResultEntry({
    required this.testName,
    required this.parameter,
    required this.value,
    required this.unit,
    required this.referenceRange,
    required this.notes,
  });

  final String testName;
  final String parameter;
  final String value;
  final String unit;
  final String referenceRange;
  final String notes;
}

class _ManualDefaultParameter {
  const _ManualDefaultParameter({
    required this.testName,
    required this.parameter,
    required this.unit,
    required this.referenceRange,
    required this.notes,
  });

  final String testName;
  final String parameter;
  final String unit;
  final String referenceRange;
  final String notes;
}

class _ManualResultDialog extends StatefulWidget {
  const _ManualResultDialog({required this.sample});

  final BloodSample sample;

  @override
  State<_ManualResultDialog> createState() => _ManualResultDialogState();
}

class _ManualResultDialogState extends State<_ManualResultDialog> {
  final _formKey = GlobalKey<FormState>();
  final List<TextEditingController> _valueControllers = [];
  List<_ManualDefaultParameter> _defaults = const <_ManualDefaultParameter>[];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadDefaults();
  }

  @override
  void dispose() {
    for (final controller in _valueControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _loadDefaults() async {
    try {
      final defaults = await _fetchManualDefaults();
      if (!mounted) return;
      setState(() {
        _defaults = defaults.isEmpty ? _fallbackDefaults() : defaults;
        _valueControllers
          ..clear()
          ..addAll(List.generate(_defaults.length, (_) => TextEditingController()));
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = 'Could not load manual defaults: $error';
        _defaults = _fallbackDefaults();
        _valueControllers
          ..clear()
          ..addAll(List.generate(_defaults.length, (_) => TextEditingController()));
        _loading = false;
      });
    }
  }

  List<_ManualDefaultParameter> _fallbackDefaults() {
    final tests = widget.sample.testIds.isEmpty ? const ['Manual Test'] : widget.sample.testIds;
    return tests
        .map(
          (test) => _ManualDefaultParameter(
            testName: test,
            parameter: test,
            unit: '',
            referenceRange: '',
            notes: '',
          ),
        )
        .toList();
  }

  String _normalize(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  Future<List<_ManualDefaultParameter>> _fetchManualDefaults() async {
    final serviceAccountJson = await rootBundle.loadString('assets/service-account.json');
    final sheets = TursoNativeService(serviceAccountJson: serviceAccountJson, applicationName: 'flutterlab');
    try {
      final rows = await sheets.fetchRows(
        spreadsheetId: GoogleConfig.spreadsheetId,
        range: 'ManualTestDefaults!A:G',
      );
      if (rows.length < 2) return const <_ManualDefaultParameter>[];
      final headers = rows.first.map((h) => _normalize(h)).toList();
      int indexOf(List<String> keys) {
        for (final key in keys) {
          final index = headers.indexOf(key);
          if (index >= 0) return index;
        }
        return -1;
      }

      final testIdIndex = indexOf(const ['testid']);
      final testNameIndex = indexOf(const ['testname', 'name']);
      final parameterIndex = indexOf(const ['parameter', 'parametername']);
      final unitIndex = indexOf(const ['unit']);
      final referenceIndex = indexOf(const ['referencerange', 'refrange', 'reference']);
      final noteIndex = indexOf(const ['note', 'notes']);
      final sampleTests = widget.sample.testIds.map(_normalize).toSet();
      final defaults = <_ManualDefaultParameter>[];
      for (final row in rows.skip(1)) {
        String cell(int index) => index >= 0 && index < row.length ? row[index].trim() : '';
        final testId = cell(testIdIndex);
        final testName = cell(testNameIndex);
        final keyMatches = sampleTests.contains(_normalize(testId)) || sampleTests.contains(_normalize(testName));
        if (!keyMatches) continue;
        defaults.add(
          _ManualDefaultParameter(
            testName: testName.isEmpty ? testId : testName,
            parameter: cell(parameterIndex).isEmpty ? (testName.isEmpty ? testId : testName) : cell(parameterIndex),
            unit: cell(unitIndex),
            referenceRange: cell(referenceIndex),
            notes: cell(noteIndex),
          ),
        );
      }
      return defaults;
    } finally {
      await sheets.close();
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Enter result: ${widget.sample.id}'),
      content: SizedBox(
        width: 640,
        child: _loading
            ? const Padding(
                padding: EdgeInsets.all(28),
                child: Center(child: CircularProgressIndicator()),
              )
            : Form(
                key: _formKey,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text('Test: ${widget.sample.testIds.join(', ')}'),
                      if (_error != null) ...[
                        const SizedBox(height: 8),
                        Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                      ],
                      const SizedBox(height: 12),
                      for (var i = 0; i < _defaults.length; i++) ...[
                        _ManualResultInputCard(
                          defaultParameter: _defaults[i],
                          controller: _valueControllers[i],
                        ),
                        const SizedBox(height: 12),
                      ],
                    ],
                  ),
                ),
              ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
        FilledButton.icon(
          onPressed: _loading
              ? null
              : () {
                  if (!_formKey.currentState!.validate()) return;
                  Navigator.of(context).pop(
                    _ManualResultBatch(
                      entries: [
                        for (var i = 0; i < _defaults.length; i++)
                          _ManualResultEntry(
                            testName: _defaults[i].testName,
                            parameter: _defaults[i].parameter,
                            value: _valueControllers[i].text.trim(),
                            unit: _defaults[i].unit,
                            referenceRange: _defaults[i].referenceRange,
                            notes: _defaults[i].notes,
                          ),
                      ],
                    ),
                  );
                },
          icon: const Icon(Icons.save_rounded),
          label: const Text('Save Result'),
        ),
      ],
    );
  }
}

class _ManualResultInputCard extends StatelessWidget {
  const _ManualResultInputCard({required this.defaultParameter, required this.controller});

  final _ManualDefaultParameter defaultParameter;
  final TextEditingController controller;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.colorScheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(defaultParameter.parameter, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          TextFormField(
            controller: controller,
            decoration: InputDecoration(
              labelText: 'Result value',
              helperText: [
                if (defaultParameter.unit.trim().isNotEmpty) 'Unit: ${defaultParameter.unit}',
                if (defaultParameter.referenceRange.trim().isNotEmpty) 'Ref: ${defaultParameter.referenceRange}',
              ].join('   '),
              border: const OutlineInputBorder(),
            ),
            validator: (value) => value == null || value.trim().isEmpty ? 'Enter result value' : null,
          ),
          if (defaultParameter.notes.trim().isNotEmpty) ...[
            const SizedBox(height: 8),
            Text('Default note: ${defaultParameter.notes}', style: theme.textTheme.bodySmall),
          ],
        ],
      ),
    );
  }
}

class _CbcCpUploadDialog extends StatefulWidget {
  const _CbcCpUploadDialog({required this.sample});

  final BloodSample sample;

  @override
  State<_CbcCpUploadDialog> createState() => _CbcCpUploadDialogState();
}

class _CbcCpUploadDialogState extends State<_CbcCpUploadDialog> {
  PlatformFile? _csvFile;
  PlatformFile? _diffImage;
  PlatformFile? _pltImage;
  PlatformFile? _exportZip;
  final Map<String, String> _graphBase64 = {};
  Map<String, String>? _preview;
  String? _error;

  Future<void> _pickCsv() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['csv'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final file = result.files.single;
    final bytes = file.bytes;
    if (bytes == null || bytes.isEmpty) {
      setState(() => _error = 'CSV is empty or cannot be read.');
      return;
    }
    try {
      final parsed = _parseCbcCsv(utf8.decode(bytes, allowMalformed: true));
      setState(() {
        _csvFile = file;
        _preview = parsed;
        _error = null;
      });
    } catch (error) {
      setState(() => _error = 'CSV parse failed: $error');
    }
  }

  Future<void> _pickImage({required bool isDiff}) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['png', 'jpg', 'jpeg'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    setState(() {
      if (isDiff) {
        _diffImage = result.files.single;
      } else {
        _pltImage = result.files.single;
      }
      _error = null;
    });
  }

  Future<void> _pickAnalyzerZip() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['zip'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final file = result.files.single;
    final bytes = file.bytes;
    if (bytes == null || bytes.isEmpty) {
      setState(() => _error = 'Analyzer ZIP is empty or cannot be read.');
      return;
    }
    try {
      final extracted = _extractAnalyzerExport(bytes);
      setState(() {
        _exportZip = file;
        _csvFile = file;
        _preview = extracted.parsedValues;
        _graphBase64
          ..clear()
          ..addAll(extracted.graphBase64);
        _error = null;
      });
    } catch (error) {
      setState(() => _error = 'Analyzer ZIP parse failed: $error');
    }
  }

  _AnalyzerExportData _extractAnalyzerExport(Uint8List zipBytes) {
    final archive = ZipDecoder().decodeBytes(zipBytes);
    String? csvText;
    final graphs = <String, String>{};
    for (final file in archive.files) {
      if (!file.isFile) continue;
      final name = file.name.split('/').last;
      final lower = name.toLowerCase();
      final data = file.readBytes();
      if (data == null || data.isEmpty) continue;
      if (lower.endsWith('.csv')) {
        csvText = utf8.decode(data, allowMalformed: true);
      } else if (lower.endsWith('.png')) {
        final key = _graphKeyFor(name);
        if (key != null) graphs[key] = base64Encode(data);
      }
    }
    if (csvText == null || csvText.trim().isEmpty) {
      throw StateError('No CSV file found inside ZIP.');
    }
    return _AnalyzerExportData(parsedValues: _parseCbcCsv(csvText), graphBase64: graphs);
  }

  String? _graphKeyFor(String fileName) {
    final upper = fileName.toUpperCase();
    if (upper.contains('WBC')) return 'wbcGraphBase64';
    if (upper.contains('RBC')) return 'rbcGraphBase64';
    if (upper.contains('PLT')) return 'pltGraphBase64';
    if (upper.contains('DIFF_HSMS')) return 'diffHsmsBase64';
    if (upper.contains('DIFF_LSHS')) return 'diffLshsBase64';
    if (upper.contains('DIFF_LSMS')) return 'diffLsmsBase64';
    return null;
  }

  Map<String, String> _parseCbcCsv(String csvText) {
    final rows = _parseCsvRows(csvText).where((row) => row.any((cell) => cell.trim().isNotEmpty)).toList();
    if (rows.length < 2) throw StateError('CSV must contain header row and one data row.');
    final headers = rows.first.map((value) => value.trim().toLowerCase()).toList();
    final row = rows[1];
    final source = <String, String>{};
    for (var i = 0; i < headers.length; i++) {
      source[headers[i]] = i < row.length ? row[i].trim() : '';
    }

    String get(List<String> keys) {
      for (final key in keys) {
        final value = source[key.toLowerCase()]?.trim() ?? '';
        if (value.isNotEmpty) return value;
      }
      return '';
    }

    final sampleId = get(['Sample ID']);
    return <String, String>{
      'id': 'CBC-${sampleId.isEmpty ? DateTime.now().microsecondsSinceEpoch : sampleId}-${DateTime.now().millisecondsSinceEpoch}',
      'testName': 'CBC / CP(Auto)',
      'sampleId': sampleId,
      'medRecNo': get(['Med Rec. No.']),
      'firstName': get(['First Name']),
      'lastName': get(['Last Name']),
      'gender': get(['Gender']),
      'age': get(['Age']),
      'ageUnit': get(['Age Unit']),
      'sampleType': get(['Sample Type']),
      'samplingTime': get(['Sampling Time']),
      'deliveryTime': get(['Delivery Time']),
      'reportTime': get(['Report Time']),
      'runTime': get(['Run Time']),
      'mode': get(['Mode']),
      'WBC': get(['WBC']),
      'NeuPercent': get(['Neu%']),
      'LymPercent': get(['Lym%']),
      'MonPercent': get(['Mon%']),
      'EosPercent': get(['Eos%']),
      'BasPercent': get(['Bas%']),
      'NeuCount': get(['Neu#']),
      'LymCount': get(['Lym#']),
      'MonCount': get(['Mon#']),
      'EosCount': get(['Eos#']),
      'BasCount': get(['Bas#']),
      'ALYCount': get(['ALY#']),
      'ALYPercent': get(['ALY%']),
      'LICCount': get(['LIC#']),
      'LICPercent': get(['LIC%']),
      'NRBCCount': get(['NRBC#']),
      'NRBCPercent': get(['NRBC%']),
      'RBC': get(['RBC']),
      'HGB': get(['HGB']),
      'HCT': get(['HCT']),
      'MCV': get(['MCV']),
      'MCH': get(['MCH']),
      'MCHC': get(['MCHC']),
      'RDWCV': get(['RDW-CV']),
      'RDWSD': get(['RDW-SD']),
      'PLT': get(['PLT']),
      'MPV': get(['MPV']),
      'PDW': get(['PDW']),
      'PCT': get(['PCT']),
      'PLCR': get(['P-LCR']),
      'PLCC': get(['P-LCC']),
      'WBCFlag': get(['WBC Flag']),
      'RBCFlag': get(['RBC Flag']),
      'PLTFlag': get(['PLT Flag']),
      'CRPFlag': get(['CRP Flag']),
    };
  }

  List<List<String>> _parseCsvRows(String text) {
    final rows = <List<String>>[];
    final currentRow = <String>[];
    final currentCell = StringBuffer();
    var inQuotes = false;
    for (var i = 0; i < text.length; i++) {
      final char = text[i];
      final next = i + 1 < text.length ? text[i + 1] : '';
      if (char == '"') {
        if (inQuotes && next == '"') {
          currentCell.write('"');
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char == ',' && !inQuotes) {
        currentRow.add(currentCell.toString().replaceAll('\t', '').trim());
        currentCell.clear();
      } else if ((char == '\n' || char == '\r') && !inQuotes) {
        if (char == '\r' && next == '\n') i++;
        currentRow.add(currentCell.toString().replaceAll('\t', '').trim());
        currentCell.clear();
        rows.add(List<String>.from(currentRow));
        currentRow.clear();
      } else {
        currentCell.write(char);
      }
    }
    if (currentCell.isNotEmpty || currentRow.isNotEmpty) {
      currentRow.add(currentCell.toString().replaceAll('\t', '').trim());
      rows.add(List<String>.from(currentRow));
    }
    return rows;
  }

  void _submit() {
    if (_preview == null) {
      setState(() => _error = 'Choose the CBC / CP(Auto) CSV file.');
      return;
    }
    if (_diffImage?.bytes == null && (_graphBase64['diffHsmsBase64'] ?? '').isEmpty) {
      setState(() => _error = 'Choose the DIFF image or analyzer ZIP.');
      return;
    }
    if (_pltImage?.bytes == null && (_graphBase64['pltGraphBase64'] ?? '').isEmpty) {
      setState(() => _error = 'Choose the PLT image or analyzer ZIP.');
      return;
    }
    Navigator.of(context).pop(
      _CbcCpUploadResult(
        parsedValues: _preview!,
        diffImageBytes: _diffImage?.bytes == null ? null : Uint8List.fromList(_diffImage!.bytes!),
        diffImageName: _diffImage?.name ?? '',
        pltImageBytes: _pltImage?.bytes == null ? null : Uint8List.fromList(_pltImage!.bytes!),
        pltImageName: _pltImage?.name ?? '',
        graphBase64: Map<String, String>.from(_graphBase64),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final preview = _preview;
    return AlertDialog(
      title: Text('CBC / CP(Auto) result: ${widget.sample.id}'),
      content: SizedBox(
        width: 650,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Upload analyzer ZIP, or CSV plus DIFF/PLT image for ${widget.sample.testIds.join(', ')}.'),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  FilledButton.tonalIcon(onPressed: _pickAnalyzerZip, icon: const Icon(Icons.folder_zip_rounded), label: Text(_exportZip == null ? 'Analyzer ZIP' : _exportZip!.name)),
                  FilledButton.tonalIcon(onPressed: _pickCsv, icon: const Icon(Icons.table_chart_rounded), label: Text(_csvFile == null ? 'CSV' : _csvFile!.name)),
                  FilledButton.tonalIcon(onPressed: () => _pickImage(isDiff: true), icon: const Icon(Icons.scatter_plot_rounded), label: Text(_diffImage == null ? 'DIFF image' : _diffImage!.name)),
                  FilledButton.tonalIcon(onPressed: () => _pickImage(isDiff: false), icon: const Icon(Icons.area_chart_rounded), label: Text(_pltImage == null ? 'PLT image' : _pltImage!.name)),
                ],
              ),
              if (_error != null) ...[
                const SizedBox(height: 10),
                Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ],
              if (preview != null) ...[
                const SizedBox(height: 14),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: ['sampleId', 'mode', 'WBC', 'RBC', 'HGB', 'HCT', 'PLT', 'WBCFlag', 'RBCFlag', 'PLTFlag']
                      .map((key) => Chip(label: Text('$key: ${preview[key] ?? '-'}')))
                      .toList(),
                ),
              ],
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
        FilledButton.icon(onPressed: _submit, icon: const Icon(Icons.save_rounded), label: const Text('Upload + Save')),
      ],
    );
  }
}

class _SampleDataSource extends DataTableSource {
  _SampleDataSource(
    this._samples,
    this._isLabTech,
    this._isAdmin,
    this._isStaff,
    this._tests,
    this._pricings, {
    required this.selectedSampleIds,
    required this.busySampleId,
    required this.onSelectSample,
    required this.onReview,
    required this.onViewResult,
  });

  final List<BloodSample> _samples;
  final bool _isLabTech;
  final bool _isAdmin;
  final bool _isStaff;
  final List<LabTest> _tests;
  final List<SubCenterPricing> _pricings;
  final Set<String> selectedSampleIds;
  final String? busySampleId;
  final void Function(BloodSample sample, bool selected) onSelectSample;
  final Future<void> Function(BloodSample sample) onReview;
  final void Function(BloodSample sample) onViewResult;

  double _sampleTotalCost(BloodSample sample) {
    return sample.testIds.fold<double>(0, (sum, testIdOrName) {
      return sum + _customerPriceFor(sample.subCenterId, testIdOrName);
    });
  }

  double _customerPriceFor(String subCenterId, String testIdOrName) {
    final test = _testFor(testIdOrName);
    final normalizedCenter = _normalize(subCenterId);
    final normalizedTestId = _normalize(test.id);
    final normalizedTestName = _normalize(test.testName);
    final normalizedOriginal = _normalize(testIdOrName);

    for (final pricing in _pricings) {
      if (_normalize(pricing.subCenterId) != normalizedCenter) continue;
      final pricingTest = _normalize(pricing.testId);
      if (pricingTest == normalizedTestId ||
          pricingTest == normalizedTestName ||
          pricingTest == normalizedOriginal) {
        return pricing.customPrice > 0 ? pricing.customPrice : test.defaultPrice;
      }
    }

    return test.defaultPrice;
  }

  LabTest _testFor(String testIdOrName) {
    final normalizedInput = _normalize(testIdOrName);
    for (final test in _tests) {
      if (_normalize(test.id) == normalizedInput ||
          _normalize(test.testName) == normalizedInput) {
        return test;
      }
    }

    return LabTest(
      id: testIdOrName,
      testName: testIdOrName,
      defaultPrice: 0,
    );
  }

  String _normalize(String value) {
    return value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
  }

  @override
  DataRow? getRow(int index) {
    if (index >= _samples.length) return null;
    final sample = _samples[index];
    final dateLabel = sample.createdAt != null
        ? sample.createdAt!.toLocal().toString().split(' ').first
        : '-';
    final testsLabel = sample.testIds.join(', ');

    final canSelectForPrint = sample.status == BloodSampleStatus.completed;
    return DataRow.byIndex(
      index: index,
      selected: selectedSampleIds.contains(sample.id),
      onSelectChanged: canSelectForPrint ? (selected) => onSelectSample(sample, selected ?? false) : null,
      cells: [
        DataCell(Text(sample.id)),
        DataCell(Text(sample.patientName)),
        DataCell(Text(sample.subCenterId)),
        DataCell(Text(testsLabel)),
        if (_isStaff)
          DataCell(Text(_sampleTotalCost(sample).toStringAsFixed(2))),
        DataCell(_StatusChip(status: sample.status)),
        DataCell(Text(dateLabel)),
        DataCell(_GeneratedResultButton(sample: sample, onView: () => onViewResult(sample))),
        if (_isLabTech || _isAdmin)
          DataCell(
            Row(
              children: [
                if (_isLabTech)
                  TextButton.icon(
                    onPressed: busySampleId == null
                        ? () => onReview(sample)
                        : null,
                    icon: busySampleId == sample.id
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : Icon(
                            sample.status == BloodSampleStatus.pending
                                ? Icons.play_arrow_rounded
                                : Icons.upload_file_rounded,
                          ),
                    label: Text(
                      busySampleId == sample.id
                          ? 'Working...'
                          : _reviewLabel(sample.status),
                    ),
                  ),
                if (_isAdmin)
                  TextButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.check_circle_outline_rounded),
                    label: const Text('Approve'),
                  ),
              ],
            ),
          ),
      ],
    );
  }

  @override
  bool get isRowCountApproximate => false;

  @override
  int get rowCount => _samples.length;

  @override
  int get selectedRowCount => selectedSampleIds.length;
}

class _PrintableSampleResult {
  const _PrintableSampleResult({required this.sample, required this.manualRows, required this.cbcRow});
  final BloodSample sample;
  final List<Map<String, String>> manualRows;
  final Map<String, String>? cbcRow;
}

class _PrintableResultRow {
  const _PrintableResultRow({
    required this.sampleId,
    required this.patientName,
    required this.testName,
    required this.parameter,
    required this.result,
    required this.unit,
    required this.referenceRange,
    required this.notes,
  });

  final String sampleId;
  final String patientName;
  final String testName;
  final String parameter;
  final String result;
  final String unit;
  final String referenceRange;
  final String notes;
}

class _MultiPrintHeaderSettings {
  const _MultiPrintHeaderSettings({
    required this.subCenterId,
    required this.hospitalName,
    required this.departmentName,
    required this.township,
    required this.ministryName,
    required this.reportTitle,
    required this.accentColor,
  });

  final String subCenterId;
  final String hospitalName;
  final String departmentName;
  final String township;
  final String ministryName;
  final String reportTitle;
  final String accentColor;

  factory _MultiPrintHeaderSettings.defaults({required String subCenterId}) {
    return _MultiPrintHeaderSettings(
      subCenterId: subCenterId,
      hospitalName: 'Aung Myin Station Hospital',
      departmentName: 'Laboratory Department',
      township: 'Kyouttaga Township',
      ministryName: 'Ministry of Health',
      reportTitle: 'LAB REPORT',
      accentColor: '#1D4ED8',
    );
  }

  factory _MultiPrintHeaderSettings.fromMap(Map<String, String> map, {required _MultiPrintHeaderSettings fallback}) {
    String pick(String key, String fallbackValue) {
      final value = map[key]?.trim() ?? '';
      return value.isEmpty ? fallbackValue : value;
    }
    return _MultiPrintHeaderSettings(
      subCenterId: pick('subcenterid', fallback.subCenterId),
      hospitalName: pick('hospitalname', fallback.hospitalName),
      departmentName: pick('departmentname', fallback.departmentName),
      township: pick('township', fallback.township),
      ministryName: pick('ministryname', fallback.ministryName),
      reportTitle: pick('reporttitle', fallback.reportTitle),
      accentColor: pick('accentcolor', fallback.accentColor),
    );
  }
}

String _reviewLabel(BloodSampleStatus status) {
  return switch (status) {
    BloodSampleStatus.pending => 'Start Review',
    BloodSampleStatus.processing => 'Complete + Upload',
    BloodSampleStatus.completed => 'Replace Result',
  };
}


class _GeneratedResultButton extends StatelessWidget {
  const _GeneratedResultButton({required this.sample, required this.onView});

  final BloodSample sample;
  final VoidCallback onView;

  @override
  Widget build(BuildContext context) {
    final completed = sample.status == BloodSampleStatus.completed;
    return FilledButton.tonalIcon(
      onPressed: completed ? onView : null,
      icon: Icon(completed ? Icons.visibility_rounded : Icons.hourglass_empty_rounded),
      label: Text(completed ? 'View result' : 'Not ready'),
    );
  }
}

class _StatusChip extends StatelessWidget {
  const _StatusChip({required this.status});

  final BloodSampleStatus status;

  @override
  Widget build(BuildContext context) {
    final color = switch (status) {
      BloodSampleStatus.pending => Colors.orange,
      BloodSampleStatus.processing => Colors.blue,
      BloodSampleStatus.completed => Colors.green,
    };

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        status.name,
        style: TextStyle(color: color, fontWeight: FontWeight.w800),
      ),
    );
  }
}

class _ErrorCard extends StatelessWidget {
  const _ErrorCard({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.error_outline_rounded,
                size: 48,
                color: Theme.of(context).colorScheme.error,
              ),
              const SizedBox(height: 12),
              Text(message, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Try again'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
