import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../config/google_config.dart';
import '../models/app_user.dart';
import '../models/lab_test.dart';
import '../models/sub_center_pricing.dart';
import '../providers/auth_notifier.dart';
import '../providers/sample_dashboard_controller.dart';
import '../providers/tests_provider.dart';
import '../services/turso_native_service.dart';
import '../widgets/app_sidebar.dart';

class RegisterSamplePage extends ConsumerStatefulWidget {
  const RegisterSamplePage({super.key});

  @override
  ConsumerState<RegisterSamplePage> createState() => _RegisterSamplePageState();
}

class _RegisterSamplePageState extends ConsumerState<RegisterSamplePage> {
  final _formKey = GlobalKey<FormState>();
  final _patientNameController = TextEditingController();
  final _patientAgeController = TextEditingController();
  final _patientAddressController = TextEditingController();
  final _testSearchController = TextEditingController();
  String? _selectedSex;
  final Set<String> _selectedTestKeys = <String>{};
  bool _saving = false;
  bool _loadingReferrals = false;
  List<_ReferralOption> _referralOptions = const <_ReferralOption>[];
  String? _selectedReferralId;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadReferralOptions());
  }

  @override
  void dispose() {
    _patientNameController.dispose();
    _patientAgeController.dispose();
    _patientAddressController.dispose();
    _testSearchController.dispose();
    super.dispose();
  }

  String _testKey(LabTest test) => test.id.trim().isNotEmpty ? test.id.trim() : test.testName.trim();

  String _normalize(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  String _subCenterIdFor(AppUser user) {
    final raw = user.subCenterId?.trim() ?? '';
    return raw.isEmpty ? 'GLOBAL' : raw;
  }

  Future<void> _loadReferralOptions() async {
    final user = ref.read(authNotifierProvider);
    if (user == null) return;
    const self = _ReferralOption(
      id: 'self',
      name: 'Self',
      subCenterId: 'Self',
      isSelf: true,
    );
    setState(() => _loadingReferrals = true);
    TursoNativeService? service;
    try {
      service = TursoNativeService(
        serviceAccountJson: await rootBundle.loadString('assets/service-account.json'),
        applicationName: 'flutterlab',
      );
      final rows = await service.fetchRows(spreadsheetId: GoogleConfig.spreadsheetId, range: 'Users!A:F');
      final options = <_ReferralOption>[self];
      if (rows.length > 1) {
        final headers = rows.first.map((header) => _normalize(header)).toList();
        String cell(List<String> row, String key) {
          final index = headers.indexOf(_normalize(key));
          return index >= 0 && index < row.length ? row[index].trim() : '';
        }
        final userCenter = _normalize(_subCenterIdFor(user));
        for (final row in rows.skip(1)) {
          final role = cell(row, 'role').toLowerCase();
          if (role != 'referred_person' && role != 'refered_person') continue;
          final center = cell(row, 'subCenterId').isEmpty ? 'GLOBAL' : cell(row, 'subCenterId');
          if (user.role != AppUserRole.superadmin && _normalize(center) != userCenter) continue;
          final id = cell(row, 'id');
          final name = cell(row, 'name').isEmpty ? cell(row, 'username') : cell(row, 'name');
          if (id.isEmpty || name.isEmpty) continue;
          options.add(_ReferralOption(id: id, name: name, subCenterId: center));
        }
      }
      if (!mounted) return;
      setState(() {
        _referralOptions = options;
        if (_selectedReferralId == null || !options.any((option) => option.id == _selectedReferralId)) {
          _selectedReferralId = self.id;
        }
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _referralOptions = <_ReferralOption>[self];
        _selectedReferralId ??= self.id;
      });
    } finally {
      await service?.close();
      if (mounted) setState(() => _loadingReferrals = false);
    }
  }

  _ReferralOption _selectedReferralFor(AppUser user) {
    const self = _ReferralOption(
      id: 'self',
      name: 'Self',
      subCenterId: 'Self',
      isSelf: true,
    );
    if (_referralOptions.isEmpty) return self;
    return _referralOptions.firstWhere(
      (option) => option.id == _selectedReferralId,
      orElse: () => _referralOptions.first,
    );
  }

  Widget _buildReferralSelector(ThemeData theme) {
    if (_loadingReferrals && _referralOptions.isEmpty) {
      return const LinearProgressIndicator(minHeight: 3);
    }
    final options = _referralOptions;
    final value = options.any((option) => option.id == _selectedReferralId)
        ? _selectedReferralId
        : (options.isEmpty ? null : options.first.id);
    return DropdownButtonFormField<String>(
      value: value,
      decoration: const InputDecoration(
        labelText: 'Referred person',
        helperText: 'Default is self. Select a referred person before registering the sample.',
        prefixIcon: Icon(Icons.person_pin_rounded),
        border: OutlineInputBorder(),
      ),
      items: [
        for (final option in options)
          DropdownMenuItem(
            value: option.id,
            child: Text(option.isSelf ? option.name : '${option.name} • ${option.subCenterId}'),
          ),
      ],
      onChanged: _saving ? null : (value) => setState(() => _selectedReferralId = value),
    );
  }

  String _sampleDatePrefix(DateTime createdAt) {
    final day = createdAt.day.toString().padLeft(2, '0');
    final month = createdAt.month.toString().padLeft(2, '0');
    final year = (createdAt.year % 100).toString().padLeft(2, '0');
    return '$day$month$year';
  }

  String _sampleIdFor({
    required DateTime createdAt,
    required int index,
  }) {
    final sequence = ((createdAt.microsecondsSinceEpoch + index) % 10000)
        .toString()
        .padLeft(4, '0');
    return '${_sampleDatePrefix(createdAt)}-$sequence';
  }

  SubCenterPricing? _pricingFor(AppUser user, LabTest test, List<SubCenterPricing> pricings) {
    final normalizedCenter = _normalize(_subCenterIdFor(user));
    final normalizedTestId = _normalize(test.id);
    final normalizedTestName = _normalize(test.testName);

    for (final pricing in pricings) {
      if (_normalize(pricing.subCenterId) != normalizedCenter) continue;
      final pricingTest = _normalize(pricing.testId);
      if (pricingTest == normalizedTestId || pricingTest == normalizedTestName) {
        return pricing;
      }
    }
    return null;
  }

  double _customerPriceFor(AppUser user, LabTest test, List<SubCenterPricing> pricings) {
    final pricing = _pricingFor(user, test, pricings);
    return pricing != null && pricing.customPrice > 0 ? pricing.customPrice : test.defaultPrice;
  }

  double _referredFeePercentFor(AppUser user, LabTest test, List<SubCenterPricing> pricings) {
    return _pricingFor(user, test, pricings)?.referredFeePercent ?? 0;
  }

  List<LabTest> _selectedTests(List<LabTest> tests) {
    return tests.where((test) => _selectedTestKeys.contains(_testKey(test))).toList();
  }

  double _selectedTotal(AppUser user, List<LabTest> tests, List<SubCenterPricing> pricings) {
    return _selectedTests(tests).fold<double>(0, (sum, test) => sum + _customerPriceFor(user, test, pricings));
  }

  Future<List<String>> _buildBloodSampleInsertRow(
    TursoNativeService service, {
    required String registrationId,
    required String sampleId,
    required String patientName,
    required String patientAge,
    required String patientSex,
    required String patientAddress,
    required String status,
    required String testId,
    required String testName,
    required String registeredByUserId,
    required String subCenterId,
    required String resultUrl,
    required String createdAt,
    required String updatedAt,
    required String testPrice,
    required String totalAmount,
    required String referredPersonId,
    required String referredPersonName,
    required String referredFeePercent,
    required String referredFeeAmount,
  }) async {
    final desiredHeaders = <String>[
      'id',
      'registrationId',
      'patientName',
      'status',
      'testIds',
      'testId',
      'registeredByUserId',
      'subCenterId',
      'resultUrl',
      'createdAt',
      'updatedAt',
      'patientAge',
      'patientSex',
      'patientAddress',
      'testPrice',
      'totalAmount',
      'referredPersonId',
      'referredPersonName',
      'referredFeePercent',
      'referredFeeAmount',
    ];

    final rows = await service.fetchRows(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'BloodSamples!A1:Z1',
    );

    var displayHeaders = rows.isEmpty || rows.first.isEmpty
        ? <String>[]
        : rows.first.map((header) => header.trim()).where((header) => header.isNotEmpty).toList();

    if (displayHeaders.isEmpty) {
      displayHeaders = List<String>.from(desiredHeaders);
    } else {
      final normalized = displayHeaders
          .map((header) => header.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
          .toSet();
      for (final header in desiredHeaders) {
        final key = header.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
        if (!normalized.contains(key)) {
          displayHeaders.add(header);
          normalized.add(key);
        }
      }
    }

    await service.updateRow(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'BloodSamples!A1:Z1',
      values: displayHeaders,
    );

    final headerMap = <String, String>{
      'id': sampleId,
      'sampleid': sampleId,
      'registrationid': registrationId,
      'patientname': patientName,
      'patient': patientName,
      'name': patientName,
      'patientage': patientAge,
      'age': patientAge,
      'patientsex': patientSex,
      'sex': patientSex,
      'gender': patientSex,
      'patientaddress': patientAddress,
      'address': patientAddress,
      'status': status,
      'testids': testName,
      'tests': testName,
      'testid': testId,
      'registeredbyuserid': registeredByUserId,
      'registeredby': registeredByUserId,
      'subcenterid': subCenterId,
      'center': subCenterId,
      'subcenter': subCenterId,
      'resulturl': resultUrl,
      'result': resultUrl,
      'createdat': createdAt,
      'created': createdAt,
      'updatedat': updatedAt,
      'updated': updatedAt,
      'testprice': testPrice,
      'price': testPrice,
      'totalamount': totalAmount,
      'amount': totalAmount,
      'referredpersonid': referredPersonId,
      'referedpersonid': referredPersonId,
      'referredbyid': referredPersonId,
      'referredpersonname': referredPersonName,
      'referedpersonname': referredPersonName,
      'referredbyname': referredPersonName,
      'referredfeepercent': referredFeePercent,
      'referedfeepercent': referredFeePercent,
      'referredfeepercent': referredFeePercent,
      'referredfeeamount': referredFeeAmount,
      'referedfeeamount': referredFeeAmount,
      'referredfee': referredFeeAmount,
    };

    final headers = displayHeaders
        .map((header) => header.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();

    return [for (final header in headers) headerMap[header] ?? ''];
  }

  Future<void> _registerSamples(AppUser user, List<LabTest> tests, List<SubCenterPricing> pricings) async {
    if (!_formKey.currentState!.validate()) return;
    final selectedTests = _selectedTests(tests);
    if (selectedTests.isEmpty) {
      _showToast('Please select at least one blood test.', isError: true);
      return;
    }

    setState(() => _saving = true);
    TursoNativeService? service;
    try {
      final now = DateTime.now();
      final timestamp = now.toUtc().toIso8601String();
      final registrationId = 'reg-${now.millisecondsSinceEpoch}';
      final totalAmount = _selectedTotal(user, tests, pricings).toStringAsFixed(0);
      final subCenterId = _subCenterIdFor(user);
      final referredPerson = _selectedReferralFor(user);
      final serviceAccountJson = await rootBundle.loadString('assets/service-account.json');
      service = TursoNativeService(
        serviceAccountJson: serviceAccountJson,
        applicationName: 'flutterlab',
      );

      for (var i = 0; i < selectedTests.length; i++) {
        final test = selectedTests[i];
        final customerPrice = _customerPriceFor(user, test, pricings);
        final referredFeePercent = referredPerson.isSelf ? 0.0 : _referredFeePercentFor(user, test, pricings);
        final referredFeeAmount = customerPrice * referredFeePercent / 100;
        final testPrice = customerPrice.toStringAsFixed(0);
        final rowValues = await _buildBloodSampleInsertRow(
          service,
          registrationId: registrationId,
          sampleId: _sampleIdFor(createdAt: now, index: i),
          patientName: _patientNameController.text.trim(),
          patientAge: _patientAgeController.text.trim(),
          patientSex: _selectedSex ?? '',
          patientAddress: _patientAddressController.text.trim(),
          status: 'pending',
          testId: test.id.trim().isNotEmpty ? test.id.trim() : test.testName.trim(),
          testName: test.testName.trim(),
          registeredByUserId: user.id,
          subCenterId: subCenterId,
          resultUrl: '',
          createdAt: timestamp,
          updatedAt: timestamp,
          testPrice: testPrice,
          totalAmount: totalAmount,
          referredPersonId: referredPerson.isSelf ? 'self' : referredPerson.id,
          referredPersonName: referredPerson.isSelf ? 'Self' : referredPerson.name,
          referredFeePercent: referredFeePercent.toStringAsFixed(2),
          referredFeeAmount: referredFeeAmount.toStringAsFixed(2),
        );

        await service.insertRow(
          spreadsheetId: GoogleConfig.spreadsheetId,
          range: 'BloodSamples!A:Z',
          values: rowValues,
          valueInputOption: 'RAW',
        );
      }

      _patientNameController.clear();
      _patientAgeController.clear();
      _patientAddressController.clear();
      _testSearchController.clear();
      _selectedSex = null;
      _selectedReferralId = _referralOptions.isEmpty ? null : _referralOptions.first.id;
      _selectedTestKeys.clear();
      ref.invalidate(sampleDashboardControllerProvider);
      _showToast('Registered ${selectedTests.length} row(s). Total amount: $totalAmount');
      if (mounted) setState(() {});
    } catch (error) {
      _showToast('Register failed: $error', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  void _showToast(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    final testsAsync = ref.watch(testsProvider);
    final pricingsAsync = ref.watch(pricingsProvider);
    final theme = Theme.of(context);

    return AppScaffold(
      title: 'Register Sample',
      selectedRoute: '/register-sample',
      user: user,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Refresh tests',
          onPressed: _saving
              ? null
              : () {
                  ref.invalidate(testsProvider);
                  ref.invalidate(pricingsProvider);
                },
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        child: user == null
            ? const Center(child: Text('Please sign in.'))
            : testsAsync.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (error, _) => Center(child: Text('Tests load failed: $error')),
                data: (tests) {
                  final pricings = pricingsAsync.maybeWhen(
                    data: (value) => value,
                    orElse: () => const <SubCenterPricing>[],
                  );
                  return _buildContent(context, user, tests, pricings, theme);
                },
              ),
      ),
    );
  }

  Widget _buildContent(BuildContext context, AppUser user, List<LabTest> tests, List<SubCenterPricing> pricings, ThemeData theme) {
    final query = _normalize(_testSearchController.text);
    final filteredTests = query.isEmpty
        ? tests
        : tests.where((test) {
            return _normalize(test.testName).contains(query) || _normalize(test.id).contains(query);
          }).toList();
    final selectedTests = _selectedTests(tests);
    final total = _selectedTotal(user, tests, pricings);
    final subCenterId = _subCenterIdFor(user);
    if (_referralOptions.isEmpty && !_loadingReferrals) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _loadReferralOptions());
    }

    return SingleChildScrollView(
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                gradient: const LinearGradient(colors: [Color(0xFF0F766E), Color(0xFF2563EB), Color(0xFF7C3AED)]),
                boxShadow: [
                  BoxShadow(color: theme.colorScheme.primary.withValues(alpha: 0.22), blurRadius: 26, offset: const Offset(0, 15)),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(24)),
                    child: const Icon(Icons.addchart_rounded, color: Colors.white, size: 36),
                  ),
                  const SizedBox(width: 18),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Register Blood Sample', style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 6),
                        Text('Sub-center: $subCenterId. Select a referred person, then select one or more tests. Each selected test creates its own row in BloodSamples.', style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white.withValues(alpha: 0.88))),
                      ],
                    ),
                  ),
                  Chip(
                    avatar: const Icon(Icons.payments_rounded, size: 18),
                    label: Text('Total: ${total.toStringAsFixed(0)}'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            Card(
              elevation: 0,
              color: theme.colorScheme.surface.withValues(alpha: 0.94),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Patient Information', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 16),
                    _buildReferralSelector(theme),
                    const SizedBox(height: 16),
                    LayoutBuilder(builder: (context, constraints) {
                      final compact = constraints.maxWidth < 760;
                      final nameField = TextFormField(
                        controller: _patientNameController,
                        decoration: const InputDecoration(labelText: 'Patient name', prefixIcon: Icon(Icons.person_rounded), border: OutlineInputBorder()),
                        validator: (value) => value == null || value.trim().isEmpty ? 'Enter patient name' : null,
                      );
                      final ageField = TextFormField(
                        controller: _patientAgeController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Age', prefixIcon: Icon(Icons.cake_rounded), border: OutlineInputBorder()),
                        validator: (value) => value == null || value.trim().isEmpty ? 'Enter age' : null,
                      );
                      final sexField = DropdownButtonFormField<String>(
                        value: _selectedSex,
                        decoration: const InputDecoration(labelText: 'Sex', prefixIcon: Icon(Icons.wc_rounded), border: OutlineInputBorder()),
                        items: const [
                          DropdownMenuItem(value: 'Male', child: Text('Male')),
                          DropdownMenuItem(value: 'Female', child: Text('Female')),
                          DropdownMenuItem(value: 'Other', child: Text('Other')),
                        ],
                        validator: (value) => value == null || value.trim().isEmpty ? 'Select sex' : null,
                        onChanged: _saving ? null : (value) => setState(() => _selectedSex = value),
                      );
                      if (compact) {
                        return Column(
                          children: [
                            nameField,
                            const SizedBox(height: 12),
                            Row(children: [Expanded(child: ageField), const SizedBox(width: 12), Expanded(child: sexField)]),
                          ],
                        );
                      }
                      return Row(
                        children: [
                          Expanded(flex: 3, child: nameField),
                          const SizedBox(width: 12),
                          Expanded(child: ageField),
                          const SizedBox(width: 12),
                          Expanded(child: sexField),
                        ],
                      );
                    }),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _patientAddressController,
                      minLines: 2,
                      maxLines: 3,
                      decoration: const InputDecoration(labelText: 'Address', prefixIcon: Icon(Icons.home_rounded), border: OutlineInputBorder()),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            Card(
              elevation: 0,
              color: theme.colorScheme.surface.withValues(alpha: 0.94),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(child: Text('Searchable Blood Tests', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900))),
                        Chip(label: Text('${selectedTests.length} selected')),
                        const SizedBox(width: 8),
                        Chip(label: Text('Total ${total.toStringAsFixed(0)}')),
                      ],
                    ),
                    const SizedBox(height: 14),
                    TextField(
                      controller: _testSearchController,
                      onChanged: (_) => setState(() {}),
                      decoration: InputDecoration(
                        hintText: 'Search blood test, e.g. CBC, ESR...',
                        prefixIcon: const Icon(Icons.search_rounded),
                        suffixIcon: _testSearchController.text.isEmpty
                            ? null
                            : IconButton(
                                onPressed: () {
                                  _testSearchController.clear();
                                  setState(() {});
                                },
                                icon: const Icon(Icons.clear_rounded),
                              ),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                      ),
                    ),
                    const SizedBox(height: 14),
                    if (tests.isEmpty)
                      const Text('No tests found. Please add tests first.')
                    else if (filteredTests.isEmpty)
                      const Text('No tests match the search.')
                    else
                      Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        children: [
                          for (final test in filteredTests)
                            FilterChip(
                              selected: _selectedTestKeys.contains(_testKey(test)),
                              label: Text('${test.testName} (${_customerPriceFor(user, test, pricings).toStringAsFixed(0)})'),
                              onSelected: _saving
                                  ? null
                                  : (selected) {
                                      setState(() {
                                        final key = _testKey(test);
                                        if (selected) {
                                          _selectedTestKeys.add(key);
                                        } else {
                                          _selectedTestKeys.remove(key);
                                        }
                                      });
                                    },
                            ),
                        ],
                      ),
                    if (selectedTests.isNotEmpty) ...[
                      const SizedBox(height: 18),
                      Text('Selected tests will be saved as separate BloodSamples rows:', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          for (final test in selectedTests)
                            Chip(
                              avatar: const Icon(Icons.biotech_rounded, size: 18),
                              label: Text('${test.testName}: ${_customerPriceFor(user, test, pricings).toStringAsFixed(0)}'),
                              onDeleted: _saving ? null : () => setState(() => _selectedTestKeys.remove(_testKey(test))),
                            ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            Align(
              alignment: Alignment.centerRight,
              child: FilledButton.icon(
                onPressed: _saving || tests.isEmpty ? null : () => _registerSamples(user, tests, pricings),
                icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_rounded),
                label: Text(_saving ? 'Registering...' : 'Register ${selectedTests.length} Sample Row(s)'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class _ReferralOption {
  const _ReferralOption({required this.id, required this.name, required this.subCenterId, this.isSelf = false});

  final String id;
  final String name;
  final String subCenterId;
  final bool isSelf;
}
