import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../config/google_config.dart';
import '../models/app_user.dart';
import '../providers/auth_notifier.dart';
import '../services/turso_native_service.dart';
import '../widgets/app_sidebar.dart';

const _sheetName = 'ReportHeaderSettings';
const _range = 'ReportHeaderSettings!A:J';
const _headerRange = 'ReportHeaderSettings!A1:J1';
const _headers = <String>[
  'scopeType',
  'subCenterId',
  'hospitalName',
  'departmentName',
  'township',
  'ministryName',
  'reportTitle',
  'accentColor',
  'updatedAt',
  'updatedByUserId',
];

class ReportHeaderSettingsPage extends ConsumerStatefulWidget {
  const ReportHeaderSettingsPage({super.key});

  @override
  ConsumerState<ReportHeaderSettingsPage> createState() => _ReportHeaderSettingsPageState();
}

class _ReportHeaderSettingsPageState extends ConsumerState<ReportHeaderSettingsPage> {
  final _hospitalController = TextEditingController();
  final _departmentController = TextEditingController();
  final _townshipController = TextEditingController();
  final _ministryController = TextEditingController();
  final _titleController = TextEditingController();
  final _accentController = TextEditingController(text: '#1D4ED8');

  bool _loading = true;
  bool _saving = false;
  String? _message;
  int? _existingRowNumber;
  String _scopeType = 'GLOBAL';
  String _subCenterId = 'GLOBAL';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  @override
  void dispose() {
    _hospitalController.dispose();
    _departmentController.dispose();
    _townshipController.dispose();
    _ministryController.dispose();
    _titleController.dispose();
    _accentController.dispose();
    super.dispose();
  }

  Future<TursoNativeService> _service() async {
    return TursoNativeService(
      serviceAccountJson: await rootBundle.loadString('assets/service-account.json'),
      applicationName: 'flutterlab',
    );
  }

  Future<void> _ensureHeaders(TursoNativeService service) async {
    await service.ensureSheet(spreadsheetId: GoogleConfig.spreadsheetId, sheetName: _sheetName);
    final rows = await service.fetchRows(spreadsheetId: GoogleConfig.spreadsheetId, range: _headerRange);
    final current = rows.isEmpty ? const <String>[] : rows.first;
    final normalized = current.map(_normalize).toList();
    final expected = _headers.map(_normalize).toList();
    var mismatch = normalized.length < expected.length;
    if (!mismatch) {
      for (var i = 0; i < expected.length; i++) {
        if (normalized[i] != expected[i]) {
          mismatch = true;
          break;
        }
      }
    }
    if (mismatch) {
      await service.updateRow(spreadsheetId: GoogleConfig.spreadsheetId, range: _headerRange, values: _headers);
    }
  }

  Future<void> _load() async {
    final user = ref.read(authNotifierProvider);
    if (user == null) return;
    final isSuperadmin = user.role == AppUserRole.superadmin;
    _scopeType = isSuperadmin ? 'GLOBAL' : 'SUBCENTER';
    _subCenterId = isSuperadmin ? 'GLOBAL' : (user.subCenterId ?? '').trim();
    if (_subCenterId.isEmpty) _subCenterId = 'GLOBAL';

    setState(() {
      _loading = true;
      _message = null;
    });

    final service = await _service();
    try {
      await _ensureHeaders(service);
      final rows = await service.fetchRows(spreadsheetId: GoogleConfig.spreadsheetId, range: _range);
      _existingRowNumber = null;
      Map<String, String>? record;
      if (rows.length > 1) {
        final normalizedHeaders = rows.first.map(_normalize).toList();
        for (var r = 1; r < rows.length; r++) {
          final row = rows[r];
          final map = <String, String>{};
          for (var c = 0; c < normalizedHeaders.length; c++) {
            map[normalizedHeaders[c]] = c < row.length ? row[c].trim() : '';
          }
          if (_normalize(map['scopetype'] ?? '') == _normalize(_scopeType) &&
              _normalize(map['subcenterid'] ?? '') == _normalize(_subCenterId)) {
            record = map;
            _existingRowNumber = r + 1;
            break;
          }
        }
      }
      final defaults = _ReportHeaderSettings.defaults(scopeType: _scopeType, subCenterId: _subCenterId);
      final settings = record == null ? defaults : _ReportHeaderSettings.fromMap(record, fallback: defaults);
      _hospitalController.text = settings.hospitalName;
      _departmentController.text = settings.departmentName;
      _townshipController.text = settings.township;
      _ministryController.text = settings.ministryName;
      _titleController.text = settings.reportTitle;
      _accentController.text = settings.accentColor;
    } catch (error) {
      _message = 'Load failed: $error';
    } finally {
      await service.close();
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _save() async {
    final user = ref.read(authNotifierProvider);
    if (user == null) return;
    setState(() {
      _saving = true;
      _message = null;
    });
    final service = await _service();
    try {
      await _ensureHeaders(service);
      final values = <String>[
        _scopeType,
        _subCenterId,
        _hospitalController.text.trim().isEmpty ? 'Aung Myin Station Hospital' : _hospitalController.text.trim(),
        _departmentController.text.trim().isEmpty ? 'Laboratory Department' : _departmentController.text.trim(),
        _townshipController.text.trim().isEmpty ? 'Kyouttaga Township' : _townshipController.text.trim(),
        _ministryController.text.trim().isEmpty ? 'Ministry of Health' : _ministryController.text.trim(),
        _titleController.text.trim().isEmpty ? 'LAB REPORT' : _titleController.text.trim(),
        _normalizeHex(_accentController.text),
        DateTime.now().toUtc().toIso8601String(),
        user.id,
      ];
      if (_existingRowNumber == null) {
        await service.insertRow(spreadsheetId: GoogleConfig.spreadsheetId, range: _range, values: values, valueInputOption: 'RAW');
      } else {
        await service.updateRow(spreadsheetId: GoogleConfig.spreadsheetId, range: '$_sheetName!A$_existingRowNumber:J$_existingRowNumber', values: values);
      }
      await _load();
      _message = 'Report header saved successfully.';
    } catch (error) {
      _message = 'Save failed: $error';
    } finally {
      await service.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  String _normalizeHex(String raw) {
    final cleaned = raw.trim().replaceAll('#', '').toUpperCase();
    if (RegExp(r'^[0-9A-F]{6}$').hasMatch(cleaned)) return '#$cleaned';
    return '#1D4ED8';
  }

  static String _normalize(String raw) => raw.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    final theme = Theme.of(context);
    final scopeLabel = user?.role == AppUserRole.superadmin ? 'Default global header' : 'Sub-center header: $_subCenterId';
    return AppScaffold(
      title: 'Report Header',
      selectedRoute: '/report-header',
      user: user,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      gradient: const LinearGradient(
                        colors: [Color(0xFF1E3A8A), Color(0xFF2563EB)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.12), blurRadius: 28, offset: const Offset(0, 14))],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 66,
                          height: 66,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withValues(alpha: 0.14),
                            border: Border.all(color: Colors.white.withValues(alpha: 0.35)),
                          ),
                          child: const Center(child: Icon(Icons.local_hospital_rounded, color: Colors.white, size: 34)),
                        ),
                        const SizedBox(width: 18),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Modern Blue Accent Header', style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w900)),
                              const SizedBox(height: 6),
                              Text(scopeLabel, style: theme.textTheme.bodyLarge?.copyWith(color: Colors.white.withValues(alpha: 0.82))),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 22),
                  LayoutBuilder(
                    builder: (context, constraints) {
                      final twoCols = constraints.maxWidth > 850;
                      final form = _settingsForm(theme);
                      final preview = _previewCard(theme);
                      return twoCols
                          ? Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: form), const SizedBox(width: 18), Expanded(child: preview)])
                          : Column(children: [form, const SizedBox(height: 18), preview]);
                    },
                  ),
                  if (_message != null) ...[
                    const SizedBox(height: 16),
                    Text(_message!, style: TextStyle(color: _message!.startsWith('Save') || _message!.startsWith('Report') ? Colors.green : theme.colorScheme.error)),
                  ],
                ],
              ),
            ),
    );
  }

  Widget _settingsForm(ThemeData theme) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26), side: BorderSide(color: theme.colorScheme.outlineVariant)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Header details', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 14),
            _field(_hospitalController, 'Hospital name', Icons.local_hospital_rounded),
            const SizedBox(height: 12),
            _field(_departmentController, 'Department name', Icons.science_rounded),
            const SizedBox(height: 12),
            _field(_townshipController, 'Township', Icons.location_city_rounded),
            const SizedBox(height: 12),
            _field(_ministryController, 'Ministry name', Icons.account_balance_rounded),
            const SizedBox(height: 12),
            _field(_titleController, 'Report title', Icons.description_rounded),
            const SizedBox(height: 12),
            _field(_accentController, 'Accent color hex', Icons.color_lens_rounded),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _saving ? null : _save,
                icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_rounded),
                label: Text(_saving ? 'Saving...' : 'Save report header'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController controller, String label, IconData icon) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        filled: true,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
      ),
      onChanged: (_) => setState(() {}),
    );
  }

  Widget _previewCard(ThemeData theme) {
    final accent = _colorFromHex(_accentController.text);
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26), side: BorderSide(color: theme.colorScheme.outlineVariant)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Live preview', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: accent.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: accent.withValues(alpha: 0.25)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 58,
                    height: 58,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white, border: Border.all(color: accent, width: 1.5)),
                    child: Center(child: Text('MOH', style: TextStyle(color: accent, fontWeight: FontWeight.w900))),
                  ),
                  const SizedBox(width: 14),
                  Container(width: 1, height: 74, color: accent.withValues(alpha: 0.35)),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_hospitalController.text.trim().isEmpty ? 'Aung Myin Station Hospital' : _hospitalController.text.trim(), style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
                        const SizedBox(height: 4),
                        Text(_departmentController.text.trim().isEmpty ? 'Laboratory Department' : _departmentController.text.trim(), style: TextStyle(color: accent, fontWeight: FontWeight.w800)),
                        Text(_townshipController.text.trim().isEmpty ? 'Kyouttaga Township' : _townshipController.text.trim()),
                        Text(_ministryController.text.trim().isEmpty ? 'Ministry of Health' : _ministryController.text.trim()),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(20)),
                    child: Text(_titleController.text.trim().isEmpty ? 'LAB REPORT' : _titleController.text.trim(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Text('Superadmin edits the default global header. Admin edits only the header for their own sub-center.', style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
          ],
        ),
      ),
    );
  }

  Color _colorFromHex(String raw) {
    final cleaned = raw.trim().replaceAll('#', '');
    if (!RegExp(r'^[0-9a-fA-F]{6}$').hasMatch(cleaned)) return const Color(0xFF1D4ED8);
    return Color(int.parse('FF$cleaned', radix: 16));
  }
}

class _ReportHeaderSettings {
  const _ReportHeaderSettings({
    required this.scopeType,
    required this.subCenterId,
    required this.hospitalName,
    required this.departmentName,
    required this.township,
    required this.ministryName,
    required this.reportTitle,
    required this.accentColor,
  });

  final String scopeType;
  final String subCenterId;
  final String hospitalName;
  final String departmentName;
  final String township;
  final String ministryName;
  final String reportTitle;
  final String accentColor;

  factory _ReportHeaderSettings.defaults({required String scopeType, required String subCenterId}) {
    return _ReportHeaderSettings(
      scopeType: scopeType,
      subCenterId: subCenterId,
      hospitalName: 'Aung Myin Station Hospital',
      departmentName: 'Laboratory Department',
      township: 'Kyouttaga Township',
      ministryName: 'Ministry of Health',
      reportTitle: 'LAB REPORT',
      accentColor: '#1D4ED8',
    );
  }

  factory _ReportHeaderSettings.fromMap(Map<String, String> map, {required _ReportHeaderSettings fallback}) {
    String pick(String key, String fallbackValue) {
      final value = map[key]?.trim() ?? '';
      return value.isEmpty ? fallbackValue : value;
    }
    return _ReportHeaderSettings(
      scopeType: pick('scopetype', fallback.scopeType),
      subCenterId: pick('subcenterid', fallback.subCenterId),
      hospitalName: pick('hospitalname', fallback.hospitalName),
      departmentName: pick('departmentname', fallback.departmentName),
      township: pick('township', fallback.township),
      ministryName: pick('ministryname', fallback.ministryName),
      reportTitle: pick('reporttitle', fallback.reportTitle),
      accentColor: pick('accentcolor', fallback.accentColor),
    );
  }
}
