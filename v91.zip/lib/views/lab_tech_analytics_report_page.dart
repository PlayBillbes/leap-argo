import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../models/app_user.dart';
import '../models/blood_sample.dart';
import '../models/lab_test.dart';
import '../providers/auth_notifier.dart';
import '../providers/sample_dashboard_controller.dart';
import '../providers/tests_provider.dart';
import '../widgets/app_sidebar.dart';

class LabTechAnalyticsReportPage extends ConsumerStatefulWidget {
  const LabTechAnalyticsReportPage({super.key});

  @override
  ConsumerState<LabTechAnalyticsReportPage> createState() => _LabTechAnalyticsReportPageState();
}

class _LabTechAnalyticsReportPageState extends ConsumerState<LabTechAnalyticsReportPage> {
  late int _selectedYear;
  int _selectedMonth = 0;
  String _searchQuery = '';
  _ReportSortMode _sortMode = _ReportSortMode.totalDesc;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _selectedYear = DateTime.now().year;
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    final samplesAsync = ref.watch(sampleDashboardControllerProvider);
    final testsAsync = ref.watch(testsProvider);

    return AppScaffold(
      title: 'Lab Tech Analytics Report',
      selectedRoute: '/lab-tech-report',
      user: user,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Refresh report',
          onPressed: () {
            ref.invalidate(sampleDashboardControllerProvider);
            ref.invalidate(testsProvider);
          },
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        child: samplesAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, _) => Center(child: Text('Failed to load report: $error')),
          data: (samples) {
            final tests = testsAsync.maybeWhen(data: (items) => items, orElse: () => const <LabTest>[]);
            final report = _LabTechReportData.fromSamples(samples: samples, tests: tests, year: _selectedYear);
            return _ReportContent(
              user: user,
              report: report,
              selectedYear: _selectedYear,
              selectedMonth: _selectedMonth,
              searchQuery: _searchQuery,
              searchController: _searchController,
              sortMode: _sortMode,
              onYearChanged: (year) => setState(() => _selectedYear = year),
              onMonthChanged: (month) => setState(() => _selectedMonth = month),
              onSearchChanged: (query) => setState(() => _searchQuery = query),
              onSortChanged: (mode) => setState(() => _sortMode = mode),
              onExportYearPdf: () => _exportYearPdf(report, user),
              onExportMonthPdf: _selectedMonth == 0 ? null : () => _exportMonthPdf(report, user),
            );
          },
        ),
      ),
    );
  }

  Future<void> _exportYearPdf(_LabTechReportData report, AppUser? user) async {
    final bytes = await _buildLabTechReportPdf(
      report: report,
      user: user,
      exportMode: _ReportExportMode.year,
      selectedMonth: 0,
      searchQuery: _searchQuery,
      sortMode: _sortMode,
    );
    await Printing.layoutPdf(
      name: 'lab_tech_yearly_${report.year}.pdf',
      onLayout: (_) async => bytes,
    );
  }

  Future<void> _exportMonthPdf(_LabTechReportData report, AppUser? user) async {
    if (_selectedMonth == 0) return;
    final bytes = await _buildLabTechReportPdf(
      report: report,
      user: user,
      exportMode: _ReportExportMode.month,
      selectedMonth: _selectedMonth,
      searchQuery: _searchQuery,
      sortMode: _sortMode,
    );
    await Printing.layoutPdf(
      name: 'lab_tech_monthly_${report.year}_${_selectedMonth.toString().padLeft(2, '0')}.pdf',
      onLayout: (_) async => bytes,
    );
  }
}

class _ReportContent extends StatelessWidget {
  const _ReportContent({
    required this.user,
    required this.report,
    required this.selectedYear,
    required this.selectedMonth,
    required this.searchQuery,
    required this.searchController,
    required this.sortMode,
    required this.onYearChanged,
    required this.onMonthChanged,
    required this.onSearchChanged,
    required this.onSortChanged,
    required this.onExportYearPdf,
    required this.onExportMonthPdf,
  });

  final AppUser? user;
  final _LabTechReportData report;
  final int selectedYear;
  final int selectedMonth;
  final String searchQuery;
  final TextEditingController searchController;
  final _ReportSortMode sortMode;
  final ValueChanged<int> onYearChanged;
  final ValueChanged<int> onMonthChanged;
  final ValueChanged<String> onSearchChanged;
  final ValueChanged<_ReportSortMode> onSortChanged;
  final VoidCallback onExportYearPdf;
  final VoidCallback? onExportMonthPdf;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final years = [for (var year = DateTime.now().year; year >= DateTime.now().year - 6; year--) year];
    final yearlyRows = report.filteredYearlyRows(searchQuery: searchQuery, sortMode: sortMode);
    final monthlyRows = report.filteredMonthlyRows(month: selectedMonth, searchQuery: searchQuery, sortMode: sortMode);
    final monthLabel = selectedMonth == 0 ? 'All months' : _monthName(selectedMonth);
    final topTest = report.yearlyRows.isEmpty ? '-' : report.yearlyRows.first.testName;
    final topMonth = report.topMonthLabel;

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _ReportHero(
            year: report.year,
            monthLabel: monthLabel,
            onExportYearPdf: onExportYearPdf,
            onExportMonthPdf: onExportMonthPdf,
          ),
          const SizedBox(height: 18),
          LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 980;
              final cards = [
                _SummaryCard(title: 'Total Tests', value: report.yearlyTotal.toString(), subtitle: '${report.year} all completed and registered tests', icon: Icons.biotech_rounded, color: const Color(0xFF2563EB)),
                _SummaryCard(title: 'Active Months', value: report.activeMonthCount.toString(), subtitle: 'Months with test activity', icon: Icons.calendar_month_rounded, color: const Color(0xFF059669)),
                _SummaryCard(title: 'Top Test', value: topTest, subtitle: 'Highest yearly count', icon: Icons.star_rounded, color: const Color(0xFF7C3AED)),
                _SummaryCard(title: 'Top Month', value: topMonth, subtitle: 'Highest monthly volume', icon: Icons.trending_up_rounded, color: const Color(0xFFEA580C)),
              ];
              if (compact) return Column(children: [for (final card in cards) Padding(padding: const EdgeInsets.only(bottom: 12), child: card)]);
              return Row(children: [for (var i = 0; i < cards.length; i++) ...[Expanded(child: cards[i]), if (i != cards.length - 1) const SizedBox(width: 14)]]);
            },
          ),
          const SizedBox(height: 18),
          _FilterPanel(
            years: years,
            selectedYear: selectedYear,
            selectedMonth: selectedMonth,
            searchQuery: searchQuery,
            searchController: searchController,
            sortMode: sortMode,
            onYearChanged: onYearChanged,
            onMonthChanged: onMonthChanged,
            onSearchChanged: onSearchChanged,
            onSortChanged: onSortChanged,
          ),
          if (selectedMonth == 0) ...[
            const SizedBox(height: 8),
            _InfoHint(text: 'Select a month to enable Export Month PDF. Export Year PDF works for the selected year.'),
          ],
          const SizedBox(height: 18),
          _MonthlyOverviewCard(report: report, selectedMonth: selectedMonth, onMonthChanged: onMonthChanged),
          const SizedBox(height: 18),
          _ReportTableCard(
            title: 'Yearly Test Totals',
            subtitle: 'Searchable yearly summary by test name',
            columns: const ['No.', 'Test Name', 'Total Tests'],
            rows: [for (var i = 0; i < yearlyRows.length; i++) ['${i + 1}', yearlyRows[i].testName, yearlyRows[i].count.toString()]],
            emptyText: 'No yearly tests match the current filter.',
          ),
          const SizedBox(height: 18),
          _ReportTableCard(
            title: 'Monthly Test Details',
            subtitle: selectedMonth == 0 ? 'All months grouped row by row' : '${_monthName(selectedMonth)} detail grouped by test name',
            columns: const ['No.', 'Month', 'Test Name', 'Total Tests'],
            rows: [for (var i = 0; i < monthlyRows.length; i++) ['${i + 1}', _monthName(monthlyRows[i].month), monthlyRows[i].testName, monthlyRows[i].count.toString()]],
            emptyText: 'No monthly tests match the current filter.',
          ),
        ],
      ),
    );
  }
}

class _ReportHero extends StatelessWidget {
  const _ReportHero({required this.year, required this.monthLabel, required this.onExportYearPdf, required this.onExportMonthPdf});
  final int year;
  final String monthLabel;
  final VoidCallback onExportYearPdf;
  final VoidCallback? onExportMonthPdf;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(colors: [Color(0xFF0F766E), Color(0xFF2563EB), Color(0xFF7C3AED)]),
        boxShadow: [BoxShadow(color: theme.colorScheme.primary.withValues(alpha: 0.22), blurRadius: 28, offset: const Offset(0, 16))],
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 760;
          final title = Row(
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.16), borderRadius: BorderRadius.circular(22)),
                child: const Icon(Icons.summarize_rounded, color: Colors.white, size: 34),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Lab Tech Test Report', style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 6),
                    Text('$year • $monthLabel • yearly and monthly totals', style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white.withValues(alpha: 0.88))),
                  ],
                ),
              ),
            ],
          );
          final buttons = Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              FilledButton.tonalIcon(
                onPressed: onExportYearPdf,
                icon: const Icon(Icons.calendar_today_rounded),
                label: const Text('Export Year PDF'),
              ),
              FilledButton.icon(
                onPressed: onExportMonthPdf,
                icon: const Icon(Icons.event_note_rounded),
                label: const Text('Export Month PDF'),
              ),
            ],
          );
          if (compact) {
            return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [title, const SizedBox(height: 16), Align(alignment: Alignment.centerLeft, child: buttons)]);
          }
          return Row(children: [Expanded(child: title), const SizedBox(width: 16), buttons]);
        },
      ),
    );
  }
}

class _InfoHint extends StatelessWidget {
  const _InfoHint({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: theme.colorScheme.primary.withValues(alpha: 0.08),
        border: Border.all(color: theme.colorScheme.primary.withValues(alpha: 0.16)),
      ),
      child: Row(
        children: [
          Icon(Icons.info_outline_rounded, size: 18, color: theme.colorScheme.primary),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: theme.textTheme.bodySmall)),
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.title, required this.value, required this.subtitle, required this.icon, required this.color});
  final String title;
  final String value;
  final String subtitle;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.96),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: color.withValues(alpha: 0.13), borderRadius: BorderRadius.circular(20)), child: Icon(icon, color: color, size: 28)),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 5),
                  Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleLarge?.copyWith(color: color, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 2),
                  Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.bodySmall),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FilterPanel extends StatelessWidget {
  const _FilterPanel({
    required this.years,
    required this.selectedYear,
    required this.selectedMonth,
    required this.searchQuery,
    required this.searchController,
    required this.sortMode,
    required this.onYearChanged,
    required this.onMonthChanged,
    required this.onSearchChanged,
    required this.onSortChanged,
  });

  final List<int> years;
  final int selectedYear;
  final int selectedMonth;
  final String searchQuery;
  final TextEditingController searchController;
  final _ReportSortMode sortMode;
  final ValueChanged<int> onYearChanged;
  final ValueChanged<int> onMonthChanged;
  final ValueChanged<String> onSearchChanged;
  final ValueChanged<_ReportSortMode> onSortChanged;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.96),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final compact = constraints.maxWidth < 920;
            final controls = [
              SizedBox(
                width: 190,
                child: DropdownButtonFormField<int>(
                  value: years.contains(selectedYear) ? selectedYear : years.first,
                  decoration: InputDecoration(labelText: 'Year', prefixIcon: const Icon(Icons.calendar_month_rounded), border: OutlineInputBorder(borderRadius: BorderRadius.circular(18))),
                  items: [for (final year in years) DropdownMenuItem(value: year, child: Text(year.toString()))],
                  onChanged: (value) { if (value != null) onYearChanged(value); },
                ),
              ),
              SizedBox(
                width: 210,
                child: DropdownButtonFormField<int>(
                  value: selectedMonth,
                  decoration: InputDecoration(labelText: 'Month', prefixIcon: const Icon(Icons.event_rounded), border: OutlineInputBorder(borderRadius: BorderRadius.circular(18))),
                  items: [const DropdownMenuItem(value: 0, child: Text('All months')), for (var month = 1; month <= 12; month++) DropdownMenuItem(value: month, child: Text(_monthName(month)))],
                  onChanged: (value) { if (value != null) onMonthChanged(value); },
                ),
              ),
              SizedBox(
                width: compact ? constraints.maxWidth : 280,
                child: TextField(
                  controller: searchController,
                  onChanged: onSearchChanged,
                  decoration: InputDecoration(labelText: 'Search test name', prefixIcon: const Icon(Icons.search_rounded), border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)), suffixIcon: searchQuery.isEmpty ? null : IconButton(onPressed: () { searchController.clear(); onSearchChanged(''); }, icon: const Icon(Icons.clear_rounded))),
                ),
              ),
              SizedBox(
                width: 220,
                child: DropdownButtonFormField<_ReportSortMode>(
                  value: sortMode,
                  decoration: InputDecoration(labelText: 'Sort', prefixIcon: const Icon(Icons.sort_rounded), border: OutlineInputBorder(borderRadius: BorderRadius.circular(18))),
                  items: const [
                    DropdownMenuItem(value: _ReportSortMode.totalDesc, child: Text('Highest total first')),
                    DropdownMenuItem(value: _ReportSortMode.nameAsc, child: Text('Test name A-Z')),
                    DropdownMenuItem(value: _ReportSortMode.monthAsc, child: Text('Month order')),
                  ],
                  onChanged: (value) { if (value != null) onSortChanged(value); },
                ),
              ),
            ];
            return Wrap(spacing: 12, runSpacing: 12, children: controls);
          },
        ),
      ),
    );
  }
}

class _MonthlyOverviewCard extends StatelessWidget {
  const _MonthlyOverviewCard({required this.report, required this.selectedMonth, required this.onMonthChanged});
  final _LabTechReportData report;
  final int selectedMonth;
  final ValueChanged<int> onMonthChanged;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final maxCount = report.monthSummary.fold<int>(0, (max, row) => row.count > max ? row.count : max);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.96),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: theme.colorScheme.primary.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(16)), child: Icon(Icons.bar_chart_rounded, color: theme.colorScheme.primary)),
                const SizedBox(width: 12),
                Expanded(child: Text('Monthly Overview', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900))),
                TextButton.icon(onPressed: () => onMonthChanged(0), icon: const Icon(Icons.filter_alt_off_rounded), label: const Text('Clear month')),
              ],
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                for (final row in report.monthSummary)
                  _MonthPill(row: row, maxCount: maxCount, selected: selectedMonth == row.month, onTap: () => onMonthChanged(row.month)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MonthPill extends StatelessWidget {
  const _MonthPill({required this.row, required this.maxCount, required this.selected, required this.onTap});
  final _MonthSummaryRow row;
  final int maxCount;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = selected ? theme.colorScheme.primary : theme.colorScheme.outline;
    final percent = maxCount <= 0 ? 0.0 : row.count / maxCount;
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        width: 150,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: selected ? theme.colorScheme.primary.withValues(alpha: 0.12) : theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.42),
          border: Border.all(color: selected ? theme.colorScheme.primary.withValues(alpha: 0.36) : theme.colorScheme.outlineVariant),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [Expanded(child: Text(_shortMonthName(row.month), style: const TextStyle(fontWeight: FontWeight.w900))), Text(row.count.toString(), style: TextStyle(color: color, fontWeight: FontWeight.w900))]),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(99),
              child: LinearProgressIndicator(value: percent, minHeight: 7, backgroundColor: theme.colorScheme.outlineVariant.withValues(alpha: 0.35), valueColor: AlwaysStoppedAnimation<Color>(selected ? theme.colorScheme.primary : const Color(0xFF64748B))),
            ),
          ],
        ),
      ),
    );
  }
}

class _ReportTableCard extends StatelessWidget {
  const _ReportTableCard({required this.title, required this.subtitle, required this.columns, required this.rows, required this.emptyText});
  final String title;
  final String subtitle;
  final List<String> columns;
  final List<List<String>> rows;
  final String emptyText;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.96),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [Expanded(child: Text(title, style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900))), Chip(label: Text('${rows.length} rows'))]),
            const SizedBox(height: 4),
            Text(subtitle),
            const SizedBox(height: 16),
            if (rows.isEmpty)
              Container(width: double.infinity, padding: const EdgeInsets.all(16), decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.42)), child: Text(emptyText))
            else
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  headingRowColor: WidgetStatePropertyAll(theme.colorScheme.primary.withValues(alpha: 0.10)),
                  dataRowMinHeight: 44,
                  dataRowMaxHeight: 56,
                  columns: [for (final column in columns) DataColumn(label: Text(column, style: const TextStyle(fontWeight: FontWeight.w900)))],
                  rows: [for (final row in rows) DataRow(cells: [for (final cell in row) DataCell(Text(cell))])],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

enum _ReportExportMode { year, month }

enum _ReportSortMode { totalDesc, nameAsc, monthAsc }

class _LabTechReportData {
  const _LabTechReportData({required this.year, required this.yearlyRows, required this.monthlyRows, required this.monthSummary});

  final int year;
  final List<_TestTotalRow> yearlyRows;
  final List<_MonthlyTestTotalRow> monthlyRows;
  final List<_MonthSummaryRow> monthSummary;

  int get yearlyTotal => yearlyRows.fold(0, (sum, row) => sum + row.count);
  int get activeMonthCount => monthSummary.where((row) => row.count > 0).length;
  String get topMonthLabel {
    final active = monthSummary.where((row) => row.count > 0).toList()..sort((a, b) => b.count.compareTo(a.count));
    return active.isEmpty ? '-' : _monthName(active.first.month);
  }

  List<_TestTotalRow> filteredYearlyRows({required String searchQuery, required _ReportSortMode sortMode}) {
    final query = _normalize(searchQuery);
    final rows = yearlyRows.where((row) => query.isEmpty || _normalize(row.testName).contains(query)).toList();
    _sortYearlyRows(rows, sortMode);
    return rows;
  }

  List<_MonthlyTestTotalRow> filteredMonthlyRows({required int month, required String searchQuery, required _ReportSortMode sortMode}) {
    final query = _normalize(searchQuery);
    final rows = monthlyRows.where((row) {
      if (month != 0 && row.month != month) return false;
      return query.isEmpty || _normalize(row.testName).contains(query);
    }).toList();
    _sortMonthlyRows(rows, sortMode);
    return rows;
  }

  factory _LabTechReportData.fromSamples({required List<BloodSample> samples, required List<LabTest> tests, required int year}) {
    final testNames = <String, String>{};
    for (final test in tests) {
      testNames[_normalize(test.id)] = test.testName;
      testNames[_normalize(test.testName)] = test.testName;
    }

    final yearlyTotals = <String, int>{};
    final monthlyTotals = <String, Map<int, int>>{};
    final monthTotals = <int, int>{for (var month = 1; month <= 12; month++) month: 0};

    for (final sample in samples) {
      final created = sample.createdAt?.toLocal();
      if (created == null || created.year != year) continue;
      for (final rawTest in sample.testIds) {
        final label = testNames[_normalize(rawTest)] ?? rawTest.trim();
        if (label.isEmpty) continue;
        yearlyTotals[label] = (yearlyTotals[label] ?? 0) + 1;
        final byMonth = monthlyTotals.putIfAbsent(label, () => <int, int>{});
        byMonth[created.month] = (byMonth[created.month] ?? 0) + 1;
        monthTotals[created.month] = (monthTotals[created.month] ?? 0) + 1;
      }
    }

    final yearlyRows = yearlyTotals.entries.map((entry) => _TestTotalRow(testName: entry.key, count: entry.value)).toList();
    _sortYearlyRows(yearlyRows, _ReportSortMode.totalDesc);

    final monthlyRows = <_MonthlyTestTotalRow>[];
    for (final entry in monthlyTotals.entries) {
      for (final monthEntry in entry.value.entries) {
        monthlyRows.add(_MonthlyTestTotalRow(month: monthEntry.key, testName: entry.key, count: monthEntry.value));
      }
    }
    _sortMonthlyRows(monthlyRows, _ReportSortMode.monthAsc);

    final summary = [for (var month = 1; month <= 12; month++) _MonthSummaryRow(month: month, count: monthTotals[month] ?? 0)];
    return _LabTechReportData(year: year, yearlyRows: yearlyRows, monthlyRows: monthlyRows, monthSummary: summary);
  }
}

class _TestTotalRow {
  const _TestTotalRow({required this.testName, required this.count});
  final String testName;
  final int count;
}

class _MonthlyTestTotalRow {
  const _MonthlyTestTotalRow({required this.month, required this.testName, required this.count});
  final int month;
  final String testName;
  final int count;
}

class _MonthSummaryRow {
  const _MonthSummaryRow({required this.month, required this.count});
  final int month;
  final int count;
}

void _sortYearlyRows(List<_TestTotalRow> rows, _ReportSortMode sortMode) {
  rows.sort((a, b) {
    if (sortMode == _ReportSortMode.nameAsc) return a.testName.compareTo(b.testName);
    final byCount = b.count.compareTo(a.count);
    if (byCount != 0) return byCount;
    return a.testName.compareTo(b.testName);
  });
}

void _sortMonthlyRows(List<_MonthlyTestTotalRow> rows, _ReportSortMode sortMode) {
  rows.sort((a, b) {
    if (sortMode == _ReportSortMode.nameAsc) {
      final byName = a.testName.compareTo(b.testName);
      if (byName != 0) return byName;
      return a.month.compareTo(b.month);
    }
    if (sortMode == _ReportSortMode.totalDesc) {
      final byCount = b.count.compareTo(a.count);
      if (byCount != 0) return byCount;
      final byMonth = a.month.compareTo(b.month);
      if (byMonth != 0) return byMonth;
      return a.testName.compareTo(b.testName);
    }
    final byMonth = a.month.compareTo(b.month);
    if (byMonth != 0) return byMonth;
    return a.testName.compareTo(b.testName);
  });
}

Future<Uint8List> _buildLabTechReportPdf({
  required _LabTechReportData report,
  required AppUser? user,
  required _ReportExportMode exportMode,
  required int selectedMonth,
  required String searchQuery,
  required _ReportSortMode sortMode,
}) async {
  final regularFont = pw.Font.ttf(await rootBundle.load('assets/fonts/DejaVuSans.ttf'));
  final boldFont = pw.Font.ttf(await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf'));
  final logo = pw.MemoryImage((await rootBundle.load('assets/images/moh.png')).buffer.asUint8List());
  final generatedAt = DateTime.now().toLocal().toString().split('.').first;
  final pdf = pw.Document(theme: pw.ThemeData.withFont(base: regularFont, bold: boldFont));
  final isMonthReport = exportMode == _ReportExportMode.month && selectedMonth != 0;
  final yearlyRows = report.filteredYearlyRows(searchQuery: searchQuery, sortMode: sortMode);
  final monthlyRows = report.filteredMonthlyRows(month: isMonthReport ? selectedMonth : 0, searchQuery: searchQuery, sortMode: sortMode);
  final monthText = isMonthReport ? _monthName(selectedMonth) : 'All months';
  final reportTitle = isMonthReport ? 'Lab Tech Monthly Report' : 'Lab Tech Yearly Report';
  final exportTotal = isMonthReport ? monthlyRows.fold<int>(0, (sum, row) => sum + row.count) : report.yearlyTotal;
  final overviewRows = isMonthReport
      ? report.monthSummary.where((row) => row.month == selectedMonth).toList()
      : report.monthSummary;

  pdf.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(28),
      build: (context) => [
        pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Container(width: 42, height: 42, child: pw.Image(logo, fit: pw.BoxFit.contain)),
            pw.SizedBox(width: 12),
            pw.Expanded(
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(reportTitle, style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
                  pw.SizedBox(height: 3),
                  pw.Text('Year: ${report.year}   Month: $monthText', style: const pw.TextStyle(fontSize: 10)),
                  pw.Text('Generated: $generatedAt', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
                  if (user != null) pw.Text('Generated by: ${user.name}', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
                  if (searchQuery.trim().isNotEmpty) pw.Text('Search: ${searchQuery.trim()}', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
                ],
              ),
            ),
            pw.Container(
              padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: pw.BoxDecoration(color: PdfColors.blue700, borderRadius: pw.BorderRadius.circular(14)),
              child: pw.Text('Total: $exportTotal', style: pw.TextStyle(color: PdfColors.white, fontWeight: pw.FontWeight.bold, fontSize: 9)),
            ),
          ],
        ),
        pw.SizedBox(height: 14),
        pw.Text('Monthly Overview', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 6),
        _pdfTable(headers: const ['Month', 'Total Tests'], rows: [for (final row in overviewRows) [_monthName(row.month), row.count.toString()]]),
        pw.SizedBox(height: 16),
        if (!isMonthReport) ...[
          pw.Text('Yearly Test Totals', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 6),
          _pdfTable(headers: const ['No.', 'Test Name', 'Total Tests'], rows: [for (var i = 0; i < yearlyRows.length; i++) ['${i + 1}', yearlyRows[i].testName, yearlyRows[i].count.toString()]]),
          pw.SizedBox(height: 16),
        ],
        pw.Text(isMonthReport ? 'Selected Month Test Details' : 'Monthly Test Details', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 6),
        _pdfTable(headers: const ['No.', 'Month', 'Test Name', 'Total Tests'], rows: [for (var i = 0; i < monthlyRows.length; i++) ['${i + 1}', _monthName(monthlyRows[i].month), monthlyRows[i].testName, monthlyRows[i].count.toString()]]),
      ],
    ),
  );
  return pdf.save();
}

pw.Widget _pdfTable({required List<String> headers, required List<List<String>> rows}) {
  if (rows.isEmpty) {
    return pw.Container(width: double.infinity, padding: const pw.EdgeInsets.all(10), decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey500), color: PdfColors.grey100), child: pw.Text('No data found.', style: const pw.TextStyle(fontSize: 9)));
  }
  return pw.Table(
    border: pw.TableBorder.all(color: PdfColors.grey500, width: 0.35),
    children: [
      pw.TableRow(decoration: const pw.BoxDecoration(color: PdfColors.grey200), children: [for (final header in headers) _pdfCell(header, bold: true)]),
      for (final row in rows) pw.TableRow(children: [for (final cell in row) _pdfCell(cell)]),
    ],
  );
}

pw.Widget _pdfCell(String text, {bool bold = false}) {
  return pw.Padding(
    padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 4),
    child: pw.Text(text.trim().isEmpty ? '-' : text.trim(), style: pw.TextStyle(fontSize: 8, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
  );
}

String _monthName(int month) {
  const names = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  if (month < 1 || month > 12) return '-';
  return names[month - 1];
}

String _shortMonthName(int month) {
  const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  if (month < 1 || month > 12) return '-';
  return names[month - 1];
}

String _normalize(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
