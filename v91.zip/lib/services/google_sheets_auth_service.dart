
import 'dart:convert';
import 'package:crypto/crypto.dart';

import '../models/app_user.dart';
import 'turso_native_service.dart';

class GoogleSheetsAuthService {
  GoogleSheetsAuthService({required this.serviceAccountJson, required this.applicationName, required this.spreadsheetId, this.sheetName = 'Users'});
  final String serviceAccountJson;
  final String applicationName;
  final String spreadsheetId;
  final String sheetName;

  Future<AppUser?> signIn({required String username, required String password}) async {
    final service = TursoNativeService(applicationName: applicationName);
    final rows = await service.fetchRows(spreadsheetId: 'native', range: 'Users!A:F');
    if (rows.length < 2) return null;
    final headers = rows.first.map((h) => h.trim().toLowerCase()).toList();
    String cell(List<String> row, String name) { final i = headers.indexOf(name.toLowerCase()); return i >= 0 && i < row.length ? row[i].trim() : ''; }
    final normalizedUsername = username.trim().toLowerCase();
    final passwordHash = sha256.convert(utf8.encode(password)).toString();
    for (final row in rows.skip(1)) {
      if (cell(row, 'username').toLowerCase() == normalizedUsername && cell(row, 'passwordhash') == passwordHash) {
        final roleRaw = cell(row, 'role').isEmpty ? 'staff' : cell(row, 'role').toLowerCase();
        return AppUser(
          id: cell(row, 'id').isEmpty ? normalizedUsername : cell(row, 'id'),
          name: cell(row, 'name').isEmpty ? normalizedUsername : cell(row, 'name'),
          role: AppUserRole.values.firstWhere((r) => r.name == roleRaw, orElse: () => AppUserRole.staff),
          subCenterId: cell(row, 'subcenterid').isEmpty ? 'GLOBAL' : cell(row, 'subcenterid'),
        );
      }
    }
    return null;
  }
}
