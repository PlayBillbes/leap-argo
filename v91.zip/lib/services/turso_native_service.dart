
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:http/io_client.dart';

import '../config/turso_config.dart';

class TursoNativeException implements Exception {
  TursoNativeException(this.message, [this.cause]);
  final String message;
  final Object? cause;
  @override
  String toString() => 'TursoNativeException: $message${cause == null ? '' : ' ($cause)'}';
}

class TursoNativeService {
  TursoNativeService({String serviceAccountJson = '', this.applicationName = 'flutterlab'});
  final String applicationName;

  static final http.Client _client = _createClient();
  static bool _schemaReady = false;

  static const List<String> _cbcHeaders = <String>[
  'id',
  'testName',
  'sampleId',
  'medRecNo',
  'firstName',
  'lastName',
  'gender',
  'age',
  'ageUnit',
  'sampleType',
  'samplingTime',
  'deliveryTime',
  'reportTime',
  'runTime',
  'mode',
  'WBC',
  'NeuPercent',
  'LymPercent',
  'MonPercent',
  'EosPercent',
  'BasPercent',
  'NeuCount',
  'LymCount',
  'MonCount',
  'EosCount',
  'BasCount',
  'ALYCount',
  'ALYPercent',
  'LICCount',
  'LICPercent',
  'NRBCCount',
  'NRBCPercent',
  'RBC',
  'HGB',
  'HCT',
  'MCV',
  'MCH',
  'MCHC',
  'RDWCV',
  'RDWSD',
  'PLT',
  'MPV',
  'PDW',
  'PCT',
  'PLCR',
  'PLCC',
  'WBCFlag',
  'RBCFlag',
  'PLTFlag',
  'CRPFlag',
  'diffHsmsImageUrl',
  'pltImageUrl',
  'wbcGraphBase64',
  'rbcGraphBase64',
  'pltGraphBase64',
  'diffHsmsBase64',
  'diffLshsBase64',
  'diffLsmsBase64',
  'basoGraphBase64',
  'diffBasoBase64',
  'createdAt',
  'uploadedByUserId'
  ];

  static http.Client _createClient() {
    final ioClient = HttpClient();
    ioClient.findProxy = (_) => 'DIRECT';
    ioClient.connectionTimeout = const Duration(seconds: 12);
    return IOClient(ioClient);
  }

  Future<void> ensureSchema() async {
    if (_schemaReady) return;
    await _executeBatch(_schemaStatements);
    await _ensureCbcColumns();
    await _ensureSubCenterPricingColumns();
    await _ensureBloodSampleColumns();
    await _ensureReportHeaderColumns();
    _schemaReady = true;
  }

  Future<List<List<String>>> fetchRows({required String spreadsheetId, required String range}) async {
    await ensureSchema();
    final sheet = _sheetName(range);
    final headers = _headersFor(sheet);
    final rows = await _selectRowsForSheet(sheet);
    return <List<String>>[
      headers,
      for (final row in rows) [for (final h in headers) row[h] ?? ''],
    ];
  }

  Future<void> insertRow({required String spreadsheetId, required String range, required List<String> values, String valueInputOption = 'USER_ENTERED'}) async {
    await ensureSchema();
    final sheet = _sheetName(range);
    final headers = _headersFor(sheet);
    final data = <String, String>{};
    for (var i = 0; i < headers.length; i++) {
      data[headers[i]] = i < values.length ? values[i] : '';
    }
    await _upsertSheetRow(sheet, data);
  }

  Future<void> updateRow({required String spreadsheetId, required String range, required List<String> values}) async {
    await ensureSchema();
    final parsed = _parseRange(range);
    final sheet = parsed.sheetName;
    if (parsed.rowNumber <= 1) return;
    final headers = _headersFor(sheet);
    final rows = await _selectRowsForSheet(sheet);
    final index = parsed.rowNumber - 2;
    final current = index >= 0 && index < rows.length ? Map<String, String>.from(rows[index]) : <String, String>{};
    for (var i = 0; i < values.length; i++) {
      final headerIndex = parsed.startColumnIndex + i;
      if (headerIndex >= 0 && headerIndex < headers.length) current[headers[headerIndex]] = values[i];
    }
    await _upsertSheetRow(sheet, current);
  }

  Future<void> deleteRow({required String spreadsheetId, required String sheetName, required int rowIndexOneBased}) async {
    await ensureSchema();
    if (rowIndexOneBased <= 1) return;
    final rows = await _selectRowsForSheet(sheetName);
    final index = rowIndexOneBased - 2;
    if (index < 0 || index >= rows.length) return;
    final row = rows[index];
    final id = row['id'] ?? row['testId'] ?? row['sampleId'] ?? '';
    if (id.isEmpty) return;
    switch (_normSheet(sheetName)) {
      case 'users': await _execute('delete from users where id = ?', args: [id]); break;
      case 'tests': await _execute('delete from tests where id = ?', args: [id]); break;
      case 'manualtestdefaults': await _execute('delete from manual_test_defaults where id = ?', args: [id]); break;
      case 'bloodsamples': await _execute('delete from blood_samples where id = ?', args: [id]); break;
      case 'cbcresults': await _execute('delete from cbc_results where id = ?', args: [id]); break;
    }
  }

  Future<void> ensureSheet({required String spreadsheetId, required String sheetName}) async => ensureSchema();
  Future<void> close() async {}

  Future<List<Map<String, String>>> _selectRowsForSheet(String sheet) async {
    switch (_normSheet(sheet)) {
      case 'users':
        return _select('select id, username, password_hash as passwordHash, name, role, sub_center_id as subCenterId from users order by name collate nocase');
      case 'tests':
        return _select('select id, test_name as testName, default_price as defaultPrice from tests order by test_name collate nocase');
      case 'subcenterpricings':
        return _select('select sub_center_id as subCenterId, test_id as testId, custom_price as customPrice, referred_fee_percent as referredFeePercent from sub_center_pricings order by sub_center_id, test_id');
      case 'bloodsamples':
        return _select('select id, patient_name as patientName, status, test_ids as testIds, registered_by_user_id as registeredByUserId, sub_center_id as subCenterId, result_url as resultUrl, result_url as resultFileUrl, created_at as createdAt, updated_at as updatedAt, patient_age as patientAge, patient_sex as patientSex, patient_address as patientAddress, registration_id as registrationId, test_id as testId, test_name as testName, test_price as testPrice, total_amount as totalAmount, referred_person_id as referredPersonId, referred_person_name as referredPersonName, referred_fee_percent as referredFeePercent, referred_fee_amount as referredFeeAmount from blood_samples order by created_at desc, id desc');
      case 'alert':
        return _select('select message as alert from alert_messages where id = 1');
      case 'testresults':
        return _select('select id, sample_id as sampleId, test_name as testName, parameter, patient_name as patientName, result_value as resultValue, unit, reference_range as referenceRange, notes, created_at as createdAt, uploaded_by_user_id as uploadedByUserId from test_results order by created_at desc');
      case 'cbcresults':
        final selected = _cbcHeaders.map((h) => '"$h"').join(', ');
        return _select('select $selected from cbc_results order by "createdAt" desc, id desc');
      case 'manualtestdefaults':
        return _select('select id, test_id as testId, test_name as testName, parameter, unit, reference_range as referenceRange, notes from manual_test_defaults order by test_name collate nocase, parameter collate nocase');
      case 'cbcreferenceranges':
        return _select('select parameter, age_group as ageGroup, unit, reference_range as referenceRange from cbc_reference_ranges order by parameter collate nocase, age_group collate nocase');
      case 'reportheadersettings':
        return _select('select scope_type as scopeType, sub_center_id as subCenterId, hospital_name as hospitalName, department_name as departmentName, township, ministry_name as ministryName, report_title as reportTitle, accent_color as accentColor, updated_at as updatedAt, updated_by_user_id as updatedByUserId from report_header_settings order by updated_at desc');
      case 'testrequirements':
        return _select('select id, test_id as testId, test_name as testName, requirements, updated_at as updatedAt from test_requirements order by test_name collate nocase');
    }
    return <Map<String, String>>[];
  }

  Future<void> _upsertSheetRow(String sheet, Map<String, String> row) async {
    switch (_normSheet(sheet)) {
      case 'users':
        await _execute('insert into users(id, username, password_hash, name, role, sub_center_id) values(?, ?, ?, ?, ?, ?) on conflict(id) do update set username = excluded.username, password_hash = excluded.password_hash, name = excluded.name, role = excluded.role, sub_center_id = excluded.sub_center_id', args: [row['id']?.isNotEmpty == true ? row['id'] : 'user-${DateTime.now().millisecondsSinceEpoch}', row['username'] ?? '', row['passwordHash'] ?? row['passwordhash'] ?? '', row['name'] ?? '', row['role'] ?? 'staff', row['subCenterId'] ?? row['subcenterid'] ?? 'GLOBAL']);
        break;
      case 'tests':
        final id = row['id']?.isNotEmpty == true ? row['id']! : _slug(row['testName'] ?? row['name'] ?? 'test');
        await _execute('insert into tests(id, test_name, default_price) values(?, ?, ?) on conflict(id) do update set test_name = excluded.test_name, default_price = excluded.default_price', args: [id, row['testName'] ?? row['name'] ?? id, double.tryParse(row['defaultPrice'] ?? row['price'] ?? '0') ?? 0]);
        break;
      case 'subcenterpricings':
        await _execute('insert into sub_center_pricings(sub_center_id, test_id, custom_price, referred_fee_percent) values(?, ?, ?, ?) on conflict(sub_center_id, test_id) do update set custom_price = excluded.custom_price, referred_fee_percent = excluded.referred_fee_percent', args: [row['subCenterId'] ?? row['subcenterid'] ?? 'GLOBAL', row['testId'] ?? row['testid'] ?? '', double.tryParse(row['customPrice'] ?? row['price'] ?? '0') ?? 0, double.tryParse(row['referredFeePercent'] ?? row['referedFeePercent'] ?? row['referredfee'] ?? row['referedfee'] ?? '0') ?? 0]);
        break;
      case 'bloodsamples':
        final id = row['id']?.isNotEmpty == true ? row['id']! : 'SAMPLE-${DateTime.now().microsecondsSinceEpoch}';
        await _execute('insert into blood_samples(id, patient_name, status, test_ids, registered_by_user_id, sub_center_id, result_url, created_at, updated_at, patient_age, patient_sex, patient_address, registration_id, test_id, test_name, test_price, total_amount, referred_person_id, referred_person_name, referred_fee_percent, referred_fee_amount) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) on conflict(id) do update set patient_name=excluded.patient_name, status=excluded.status, test_ids=excluded.test_ids, registered_by_user_id=excluded.registered_by_user_id, sub_center_id=excluded.sub_center_id, result_url=excluded.result_url, updated_at=excluded.updated_at, patient_age=excluded.patient_age, patient_sex=excluded.patient_sex, patient_address=excluded.patient_address, registration_id=excluded.registration_id, test_id=excluded.test_id, test_name=excluded.test_name, test_price=excluded.test_price, total_amount=excluded.total_amount, referred_person_id=excluded.referred_person_id, referred_person_name=excluded.referred_person_name, referred_fee_percent=excluded.referred_fee_percent, referred_fee_amount=excluded.referred_fee_amount', args: [id, row['patientName'] ?? '', row['status'] ?? 'pending', row['testIds'] ?? row['tests'] ?? '', row['registeredByUserId'] ?? '', row['subCenterId'] ?? 'GLOBAL', row['resultUrl'] ?? row['resultFileUrl'] ?? '', row['createdAt']?.isNotEmpty == true ? row['createdAt'] : DateTime.now().toIso8601String(), row['updatedAt']?.isNotEmpty == true ? row['updatedAt'] : DateTime.now().toIso8601String(), row['patientAge'] ?? '', row['patientSex'] ?? '', row['patientAddress'] ?? '', row['registrationId'] ?? '', row['testId'] ?? '', row['testName'] ?? '', double.tryParse(row['testPrice'] ?? '0') ?? 0, double.tryParse(row['totalAmount'] ?? '0') ?? 0, row['referredPersonId'] ?? row['referedPersonId'] ?? row['referred_person_id'] ?? '', row['referredPersonName'] ?? row['referedPersonName'] ?? row['referred_person_name'] ?? '', double.tryParse(row['referredFeePercent'] ?? row['referedFeePercent'] ?? row['referred_fee_percent'] ?? '0') ?? 0, double.tryParse(row['referredFeeAmount'] ?? row['referedFeeAmount'] ?? row['referred_fee_amount'] ?? row['referredFee'] ?? '0') ?? 0]);
        break;
      case 'alert':
        await _execute('insert into alert_messages(id, message, updated_at) values(1, ?, ?) on conflict(id) do update set message=excluded.message, updated_at=excluded.updated_at', args: [row['alert'] ?? '', DateTime.now().toIso8601String()]);
        break;
      case 'testresults':
        await _execute('insert into test_results(id, sample_id, test_name, parameter, patient_name, result_value, unit, reference_range, notes, created_at, uploaded_by_user_id) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) on conflict(id) do update set result_value=excluded.result_value, notes=excluded.notes', args: [row['id']?.isNotEmpty == true ? row['id'] : 'RESULT-${DateTime.now().microsecondsSinceEpoch}', row['sampleId'] ?? '', row['testName'] ?? '', row['parameter'] ?? '', row['patientName'] ?? '', row['resultValue'] ?? '', row['unit'] ?? '', row['referenceRange'] ?? '', row['notes'] ?? '', row['createdAt']?.isNotEmpty == true ? row['createdAt'] : DateTime.now().toIso8601String(), row['uploadedByUserId'] ?? '']);
        break;
      case 'cbcresults':
        await _upsertCbcResult(row);
        break;
      case 'manualtestdefaults':
        final id = row['id']?.isNotEmpty == true ? row['id']! : '${row['testId'] ?? row['testName']}-${row['parameter'] ?? 'default'}';
        await _execute('insert into manual_test_defaults(id, test_id, test_name, parameter, unit, reference_range, notes) values(?, ?, ?, ?, ?, ?, ?) on conflict(id) do update set test_id=excluded.test_id, test_name=excluded.test_name, parameter=excluded.parameter, unit=excluded.unit, reference_range=excluded.reference_range, notes=excluded.notes', args: [id, row['testId'] ?? '', row['testName'] ?? '', row['parameter'] ?? '', row['unit'] ?? '', row['referenceRange'] ?? '', row['notes'] ?? '']);
        break;
      case 'cbcreferenceranges':
        await _execute('insert into cbc_reference_ranges(parameter, age_group, unit, reference_range) values(?, ?, ?, ?) on conflict(parameter, age_group) do update set unit=excluded.unit, reference_range=excluded.reference_range', args: [row['parameter'] ?? '', row['ageGroup'] ?? row['agegroup'] ?? 'Adult', row['unit'] ?? '', row['referenceRange'] ?? '']);
        break;
      case 'reportheadersettings':
        final scopeType = (row['scopeType'] ?? 'GLOBAL').trim().isEmpty ? 'GLOBAL' : (row['scopeType'] ?? 'GLOBAL').trim();
        final subCenterId = (row['subCenterId'] ?? 'GLOBAL').trim().isEmpty ? 'GLOBAL' : (row['subCenterId'] ?? 'GLOBAL').trim();
        final id = row['id']?.isNotEmpty == true ? row['id']! : 'report-header-${_normSheet(scopeType)}-${_normSheet(subCenterId)}';
        await _execute('insert into report_header_settings(id, scope_type, sub_center_id, hospital_name, department_name, township, ministry_name, report_title, accent_color, updated_at, updated_by_user_id) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) on conflict(id) do update set scope_type=excluded.scope_type, sub_center_id=excluded.sub_center_id, hospital_name=excluded.hospital_name, department_name=excluded.department_name, township=excluded.township, ministry_name=excluded.ministry_name, report_title=excluded.report_title, accent_color=excluded.accent_color, updated_at=excluded.updated_at, updated_by_user_id=excluded.updated_by_user_id', args: [id, scopeType, subCenterId, row['hospitalName'] ?? '', row['departmentName'] ?? '', row['township'] ?? '', row['ministryName'] ?? '', row['reportTitle'] ?? '', row['accentColor'] ?? '#1D4ED8', row['updatedAt']?.isNotEmpty == true ? row['updatedAt'] : DateTime.now().toIso8601String(), row['updatedByUserId'] ?? '']);
        break;
      case 'testrequirements':
        final id = row['id']?.isNotEmpty == true ? row['id']! : row['testId'] ?? row['testName'] ?? 'requirement';
        await _execute('insert into test_requirements(id, test_id, test_name, requirements, updated_at) values(?, ?, ?, ?, ?) on conflict(id) do update set test_id=excluded.test_id, test_name=excluded.test_name, requirements=excluded.requirements, updated_at=excluded.updated_at', args: [id, row['testId'] ?? '', row['testName'] ?? '', row['requirements'] ?? '', DateTime.now().toIso8601String()]);
        break;
    }
  }

  Future<void> _upsertCbcResult(Map<String, String> row) async {
    final id = row['id']?.isNotEmpty == true ? row['id']! : 'CBC-${DateTime.now().microsecondsSinceEpoch}';
    row['id'] = id;
    row['createdAt'] = row['createdAt']?.isNotEmpty == true ? row['createdAt']! : DateTime.now().toIso8601String();

    // Some existing demo/native DB files created payload_json as NOT NULL.
    // Keep a full JSON snapshot there while also saving every analyzer field
    // as individual columns for original UI reads.
    final payloadJson = jsonEncode(row);
    final columns = _cbcHeaders;
    final quotedColumns = <String>['payload_json', ...columns.map((h) => '"$h"')].join(', ');
    final placeholders = List<String>.filled(columns.length + 1, '?').join(', ');
    final updates = <String>[
      'payload_json = excluded.payload_json',
      ...columns.where((h) => h != 'id').map((h) => '"$h" = excluded."$h"'),
    ].join(', ');
    await _execute(
      'insert into cbc_results ($quotedColumns) values ($placeholders) on conflict(id) do update set $updates',
      args: [payloadJson, for (final h in columns) row[h] ?? ''],
    );
  }

  List<String> _headersFor(String sheet) {
    switch (_normSheet(sheet)) {
      case 'users': return const ['id','username','passwordHash','name','role','subCenterId'];
      case 'tests': return const ['id','testName','defaultPrice'];
      case 'subcenterpricings': return const ['subCenterId','testId','customPrice','referredFeePercent'];
      case 'bloodsamples': return const ['id','patientName','status','testIds','registeredByUserId','subCenterId','resultUrl','createdAt','updatedAt','patientAge','patientSex','patientAddress','registrationId','testId','testName','testPrice','totalAmount','referredPersonId','referredPersonName','referredFeePercent','referredFeeAmount'];
      case 'alert': return const ['alert'];
      case 'testresults': return const ['id','sampleId','testName','parameter','patientName','resultValue','unit','referenceRange','notes','createdAt','uploadedByUserId'];
      case 'cbcresults': return _cbcHeaders;
      case 'manualtestdefaults': return const ['id','testId','testName','parameter','unit','referenceRange','notes'];
      case 'cbcreferenceranges': return const ['parameter','ageGroup','unit','referenceRange'];
      case 'reportheadersettings': return const ['scopeType','subCenterId','hospitalName','departmentName','township','ministryName','reportTitle','accentColor','updatedAt','updatedByUserId'];
      case 'testrequirements': return const ['id','testId','testName','requirements','updatedAt'];
    }
    return const ['id'];
  }

  Future<void> _ensureCbcColumns() async {
    for (final header in _cbcHeaders) {
      try {
        await _execute('alter table cbc_results add column "$header" text');
      } catch (error) {
        final message = error.toString().toLowerCase();
        if (!message.contains('duplicate column') && !message.contains('already exists')) rethrow;
      }
    }
    await _execute('create index if not exists idx_cbc_results_sample on cbc_results("sampleId")');
  }


  Future<void> _ensureSubCenterPricingColumns() async {
    try {
      await _execute('alter table sub_center_pricings add column referred_fee_percent real not null default 0');
    } catch (error) {
      final message = error.toString().toLowerCase();
      if (!message.contains('duplicate column') && !message.contains('already exists')) rethrow;
    }
  }

  Future<void> _ensureBloodSampleColumns() async {
    const columns = <String, String>{
      'referred_person_id': 'text',
      'referred_person_name': 'text',
      'referred_fee_percent': 'real',
      'referred_fee_amount': 'real',
    };
    for (final entry in columns.entries) {
      try {
        await _execute('alter table blood_samples add column ${entry.key} ${entry.value}');
      } catch (error) {
        final message = error.toString().toLowerCase();
        if (!message.contains('duplicate column') && !message.contains('already exists')) rethrow;
      }
    }
  }

  Future<void> _ensureReportHeaderColumns() async {
    const columns = <String, String>{
      'hospital_name': 'text',
      'department_name': 'text',
      'township': 'text',
      'ministry_name': 'text',
      'report_title': 'text',
      'accent_color': 'text',
      'updated_by_user_id': 'text',
    };
    for (final entry in columns.entries) {
      try {
        await _execute('alter table report_header_settings add column ${entry.key} ${entry.value}');
      } catch (error) {
        final message = error.toString().toLowerCase();
        if (!message.contains('duplicate column') && !message.contains('already exists')) rethrow;
      }
    }
    await _execute('create unique index if not exists idx_report_header_scope_center on report_header_settings(scope_type, sub_center_id)');
  }

  Future<List<Map<String, String>>> _select(String sql, {List<Object?> args = const []}) async {
    final rows = await _execute(sql, args: args);
    return rows.map((row) => row.map((key, value) => MapEntry(key, (value ?? '').toString()))).toList();
  }

  Future<List<Map<String, dynamic>>> _execute(String sql, {List<Object?> args = const []}) async {
    if (!TursoConfig.isConfigured) throw TursoNativeException('Turso is not configured. Provide TURSO_DATABASE_URL and TURSO_AUTH_TOKEN.');
    final response = await _client.post(Uri.parse(_pipelineUrl()), headers: {'Authorization':'Bearer ${TursoConfig.authToken}', 'Content-Type':'application/json'}, body: jsonEncode({'requests':[{'type':'execute','stmt':{'sql':sql, if(args.isNotEmpty) 'args': args.map(_sqlArg).toList()}},{'type':'close'}]}));
    if (response.statusCode < 200 || response.statusCode >= 300) throw TursoNativeException('Turso HTTP ${response.statusCode}: ${response.body}');
    final decoded = jsonDecode(response.body);
    final results = decoded is Map<String, dynamic> ? decoded['results'] : null;
    if (results is! List || results.isEmpty) return const [];
    final first = results.first;
    if (first is! Map<String, dynamic>) return const [];
    if (first['type'] != 'ok') throw TursoNativeException('Turso SQL error: ${jsonEncode(first)}');
    final result = (first['response'] as Map?)?['result'];
    if (result is! Map<String, dynamic>) return const [];
    return _rowsFromResult(result);
  }

  Future<void> _executeBatch(List<String> sqlStatements) async {
    if (!TursoConfig.isConfigured) throw TursoNativeException('Turso is not configured. Provide TURSO_DATABASE_URL and TURSO_AUTH_TOKEN.');
    final requests = <Object>[for(final sql in sqlStatements) {'type':'execute','stmt':{'sql':sql}}, {'type':'close'}];
    final response = await _client.post(Uri.parse(_pipelineUrl()), headers: {'Authorization':'Bearer ${TursoConfig.authToken}', 'Content-Type':'application/json'}, body: jsonEncode({'requests':requests}));
    if (response.statusCode < 200 || response.statusCode >= 300) throw TursoNativeException('Turso HTTP ${response.statusCode}: ${response.body}');
  }

  Map<String, Object?> _sqlArg(Object? value) {
    if(value == null) return {'type':'null'};
    if(value is int) return {'type':'integer','value':value.toString()};
    if(value is double) return {'type':'float','value':value};
    return {'type':'text','value':value.toString()};
  }

  List<Map<String, dynamic>> _rowsFromResult(Map<String, dynamic> result) {
    final rawCols = result['cols']; final rawRows = result['rows'];
    if(rawCols is! List || rawRows is! List) return const [];
    final cols = <String>[for(final c in rawCols) if(c is Map) (c['name'] ?? c['column'] ?? c['label'] ?? '').toString() else c.toString()];
    final rows = <Map<String, dynamic>>[];
    for(final raw in rawRows) {
      if(raw is Map<String, dynamic>) { rows.add(raw); continue; }
      if(raw is! List) continue;
      final row = <String, dynamic>{};
      for(var i=0;i<cols.length && i<raw.length;i++) row[cols[i]] = _value(raw[i]);
      rows.add(row);
    }
    return rows;
  }

  dynamic _value(dynamic cell) {
    if(cell == null) return '';
    if(cell is Map) {
      if(cell['type'] == 'null') return '';
      if(cell.containsKey('value')) return cell['value'] ?? '';
      if(cell.containsKey('base64')) return cell['base64'] ?? '';
      return cell.values.isEmpty ? '' : cell.values.last;
    }
    return cell;
  }

  String _pipelineUrl() {
    var url = TursoConfig.databaseUrl.trim();
    if(url.startsWith('libsql://')) url = 'https://${url.substring('libsql://'.length)}';
    if(url.endsWith('/')) url = url.substring(0, url.length - 1);
    if(!url.endsWith('/v2/pipeline')) url = '$url/v2/pipeline';
    return url;
  }

  _ParsedRange _parseRange(String range) {
    final parts = range.split('!');
    final sheet = parts.first.trim();
    final cellRange = parts.length > 1 ? parts[1].trim() : 'A:A';
    final match = RegExp(r'^([A-Za-z]+)?(\d+)?').firstMatch(cellRange);
    final letters = match?.group(1) ?? 'A';
    final row = int.tryParse(match?.group(2) ?? '') ?? 1;
    return _ParsedRange(sheet, row, _columnIndex(letters));
  }

  int _columnIndex(String letters) { var value = 0; for(final c in letters.toUpperCase().codeUnits) { if(c < 65 || c > 90) continue; value = value * 26 + (c - 64); } return value <= 0 ? 0 : value - 1; }
  String _sheetName(String range) => range.split('!').first.trim();
  String _normSheet(String sheet) => sheet.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
  String _slug(String text) => text.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '_').replaceAll(RegExp(r'^_+|_+$'), '');
}

class _ParsedRange { const _ParsedRange(this.sheetName, this.rowNumber, this.startColumnIndex); final String sheetName; final int rowNumber; final int startColumnIndex; }

const List<String> _schemaStatements = [
  "create table if not exists users (id text primary key, username text not null unique, password_hash text not null, name text not null, role text not null, sub_center_id text not null default 'GLOBAL')",
  "create index if not exists idx_users_username on users(username)",
  "create table if not exists tests (id text primary key, test_name text not null, default_price real not null default 0)",
  "create index if not exists idx_tests_name on tests(test_name)",
  "create table if not exists sub_center_pricings (sub_center_id text not null, test_id text not null, custom_price real not null default 0, referred_fee_percent real not null default 0, primary key (sub_center_id, test_id))",
  "create index if not exists idx_pricing_center on sub_center_pricings(sub_center_id)",
  "create table if not exists blood_samples (id text primary key, patient_name text not null, status text not null, test_ids text not null, registered_by_user_id text not null, sub_center_id text not null, result_url text, created_at text, updated_at text, patient_age text, patient_sex text, patient_address text, registration_id text, test_id text, test_name text, test_price real, total_amount real, referred_person_id text, referred_person_name text, referred_fee_percent real, referred_fee_amount real)",
  "create index if not exists idx_samples_sub_center on blood_samples(sub_center_id)",
  "create index if not exists idx_samples_status on blood_samples(status)",
  "create index if not exists idx_samples_created_at on blood_samples(created_at)",
  "create index if not exists idx_samples_registration on blood_samples(registration_id)",
  "create table if not exists test_results (id text primary key, sample_id text not null, test_name text, parameter text, patient_name text, result_value text, unit text, reference_range text, notes text, created_at text, uploaded_by_user_id text)",
  "create index if not exists idx_test_results_sample on test_results(sample_id)",
  "create table if not exists cbc_results (id text primary key, payload_json text)",
  "create table if not exists manual_test_defaults (id text primary key, test_id text, test_name text, parameter text, unit text, reference_range text, notes text)",
  "create table if not exists cbc_reference_ranges (parameter text not null, age_group text not null, unit text, reference_range text, primary key(parameter, age_group))",
  "create table if not exists report_header_settings (id text primary key, scope_type text, sub_center_id text, title text, subtitle text, address text, phone text, logo_url text, footer text, updated_at text)",
  "create table if not exists test_requirements (id text primary key, test_id text, test_name text, requirements text, updated_at text)",
  "create table if not exists alert_messages (id integer primary key check (id = 1), message text not null default '', updated_at text)",
];
