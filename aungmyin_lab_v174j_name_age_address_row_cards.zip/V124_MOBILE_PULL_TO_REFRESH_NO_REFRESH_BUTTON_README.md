# v124 mobile pull-to-refresh and no refresh button

This build removes refresh buttons from mobile app bars and uses pull-down refresh instead.

Changes:
- Mobile AppScaffold filters out refresh/reload IconButton actions and the dashboard refresh TextButton action.
- Dashboard mobile view supports pull-down refresh and invalidates samples, tests, and pricing providers.
- Search patient mobile view supports pull-down refresh and reloads the patient list.
- Sample result mobile CBC/CP(Auto) view supports pull-down refresh while keeping the Print button visible.
- Desktop refresh actions remain available.
