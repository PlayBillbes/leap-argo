### v174h review patient details and qualitative color fix

This patch updates the lab tech manual review / Save Result popup and printed qualitative result colors.

Changes:
- The manual review popup now shows Patient, Age, and Test in the header details area.
- BloodSample now preserves patientAge from BloodSamples rows so the review popup can display it.
- The qualitative Positive button is now red with white text.
- Printed results now color Positive in red and Negative in blue.
- Numeric high/low print coloring is preserved.

Updated files:
- lib/models/blood_sample.dart
- lib/providers/sample_dashboard_controller.dart
- lib/views/dashboard_view.dart

Preserved:
- v174g tablet/desktop Blood Samples minimum 2-column cards.
- v174f tablet dashboard bounded-height fix.
- v174d lab tech update/replace completed results behavior.
- v174c compact Blood Samples cards and status filter.
