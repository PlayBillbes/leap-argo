## v174d lab tech update completed results

This patch updates the Windows/tablet Blood Samples responsive cards so lab tech users can update completed test results.

Changes:
- Lab tech Review action is now shown for every non-canceled sample, including Completed samples.
- Completed samples show the status-aware action label `Replace Result` using the existing `_reviewLabel` behavior.
- Pending samples still show `Start Review`; Processing samples still show `Complete + Upload`; Canceled samples remain disabled.

Preserved:
- v174c compact Windows/tablet Blood Samples cards and status filter.
- Existing mobile lab tech behavior, which already allows review/update for non-canceled samples.
- Existing replace-result duplicate prevention and related result deletion behavior.
