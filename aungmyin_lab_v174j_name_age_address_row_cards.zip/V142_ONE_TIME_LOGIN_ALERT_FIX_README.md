# v142 one-time login alert fix

This build fixes the login alert display flow.

Changes:
- AppScaffold now wraps every authenticated page body with `_GlobalLoginAlertGate`, so the active Alert message is checked after login.
- The alert dialog is shown once per user and alert message during the current app session.
- Navigating between pages no longer repeats the same alert.
- Explicit logout clears the shown-alert session cache so a future login can see the active alert again.
- The alert dialog is modal until the user presses OK.

Updated file:
- lib/widgets/app_sidebar.dart

Preserved:
- v141 dashboard role sample-scope rules.
- v139 Advanced Analytics mobile rewrite.
- v138 Report Header footer load parse fix.
