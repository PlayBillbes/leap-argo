# v119 result title by test name

This build fixes the result screen title so it follows the actual test name instead of always showing `CP (Auto) Result`.

Changes:
- Sample result app bar title is now computed from sample/test result data.
- Manual result sections now use the manual test name, for example `ESR Result`.
- CBC/CP(Auto) sections still use the CBC test name or fallback to `CBC / CP(Auto) Result`.
- The generated-result hero title now follows the same computed result title.
- Mobile CBC sample header/details also use the stored test name when available.
