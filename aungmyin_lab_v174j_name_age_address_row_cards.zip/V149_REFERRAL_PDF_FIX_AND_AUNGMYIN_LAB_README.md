# v149 referral PDF fix and AungMyin Lab branding

This build fixes the referral PDF layout and updates visible app branding.

Changes:
- Referral PDF header rebuilt with a clean custom Report Header layout to avoid overlap and stray image/vector artifacts.
- Referral PDF text uses bundled DejaVu fonts for more reliable PDF rendering.
- Referral PDF now includes referral-person summary, person-by-month summary, person-by-year summary, sample details, and grouped person details.
- Referral PDF still loads custom header values from `ReportHeaderSettings!A:K` and falls back to global header settings when a sub-center header is not found.
- Visible app name changed from LabOps/FlutterLab to AungMyin Lab in Flutter title, login page, sidebar branding, Android label, and iOS display/name strings.

Preserved:
- v148 referral report custom header and mobile login blue buttons.
- v147 strict blood sample visibility.
- v146 refer fee report buttons.
