# v160 superadmin and lab tech all blood samples visibility

This build makes the all-center visibility rule explicit.

Rules enforced:
- Superadmin can see all blood samples from GLOBAL and every sub-center.
- Lab tech can see all blood samples from GLOBAL and every sub-center.
- Admin users can see registered blood samples from their own non-GLOBAL sub-center.
- Staff users can see registered blood samples from their own non-GLOBAL sub-center.
- Referred person users can see only blood samples referred by their account.

Applied to:
- Dashboard sample provider.
- Dashboard content sample set.
- Patient search results.
- Direct sample result access checks.

Terminology preserved:
- Visible `Sub-center Pricing` term remains `Custom Pricing`.

Preserved:
- v159 sub-center role visibility fix.
- v157 mobile sticky status tabs only.
- v155 lab tech offline result completion.
