### v174g tablet two-column Blood Samples cards

This patch updates the Windows/tablet Blood Samples card layout.

Changes:
- Blood Samples cards now stay at a minimum of 2 columns for tablet and desktop widths.
- Wider desktop screens still use 3 columns when the available width is at least 1480 px.
- Mobile widths below 760 px are unchanged and continue using the existing mobile card branch.

Pagination note:
- UI-only pagination would not reduce Turso row-read usage if the app still fetches all BloodSamples rows first.
- To reduce row-read usage, pagination must be implemented at the data/query layer with indexed server-side queries such as LIMIT/OFFSET or cursor-based paging.

Updated file:
- lib/views/dashboard_view.dart

Preserved:
- v174f tablet dashboard bounded-height fix.
- v174d lab tech update/replace completed results behavior.
- v174c compact Blood Samples cards and status filter.
