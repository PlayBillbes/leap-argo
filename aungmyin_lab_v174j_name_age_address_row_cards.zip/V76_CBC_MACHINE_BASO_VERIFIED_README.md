# CBC machine BASO verification

Validated against uploaded analyzer ZIP `New folder.zip.pptx`.

CSV findings:
- CSV file includes `Bas%` and `Bas#` columns.
- The app maps these to `BasPercent` and `BasCount`.

Graph findings:
- ZIP includes WBC/RBC/PLT graphs and DIFF_LSMS, DIFF_LSHS, DIFF_HSMS scattergrams.
- No PNG filename in this uploaded ZIP contains BASO/BAS.

Backend support included anyway:
- `basoGraphBase64`
- `diffBasoBase64`
- `payload_json` full row snapshot
- all CBC analyzer columns and graph Base64 columns
