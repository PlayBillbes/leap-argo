# v129 report footer section

This build adds a footer section to the Report Header settings and applies it to printed/saved PDFs for non-global users.

Changes:
- Report Header settings sheet expanded from A:J to A:K with a new `footerText` column.
- Report Header page now has a Footer text field and footer preview.
- Footer is applied only when the resolved report header belongs to a non-global/sub-center context.
- Single result PDFs now render the footer through the PDF footer callback.
- Dashboard single/multi-select print PDFs now render the footer through the PDF footer callback.
- Global report headers do not print the footer.
