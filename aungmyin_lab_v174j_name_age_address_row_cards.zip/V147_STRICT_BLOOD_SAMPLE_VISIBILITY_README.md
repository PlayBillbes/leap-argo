# v147 strict blood sample visibility

This build makes the requested role-based blood sample visibility explicit and consistent.

Rules enforced:
- Superadmin can see all blood samples.
- Lab tech can see all blood samples.
- Admin users can see all registered blood samples from their own non-GLOBAL sub-center only.
- Staff users can see all registered blood samples from their own non-GLOBAL sub-center only.
- Referred person users can see all blood samples referred by their account, matched by referred person id or fallback referred person name.

Changes:
- Fixed referred-person fallback matching when older sample rows have only referredPersonName and no referredPersonId.
- Applied the same role visibility rules to dashboard filtering, referred-person analytics, patient search, and direct sample result access.
- Updated superadmin refer fee report row filtering so name-only referral rows are not dropped.
- Direct sample result links now deny access if the signed-in user is outside the allowed role/sub-center/referral scope.
- GLOBAL or empty sub-center rows remain hidden from admin and staff users.

Preserved:
- v146 refer fee report buttons.
- v145 mobile Users page rewrite.
- v144 native Turso compile fix.
