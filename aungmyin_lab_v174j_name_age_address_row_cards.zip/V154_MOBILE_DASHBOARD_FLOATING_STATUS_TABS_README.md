# v154 mobile dashboard floating status tabs

This build changes the mobile Lab Dashboard layout so the status filter bar floats while users scroll the sample list.

Changes:
- Processing/Pending/Completed/Total summary cards stay fixed above the sample list.
- Search and Filters stay fixed above the sample list.
- Only the All / Processing / Pending / Completed status bar floats over the sample list while scrolling.
- The floating status bar is positioned directly below the fixed summary/search area, visually near the upper third of the mobile screen.
- Added top padding to the mobile sample list so sample cards do not hide under the floating status bar.
- Added a soft shadow behind the floating status bar.

Preserved:
- v153 mobile dashboard summary-card overflow fix.
- v152 offline registered samples appear immediately on dashboard cache.
- v151 automatic sync queue and Sync now button.
