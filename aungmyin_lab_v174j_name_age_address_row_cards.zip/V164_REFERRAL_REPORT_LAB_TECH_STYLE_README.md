# v164 referral report lab tech style

This build updates the referral fee PDF report so it visually matches the lab tech PDF report style.

Changes:
- Referral report header now uses the same blue lab-report style header structure as the lab tech print report.
- Referral report header uses the MOH image asset when available, with AM fallback text if the asset cannot be loaded.
- Report metadata is shown in the same gray information panel style under the header.
- Section headings and tables now use a simpler lab-report style with gray headers and gray borders instead of colored report tables.
- Referral summary, period summary, and sample detail sections are preserved but restyled.

Updated file:
- lib/services/refer_fee_report_service.dart

Preserved:
- v163 Custom Pricing sticky search box.
- v162 superadmin delete blood sample row.
- v161 pending sample cancel.
