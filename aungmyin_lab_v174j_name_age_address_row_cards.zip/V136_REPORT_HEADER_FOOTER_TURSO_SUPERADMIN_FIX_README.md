# v136 report header footer Turso and superadmin edit fix

This build fixes the Report Header footer field when saving through Turso and restricts Report Header editing to superadmin.

Changes:
- ReportHeaderSettings Turso mapping now includes `footerText` in the fetch header list.
- ReportHeaderSettings save now writes `footerText` to the `footer_text` column in `report_header_settings`.
- Schema initialization now ensures the `footer_text` column exists.
- Fetching report header settings reads `footer_text`, with fallback to legacy `footer`.
- `/report-header` route is now superadmin-only.
- Report Header sidebar navigation is shown only to superadmin users.
- Report Header save action now has an explicit superadmin guard.
- Header input fields are disabled for non-superadmin users if the page is reached unexpectedly.

Reason:
The page already had a footer text field, but the Turso adapter did not include `footerText` in the ReportHeaderSettings header mapping or upsert SQL. This caused the footer value to be dropped before it reached Turso.
