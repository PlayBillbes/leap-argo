# v161 pending blood sample cancel

This build adds cancellation for pending blood samples.

Rules:
- Superadmin can cancel a blood sample only while it is Pending.
- Admin can cancel a blood sample only while it is Pending.
- Staff can cancel a blood sample only while it is Pending.
- Lab tech does not get the cancel action.
- Processing and Completed samples cannot be canceled.

Behavior:
- Cancel marks the BloodSamples row status as `canceled` instead of deleting the record.
- The status update uses the existing optimistic BloodSamples upsert path, so offline cancellation is queued and cached like other status changes.
- Canceled samples show a gray status chip and cannot be reviewed by lab tech.

Updated files:
- lib/models/blood_sample.dart
- lib/models/blood_sample.g.dart
- lib/views/dashboard_view.dart

Preserved:
- v160 superadmin/lab tech all blood samples visibility.
- v159 sub-center role visibility fix.
- v157 mobile sticky status tabs only.
