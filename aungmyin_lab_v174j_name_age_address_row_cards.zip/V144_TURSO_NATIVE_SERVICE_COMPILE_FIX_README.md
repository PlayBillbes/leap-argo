# v144 TursoNativeService compile fix

This build fixes the v143 Linux build errors in `lib/services/turso_native_service.dart`.

Changes:
- Restored the local `sheet` variable inside `fetchRows`, `insertRow`, and `updateRow`.
- Fixed `_parseRange` to pass the parsed table/sheet name into `_ParsedRange`.
- Fixed `_normSheet` to normalize the method parameter instead of an undefined `table` variable.

Preserved:
- v143 pure native Turso cleanup.
- v142 one-time login alert behavior.
- v141 dashboard role sample-scope rules.
