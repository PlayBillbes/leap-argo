function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('LabOps')
    .addItem('Create Demo Data', 'createDemoData')
    .addToUi();
}

function createDemoData() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = spreadsheet.getActiveSheet();
  sheet.clear();
  sheet.setName('Samples');

  const headers = [
    'id',
    'patientName',
    'status',
    'testIds',
    'subCenterId',
    'resultUrl',
    'createdAt',
    'updatedAt',
  ];

  sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  sheet.getRange(1, 1, 1, headers.length).setFontWeight('bold');

  const rows = [
    [
      'sample-001',
      'Amina Yusuf',
      'pending',
      'CBC,Malaria',
      'CENTER-01',
      '',
      new Date().toISOString(),
      new Date().toISOString(),
    ],
    [
      'sample-002',
      'Ibrahim Sule',
      'processing',
      'Blood Group',
      'CENTER-02',
      '',
      new Date().toISOString(),
      new Date().toISOString(),
    ],
    [
      'sample-003',
      'Rita Okafor',
      'completed',
      'CBC,HIV',
      'CENTER-01',
      'https://example.com/result.pdf',
      new Date().toISOString(),
      new Date().toISOString(),
    ],
    [
      'sample-004',
      'Daniel Kanu',
      'pending',
      'Malaria',
      'CENTER-03',
      '',
      new Date().toISOString(),
      new Date().toISOString(),
    ],
  ];

  sheet.getRange(2, 1, rows.length, headers.length).setValues(rows);
  sheet.autoResizeColumns(1, headers.length);

  sheet.getRange(1, 1, rows.length + 1, headers.length).setBorder(
    true,
    true,
    true,
    true,
    true,
    true,
    '#d0d7de',
    SpreadsheetApp.BorderStyle.SOLID
  );

  return {
    ok: true,
    sheetName: sheet.getName(),
    rowsInserted: rows.length,
  };
}
