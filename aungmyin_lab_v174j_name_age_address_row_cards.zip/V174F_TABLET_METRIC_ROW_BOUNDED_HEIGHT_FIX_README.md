## v174f tablet dashboard metric row bounded-height fix

This patch fixes the blank Lab Dashboard content introduced by the v174e metric-card row change.

Fix:
- Wrapped the desktop/tablet metric card row in a bounded-height SizedBox so the Row no longer receives unbounded vertical constraints inside the dashboard scroll view.
- Kept the metric cards in one horizontal row for tablet/desktop.
- Reduced metric card padding, icon size, title size, value size, and subtitle size slightly so the row fits better on tablet screens.

Preserved:
- Mobile dashboard branch remains unchanged.
- v174d lab tech update/replace completed results behavior.
- v174c compact Blood Samples cards and status filter.
