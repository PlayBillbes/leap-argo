# v166 desktop Global Pricing and alert delete fix

This build fixes two reported issues.

Changes:
- Global Pricing now has a centered max-width desktop layout so very wide screens remain readable.
- Global Pricing switches to the compact single-column layout below 1120 px, covering narrow desktop/tablet widths better.
- Global Pricing desktop editor width now scales with the available width instead of staying fixed.
- Global Pricing editor card is internally scrollable to prevent vertical overflow on shorter desktop screens.
- Alert delete now writes to the real `Alert!A2:A2` range instead of the invalid `the active alert row:A2` range.
- Alert save uses the same corrected `Alert!A2:A2` range.

Updated files:
- lib/views/global_pricing_page.dart
- lib/providers/alert_provider.dart

Preserved:
- v165 responsive pricing/tablet sample fixes.
- v164 referral report lab tech style.
