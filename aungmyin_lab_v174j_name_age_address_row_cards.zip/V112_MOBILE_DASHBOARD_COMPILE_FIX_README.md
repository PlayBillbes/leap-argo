# v112 mobile dashboard compile fix

Fixes the Linux/Flutter build error in lib/views/dashboard_view.dart:
- Replaced invalid `Container(minHeight: ...)` with `Container(constraints: BoxConstraints(minHeight: ...))`.
- Keeps the v111 screenshot-style mobile Lab Dashboard UI changes.
