# v148 referral report custom header and mobile login buttons

This build updates the referral fee reports and mobile login page.

Changes:
- Referral fee PDF reports now load the custom Report Header settings from `ReportHeaderSettings!A:K`.
- Referral fee reports now render the same modern blue accent letterhead style used by the Report Header preview and result PDFs.
- Referral fee reports use sub-center header settings when available and fall back to the global custom header.
- Referral fee report footers use the saved footer text for non-global/sub-center report output.
- Mobile login page About and Settings buttons now render as blue buttons with white text/icons.

Preserved:
- v147 strict blood sample visibility.
- v146 refer fee report buttons.
- v145 mobile Users page rewrite.
