class TursoConfig {
  static const String databaseUrl = 'libsql://modsbots-modsbots.aws-ap-south-1.turso.io';
  static const String authToken = 'eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhIjoicnciLCJpYXQiOjE3ODQ3OTY2NzYsImlkIjoiMDE5ZjhlMmItNDgwMS03NWUzLTlmNDUtZTBhMmY0ODkxZTE1Iiwia2lkIjoiZWd3ZFFqVmUwUFR1ZnV2VnQ5WmFUN3hNMlNDMVh1S0MyQ3h3VzBhZFNaNCIsInJpZCI6ImYwYTJmZGQ5LTIyYmItNDAyZS1hMDZkLTM5MGRmMDI2MTc2YyJ9.Zp4zvtPX3LwyNfTgI9tgQ22Pun2OOnVIzxv3HdlY7PVyMrua8IdErqFOZPXkIiOYji53FWwJXlfIczwYyQ6KDA';

  static bool get isConfigured => databaseUrl.trim().isNotEmpty && authToken.trim().isNotEmpty;
}
