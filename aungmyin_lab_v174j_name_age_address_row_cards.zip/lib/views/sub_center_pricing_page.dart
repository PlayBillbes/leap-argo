import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/app_user.dart';
import '../models/lab_test.dart';
import '../models/sub_center_pricing.dart';
import '../providers/auth_notifier.dart';
import '../providers/tests_provider.dart';
import '../services/turso_native_service.dart';
import '../widgets/app_sidebar.dart';

class SubCenterPricingPage extends ConsumerStatefulWidget {
  const SubCenterPricingPage({super.key});

  @override
  ConsumerState<SubCenterPricingPage> createState() => _SubCenterPricingPageState();
}

class _SubCenterPricingPageState extends ConsumerState<SubCenterPricingPage> {
  static const _sheetName = 'SubCenterPricings';
  static const _range = 'SubCenterPricings!A:D';
  final _searchController = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  String _normalize(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  Future<TursoNativeService> _newTursoService() async {
    return TursoNativeService(
      applicationName: 'flutterlab',
    );
  }

  SubCenterPricing? _pricingFor(List<SubCenterPricing> pricings, String subCenterId, LabTest test) {
    final center = _normalize(subCenterId);
    final testId = _normalize(test.id);
    final testName = _normalize(test.testName);
    for (final pricing in pricings) {
      if (_normalize(pricing.subCenterId) != center) continue;
      final pricingTest = _normalize(pricing.testId);
      if (pricingTest == testId || pricingTest == testName) return pricing;
    }
    return null;
  }

  Future<int?> _findRow(TursoNativeService service, String subCenterId, LabTest test) async {
    final rows = await service.fetchRows(range: _range);
    if (rows.isEmpty) return null;
    final testId = _normalize(test.id);
    final testName = _normalize(test.testName);
    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      final rowCenter = row.isNotEmpty ? row[0] : '';
      final rowTest = row.length > 1 ? row[1] : '';
      if (_normalize(rowCenter) == _normalize(subCenterId) &&
          (_normalize(rowTest) == testId || _normalize(rowTest) == testName)) {
        return i + 1;
      }
    }
    return null;
  }

  Future<void> _savePrice(AppUser user, LabTest test, double price, double referredFeePercent) async {
    final subCenterId = (user.subCenterId ?? '').trim().isEmpty ? 'GLOBAL' : user.subCenterId!.trim();
    if (price <= 0) {
      _showToast('Customer price must be greater than 0.', isError: true);
      return;
    }
    if (referredFeePercent < 0 || referredFeePercent > 100) {
      _showToast('Referred fee percent must be between 0 and 100.', isError: true);
      return;
    }
    setState(() => _saving = true);
    TursoNativeService? service;
    try {
      service = await _newTursoService();
      final row = await _findRow(service, subCenterId, test);
      final values = <String>[subCenterId, test.id, price.toStringAsFixed(2), referredFeePercent.toStringAsFixed(2)];
      if (row == null) {
        await service.insertRow(range: _range, values: values);
      } else {
        await service.updateRow(range: '$_sheetName!A$row:D$row', values: values);
      }
      ref.invalidate(pricingsProvider);
      _showToast('${test.testName} customer price and referred fee saved.');
    } catch (error) {
      _showToast('Save failed: $error', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _openDialog(AppUser user, LabTest test, double currentPrice, double currentReferredFeePercent) async {
    final priceController = TextEditingController(text: currentPrice.toStringAsFixed(2));
    final feeController = TextEditingController(text: currentReferredFeePercent.toStringAsFixed(2));
    final result = await showDialog<_PriceDialogResult>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Set ${test.testName} pricing'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: priceController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'Customer price',
                helperText: 'Global price: ${test.defaultPrice.toStringAsFixed(2)}',
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: feeController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Referred fee %',
                helperText: 'Example: 10 means 10% of customer price.',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(
              context,
              _PriceDialogResult(
                price: double.tryParse(priceController.text.trim()),
                referredFeePercent: double.tryParse(feeController.text.trim()) ?? 0,
              ),
            ),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    priceController.dispose();
    feeController.dispose();
    if (result != null && result.price != null) {
      await _savePrice(user, test, result.price!, result.referredFeePercent);
    }
  }

  void _showToast(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating, backgroundColor: isError ? Theme.of(context).colorScheme.error : null),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    final testsAsync = ref.watch(testsProvider);
    final pricingsAsync = ref.watch(pricingsProvider);
    return AppScaffold(
      title: 'Custom Pricing',
      selectedRoute: '/sub-center-pricing',
      user: user,
      actions: [IconButton.filledTonal(onPressed: _saving ? null : () { ref.invalidate(testsProvider); ref.invalidate(pricingsProvider); }, icon: const Icon(Icons.refresh_rounded))],
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: testsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('Tests load failed: $e')),
          data: (tests) => pricingsAsync.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, _) => Center(child: Text('Pricing load failed: $e')),
            data: (pricings) => _buildContent(context, user, tests, pricings),
          ),
        ),
      ),
    );
  }

  Widget _buildContent(BuildContext context, AppUser? user, List<LabTest> tests, List<SubCenterPricing> pricings) {
    if (user == null || user.role != AppUserRole.admin) {
      return const Center(child: Text('Only admin users can set custom pricing.'));
    }
    final subCenterId = (user.subCenterId ?? '').trim().isEmpty ? 'GLOBAL' : user.subCenterId!.trim();
    final query = _searchController.text.trim().toLowerCase();
    final filtered = query.isEmpty ? tests : tests.where((t) => t.testName.toLowerCase().contains(query) || t.id.toLowerCase().contains(query)).toList();

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Customer Pricing for $subCenterId', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              const Text('Set customer prices and referred fee percentage for your sub-center. Referred fee is calculated from customer price.'),
              const SizedBox(height: 12),
            ],
          ),
        ),
        SliverPersistentHeader(
          pinned: true,
          delegate: _CustomPricingSearchHeaderDelegate(
            controller: _searchController,
            onChanged: (_) => setState(() {}),
          ),
        ),
        SliverToBoxAdapter(child: const SizedBox(height: 12)),
        if (filtered.isEmpty)
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.only(top: 24),
              child: Center(child: Text('No tests match this search.')),
            ),
          )
        else
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                if (index.isOdd) return const SizedBox(height: 10);
                final test = filtered[index ~/ 2];
                final pricing = _pricingFor(pricings, subCenterId, test);
                final customerPrice = pricing?.customPrice ?? test.defaultPrice;
                final profit = customerPrice - test.defaultPrice;
                final referredFeePercent = pricing?.referredFeePercent ?? 0;
                final referredFeeAmount = customerPrice * referredFeePercent / 100;
                return LayoutBuilder(
                  builder: (context, constraints) {
                    if (constraints.maxWidth < 620) {
                      return Card(
                        elevation: 0,
                        color: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(color: const Color(0xFFEFF6FF), borderRadius: BorderRadius.circular(12)),
                                    child: const Icon(Icons.science_rounded, color: Color(0xFF2563EB)),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(child: Text(test.testName, style: const TextStyle(fontWeight: FontWeight.w900))),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Expanded(child: _MiniPriceBox(label: 'Custom Price', value: customerPrice.toStringAsFixed(0))),
                                  const SizedBox(width: 8),
                                  Expanded(child: _MiniPriceBox(label: 'Refer Fee %', value: referredFeePercent.toStringAsFixed(0))),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text('Global ${test.defaultPrice.toStringAsFixed(0)} • Profit ${profit.toStringAsFixed(0)} • Refer ${referredFeeAmount.toStringAsFixed(0)}', style: const TextStyle(color: Color(0xFF64748B), fontSize: 12)),
                              const SizedBox(height: 12),
                              SizedBox(
                                width: double.infinity,
                                child: FilledButton.tonalIcon(
                                  onPressed: _saving ? null : () => _openDialog(user, test, customerPrice, referredFeePercent),
                                  icon: const Icon(Icons.edit_rounded),
                                  label: const Text('Set Price'),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }
                    return Card(
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      child: ListTile(
                        leading: CircleAvatar(backgroundColor: const Color(0xFFEFF6FF), child: Text(test.testName.characters.first.toUpperCase(), style: const TextStyle(color: Color(0xFF2563EB), fontWeight: FontWeight.w900))),
                        title: Text(test.testName, style: const TextStyle(fontWeight: FontWeight.w800)),
                        subtitle: Text('Global: ${test.defaultPrice.toStringAsFixed(2)}  •  Customer: ${customerPrice.toStringAsFixed(2)}  •  Profit: ${profit.toStringAsFixed(2)}  •  Referred fee: ${referredFeePercent.toStringAsFixed(2)}% (${referredFeeAmount.toStringAsFixed(2)})'),
                        trailing: FilledButton.tonalIcon(
                          onPressed: _saving ? null : () => _openDialog(user, test, customerPrice, referredFeePercent),
                          icon: const Icon(Icons.edit_rounded),
                          label: const Text('Set Price'),
                        ),
                      ),
                    );
                  },
                );
              },
              childCount: filtered.length * 2 - 1,
            ),
          ),
      ],
    );
  }

}


class _CustomPricingSearchHeaderDelegate extends SliverPersistentHeaderDelegate {
  _CustomPricingSearchHeaderDelegate({required this.controller, required this.onChanged});

  final TextEditingController controller;
  final ValueChanged<String> onChanged;

  @override
  double get minExtent => 74;

  @override
  double get maxExtent => 74;

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: const Color(0xFFF6F8FC),
      padding: const EdgeInsets.only(top: 8, bottom: 12),
      alignment: Alignment.topCenter,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          boxShadow: overlapsContent || shrinkOffset > 0
              ? [BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 12, offset: const Offset(0, 6))]
              : const [],
        ),
        child: TextField(
          controller: controller,
          onChanged: onChanged,
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search_rounded),
            border: OutlineInputBorder(),
            hintText: 'Search tests...',
            filled: true,
            fillColor: Colors.white,
          ),
        ),
      ),
    );
  }

  @override
  bool shouldRebuild(covariant _CustomPricingSearchHeaderDelegate oldDelegate) {
    return oldDelegate.controller != controller || oldDelegate.onChanged != onChanged;
  }
}

class _MiniPriceBox extends StatelessWidget {
  const _MiniPriceBox({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: const Color(0xFFF8FAFC),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontSize: 11, color: Color(0xFF64748B), fontWeight: FontWeight.w700)),
        const SizedBox(height: 3),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

class _PriceDialogResult {
  const _PriceDialogResult({required this.price, required this.referredFeePercent});

  final double? price;
  final double referredFeePercent;
}
