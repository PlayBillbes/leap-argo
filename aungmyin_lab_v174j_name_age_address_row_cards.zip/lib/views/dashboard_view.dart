import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../models/app_user.dart';
import '../models/blood_sample.dart';
import '../models/lab_test.dart';
import '../models/sub_center_pricing.dart';
import '../providers/auth_notifier.dart';
import '../providers/sample_dashboard_controller.dart';
import '../providers/tests_provider.dart';
import '../services/native_file_service.dart';
import '../services/turso_native_service.dart';
import '../utils/report_generator.dart';
import '../widgets/app_sidebar.dart';

class DashboardView extends ConsumerWidget {
  const DashboardView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final user = ref.watch(authNotifierProvider);
    final samplesAsync = ref.watch(sampleDashboardControllerProvider);

    return AppScaffold(
      title: 'Lab Dashboard',
      selectedRoute: '/',
      user: user,
      actions: [
        TextButton.icon(
          onPressed: () {
            ref.invalidate(sampleDashboardControllerProvider);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Refreshing samples...')),
            );
          },
          style: TextButton.styleFrom(
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
          ),
          icon: const Icon(Icons.refresh_rounded, size: 28),
          label: const Text('Refresh'),
        ),
      ],
      body: LayoutBuilder(
        builder: (context, constraints) {
          final isMobile = constraints.maxWidth < 760;
          return Padding(
            padding: EdgeInsets.fromLTRB(isMobile ? 16 : 24, isMobile ? 22 : 8, isMobile ? 16 : 24, isMobile ? 18 : 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: samplesAsync.when(
                    data: (samples) {
                      final content = _DashboardContent(samples: samples);
                      if (!isMobile) return content;
                      return RefreshIndicator(
                        onRefresh: () async {
                          ref.invalidate(sampleDashboardControllerProvider);
                          ref.invalidate(testsProvider);
                          ref.invalidate(pricingsProvider);
                          await Future<void>.delayed(const Duration(milliseconds: 350));
                        },
                        child: content,
                      );
                    },
                    loading: () => const Center(child: CircularProgressIndicator()),
                    error: (error, stack) => _ErrorCard(
                      message: 'Failed to load samples: $error',
                      onRetry: () => ref.invalidate(sampleDashboardControllerProvider),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _DashboardContent extends ConsumerWidget {
  const _DashboardContent({required this.samples});

  final List<BloodSample> samples;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final user = ref.watch(authNotifierProvider);
    final testsAsync = ref.watch(testsProvider);
    final pricingsAsync = ref.watch(pricingsProvider);

    final tests = testsAsync.maybeWhen(
      data: (items) => items,
      orElse: () => const <LabTest>[],
    );
    final pricings = pricingsAsync.maybeWhen(
      data: (items) => items,
      orElse: () => const <SubCenterPricing>[],
    );

    final isStaff = user?.role == AppUserRole.staff;
    final isReferredPerson = user?.role == AppUserRole.referred_person;
    String normalizeReferral(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
    final canSeeAllBloodSamples = user?.role == AppUserRole.superadmin || user?.role == AppUserRole.lab_tech;
    final dashboardSamples = canSeeAllBloodSamples
        ? samples
        : isReferredPerson && user != null
        ? samples.where((sample) {
            final referredId = normalizeReferral(sample.referredPersonId ?? '');
            final referredName = normalizeReferral(sample.referredPersonName ?? '');
            final userId = normalizeReferral(user.id);
            final userName = normalizeReferral(user.name);
            if (referredId == 'self' || referredName == 'self') return false;
            if (referredId.isNotEmpty && referredId == userId) return true;
            return userName.isNotEmpty && referredName == userName;
          }).toList()
        : samples;
    final report = ReportGenerator(
      samples: dashboardSamples,
      tests: tests,
      pricings: pricings,
      useCustomerPrices: user?.role != AppUserRole.superadmin,
    );
    final now = DateTime.now();
    final daily = report.totalDailyRevenue(now);
    final monthly = report.totalMonthlyRevenue(now);
    final yearly = report.totalYearlyRevenue(now);
    final dailyTests = report.totalDailyTests(now);
    final monthlyTests = report.totalMonthlyTests(now);
    final yearlyTests = report.totalYearlyTests(now);
    final monthlyProfit = report.totalMonthlyProfit(now);
    final dailyReferredFee = report.totalDailyReferredFee(now);
    final monthlyReferredFee = report.totalMonthlyReferredFee(now);
    final totalReferredFee = report.totalReferredFee();
    final isLabTech = user?.role == AppUserRole.lab_tech;
    final pendingTodayByTest = report.pendingTestCountByNameForDay(now);
    final labTechTodayTotal = report.totalDailyTests(now);
    final labTechMonthTotal = report.totalMonthlyTests(now);
    final labTechYearTotal = report.totalYearlyTests(now);
    final summary = report.groupedRevenueSummary(includeCounts: true);

    final pending = dashboardSamples
        .where((sample) => sample.status == BloodSampleStatus.pending)
        .length;
    final processing = dashboardSamples
        .where((sample) => sample.status == BloodSampleStatus.processing)
        .length;
    final completed = dashboardSamples
        .where((sample) => sample.status == BloodSampleStatus.completed)
        .length;
    final isAdminDashboard = !isStaff && !isReferredPerson && !isLabTech;

    if (MediaQuery.sizeOf(context).width < 760) {
      return _MobileAdminDashboardContent(
        user: user,
        samples: dashboardSamples,
        tests: tests,
        pricings: pricings,
        daily: daily,
        monthly: monthly,
        yearly: yearly,
        monthlyProfit: monthlyProfit,
        monthlyReferredFee: monthlyReferredFee,
        pending: pending,
        processing: processing,
        completed: completed,
      );
    }

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          LayoutBuilder(
            builder: (context, constraints) {
              final cards = isReferredPerson
                  ? [
                      _MetricCard(
                        title: 'Tests Today',
                        value: dailyTests.toString(),
                        subtitle: 'Your referred tests today',
                        icon: Icons.today_rounded,
                        color: const Color(0xFF2563EB),
                      ),
                      _MetricCard(
                        title: 'Tests This Month',
                        value: monthlyTests.toString(),
                        subtitle: 'Your referred tests this month',
                        icon: Icons.calendar_month_rounded,
                        color: const Color(0xFF059669),
                      ),
                      _MetricCard(
                        title: 'Tests This Year',
                        value: yearlyTests.toString(),
                        subtitle: 'Your referred tests this year',
                        icon: Icons.auto_graph_rounded,
                        color: const Color(0xFF2563EB),
                      ),
                      _MetricCard(
                        title: 'Today Refer Fee',
                        value: _formatDashboardNumber(dailyReferredFee),
                        subtitle: 'Refer fee earned today',
                        icon: Icons.person_pin_circle_rounded,
                        color: const Color(0xFFF59E0B),
                      ),
                      _MetricCard(
                        title: 'This Month Refer Fee',
                        value: _formatDashboardNumber(monthlyReferredFee),
                        subtitle: 'Refer fee earned this month',
                        icon: Icons.payments_rounded,
                        color: const Color(0xFFEA580C),
                      ),
                      _MetricCard(
                        title: 'Total Refer Fee',
                        value: _formatDashboardNumber(totalReferredFee),
                        subtitle: 'All referred tests shown below',
                        icon: Icons.savings_rounded,
                        color: const Color(0xFF0EA5E9),
                      ),
                    ]
                  : isLabTech
                  ? [
                      _MetricCard(
                        title: 'Tests / Today',
                        value: labTechTodayTotal.toString(),
                        subtitle: 'Total tests today',
                        icon: Icons.pending_actions_rounded,
                        color: const Color(0xFF2563EB),
                      ),
                      _MetricCard(
                        title: 'Tests / This Month',
                        value: labTechMonthTotal.toString(),
                        subtitle: 'Total tests this month',
                        icon: Icons.calendar_month_rounded,
                        color: const Color(0xFF059669),
                      ),
                      _MetricCard(
                        title: 'Tests / This Year',
                        value: labTechYearTotal.toString(),
                        subtitle: 'Total tests this year',
                        icon: Icons.auto_graph_rounded,
                        color: const Color(0xFF2563EB),
                      ),
                      _MetricCard(
                        title: 'Pending Samples',
                        value: pending.toString(),
                        subtitle: 'Samples waiting review',
                        icon: Icons.science_rounded,
                        color: const Color(0xFFEA580C),
                      ),
                    ]
                  : isStaff
                  ? [
                      _MetricCard(
                        title: 'Today Tests',
                        value: dailyTests.toString(),
                        subtitle: 'Tests requested today',
                        icon: Icons.today_rounded,
                        color: const Color(0xFF2563EB),
                      ),
                      _MetricCard(
                        title: 'This Month Tests',
                        value: monthlyTests.toString(),
                        subtitle: 'Tests requested this month',
                        icon: Icons.calendar_month_rounded,
                        color: const Color(0xFF059669),
                      ),
                      _MetricCard(
                        title: 'This Year Tests',
                        value: yearlyTests.toString(),
                        subtitle: 'Tests requested this year',
                        icon: Icons.auto_graph_rounded,
                        color: const Color(0xFF2563EB),
                      ),
                      _MetricCard(
                        title: 'This Month Cost',
                        value: _formatDashboardNumber(monthly),
                        subtitle: 'Cost by sub-center custom price',
                        icon: Icons.payments_rounded,
                        color: const Color(0xFFEA580C),
                      ),
                    ]
                  : [
                      _MetricCard(
                        title: 'Today',
                        value: _formatDashboardNumber(daily),
                        subtitle: 'Daily revenue',
                        icon: Icons.today_rounded,
                        color: const Color(0xFF2563EB),
                      ),
                      _MetricCard(
                        title: 'This Month',
                        value: _formatDashboardNumber(monthly),
                        subtitle: 'Monthly revenue',
                        icon: Icons.calendar_month_rounded,
                        color: const Color(0xFF059669),
                      ),
                      _MetricCard(
                        title: 'This Year',
                        value: _formatDashboardNumber(yearly),
                        subtitle: 'Yearly revenue',
                        icon: Icons.auto_graph_rounded,
                        color: const Color(0xFF2563EB),
                      ),
                      _MetricCard(
                        title: 'This Month Profit',
                        value: _formatDashboardNumber(monthlyProfit),
                        subtitle: user?.role == AppUserRole.superadmin
                            ? 'Superadmin uses default price'
                            : 'Custom - global - refer fee',
                        icon: Icons.trending_up_rounded,
                        color: const Color(0xFFEA580C),
                      ),
                      if (user?.role != AppUserRole.superadmin)
                        _MetricCard(
                          title: 'This Month Refer Fee',
                          value: _formatDashboardNumber(monthlyReferredFee),
                          subtitle: 'Paid when referral is not Self',
                          icon: Icons.person_pin_circle_rounded,
                          color: const Color(0xFFF59E0B),
                        ),
                    ];

              final gap = constraints.maxWidth < 980 ? 8.0 : 12.0;
              final metricHeight = constraints.maxWidth < 980 ? 116.0 : 132.0;
              return SizedBox(
                height: metricHeight,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    for (var i = 0; i < cards.length; i++) ...[
                      Expanded(child: cards[i]),
                      if (i != cards.length - 1) SizedBox(width: gap),
                    ],
                  ],
                ),
              );
            },
          ),
          if (isLabTech || isStaff) ...[
            const SizedBox(height: 18),
            _TodayPendingTestsCard(counts: pendingTodayByTest),
          ],
          if (!isStaff && !isReferredPerson) ...[
            const SizedBox(height: 18),
            LayoutBuilder(
              builder: (context, constraints) {
                final compact = constraints.maxWidth < 920;
                final statusCard = _StatusOverviewCard(
                  pending: pending,
                  processing: processing,
                  completed: completed,
                  total: dashboardSamples.length,
                );
                final summaryCard = _SummaryCard(summary: summary, isStaff: isStaff);

                if (compact) {
                  return Column(
                    children: [
                      statusCard,
                      const SizedBox(height: 14),
                      summaryCard,
                    ],
                  );
                }

                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(child: statusCard),
                    const SizedBox(width: 14),
                    Expanded(child: summaryCard),
                  ],
                );
              },
            ),
          ],
          if ((isStaff || isLabTech) && user != null) ...[
            const SizedBox(height: 18),
            Card(
              elevation: 0,
              color: theme.colorScheme.surface.withValues(alpha: 0.92),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: theme.colorScheme.primaryContainer,
                      foregroundColor: theme.colorScheme.onPrimaryContainer,
                      child: const Icon(Icons.addchart_rounded),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Register Blood Sample', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
                          const Text('Open the dedicated registration page to select searchable tests and create one table row per test.'),
                        ],
                      ),
                    ),
                    FilledButton.icon(
                      onPressed: () => context.go('/register-sample'),
                      icon: const Icon(Icons.arrow_forward_rounded),
                      label: const Text('Open'),
                    ),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 18),
          _SampleTable(
            user: user,
            samples: dashboardSamples,
            tests: tests,
            pricings: pricings,
          ),
        ],
      ),
    );
  }

}


class _MobileAdminDashboardContent extends StatefulWidget {
  const _MobileAdminDashboardContent({
    required this.user,
    required this.samples,
    required this.tests,
    required this.pricings,
    required this.daily,
    required this.monthly,
    required this.yearly,
    required this.monthlyProfit,
    required this.monthlyReferredFee,
    required this.pending,
    required this.processing,
    required this.completed,
  });

  final AppUser? user;
  final List<BloodSample> samples;
  final List<LabTest> tests;
  final List<SubCenterPricing> pricings;
  final double daily;
  final double monthly;
  final double yearly;
  final double monthlyProfit;
  final double monthlyReferredFee;
  final int pending;
  final int processing;
  final int completed;

  @override
  State<_MobileAdminDashboardContent> createState() => _MobileAdminDashboardContentState();
}

class _MobileAdminDashboardContentState extends State<_MobileAdminDashboardContent> {
  String _query = '';
  BloodSampleStatus? _statusFilter;

  List<BloodSample> get _filteredSamples {
    final query = _query.trim().toLowerCase();
    return widget.samples.where((sample) {
      if (_statusFilter != null && sample.status != _statusFilter) return false;
      if (query.isEmpty) return true;
      final searchable = <String>[
        sample.id,
        sample.patientName,
        sample.subCenterId,
        sample.registeredByUserId,
        sample.status.name,
        sample.testIds.join(' '),
      ].join(' ').toLowerCase();
      return searchable.contains(query);
    }).toList();
  }

  int get _totalTests => widget.samples.fold<int>(0, (sum, sample) => sum + sample.testIds.length);

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final scale = (width / 390).clamp(0.78, 1.12).toDouble();

    final floatingTabsHeight = (50 * scale).clamp(44.0, 54.0).toDouble();

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Column(
            children: [
              _MobileDashboardReferenceStatsRow(
                scale: scale,
                processing: widget.processing,
                pending: widget.pending,
                completed: widget.completed,
                totalTests: _totalTests,
              ),
              SizedBox(height: 14 * scale),
              _MobileDashboardReferenceSearchFilter(
                scale: scale,
                query: _query,
                onQueryChanged: (value) => setState(() => _query = value),
                onFilterTap: () => _showFilterSheet(context),
              ),
              SizedBox(height: (10 * scale).clamp(8.0, 12.0).toDouble()),
            ],
          ),
        ),
        SliverPersistentHeader(
          pinned: true,
          delegate: _MobileStickyStatusTabsDelegate(
            height: floatingTabsHeight,
            scale: scale,
            selected: _statusFilter,
            onChanged: (value) => setState(() => _statusFilter = value),
          ),
        ),
        SliverToBoxAdapter(child: SizedBox(height: (12 * scale).clamp(8.0, 14.0).toDouble())),
        SliverToBoxAdapter(
          child: _SampleTable(
            user: widget.user,
            samples: _filteredSamples,
            tests: widget.tests,
            pricings: widget.pricings,
            mobileUseParentScroll: true,
          ),
        ),
      ],
    );
  }

  void _showFilterSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return SafeArea(
          child: Container(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 18),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    const Expanded(
                      child: Text('Filters', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                    ),
                    IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded)),
                  ],
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    ChoiceChip(label: const Text('All'), selected: _statusFilter == null, onSelected: (_) => _applyStatusFilter(null)),
                    ChoiceChip(label: const Text('Processing'), selected: _statusFilter == BloodSampleStatus.processing, onSelected: (_) => _applyStatusFilter(BloodSampleStatus.processing)),
                    ChoiceChip(label: const Text('Pending'), selected: _statusFilter == BloodSampleStatus.pending, onSelected: (_) => _applyStatusFilter(BloodSampleStatus.pending)),
                    ChoiceChip(label: const Text('Completed'), selected: _statusFilter == BloodSampleStatus.completed, onSelected: (_) => _applyStatusFilter(BloodSampleStatus.completed)),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _applyStatusFilter(BloodSampleStatus? status) {
    setState(() => _statusFilter = status);
    Navigator.pop(context);
  }
}

class _MobileDashboardReferenceStatsRow extends StatelessWidget {
  const _MobileDashboardReferenceStatsRow({
    required this.scale,
    required this.processing,
    required this.pending,
    required this.completed,
    required this.totalTests,
  });

  final double scale;
  final int processing;
  final int pending;
  final int completed;
  final int totalTests;

  @override
  Widget build(BuildContext context) {
    final cards = <_MobileDashboardReferenceStatData>[
      _MobileDashboardReferenceStatData(label: 'Processing', value: processing, icon: Icons.science_rounded, color: const Color(0xFF0B6BD3), background: const Color(0xFFEAF3FF)),
      _MobileDashboardReferenceStatData(label: 'Pending', value: pending, icon: Icons.schedule_rounded, color: const Color(0xFFF59E0B), background: const Color(0xFFFFF7E6)),
      _MobileDashboardReferenceStatData(label: 'Completed', value: completed, icon: Icons.check_circle_outline_rounded, color: const Color(0xFF16A34A), background: const Color(0xFFEAFBF1)),
      _MobileDashboardReferenceStatData(label: 'Total Tests', value: totalTests, icon: Icons.assignment_rounded, color: const Color(0xFF7C3AED), background: const Color(0xFFF3ECFF)),
    ];

    return Row(
      children: [
        for (var i = 0; i < cards.length; i++) ...[
          Expanded(child: _MobileDashboardReferenceStatCard(scale: scale, data: cards[i])),
          if (i != cards.length - 1) SizedBox(width: (6 * scale).clamp(4.0, 7.0).toDouble()),
        ],
      ],
    );
  }
}

class _MobileDashboardReferenceStatData {
  const _MobileDashboardReferenceStatData({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    required this.background,
  });

  final String label;
  final int value;
  final IconData icon;
  final Color color;
  final Color background;
}

class _MobileDashboardReferenceStatCard extends StatelessWidget {
  const _MobileDashboardReferenceStatCard({required this.scale, required this.data});

  final double scale;
  final _MobileDashboardReferenceStatData data;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: (104 * scale).clamp(94.0, 112.0).toDouble(),
      padding: EdgeInsets.symmetric(horizontal: (6 * scale).clamp(4.0, 7.0).toDouble(), vertical: (5 * scale).clamp(4.0, 6.0).toDouble()),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16 * scale),
        border: Border.all(color: const Color(0xFFE5EAF3)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.035), blurRadius: 12, offset: const Offset(0, 7))],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: (34 * scale).clamp(30.0, 38.0).toDouble(),
            height: (34 * scale).clamp(30.0, 38.0).toDouble(),
            decoration: BoxDecoration(color: data.background, shape: BoxShape.circle),
            child: Icon(data.icon, color: data.color, size: (18 * scale).clamp(16.0, 20.0).toDouble()),
          ),
          SizedBox(height: (5 * scale).clamp(3.0, 6.0).toDouble()),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              data.value.toString(),
              style: TextStyle(color: data.color, fontSize: (21 * scale).clamp(18.0, 23.0).toDouble(), fontWeight: FontWeight.w900, height: 0.9),
            ),
          ),
          SizedBox(height: (2 * scale).clamp(1.0, 3.0).toDouble()),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              data.label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: const Color(0xFF526070), fontSize: (10.5 * scale).clamp(8.5, 11.5).toDouble(), fontWeight: FontWeight.w700, height: 1.0),
            ),
          ),
        ],
      ),
    );
  }
}

class _MobileDashboardReferenceSearchFilter extends StatelessWidget {
  const _MobileDashboardReferenceSearchFilter({
    required this.scale,
    required this.query,
    required this.onQueryChanged,
    required this.onFilterTap,
  });

  final double scale;
  final String query;
  final ValueChanged<String> onQueryChanged;
  final VoidCallback onFilterTap;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: SizedBox(
            height: (52 * scale).clamp(44.0, 56.0).toDouble(),
            child: TextField(
              onChanged: onQueryChanged,
              style: TextStyle(fontSize: 15 * scale, fontWeight: FontWeight.w600),
              decoration: InputDecoration(
                hintText: 'Search by ID, Patient, Test...',
                hintStyle: TextStyle(color: const Color(0xFF8A95A5), fontSize: 15 * scale, fontWeight: FontWeight.w500),
                prefixIcon: Icon(Icons.search_rounded, color: const Color(0xFF536274), size: 26 * scale),
                filled: true,
                fillColor: Colors.white,
                contentPadding: EdgeInsets.zero,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16 * scale), borderSide: const BorderSide(color: Color(0xFFD8DEE9))),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16 * scale), borderSide: const BorderSide(color: Color(0xFFD8DEE9))),
              ),
            ),
          ),
        ),
        SizedBox(width: 10 * scale),
        SizedBox(
          height: (52 * scale).clamp(44.0, 56.0).toDouble(),
          child: OutlinedButton.icon(
            onPressed: onFilterTap,
            icon: Icon(Icons.tune_rounded, size: 22 * scale),
            label: Text('Filters', style: TextStyle(fontSize: 14 * scale, fontWeight: FontWeight.w800)),
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFF0B57B7),
              side: const BorderSide(color: Color(0xFFC9D7EA)),
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16 * scale)),
            ),
          ),
        ),
      ],
    );
  }
}

class _MobileFloatingStatusTabs extends StatelessWidget {
  const _MobileFloatingStatusTabs({required this.scale, required this.selected, required this.onChanged});

  final double scale;
  final BloodSampleStatus? selected;
  final ValueChanged<BloodSampleStatus?> onChanged;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20 * scale),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: _MobileDashboardReferenceStatusTabs(
        scale: scale,
        selected: selected,
        onChanged: onChanged,
      ),
    );
  }
}

class _MobileStickyStatusTabsDelegate extends SliverPersistentHeaderDelegate {
  _MobileStickyStatusTabsDelegate({required this.height, required this.scale, required this.selected, required this.onChanged});

  final double height;
  final double scale;
  final BloodSampleStatus? selected;
  final ValueChanged<BloodSampleStatus?> onChanged;

  @override
  double get minExtent => height;

  @override
  double get maxExtent => height;

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: const Color(0xFFF6F8FC),
      alignment: Alignment.topCenter,
      padding: EdgeInsets.only(top: (2 * scale).clamp(1.0, 4.0).toDouble()),
      child: _MobileFloatingStatusTabs(
        scale: scale,
        selected: selected,
        onChanged: onChanged,
      ),
    );
  }

  @override
  bool shouldRebuild(covariant _MobileStickyStatusTabsDelegate oldDelegate) {
    return oldDelegate.height != height ||
        oldDelegate.scale != scale ||
        oldDelegate.selected != selected ||
        oldDelegate.onChanged != onChanged;
  }
}

class _MobileDashboardReferenceStatusTabs extends StatelessWidget {
  const _MobileDashboardReferenceStatusTabs({required this.scale, required this.selected, required this.onChanged});

  final double scale;
  final BloodSampleStatus? selected;
  final ValueChanged<BloodSampleStatus?> onChanged;

  @override
  Widget build(BuildContext context) {
    final labels = <String>['All', 'Processing', 'Pending', 'Completed'];
    final values = <BloodSampleStatus?>[null, BloodSampleStatus.processing, BloodSampleStatus.pending, BloodSampleStatus.completed];

    return Container(
      height: (50 * scale).clamp(44.0, 54.0).toDouble(),
      padding: EdgeInsets.all(4 * scale),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18 * scale),
        border: Border.all(color: const Color(0xFFE1E7F0)),
      ),
      child: Row(
        children: [
          for (var i = 0; i < labels.length; i++)
            Expanded(
              child: GestureDetector(
                onTap: () => onChanged(values[i]),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: selected == values[i] ? const Color(0xFF0B6BD3) : Colors.transparent,
                    borderRadius: BorderRadius.circular(15 * scale),
                  ),
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      labels[i],
                      style: TextStyle(
                        color: selected == values[i] ? Colors.white : const Color(0xFF4B5563),
                        fontSize: 12.5 * scale,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _MobileDashboardMetricData {
  const _MobileDashboardMetricData({
    required this.title,
    required this.value,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.background,
  });

  final String title;
  final String value;
  final String subtitle;
  final IconData icon;
  final Color color;
  final Color background;
}

class _MobileDashboardMetricCard extends StatelessWidget {
  const _MobileDashboardMetricCard({required this.data});

  final _MobileDashboardMetricData data;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFE5E7EB)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.035),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(
                  color: data.background,
                  borderRadius: BorderRadius.circular(17),
                ),
                child: Icon(data.icon, color: data.color, size: 24),
              ),
              const Spacer(),
              Icon(Icons.more_horiz_rounded, color: data.color.withValues(alpha: 0.45)),
            ],
          ),
          const Spacer(),
          Text(
            data.title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w900,
              color: Color(0xFF111827),
              height: 1.15,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            data.value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: data.color,
              fontSize: 26,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.8,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            data.subtitle,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: Color(0xFF64748B),
              height: 1.2,
            ),
          ),
        ],
      ),
    );
  }
}

class _MobileStatusOverviewCard extends StatelessWidget {
  const _MobileStatusOverviewCard({
    required this.pending,
    required this.processing,
    required this.completed,
    required this.total,
  });

  final int pending;
  final int processing;
  final int completed;
  final int total;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: const Color(0xFFE5E7EB)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.035),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(
                  color: const Color(0xFFEFF6FF),
                  borderRadius: BorderRadius.circular(17),
                ),
                child: const Icon(Icons.fact_check_rounded, color: Color(0xFF0B57B7)),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text(
                  'Sample Status',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF111827),
                    letterSpacing: -0.3,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              _MobileStatusPill(label: 'Pending', value: pending, color: const Color(0xFFD97706), background: const Color(0xFFFFF7ED)),
              _MobileStatusPill(label: 'Processing', value: processing, color: const Color(0xFF2563EB), background: const Color(0xFFEFF6FF)),
              _MobileStatusPill(label: 'Completed', value: completed, color: const Color(0xFF059669), background: const Color(0xFFECFDF5)),
              _MobileStatusPill(label: 'Total', value: total, color: const Color(0xFF0B57B7), background: const Color(0xFFEFF6FF)),
            ],
          ),
        ],
      ),
    );
  }
}

class _MobileStatusPill extends StatelessWidget {
  const _MobileStatusPill({
    required this.label,
    required this.value,
    required this.color,
    required this.background,
  });

  final String label;
  final int value;
  final Color color;
  final Color background;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.25)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('$value', style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 15)),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF111827))),
        ],
      ),
    );
  }
}



class _TodayPendingTestsCard extends StatelessWidget {
  const _TodayPendingTestsCard({required this.counts});

  final Map<String, int> counts;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Pending Tests / Today',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 6),
            const Text('Shows only today pending tests, grouped as count / test name.'),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.45),
                border: Border.all(color: theme.colorScheme.outlineVariant),
              ),
              child: counts.isEmpty
                  ? Text(
                      'No pending tests today',
                      style: TextStyle(color: theme.colorScheme.outline),
                    )
                  : Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final entry in counts.entries)
                          Chip(
                            avatar: CircleAvatar(child: Text(entry.value.toString())),
                            label: Text('${entry.value} / ${entry.key}'),
                            visualDensity: VisualDensity.compact,
                          ),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.title,
    required this.value,
    required this.subtitle,
    required this.icon,
    required this.color,
  });

  final String title;
  final String value;
  final String subtitle;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final tight = width < 210;
        final veryTight = width < 170;
        final radius = veryTight ? 16.0 : 20.0;
        final padding = veryTight ? 8.0 : tight ? 10.0 : 12.0;
        final iconBox = veryTight ? 30.0 : tight ? 34.0 : 40.0;
        final iconSize = veryTight ? 17.0 : tight ? 20.0 : 23.0;
        final gap = veryTight ? 7.0 : 9.0;
        final titleSize = veryTight ? 11.0 : tight ? 12.0 : 14.0;
        final valueSize = veryTight ? 18.0 : tight ? 20.0 : 23.0;
        final subtitleSize = veryTight ? 9.0 : tight ? 10.0 : 11.0;

        return Card(
          elevation: 0,
          color: theme.colorScheme.surface.withValues(alpha: 0.92),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius)),
          child: Padding(
            padding: EdgeInsets.all(padding),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: iconBox,
                  height: iconBox,
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(veryTight ? 12 : 15),
                  ),
                  child: Icon(icon, color: color, size: iconSize),
                ),
                SizedBox(width: gap),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        maxLines: tight ? 2 : 1,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontSize: titleSize,
                          height: 1.12,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      SizedBox(height: veryTight ? 3 : 4),
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: Alignment.centerLeft,
                        child: Text(
                          value,
                          style: theme.textTheme.headlineSmall?.copyWith(
                            color: color,
                            fontSize: valueSize,
                            fontWeight: FontWeight.w900,
                            height: 1.0,
                          ),
                        ),
                      ),
                      SizedBox(height: veryTight ? 2 : 3),
                      Text(
                        subtitle,
                        maxLines: tight ? 2 : 1,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.bodySmall?.copyWith(
                          fontSize: subtitleSize,
                          height: 1.14,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _StatusOverviewCard extends StatelessWidget {
  const _StatusOverviewCard({
    required this.pending,
    required this.processing,
    required this.completed,
    required this.total,
  });

  final int pending;
  final int processing;
  final int completed;
  final int total;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Sample Status',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _CountPill(label: 'Pending', value: pending, color: Colors.orange),
                _CountPill(label: 'Processing', value: processing, color: Colors.blue),
                _CountPill(label: 'Completed', value: completed, color: Colors.green),
                _CountPill(label: 'Total', value: total, color: theme.colorScheme.primary),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.summary, required this.isStaff});

  final RevenueSummary summary;
  final bool isStaff;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isStaff ? 'Grouped Tests Summary' : 'Grouped Revenue and Profit Summary',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _CountPill(
                  label: 'Sub-centers',
                  value: summary.bySubCenter.length,
                  color: theme.colorScheme.primary,
                ),
                _CountPill(
                  label: 'Statuses',
                  value: summary.byStatus.length,
                  color: Colors.indigo,
                ),
                _CountPill(
                  label: 'Sub-center counts',
                  value: summary.countBySubCenter.length,
                  color: Colors.teal,
                ),
                _CountPill(
                  label: 'Status counts',
                  value: summary.countByStatus.length,
                  color: Colors.purple,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _CountPill extends StatelessWidget {
  const _CountPill({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final int value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: color.withValues(alpha: 0.12),
        border: Border.all(color: color.withValues(alpha: 0.22)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            '$value',
            style: TextStyle(color: color, fontWeight: FontWeight.w900),
          ),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}



class _StaffRegisterSampleCard extends ConsumerStatefulWidget {
  const _StaffRegisterSampleCard({
    required this.user,
    required this.tests,
    required this.pricings,
  });

  final AppUser user;
  final List<LabTest> tests;
  final List<SubCenterPricing> pricings;

  @override
  ConsumerState<_StaffRegisterSampleCard> createState() =>
      _StaffRegisterSampleCardState();
}

class _StaffRegisterSampleCardState extends ConsumerState<_StaffRegisterSampleCard> {
  final _formKey = GlobalKey<FormState>();
  final _patientNameController = TextEditingController();
  final _patientAgeController = TextEditingController();
  final _patientAddressController = TextEditingController();
  String? _selectedSex;
  final Set<String> _selectedTestKeys = <String>{};
  bool _saving = false;

  @override
  void dispose() {
    _patientNameController.dispose();
    _patientAgeController.dispose();
    _patientAddressController.dispose();
    super.dispose();
  }

  String get _subCenterId {
    final raw = widget.user.subCenterId?.trim() ?? '';
    return raw.isEmpty ? 'GLOBAL' : raw;
  }

  String _testKey(LabTest test) => test.id.trim().isNotEmpty ? test.id.trim() : test.testName.trim();

  String _normalize(String value) =>
      value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  String _sampleDatePrefix(DateTime createdAt) {
    final day = createdAt.day.toString().padLeft(2, '0');
    final month = createdAt.month.toString().padLeft(2, '0');
    final year = (createdAt.year % 100).toString().padLeft(2, '0');
    return '$day$month$year';
  }

  String _sampleIdFor(DateTime createdAt) {
    final sequence = (createdAt.microsecondsSinceEpoch % 10000)
        .toString()
        .padLeft(4, '0');
    return '${_sampleDatePrefix(createdAt)}-$sequence';
  }

  double _customerPriceFor(LabTest test) {
    final normalizedCenter = _normalize(_subCenterId);
    final normalizedTestId = _normalize(test.id);
    final normalizedTestName = _normalize(test.testName);

    for (final pricing in widget.pricings) {
      if (_normalize(pricing.subCenterId) != normalizedCenter) continue;
      final pricingTest = _normalize(pricing.testId);
      if (pricingTest == normalizedTestId || pricingTest == normalizedTestName) {
        return pricing.customPrice > 0 ? pricing.customPrice : test.defaultPrice;
      }
    }

    return test.defaultPrice;
  }

  double get _selectedTotalCost {
    return widget.tests
        .where((test) => _selectedTestKeys.contains(_testKey(test)))
        .fold<double>(0, (sum, test) => sum + _customerPriceFor(test));
  }


  Future<List<String>> _buildBloodSampleInsertRow(
    TursoNativeService service, {
    required String sampleId,
    required String patientName,
    required String patientAge,
    required String patientSex,
    required String patientAddress,
    required String status,
    required String testIds,
    required String registeredByUserId,
    required String subCenterId,
    required String resultUrl,
    required String createdAt,
    required String updatedAt,
  }) async {
    final desiredHeaders = <String>[
      'id',
      'patientName',
      'status',
      'testIds',
      'registeredByUserId',
      'subCenterId',
      'resultUrl',
      'createdAt',
      'updatedAt',
      'patientAge',
      'patientSex',
      'patientAddress',
    ];

    final rows = await service.fetchRows(
      range: 'BloodSamples!A1:Z1',
    );

    var displayHeaders = rows.isEmpty || rows.first.isEmpty
        ? <String>[]
        : rows.first.map((header) => header.trim()).where((header) => header.isNotEmpty).toList();

    if (displayHeaders.isEmpty) {
      displayHeaders = List<String>.from(desiredHeaders);
    } else {
      final normalized = displayHeaders
          .map((header) => header.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
          .toSet();
      for (final header in desiredHeaders) {
        final key = header.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
        if (!normalized.contains(key)) {
          displayHeaders.add(header);
          normalized.add(key);
        }
      }
    }

    await service.updateRow(
      range: 'BloodSamples!A1:Z1',
      values: displayHeaders,
    );

    final headerMap = <String, String>{
      'id': sampleId,
      'sampleid': sampleId,
      'patientname': patientName,
      'patient': patientName,
      'name': patientName,
      'patientage': patientAge,
      'age': patientAge,
      'patientsex': patientSex,
      'sex': patientSex,
      'gender': patientSex,
      'patientaddress': patientAddress,
      'address': patientAddress,
      'status': status,
      'testids': testIds,
      'tests': testIds,
      'registeredbyuserid': registeredByUserId,
      'registeredby': registeredByUserId,
      'subcenterid': subCenterId,
      'center': subCenterId,
      'subcenter': subCenterId,
      'resulturl': resultUrl,
      'result': resultUrl,
      'createdat': createdAt,
      'created': createdAt,
      'updatedat': updatedAt,
      'updated': updatedAt,
    };

    final headers = displayHeaders
        .map((header) => header.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();

    return [for (final header in headers) headerMap[header] ?? ''];
  }

  Future<void> _registerSample() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedTestKeys.isEmpty) {
      _showToast('Please select at least one test.', isError: true);
      return;
    }

    setState(() => _saving = true);
    TursoNativeService? service;
    try {
      final selectedTests = widget.tests
          .where((test) => _selectedTestKeys.contains(_testKey(test)))
          .toList();
      final now = DateTime.now();
      service = TursoNativeService(
        applicationName: 'flutterlab',
      );

      final timestamp = now.toUtc().toIso8601String();
      final rowValues = await _buildBloodSampleInsertRow(
        service,
        sampleId: _sampleIdFor(now),
        patientName: _patientNameController.text.trim(),
        patientAge: _patientAgeController.text.trim(),
        patientSex: _selectedSex ?? '',
        patientAddress: _patientAddressController.text.trim(),
        status: BloodSampleStatus.pending.name,
        testIds: selectedTests.map((test) => test.testName).join(', '),
        registeredByUserId: widget.user.id,
        subCenterId: _subCenterId,
        resultUrl: '',
        createdAt: timestamp,
        updatedAt: timestamp,
      );

      await service.insertRow(
        range: 'BloodSamples!A:Z',
        values: rowValues,
        valueInputOption: 'RAW',
      );

      _patientNameController.clear();
      _patientAgeController.clear();
      _patientAddressController.clear();
      _selectedSex = null;
      _selectedTestKeys.clear();
      ref.invalidate(sampleDashboardControllerProvider);
      _showToast('Blood sample registered successfully.');
      if (mounted) setState(() {});
    } catch (error) {
      _showToast('Register sample failed: $error', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  void _showToast(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    backgroundColor: theme.colorScheme.primaryContainer,
                    foregroundColor: theme.colorScheme.onPrimaryContainer,
                    child: const Icon(Icons.addchart_rounded),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Register Blood Sample',
                          style: theme.textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        Text('Sub-center: $_subCenterId • Select one or more test names'),
                      ],
                    ),
                  ),
                  _CountPill(
                    label: 'Selected cost',
                    value: _selectedTotalCost.round(),
                    color: theme.colorScheme.primary,
                  ),
                ],
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _patientNameController,
                enabled: !_saving,
                decoration: const InputDecoration(
                  labelText: 'Patient name',
                  prefixIcon: Icon(Icons.person_rounded),
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Enter patient name'
                    : null,
              ),
              const SizedBox(height: 12),
              LayoutBuilder(
                builder: (context, constraints) {
                  final compact = constraints.maxWidth < 720;
                  final ageField = TextFormField(
                    controller: _patientAgeController,
                    enabled: !_saving,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Age',
                      prefixIcon: Icon(Icons.cake_rounded),
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      final age = int.tryParse(value?.trim() ?? '');
                      if (age == null || age <= 0) return 'Enter valid age';
                      return null;
                    },
                  );
                  final sexField = DropdownButtonFormField<String>(
                    value: _selectedSex,
                    decoration: const InputDecoration(
                      labelText: 'Sex',
                      prefixIcon: Icon(Icons.wc_rounded),
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      DropdownMenuItem(value: 'Male', child: Text('Male')),
                      DropdownMenuItem(value: 'Female', child: Text('Female')),
                      DropdownMenuItem(value: 'Other', child: Text('Other')),
                    ],
                    onChanged: _saving ? null : (value) => setState(() => _selectedSex = value),
                    validator: (value) => value == null || value.trim().isEmpty
                        ? 'Select sex'
                        : null,
                  );

                  if (compact) {
                    return Column(
                      children: [ageField, const SizedBox(height: 12), sexField],
                    );
                  }
                  return Row(
                    children: [
                      Expanded(child: ageField),
                      const SizedBox(width: 12),
                      Expanded(child: sexField),
                    ],
                  );
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _patientAddressController,
                enabled: !_saving,
                minLines: 2,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Address',
                  prefixIcon: Icon(Icons.home_rounded),
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Enter patient address'
                    : null,
              ),
              const SizedBox(height: 16),
              if (widget.tests.isEmpty)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    color: theme.colorScheme.errorContainer,
                  ),
                  child: Text(
                    'No tests found. Please add tests in Global Pricing first.',
                    style: TextStyle(color: theme.colorScheme.onErrorContainer),
                  ),
                )
              else
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    for (final test in widget.tests)
                      FilterChip(
                        selected: _selectedTestKeys.contains(_testKey(test)),
                        label: Text(
                          '${test.testName} (${_customerPriceFor(test).toStringAsFixed(0)})',
                        ),
                        onSelected: _saving
                            ? null
                            : (selected) {
                                setState(() {
                                  final key = _testKey(test);
                                  if (selected) {
                                    _selectedTestKeys.add(key);
                                  } else {
                                    _selectedTestKeys.remove(key);
                                  }
                                });
                              },
                      ),
                  ],
                ),
              const SizedBox(height: 16),
              Align(
                alignment: Alignment.centerRight,
                child: FilledButton.icon(
                  onPressed: _saving || widget.tests.isEmpty ? null : _registerSample,
                  icon: _saving
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.save_rounded),
                  label: Text(_saving ? 'Registering...' : 'Register Sample'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SampleTable extends ConsumerStatefulWidget {
  const _SampleTable({
    required this.user,
    required this.samples,
    required this.tests,
    required this.pricings,
    this.mobileTopPadding = 0,
    this.mobileUseParentScroll = false,
  });

  final AppUser? user;
  final List<BloodSample> samples;
  final List<LabTest> tests;
  final List<SubCenterPricing> pricings;
  final double mobileTopPadding;
  final bool mobileUseParentScroll;

  @override
  ConsumerState<_SampleTable> createState() => _SampleTableState();
}

class _SampleTableState extends ConsumerState<_SampleTable> {
  String? _busySampleId;
  String? _busyMessage;
  double? _uploadProgress;
  final Set<String> _selectedSampleIds = <String>{};
  bool _printingSelected = false;
  BloodSampleStatus? _desktopStatusFilter;

  bool get _isBusy => _busySampleId != null || _printingSelected;

  OverlayEntry? _mobilePrintOverlayEntry;

  @override
  void dispose() {
    _removeMobilePrintOverlay();
    super.dispose();
  }

  void _scheduleMobilePrintOverlaySync() {
    WidgetsBinding.instance.addPostFrameCallback((_) => _syncMobilePrintOverlay());
  }

  void _syncMobilePrintOverlay() {
    if (!mounted) return;
    final shouldShow = MediaQuery.sizeOf(context).width < 760 && _selectedCompletedSamples.isNotEmpty;
    if (!shouldShow) {
      _removeMobilePrintOverlay();
      return;
    }
    if (_mobilePrintOverlayEntry == null) {
      _mobilePrintOverlayEntry = OverlayEntry(
        builder: (context) {
          final width = MediaQuery.sizeOf(context).width;
          final scale = (width / 390).clamp(0.78, 1.12).toDouble();
          final bottomOffset = MediaQuery.viewPaddingOf(context).bottom + 78;
          return Positioned(
            left: 14,
            right: 14,
            bottom: bottomOffset,
            child: Material(
              color: Colors.transparent,
              child: _mobileFloatingPrintBar(scale),
            ),
          );
        },
      );
      Overlay.of(context, rootOverlay: true).insert(_mobilePrintOverlayEntry!);
    } else {
      _mobilePrintOverlayEntry!.markNeedsBuild();
    }
  }

  void _removeMobilePrintOverlay() {
    _mobilePrintOverlayEntry?.remove();
    _mobilePrintOverlayEntry = null;
  }

  Widget _mobileFloatingPrintBar(double scale) {
    final selectedCompletedCount = _selectedCompletedSamples.length;
    if (selectedCompletedCount == 0) return const SizedBox.shrink();
    final buttonHeight = (40 * scale).clamp(36.0, 44.0).toDouble();
    final buttonFontSize = (14 * scale).clamp(12.0, 15.0).toDouble();
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 180),
      child: Container(
        key: ValueKey<int>(selectedCompletedCount),
        padding: EdgeInsets.symmetric(horizontal: (12 * scale).clamp(10.0, 14.0).toDouble(), vertical: (10 * scale).clamp(8.0, 11.0).toDouble()),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular((16 * scale).clamp(14.0, 18.0).toDouble()),
          border: Border.all(color: const Color(0xFFBFDBFE)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.14),
              blurRadius: 22,
              offset: const Offset(0, 9),
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                '$selectedCompletedCount selected',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: buttonFontSize, fontWeight: FontWeight.w900, color: const Color(0xFF111827)),
              ),
            ),
            TextButton(
              onPressed: _isBusy ? null : _clearPrintSelection,
              style: TextButton.styleFrom(
                foregroundColor: const Color(0xFF64748B),
                visualDensity: VisualDensity.compact,
                padding: EdgeInsets.symmetric(horizontal: (8 * scale).clamp(6.0, 10.0).toDouble()),
              ),
              child: Text('Clear', style: TextStyle(fontSize: (12 * scale).clamp(10.5, 13.0).toDouble(), fontWeight: FontWeight.w800)),
            ),
            SizedBox(width: (8 * scale).clamp(5.0, 10.0).toDouble()),
            SizedBox(
              height: buttonHeight,
              child: FilledButton.icon(
                onPressed: !_isBusy ? _printSelectedResults : null,
                icon: _printingSelected
                    ? SizedBox(width: (16 * scale).clamp(14.0, 17.0).toDouble(), height: (16 * scale).clamp(14.0, 17.0).toDouble(), child: const CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Icon(Icons.print_rounded, size: (17 * scale).clamp(14.0, 18.0).toDouble()),
                label: Text('Print', style: TextStyle(fontSize: buttonFontSize, fontWeight: FontWeight.w900)),
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF0B6BD3),
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(horizontal: (18 * scale).clamp(14.0, 22.0).toDouble()),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular((10 * scale).clamp(8.0, 12.0).toDouble())),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _setBusy(String sampleId, String message, {double? progress}) {
    if (!mounted) return;
    setState(() {
      _busySampleId = sampleId;
      _busyMessage = message;
      _uploadProgress = progress;
    });
  }

  void _clearBusy() {
    if (!mounted) return;
    setState(() {
      _busySampleId = null;
      _busyMessage = null;
      _uploadProgress = null;
    });
  }

  void _showToast(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
      ),
    );
  }

  void _toggleSampleSelection(BloodSample sample, bool selected) {
    if (sample.status != BloodSampleStatus.completed) return;
    setState(() {
      if (selected) {
        _selectedSampleIds.add(sample.id);
      } else {
        _selectedSampleIds.remove(sample.id);
      }
    });
    _scheduleMobilePrintOverlaySync();
  }

  void _selectAllCompletedVisible() {
    setState(() {
      _selectedSampleIds
        ..clear()
        ..addAll(widget.samples.where((sample) => sample.status == BloodSampleStatus.completed).map((sample) => sample.id));
    });
    _scheduleMobilePrintOverlaySync();
  }

  void _clearPrintSelection() {
    setState(_selectedSampleIds.clear);
    _scheduleMobilePrintOverlaySync();
  }

  List<BloodSample> get _selectedCompletedSamples {
    return widget.samples
        .where((sample) => sample.status == BloodSampleStatus.completed && _selectedSampleIds.contains(sample.id))
        .toList();
  }

  Future<List<Map<String, String>>> _fetchRowsAsMaps(TursoNativeService service, String range) async {
    final rows = await service.fetchRows(range: range);
    if (rows.length < 2) return const <Map<String, String>>[];
    final headers = rows.first.map((header) => header.trim()).toList();
    return [
      for (final row in rows.skip(1))
        <String, String>{
          for (var i = 0; i < headers.length; i++)
            (headers[i].isEmpty ? 'column$i' : headers[i]): i < row.length ? row[i].trim() : '',
        },
    ];
  }

  String _normalizedId(String value) => value.trim().toLowerCase();

  Map<String, String> _sampleInfoForHeader(BloodSample sample, List<Map<String, String>> sampleRows) {
    final sampleId = _normalizedId(sample.id);
    Map<String, String> matched = const <String, String>{};
    for (final row in sampleRows) {
      if (_normalizedId(row['id'] ?? row['sampleId'] ?? '') == sampleId) {
        matched = row;
        break;
      }
    }

    String pick(List<String> keys, String fallback) {
      for (final key in keys) {
        final value = matched[key]?.trim() ?? '';
        if (value.isNotEmpty) return value;
      }
      return fallback;
    }

    return <String, String>{
      'patientName': pick(['patientName', 'patient', 'name'], sample.patientName),
      'patientAge': pick(['patientAge', 'age'], ''),
      'patientSex': pick(['patientSex', 'sex', 'gender'], ''),
      'referDr': pick(['referDr', 'referDoctor', 'doctor'], ''),
      'referName': pick(['referredPersonName', 'referName', 'referrerName', 'referredName'], sample.referredPersonName ?? ''),
      'sampleId': sample.id,
      'runTime': pick(['runTime', 'updatedAt', 'createdAt', 'created'], sample.createdAt?.toIso8601String() ?? ''),
      'subCenterId': pick(['subCenterId', 'subcenter', 'center'], sample.subCenterId),
    };
  }

  Future<void> _printSingleResult(BloodSample sample) async {
    if (sample.status != BloodSampleStatus.completed) {
      _showToast('Only completed results can be printed.', isError: true);
      return;
    }
    await _printCompletedSamples(<BloodSample>[sample]);
  }

  Future<void> _printSelectedResults() async {
    final selected = _selectedCompletedSamples;
    if (selected.isEmpty) {
      _showToast('Select at least 1 completed result to print.', isError: true);
      return;
    }
    await _printCompletedSamples(selected);
  }

  Future<void> _printCompletedSamples(List<BloodSample> selected) async {
    setState(() => _printingSelected = true);
    TursoNativeService? service;
    try {
      service = TursoNativeService(
        applicationName: 'flutterlab',
      );
      final sampleRows = await _fetchRowsAsMaps(service, 'BloodSamples!A:Z');
      final manualRows = await _fetchRowsAsMaps(service, 'TestResults!A:Z');
      final cbcRows = await _fetchRowsAsMaps(service, 'CBCResults!A:BZ');
      final printable = selected.map((sample) {
        final sampleId = _normalizedId(sample.id);
        final manualMatches = manualRows.where((row) => _normalizedId(row['sampleId'] ?? '') == sampleId).toList();
        final cbcMatches = cbcRows.where((row) => _normalizedId(row['sampleId'] ?? '') == sampleId).toList();
        return _PrintableSampleResult(
          sample: sample,
          manualRows: manualMatches,
          cbcRow: cbcMatches.isEmpty ? null : cbcMatches.first,
        );
      }).toList();
      final headerSample = printable.first.sample;
      final headerInfo = _sampleInfoForHeader(headerSample, sampleRows);
      final headerSettings = await _fetchMultiPrintHeaderSettings(service, headerSample.subCenterId);
      final pdfName = printable.length == 1
          ? 'result_${printable.first.sample.id}.pdf'
          : 'selected_results_${DateTime.now().millisecondsSinceEpoch}.pdf';
      await Printing.layoutPdf(
        name: pdfName,
        onLayout: (format) => _buildSelectedResultsPdf(printable, format, headerSettings, headerInfo),
      );
    } catch (error) {
      _showToast('Print failed: $error', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _printingSelected = false);
      _scheduleMobilePrintOverlaySync();
    }
  }

  Future<Uint8List> _buildSelectedResultsPdf(
    List<_PrintableSampleResult> results,
    PdfPageFormat format,
    _MultiPrintHeaderSettings headerSettings,
    Map<String, String> headerInfo,
  ) async {
    final regularFont = pw.Font.ttf(await rootBundle.load('assets/fonts/DejaVuSans.ttf'));
    final boldFont = pw.Font.ttf(await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf'));
    final pdf = pw.Document(theme: pw.ThemeData.withFont(base: regularFont, bold: boldFont));
    final mohLogo = pw.MemoryImage((await rootBundle.load('assets/images/moh.png')).buffer.asUint8List());
    final generatedAt = DateTime.now().toLocal().toString().split('.').first;
    final headerSample = results.first.sample;
    final resultRows = _selectedResultRows(results);

    pdf.addPage(
      pw.MultiPage(
        pageFormat: format,
        margin: const pw.EdgeInsets.fromLTRB(28, 28, 28, 28),
        footer: (context) => _multiPrintFooter(headerSettings),
        build: (context) => [
          _multiPrintCustomHeader(
            settings: headerSettings,
            sample: headerSample,
            sampleInfo: headerInfo,
            generatedAt: generatedAt,
            mohLogo: mohLogo,
          ),
          pw.SizedBox(height: 10),
          _selectedResultsTable(resultRows),
        ],
      ),
    );
    return pdf.save();
  }

  Future<_MultiPrintHeaderSettings> _fetchMultiPrintHeaderSettings(TursoNativeService service, String subCenterId) async {
    final defaults = _MultiPrintHeaderSettings.defaults(subCenterId: subCenterId);
    try {
      await service.ensureSheet(sheetName: 'ReportHeaderSettings');
      final rows = await service.fetchRows(range: 'ReportHeaderSettings!A:K');
      if (rows.length < 2) return defaults;
      final headers = rows.first.map((header) => _normalizeHeaderKey(header)).toList();
      Map<String, String>? global;
      Map<String, String>? matchedCenter;
      for (final row in rows.skip(1)) {
        final map = <String, String>{};
        for (var i = 0; i < headers.length; i++) {
          map[headers[i]] = i < row.length ? row[i].trim() : '';
        }
        final scope = _normalizeHeaderKey(map['scopetype'] ?? '');
        final center = _normalizeHeaderKey(map['subcenterid'] ?? '');
        if (scope == 'global' || center == 'global') global ??= map;
        if (subCenterId.trim().isNotEmpty && center == _normalizeHeaderKey(subCenterId)) matchedCenter = map;
      }
      final globalSettings = global == null ? defaults : _MultiPrintHeaderSettings.fromMap(global, fallback: defaults);
      return matchedCenter == null ? globalSettings : _MultiPrintHeaderSettings.fromMap(matchedCenter, fallback: globalSettings);
    } catch (_) {
      return defaults;
    }
  }

  String _normalizeHeaderKey(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  pw.Widget _multiPrintCustomHeader({
    required _MultiPrintHeaderSettings settings,
    required BloodSample sample,
    required Map<String, String> sampleInfo,
    required String generatedAt,
    required pw.MemoryImage mohLogo,
  }) {
    final accent = _pdfColorFromHex(settings.accentColor);
    final runTime = _formatMultiPrintDateTime(sampleInfo['runTime'] ?? '');
    String info(String key, String fallback) {
      final value = sampleInfo[key]?.trim() ?? '';
      return value.isEmpty ? fallback : value;
    }

    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.stretch,
      children: [
        pw.Container(
          padding: const pw.EdgeInsets.all(10),
          decoration: pw.BoxDecoration(
            border: pw.Border.all(color: PdfColor(0.576, 0.773, 0.992), width: 0.6),
            borderRadius: pw.BorderRadius.circular(8),
            color: PdfColor(0.937, 0.965, 1.0),
          ),
          child: pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.center,
            children: [
              pw.Container(
                width: 42,
                height: 42,
                padding: const pw.EdgeInsets.all(3),
                decoration: pw.BoxDecoration(
                  shape: pw.BoxShape.circle,
                  border: pw.Border.all(color: accent, width: 1.1),
                  color: PdfColors.white,
                ),
                child: pw.ClipOval(
                  child: pw.Image(mohLogo, fit: pw.BoxFit.contain),
                ),
              ),
              pw.SizedBox(width: 9),
              pw.Container(width: 0.8, height: 42, color: PdfColor(0.576, 0.773, 0.992)),
              pw.SizedBox(width: 9),
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text(settings.hospitalName.toUpperCase(), style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold, color: PdfColors.grey900)),
                    pw.SizedBox(height: 2),
                    pw.Text(settings.departmentName, style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold, color: accent)),
                    pw.Text(settings.township, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
                    pw.Text(settings.ministryName, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
                  ],
                ),
              ),
              pw.Container(
                padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: pw.BoxDecoration(color: accent, borderRadius: pw.BorderRadius.circular(12)),
                child: pw.Text(settings.reportTitle, style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold, color: PdfColors.white)),
              ),
            ],
          ),
        ),
        pw.SizedBox(height: 7),
        pw.Container(
          padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 7),
          decoration: pw.BoxDecoration(
            border: pw.Border.all(color: PdfColors.grey600, width: 0.6),
            color: PdfColors.grey100,
          ),
          child: pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Expanded(child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                _pdfInfoLine('Name', info('patientName', sample.patientName)),
                _pdfInfoLine('Gender', info('patientSex', '')),
              ])),
              pw.Expanded(child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                _pdfInfoLine('Age', info('patientAge', '')),
                _pdfInfoLine('Refer', info('referName', sample.referredPersonName ?? '')),
              ])),
              pw.Expanded(child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                _pdfInfoLine('Sample ID', info('sampleId', sample.id)),
                _pdfInfoLine('Run Time', runTime.isEmpty ? generatedAt : runTime),
              ])),
            ],
          ),
        ),
        pw.SizedBox(height: 6),
        pw.Container(height: 0.7, color: PdfColors.grey700),
      ],
    );
  }

  pw.Widget _multiPrintFooter(_MultiPrintHeaderSettings settings) {
    final footer = settings.footerText.trim();
    final center = settings.subCenterId.trim().toLowerCase();
    if (footer.isEmpty || center.isEmpty || center == 'global') return pw.SizedBox.shrink();
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.only(top: 6),
      decoration: const pw.BoxDecoration(border: pw.Border(top: pw.BorderSide(color: PdfColors.grey400, width: 0.4))),
      child: pw.Text(
        footer,
        textAlign: pw.TextAlign.center,
        style: const pw.TextStyle(fontSize: 7.5, color: PdfColors.grey700),
      ),
    );
  }

  String _formatMultiPrintDateTime(String value) {
    final raw = value.trim();
    if (raw.isEmpty) return '';
    final parsed = DateTime.tryParse(raw);
    if (parsed == null) return raw;
    final local = parsed.toLocal();
    final year = local.year.toString().padLeft(4, '0');
    final month = local.month.toString().padLeft(2, '0');
    final day = local.day.toString().padLeft(2, '0');
    final hour = local.hour.toString().padLeft(2, '0');
    final minute = local.minute.toString().padLeft(2, '0');
    return '$year-$month-$day $hour:$minute';
  }

  PdfColor _pdfColorFromHex(String raw) {
    final cleaned = raw.trim().replaceAll('#', '');
    if (!RegExp(r'^[0-9a-fA-F]{6}$').hasMatch(cleaned)) return PdfColor(0.114, 0.306, 0.847);
    final value = int.parse(cleaned, radix: 16);
    return PdfColor(((value >> 16) & 0xFF) / 255.0, ((value >> 8) & 0xFF) / 255.0, (value & 0xFF) / 255.0);
  }

  List<_PrintableResultRow> _selectedResultRows(List<_PrintableSampleResult> results) {
    return [
      for (final result in results) ..._rowsForPrintableSample(result),
    ];
  }

  List<_PrintableResultRow> _rowsForPrintableSample(_PrintableSampleResult result) {
    if (result.cbcRow != null) return _cbcPrintableRows(result);
    if (result.manualRows.isNotEmpty) return _manualPrintableRows(result);
    return [
      _PrintableResultRow(
        sampleId: result.sample.id,
        patientName: result.sample.patientName,
        testName: result.sample.testIds.join(', '),
        parameter: 'Result',
        result: 'No generated result rows found',
        unit: '',
        referenceRange: '',
        notes: '',
      ),
    ];
  }

  List<_PrintableResultRow> _cbcPrintableRows(_PrintableSampleResult printable) {
    final row = printable.cbcRow!;
    final testName = row['testName']?.trim().isNotEmpty == true ? row['testName']!.trim() : 'CBC / CP(Auto)';
    const fields = <_CbcPrintParameterDef>[
      _CbcPrintParameterDef('WBC', 'WBC', '3.50-9.50', '10^3/uL'),
      _CbcPrintParameterDef('Neu%', 'NeuPercent', '40.0-75.0', '%'),
      _CbcPrintParameterDef('Lym%', 'LymPercent', '20.0-50.0', '%'),
      _CbcPrintParameterDef('Mon%', 'MonPercent', '3.0-10.0', '%'),
      _CbcPrintParameterDef('Eos%', 'EosPercent', '0.4-8.0', '%'),
      _CbcPrintParameterDef('Bas%', 'BasPercent', '0.0-1.0', '%'),
      _CbcPrintParameterDef('Neu#', 'NeuCount', '1.80-6.30', '10^3/uL'),
      _CbcPrintParameterDef('Lym#', 'LymCount', '1.10-3.20', '10^3/uL'),
      _CbcPrintParameterDef('Mon#', 'MonCount', '0.10-0.60', '10^3/uL'),
      _CbcPrintParameterDef('Eos#', 'EosCount', '0.02-0.52', '10^3/uL'),
      _CbcPrintParameterDef('Bas#', 'BasCount', '0.00-0.06', '10^3/uL'),
      _CbcPrintParameterDef('ALY#', 'ALYCount', '0.00-0.20', '10^3/uL'),
      _CbcPrintParameterDef('ALY%', 'ALYPercent', '0.0-2.0', '%'),
      _CbcPrintParameterDef('LIC#', 'LICCount', '0.00-0.20', '10^3/uL'),
      _CbcPrintParameterDef('LIC%', 'LICPercent', '0.0-2.5', '%'),
      _CbcPrintParameterDef('NRBC#', 'NRBCCount', '0.000-9999.999', '10^9/L'),
      _CbcPrintParameterDef('NRBC%', 'NRBCPercent', '0.00-9999.99', '%'),
      _CbcPrintParameterDef('RBC', 'RBC', '3.80-5.80', '10^6/uL'),
      _CbcPrintParameterDef('HGB', 'HGB', '11.5-17.5', 'g/dL'),
      _CbcPrintParameterDef('HCT', 'HCT', '35.0-50.0', '%'),
      _CbcPrintParameterDef('MCV', 'MCV', '82.0-100.0', 'fL'),
      _CbcPrintParameterDef('MCH', 'MCH', '27.0-34.0', 'pg'),
      _CbcPrintParameterDef('MCHC', 'MCHC', '31.6-35.4', 'g/dL'),
      _CbcPrintParameterDef('RDW-CV', 'RDWCV', '11.0-16.0', '%'),
      _CbcPrintParameterDef('RDW-SD', 'RDWSD', '35.0-56.0', 'fL'),
      _CbcPrintParameterDef('PLT', 'PLT', '125-350', '10^3/uL'),
      _CbcPrintParameterDef('MPV', 'MPV', '6.5-12.0', 'fL'),
      _CbcPrintParameterDef('PDW', 'PDW', '9.0-17.0', 'fL'),
      _CbcPrintParameterDef('PCT', 'PCT', '0.108-0.282', '%'),
      _CbcPrintParameterDef('P-LCR', 'PLCR', '11.0-45.0', '%'),
      _CbcPrintParameterDef('P-LCC', 'PLCC', '30-90', '10^9/L'),
    ];
    return [
      for (final field in fields)
        _PrintableResultRow(
          sampleId: printable.sample.id,
          patientName: printable.sample.patientName,
          testName: testName,
          parameter: field.parameter,
          result: row[field.key]?.trim() ?? '',
          unit: field.unit,
          referenceRange: field.referenceRange,
          notes: '',
        ),
    ];
  }

  List<_PrintableResultRow> _manualPrintableRows(_PrintableSampleResult printable) {
    return printable.manualRows.map((row) {
      final parameter = (row['parameter'] ?? '').trim().isEmpty ? (row['testName'] ?? 'Result') : row['parameter']!;
      return _PrintableResultRow(
        sampleId: printable.sample.id,
        patientName: printable.sample.patientName,
        testName: row['testName'] ?? printable.sample.testIds.join(', '),
        parameter: parameter,
        result: row['resultValue'] ?? '',
        unit: row['unit'] ?? '',
        referenceRange: row['referenceRange'] ?? '',
        notes: row['notes'] ?? '',
      );
    }).toList();
  }

  pw.Widget _selectedResultsTable(List<_PrintableResultRow> rows) {
    if (rows.isEmpty) {
      return pw.Text('No result rows found for the selected samples.', style: const pw.TextStyle(fontSize: 9));
    }
    final qualitativeOnly = rows.every(_isQualitativePrintableRow);
    final remarks = rows
        .map((row) => row.notes.trim())
        .where((note) => note.isNotEmpty)
        .toSet()
        .join('\n');
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.stretch,
      children: [
        pw.Table(
          border: const pw.TableBorder(
            top: pw.BorderSide(color: PdfColors.grey700, width: 0.5),
            bottom: pw.BorderSide(color: PdfColors.grey700, width: 0.5),
            horizontalInside: pw.BorderSide(color: PdfColors.grey300, width: 0.25),
          ),
          columnWidths: qualitativeOnly
              ? const <int, pw.TableColumnWidth>{
                  0: pw.FixedColumnWidth(20),
                  1: pw.FlexColumnWidth(1.6),
                  2: pw.FlexColumnWidth(1.0),
                }
              : const <int, pw.TableColumnWidth>{
                  0: pw.FixedColumnWidth(20),
                  1: pw.FlexColumnWidth(1.55),
                  2: pw.FlexColumnWidth(1.05),
                  3: pw.FlexColumnWidth(1.28),
                  4: pw.FlexColumnWidth(0.95),
                },
          children: [
            pw.TableRow(
              decoration: const pw.BoxDecoration(color: PdfColors.grey200),
              children: qualitativeOnly
                  ? [_resultTableCell('', bold: true), _resultTableCell('Test', bold: true), _resultTableCell('Result', bold: true)]
                  : [_resultTableCell('', bold: true), _resultTableCell('Parameter', bold: true), _resultTableCell('Result', bold: true), _resultTableCell('Ref. Range', bold: true), _resultTableCell('Unit', bold: true)],
            ),
            for (var index = 0; index < rows.length; index++)
              pw.TableRow(
                children: qualitativeOnly
                    ? [
                        _resultTableCell('${index + 1}', align: pw.TextAlign.right),
                        _resultTableCell(rows[index].parameter, bold: true),
                        _resultTableCell(rows[index].result, bold: true, color: _qualitativeResultColor(rows[index].result)),
                      ]
                    : [
                        _resultTableCell('${index + 1}', align: pw.TextAlign.right),
                        _resultTableCell(rows[index].parameter, bold: true),
                        _resultValueTableCell(rows[index].result, rows[index].referenceRange),
                        _resultTableCell(rows[index].referenceRange),
                        _resultTableCell(rows[index].unit),
                      ],
              ),
          ],
        ),
        pw.SizedBox(height: 10),
        pw.Container(
          width: double.infinity,
          padding: const pw.EdgeInsets.all(8),
          decoration: pw.BoxDecoration(
            border: pw.Border.all(color: PdfColors.grey600, width: 0.7),
            color: PdfColors.grey100,
          ),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('Remarks', style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 4),
              pw.Text(remarks.isEmpty ? '-' : remarks, style: const pw.TextStyle(fontSize: 8)),
            ],
          ),
        ),
      ],
    );
  }

  pw.Widget _resultValueTableCell(String value, String referenceRange) {
    final raw = value.trim();
    final qualitativeColor = _qualitativeResultColor(raw);
    if (qualitativeColor != null) {
      return _resultTableCell(raw.isEmpty ? '-' : raw, bold: true, color: qualitativeColor);
    }
    final status = _printRangeStatus(raw, referenceRange);
    final suffix = status > 0 ? '↑' : status < 0 ? '↓' : '';
    final color = status > 0
        ? PdfColors.red700
        : status < 0
            ? PdfColors.lightBlue400
            : PdfColors.grey900;
    return _resultTableCell(raw.isEmpty ? '-' : '$raw$suffix', bold: true, color: color);
  }

  PdfColor? _qualitativeResultColor(String value) {
    final normalized = value.trim().toLowerCase();
    if (normalized == 'positive') return PdfColors.red700;
    if (normalized == 'negative') return PdfColors.blue700;
    return null;
  }

  int _printRangeStatus(String result, String referenceRange) {
    final raw = result.trim();
    if (raw.isEmpty) return 0;
    final numberMatch = RegExp(r'-?\d+(?:\.\d+)?').firstMatch(raw.replaceAll(',', ''));
    if (numberMatch == null) return 0;
    final value = double.tryParse(numberMatch.group(0) ?? '');
    final rangeMatch = RegExp(r'(-?\d+(?:\.\d+)?)\s*-\s*(-?\d+(?:\.\d+)?)').firstMatch(referenceRange.replaceAll(',', ''));
    if (value == null || rangeMatch == null) return 0;
    final low = double.tryParse(rangeMatch.group(1) ?? '');
    final high = double.tryParse(rangeMatch.group(2) ?? '');
    if (low == null || high == null) return 0;
    if (value < low) return -1;
    if (value > high) return 1;
    return 0;
  }

  pw.Widget _resultTableCell(String value, {bool bold = false, pw.TextAlign align = pw.TextAlign.left, PdfColor? color}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 3, horizontal: 3),
      child: pw.Text(
        value.trim().isEmpty ? '-' : value.trim(),
        textAlign: align,
        style: pw.TextStyle(fontSize: 7.2, color: color ?? PdfColors.grey900, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal),
      ),
    );
  }

  pw.Widget _pdfInfoLine(String label, String value) {
    return pw.RichText(
      text: pw.TextSpan(
        children: [
          pw.TextSpan(text: '$label: ', style: pw.TextStyle(fontSize: 7.5, fontWeight: pw.FontWeight.bold)),
          pw.TextSpan(text: value.trim().isEmpty ? '-' : value.trim(), style: const pw.TextStyle(fontSize: 7.5)),
        ],
      ),
    );
  }

  pw.Widget _cbcSummaryTable(Map<String, String> row) {
    final items = <List<String>>[
      ['WBC', row['WBC'] ?? '', '10^9/L'],
      ['RBC', row['RBC'] ?? '', '10^12/L'],
      ['HGB', row['HGB'] ?? '', 'g/dL'],
      ['HCT', row['HCT'] ?? '', '%'],
      ['PLT', row['PLT'] ?? '', '10^9/L'],
    ].where((item) => item[1].trim().isNotEmpty).toList();
    return _miniResultTable(
      title: row['testName']?.trim().isNotEmpty == true ? row['testName']!.trim() : 'CBC / CP(Auto)',
      rows: items.isEmpty ? const <List<String>>[['CBC / CP(Auto)', 'Saved', '']] : items,
    );
  }

  pw.Widget _manualSummaryTable(List<Map<String, String>> rows) {
    if (rows.isEmpty) return pw.SizedBox.shrink();
    final qualitativeOnly = rows.every((row) => (row['unit'] ?? '').trim().isEmpty && (row['referenceRange'] ?? '').trim().isEmpty);
    final items = rows.map((row) {
      final parameter = (row['parameter'] ?? '').trim().isEmpty ? (row['testName'] ?? 'Result') : row['parameter']!;
      final value = row['resultValue'] ?? '';
      final unit = row['unit'] ?? '';
      return qualitativeOnly ? [parameter, value] : [parameter, value, unit];
    }).toList();
    return _miniResultTable(title: rows.first['testName'] ?? 'Manual result', rows: items, qualitativeOnly: qualitativeOnly);
  }

  pw.Widget _miniResultTable({required String title, required List<List<String>> rows, bool qualitativeOnly = false}) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.stretch,
      children: [
        pw.Container(
          padding: const pw.EdgeInsets.symmetric(vertical: 3, horizontal: 4),
          color: PdfColors.grey300,
          child: pw.Text(title.trim().isEmpty ? 'Result' : title.trim(), style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold)),
        ),
        pw.Table(
          border: pw.TableBorder.all(color: PdfColors.grey500, width: 0.4),
          columnWidths: qualitativeOnly ? const <int, pw.TableColumnWidth>{0: pw.FlexColumnWidth(1.3), 1: pw.FlexColumnWidth(1)} : const <int, pw.TableColumnWidth>{0: pw.FlexColumnWidth(1.3), 1: pw.FlexColumnWidth(1), 2: pw.FlexColumnWidth(0.8)},
          children: [
            pw.TableRow(
              decoration: const pw.BoxDecoration(color: PdfColors.grey200),
              children: qualitativeOnly ? [_cell('Test', bold: true), _cell('Result', bold: true)] : [_cell('Parameter', bold: true), _cell('Result', bold: true), _cell('Unit', bold: true)],
            ),
            for (final row in rows)
              pw.TableRow(children: qualitativeOnly ? [_cell(row[0]), _cell(row[1])] : [_cell(row[0]), _cell(row[1]), _cell(row[2])]),
          ],
        ),
      ],
    );
  }

  pw.Widget _cell(String value, {bool bold = false}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 2.5, horizontal: 3),
      child: pw.Text(value.trim().isEmpty ? '-' : value.trim(), style: pw.TextStyle(fontSize: 7, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
    );
  }

  String _mobileDateLabel(BloodSample sample) {
    return sample.createdAt != null ? sample.createdAt!.toLocal().toString().split(' ').first : '-';
  }

  String _normalizeMobileValue(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  LabTest _mobileTestFor(String testText) {
    final normalized = _normalizeMobileValue(testText);
    for (final test in widget.tests) {
      if (_normalizeMobileValue(test.id) == normalized || _normalizeMobileValue(test.testName) == normalized) return test;
    }
    return LabTest(id: testText, testName: testText, defaultPrice: 0);
  }

  SubCenterPricing? _mobilePricingFor(BloodSample sample, String testText) {
    final test = _mobileTestFor(testText);
    final center = _normalizeMobileValue(sample.subCenterId);
    final testId = _normalizeMobileValue(test.id);
    final testName = _normalizeMobileValue(test.testName);
    final original = _normalizeMobileValue(testText);
    for (final pricing in widget.pricings) {
      final pricingTest = _normalizeMobileValue(pricing.testId);
      if (_normalizeMobileValue(pricing.subCenterId) == center && (pricingTest == testId || pricingTest == testName || pricingTest == original)) return pricing;
    }
    return null;
  }

  double _mobileCustomerPrice(BloodSample sample, String testText) {
    final test = _mobileTestFor(testText);
    final pricing = _mobilePricingFor(sample, testText);
    return pricing != null && pricing.customPrice > 0 ? pricing.customPrice : test.defaultPrice;
  }

  double _mobileSampleTotal(BloodSample sample) => sample.testIds.fold<double>(0, (sum, test) => sum + _mobileCustomerPrice(sample, test));

  double _mobileReferFee(BloodSample sample) {
    final id = _normalizeMobileValue(sample.referredPersonId ?? '');
    final name = _normalizeMobileValue(sample.referredPersonName ?? '');
    if (id.isEmpty || id == 'self' || name == 'self') return 0;
    if (sample.referredFeeAmount > 0) return sample.referredFeeAmount;
    return sample.testIds.fold<double>(0, (sum, test) {
      final percent = _mobilePricingFor(sample, test)?.referredFeePercent ?? 0;
      return sum + (_mobileCustomerPrice(sample, test) * percent / 100);
    });
  }

  Color _mobileStatusColor(BloodSampleStatus status) {
    switch (status) {
      case BloodSampleStatus.completed:
        return const Color(0xFF16A34A);
      case BloodSampleStatus.processing:
        return const Color(0xFF0B6BD3);
      case BloodSampleStatus.pending:
        return const Color(0xFFF59E0B);
      case BloodSampleStatus.canceled:
        return const Color(0xFF64748B);
    }
  }

  String _mobileStatusLabel(BloodSampleStatus status) {
    final raw = status.name;
    return raw[0].toUpperCase() + raw.substring(1);
  }

  String _mobileTimeLabel(BloodSample sample) {
    final value = sample.updatedAt ?? sample.createdAt;
    if (value == null) return '';
    final local = value.toLocal();
    final now = DateTime.now();
    final date = DateTime(local.year, local.month, local.day);
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final dayLabel = date == today ? 'Today' : date == yesterday ? 'Yesterday' : _mobileDateLabel(sample);
    final hour = local.hour == 0 ? 12 : local.hour > 12 ? local.hour - 12 : local.hour;
    final minute = local.minute.toString().padLeft(2, '0');
    final period = local.hour >= 12 ? 'PM' : 'AM';
    return '$dayLabel, ${hour.toString().padLeft(2, '0')}:$minute $period';
  }

  Widget _buildMobileSampleCards({required bool isLabTech, required bool isAdmin, required bool isStaff}) {
    final selectedCompletedCount = _selectedCompletedSamples.length;
    final width = MediaQuery.sizeOf(context).width;
    final scale = (width / 390).clamp(0.78, 1.12).toDouble();
    final cardRadius = (13 * scale).clamp(10.0, 16.0).toDouble();
    final cardPaddingH = (14 * scale).clamp(10.0, 16.0).toDouble();
    final cardPaddingV = (12 * scale).clamp(9.0, 14.0).toDouble();
    final buttonHeight = (37 * scale).clamp(34.0, 40.0).toDouble();
    final buttonFontSize = (13 * scale).clamp(11.0, 14.0).toDouble();
    final buttonHPadding = (12 * scale).clamp(9.0, 13.0).toDouble();
    final canUsePrintActions = true;

    if (widget.samples.isEmpty) {
      return Container(
        width: double.infinity,
        padding: EdgeInsets.all((18 * scale).clamp(14.0, 20.0).toDouble()),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular((18 * scale).clamp(14.0, 20.0).toDouble()),
          color: Colors.white,
          border: Border.all(color: const Color(0xFFE5EAF3)),
        ),
        child: Text(
          'No sample records in this view.',
          textAlign: TextAlign.center,
          style: TextStyle(color: const Color(0xFF64748B), fontSize: (14 * scale).clamp(12.0, 15.0).toDouble(), fontWeight: FontWeight.w700),
        ),
      );
    }


    Widget buildCard(BloodSample sample) {
      final canPrintSample = sample.status == BloodSampleStatus.completed;
      final isSelectedForPrint = _selectedSampleIds.contains(sample.id);
      final testsLabel = sample.testIds.join(', ');
      final referFee = _mobileReferFee(sample);
      final statusColor = _mobileStatusColor(sample.status);
      final subCenterLabel = sample.subCenterId.trim().isEmpty ? 'GLOBAL' : sample.subCenterId.trim();
      final canCancelPending = _canCancelPendingSample(sample);
      final canDeleteBloodSample = _canDeleteBloodSample(sample);

      Widget statusChip() {
        return Container(
          padding: EdgeInsets.symmetric(horizontal: (10 * scale).clamp(8.0, 11.0).toDouble(), vertical: (5 * scale).clamp(4.0, 6.0).toDouble()),
          decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(999)),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: (8 * scale).clamp(6.0, 9.0).toDouble(), height: (8 * scale).clamp(6.0, 9.0).toDouble(), decoration: BoxDecoration(color: statusColor, shape: BoxShape.circle)),
              SizedBox(width: (7 * scale).clamp(5.0, 8.0).toDouble()),
              Text(
                _mobileStatusLabel(sample.status),
                style: TextStyle(color: statusColor, fontSize: (12.5 * scale).clamp(10.5, 13.5).toDouble(), fontWeight: FontWeight.w900),
              ),
            ],
          ),
        );
      }

      Widget labTechReviewButton() {
        return SizedBox(
          height: buttonHeight,
          child: FilledButton.icon(
            onPressed: _isBusy || sample.status == BloodSampleStatus.canceled ? null : () => _reviewSample(sample),
            icon: _busySampleId == sample.id
                ? SizedBox(width: (16 * scale).clamp(14.0, 17.0).toDouble(), height: (16 * scale).clamp(14.0, 17.0).toDouble(), child: const CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : Icon(Icons.fact_check_rounded, size: (16 * scale).clamp(14.0, 17.0).toDouble()),
            label: Text('Review', style: TextStyle(fontSize: buttonFontSize, fontWeight: FontWeight.w800)),
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFF0B6BD3),
              foregroundColor: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: buttonHPadding),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular((9 * scale).clamp(7.0, 10.0).toDouble())),
            ),
          ),
        );
      }

      Widget userActionButtons() {
        return Wrap(
          alignment: WrapAlignment.end,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: (7 * scale).clamp(5.0, 8.0).toDouble(),
          runSpacing: (7 * scale).clamp(5.0, 8.0).toDouble(),
          children: [
            SizedBox(
              height: buttonHeight,
              child: OutlinedButton.icon(
                onPressed: _isBusy ? null : () => context.go('/sample-result/${Uri.encodeComponent(sample.id)}'),
                icon: Icon(Icons.visibility_rounded, size: (17 * scale).clamp(14.0, 18.0).toDouble()),
                label: Text('View', style: TextStyle(fontSize: buttonFontSize, fontWeight: FontWeight.w800)),
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFF0B6BD3),
                  side: const BorderSide(color: Color(0xFF0B6BD3)),
                  padding: EdgeInsets.symmetric(horizontal: buttonHPadding),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular((9 * scale).clamp(7.0, 10.0).toDouble())),
                ),
              ),
            ),
            SizedBox(
              height: buttonHeight,
              child: OutlinedButton.icon(
                onPressed: canPrintSample && !_isBusy ? () => _printSingleResult(sample) : null,
                icon: Icon(Icons.print_rounded, size: (17 * scale).clamp(14.0, 18.0).toDouble()),
                label: Text('Print', style: TextStyle(fontSize: buttonFontSize, fontWeight: FontWeight.w800)),
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFF0B6BD3),
                  side: const BorderSide(color: Color(0xFF0B6BD3)),
                  padding: EdgeInsets.symmetric(horizontal: buttonHPadding),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular((9 * scale).clamp(7.0, 10.0).toDouble())),
                ),
              ),
            ),
            if (canCancelPending)
              SizedBox(
                height: buttonHeight,
                child: OutlinedButton.icon(
                  onPressed: _isBusy ? null : () => _cancelPendingSample(sample),
                  icon: Icon(Icons.cancel_outlined, size: (17 * scale).clamp(14.0, 18.0).toDouble()),
                  label: Text('Cancel', style: TextStyle(fontSize: buttonFontSize, fontWeight: FontWeight.w800)),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFFDC2626),
                    side: const BorderSide(color: Color(0xFFDC2626)),
                    padding: EdgeInsets.symmetric(horizontal: buttonHPadding),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular((9 * scale).clamp(7.0, 10.0).toDouble())),
                  ),
                ),
              ),
            if (canDeleteBloodSample)
              SizedBox(
                height: buttonHeight,
                child: OutlinedButton.icon(
                  onPressed: _isBusy ? null : () => _deleteBloodSample(sample),
                  icon: Icon(Icons.delete_outline_rounded, size: (17 * scale).clamp(14.0, 18.0).toDouble()),
                  label: Text('Delete', style: TextStyle(fontSize: buttonFontSize, fontWeight: FontWeight.w800)),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF991B1B),
                    side: const BorderSide(color: Color(0xFF991B1B)),
                    padding: EdgeInsets.symmetric(horizontal: buttonHPadding),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular((9 * scale).clamp(7.0, 10.0).toDouble())),
                  ),
                ),
              ),
            if (canPrintSample)
              FilterChip(
                visualDensity: VisualDensity.compact,
                selected: isSelectedForPrint,
                avatar: Icon(isSelectedForPrint ? Icons.check_circle_rounded : Icons.check_circle_outline_rounded, size: (16 * scale).clamp(14.0, 17.0).toDouble()),
                label: Text(isSelectedForPrint ? 'Selected' : 'Select', style: TextStyle(fontSize: (12 * scale).clamp(10.5, 13.0).toDouble(), fontWeight: FontWeight.w700)),
                onSelected: _isBusy ? null : (selected) => _toggleSampleSelection(sample, selected),
              ),
          ],
        );
      }

      Widget actionButtons() {
        if (!isLabTech) return userActionButtons();
        return Wrap(
          alignment: WrapAlignment.end,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: (7 * scale).clamp(5.0, 8.0).toDouble(),
          runSpacing: (7 * scale).clamp(5.0, 8.0).toDouble(),
          children: [
            userActionButtons(),
            labTechReviewButton(),
          ],
        );
      }

      Widget pills() {
        return Wrap(
          spacing: (8 * scale).clamp(6.0, 9.0).toDouble(),
          runSpacing: (7 * scale).clamp(5.0, 8.0).toDouble(),
          children: [
            _MobileInfoPill(icon: Icons.apartment_rounded, label: subCenterLabel),
            _MobileInfoPill(icon: Icons.calendar_today_rounded, label: _mobileDateLabel(sample)),
            if ((sample.referredPersonName ?? '').trim().isNotEmpty && (sample.referredPersonName ?? '').trim().toLowerCase() != 'self')
              _MobileInfoPill(icon: Icons.person_pin_circle_rounded, label: 'Refer: ${(sample.referredPersonName ?? '').trim()}'),
            if (referFee > 0) _MobileInfoPill(icon: Icons.location_on_rounded, label: 'Refer ${_formatDashboardNumber(referFee)}'),
            if (isStaff) _MobileInfoPill(icon: Icons.payments_rounded, label: _formatDashboardNumber(_mobileSampleTotal(sample))),
          ],
        );
      }

      return Container(
        constraints: BoxConstraints(minHeight: (126 * scale).clamp(108.0, 148.0).toDouble()),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(cardRadius),
          border: Border.all(color: const Color(0xFFE7ECF4)),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.025), blurRadius: (10 * scale).clamp(8.0, 12.0).toDouble(), offset: const Offset(0, 5))],
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          children: [
            Positioned.fill(
              left: 0,
              right: null,
              child: SizedBox(
                width: (4 * scale).clamp(3.0, 5.0).toDouble(),
                child: DecoratedBox(decoration: BoxDecoration(color: statusColor)),
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(cardPaddingH + (4 * scale).clamp(3.0, 5.0).toDouble(), cardPaddingV, (12 * scale).clamp(9.0, 14.0).toDouble(), cardPaddingV),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              sample.id,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(fontSize: (18 * scale).clamp(15.0, 20.0).toDouble(), fontWeight: FontWeight.w900, color: const Color(0xFF111827), letterSpacing: -0.25),
                            ),
                            SizedBox(height: (7 * scale).clamp(5.0, 8.0).toDouble()),
                            Row(
                              children: [
                                Icon(Icons.person_rounded, size: (17 * scale).clamp(14.0, 18.0).toDouble(), color: const Color(0xFF64748B)),
                                SizedBox(width: (6 * scale).clamp(4.0, 7.0).toDouble()),
                                Expanded(
                                  child: Text(
                                    sample.patientName,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(fontSize: (13.5 * scale).clamp(11.5, 15.0).toDouble(), fontWeight: FontWeight.w900, color: const Color(0xFF1F2937)),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: (3 * scale).clamp(2.0, 4.0).toDouble()),
                            Text(
                              testsLabel.isEmpty ? '-' : testsLabel,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(fontSize: (12.2 * scale).clamp(10.5, 13.5).toDouble(), color: const Color(0xFF64748B), fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: (10 * scale).clamp(7.0, 12.0).toDouble()),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              statusChip(),
                              SizedBox(width: (10 * scale).clamp(6.0, 11.0).toDouble()),
                              Icon(Icons.more_vert_rounded, color: const Color(0xFF526070), size: (24 * scale).clamp(20.0, 25.0).toDouble()),
                            ],
                          ),
                          SizedBox(height: (6 * scale).clamp(4.0, 7.0).toDouble()),
                          Padding(
                            padding: EdgeInsets.only(right: (30 * scale).clamp(20.0, 32.0).toDouble()),
                            child: Text(
                              _mobileTimeLabel(sample),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: const Color(0xFF64748B), fontSize: (11.5 * scale).clamp(9.5, 12.5).toDouble(), fontWeight: FontWeight.w600),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(height: (14 * scale).clamp(10.0, 16.0).toDouble()),
                  LayoutBuilder(
                    builder: (context, constraints) {
                      final stackActions = constraints.maxWidth < 360 || (canPrintSample && constraints.maxWidth < 430);
                      if (stackActions) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            pills(),
                            SizedBox(height: (9 * scale).clamp(7.0, 10.0).toDouble()),
                            Align(alignment: Alignment.centerRight, child: actionButtons()),
                          ],
                        );
                      }
                      return Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Expanded(child: pills()),
                          SizedBox(width: (8 * scale).clamp(6.0, 10.0).toDouble()),
                          actionButtons(),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    final showFloatingPrint = canUsePrintActions && selectedCompletedCount > 0;
    final bottomPadding = showFloatingPrint ? (86 * scale).clamp(76.0, 98.0).toDouble() : 0.0;

    return Stack(
      children: [
        ListView.separated(
          padding: EdgeInsets.only(top: widget.mobileTopPadding, bottom: bottomPadding),
          shrinkWrap: widget.mobileUseParentScroll,
          physics: widget.mobileUseParentScroll ? const NeverScrollableScrollPhysics() : null,
          itemCount: widget.samples.length,
          separatorBuilder: (_, __) => SizedBox(height: (10 * scale).clamp(8.0, 12.0).toDouble()),
          itemBuilder: (context, index) => buildCard(widget.samples[index]),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isLabTech = widget.user?.role == AppUserRole.lab_tech;
    final isAdmin = widget.user?.role == AppUserRole.admin;
    final isStaff = widget.user?.role == AppUserRole.staff;
    final completedIds = widget.samples.where((sample) => sample.status == BloodSampleStatus.completed).map((sample) => sample.id).toSet();
    _selectedSampleIds.removeWhere((id) => !completedIds.contains(id));
    _scheduleMobilePrintOverlaySync();
    if (MediaQuery.sizeOf(context).width < 760) {
      return _buildMobileSampleCards(isLabTech: isLabTech, isAdmin: isAdmin, isStaff: isStaff);
    }

    final desktopSamples = _desktopStatusFilter == null
        ? widget.samples
        : widget.samples.where((sample) => sample.status == _desktopStatusFilter).toList();

    return _DesktopTabletBloodSampleDeck(
      samples: desktopSamples,
      totalSamples: widget.samples.length,
      selectedStatus: _desktopStatusFilter,
      onStatusFilterChanged: (status) => setState(() => _desktopStatusFilter = status),
      user: widget.user,
      tests: widget.tests,
      pricings: widget.pricings,
      selectedSampleIds: _selectedSampleIds,
      busySampleId: _busySampleId,
      isBusy: _isBusy,
      isPrintingSelected: _printingSelected,
      onSelectSample: _toggleSampleSelection,
      onPrintSample: _printSingleResult,
      onReview: _reviewSample,
      onCancelSample: _cancelPendingSample,
      onDeleteSample: _deleteBloodSample,
      onViewResult: (sample) => context.go('/sample-result/${Uri.encodeComponent(sample.id)}'),
      onPrintSelected: _printSelectedResults,
      onSelectAllCompleted: _selectAllCompletedVisible,
      onClearSelection: _clearPrintSelection,
      canCancelSample: _canCancelPendingSample,
      canDeleteSample: _canDeleteBloodSample,
    );
  }

  bool _canDeleteBloodSample(BloodSample sample) {
    return widget.user?.role == AppUserRole.superadmin;
  }

  Future<void> _deleteBloodSample(BloodSample sample) async {
    if (_isBusy) return;
    if (!_canDeleteBloodSample(sample)) {
      _showToast('Only superadmin can delete blood sample rows.', isError: true);
      return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete blood sample and results?'),
        content: Text('Permanently delete ${sample.id} for ${sample.patientName}? This removes the BloodSamples row and related TestResults/CBCResults rows.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Keep')),
          FilledButton.icon(
            onPressed: () => Navigator.of(context).pop(true),
            icon: const Icon(Icons.delete_outline_rounded),
            label: const Text('Delete row'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    _setBusy(sample.id, 'Deleting ${sample.id} and related results...');
    final service = TursoNativeService(applicationName: 'flutterlab');
    try {
      await _deleteRelatedResultRowsForSample(service, sample: sample);
      await _deleteBloodSampleRow(service, sample: sample);
      setState(() => _selectedSampleIds.remove(sample.id));
      ref.invalidate(sampleDashboardControllerProvider);
      _showToast('${sample.id} and related results deleted.');
    } catch (error) {
      _showToast('Delete failed: $error', isError: true);
    } finally {
      await service.close();
      _clearBusy();
    }
  }

  bool _canCancelPendingSample(BloodSample sample) {
    final role = widget.user?.role;
    return sample.status == BloodSampleStatus.pending &&
        (role == AppUserRole.superadmin || role == AppUserRole.admin || role == AppUserRole.staff);
  }

  Future<void> _cancelPendingSample(BloodSample sample) async {
    if (_isBusy) return;
    if (!_canCancelPendingSample(sample)) {
      _showToast('Only pending samples can be canceled by superadmin, admin, or staff.', isError: true);
      return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Cancel pending sample?'),
        content: Text('Cancel ${sample.id}? This keeps the record but marks it as canceled.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Keep')),
          FilledButton.tonalIcon(
            onPressed: () => Navigator.of(context).pop(true),
            icon: const Icon(Icons.cancel_outlined),
            label: const Text('Cancel sample'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    _setBusy(sample.id, 'Canceling ${sample.id}...');
    final service = TursoNativeService(applicationName: 'flutterlab');
    try {
      await _updateBloodSampleRow(service, sample: sample, status: BloodSampleStatus.canceled, resultUrl: sample.resultFileUrl);
      ref.invalidate(sampleDashboardControllerProvider);
      _showToast('${sample.id} canceled.');
    } catch (error) {
      _showToast('Cancel failed: $error', isError: true);
    } finally {
      await service.close();
      _clearBusy();
    }
  }

  Future<void> _reviewSample(BloodSample sample) async {
    if (_isBusy) return;

    final user = ref.read(authNotifierProvider);
    if (user?.role != AppUserRole.lab_tech) {
      _showToast('Only lab tech users can review samples.', isError: true);
      return;
    }
    if (sample.status == BloodSampleStatus.canceled) {
      _showToast('Canceled samples cannot be reviewed.', isError: true);
      return;
    }

    var nextStatus = BloodSampleStatus.processing;
    String? resultUrl = sample.resultFileUrl;
    var printAfterSave = false;

    try {
      if (sample.status == BloodSampleStatus.pending) {
        _setBusy(sample.id, 'Updating ${sample.id} to processing...');
        nextStatus = BloodSampleStatus.processing;
      } else {
        nextStatus = BloodSampleStatus.completed;
        if (_isCbcOrCpAuto(sample)) {
          final result = await showDialog<_CbcCpUploadResult>(
            context: context,
            barrierDismissible: false,
            builder: (context) => _CbcCpUploadDialog(sample: sample),
          );
          if (result == null) return;
          resultUrl = await _saveCbcCpResult(sample: sample, result: result, user: user!);
        } else {
          final result = await showDialog<_ManualResultBatch>(
            context: context,
            barrierDismissible: false,
            builder: (context) => _ManualResultDialog(sample: sample),
          );
          if (result == null) return;
          printAfterSave = result.printAfterSave;
          await _saveManualResult(sample: sample, result: result, user: user!);
          // Manual results are stored in the TestResults table.
          // Do not write the manual result text into BloodSamples.resultUrl.
          resultUrl = sample.resultFileUrl;
        }
      }

      _setBusy(sample.id, 'Saving ${sample.id} status to ${nextStatus.name}...');
      final turso = TursoNativeService(applicationName: 'flutterlab');
      try {
        await _updateBloodSampleRow(turso, sample: sample, status: nextStatus, resultUrl: resultUrl);
        ref.invalidate(sampleDashboardControllerProvider);
        _showToast(nextStatus == BloodSampleStatus.processing
            ? '${sample.id} is now processing.'
            : '${sample.id} completed and result saved.');
        if (nextStatus == BloodSampleStatus.completed && printAfterSave) {
          final printableSample = BloodSample(
            id: sample.id,
            patientName: sample.patientName,
            subCenterId: sample.subCenterId,
            registeredByUserId: sample.registeredByUserId,
            testIds: sample.testIds,
            status: BloodSampleStatus.completed,
            resultFileUrl: resultUrl,
            patientAge: sample.patientAge,
            patientAddress: sample.patientAddress,
            createdAt: sample.createdAt,
            updatedAt: DateTime.now(),
            referredPersonId: sample.referredPersonId,
            referredPersonName: sample.referredPersonName,
            referredFeePercent: sample.referredFeePercent,
            referredFeeAmount: sample.referredFeeAmount,
          );
          await _printCompletedSamples(<BloodSample>[printableSample]);
        }
      } finally {
        await turso.close();
      }
    } catch (error) {
      _showToast('Review failed: $error', isError: true);
    } finally {
      _clearBusy();
    }
  }

  double _desktopTableMinWidth(
    double availableWidth, {
    required bool isStaff,
    required bool isLabTech,
    required bool isAdmin,
    required bool isSuperadmin,
  }) {
    var minWidth = 1320.0;
    if (isStaff) minWidth = 1460.0;
    if (isLabTech) minWidth = 1480.0;
    if (isAdmin || isSuperadmin) minWidth = 1480.0;
    return availableWidth < minWidth ? minWidth : availableWidth;
  }

  bool _isCbcOrCpAuto(BloodSample sample) {
    final joined = sample.testIds.join(' ').toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
    return joined.contains('cbc') || joined.contains('cpauto') || joined.contains('cp');
  }

  Future<String> _saveCbcCpResult({required BloodSample sample, required _CbcCpUploadResult result, required AppUser user}) async {
    final drive = NativeFileService(applicationName: 'flutterlab');
    final turso = TursoNativeService(applicationName: 'flutterlab');
    try {
      final row = Map<String, String>.from(result.parsedValues);
      row['id'] = 'CBC-${_stableResultIdPart(sample.id)}';
      row['testName'] = sample.testIds.isEmpty ? 'CBC / CP(Auto)' : sample.testIds.join(', ');
      row['sampleId'] = sample.id;
      row['createdAt'] = DateTime.now().toIso8601String();
      row['uploadedByUserId'] = user.id;
      row.addAll(result.graphBase64);

      if (result.diffImageBytes != null) {
        _setBusy(sample.id, 'Uploading DIFF image...');
        row['diffHsmsImageUrl'] = await drive.uploadImageBytes(bytes: result.diffImageBytes!, parentFolderId: 'native', fileName: result.diffImageName, mimeType: _mimeTypeFor(result.diffImageName));
      }
      if (result.pltImageBytes != null) {
        _setBusy(sample.id, 'Uploading PLT image...');
        row['pltImageUrl'] = await drive.uploadImageBytes(bytes: result.pltImageBytes!, parentFolderId: 'native', fileName: result.pltImageName, mimeType: _mimeTypeFor(result.pltImageName));
      }

      _setBusy(sample.id, 'Saving CBC / CP(Auto) result values...');
      await _ensureResultSheetHeaders(turso: turso, sheetName: 'CBCResults', range: 'CBCResults!A1:BH1', headers: _cbcResultHeaders);
      await _deleteExistingResultRowsForSample(
        turso: turso,
        sheetName: 'CBCResults',
        range: 'CBCResults!A:BZ',
        sampleId: sample.id,
      );
      await turso.insertRow(range: 'CBCResults!A:BH', values: _cbcResultHeaders.map((header) => row[header] ?? '').toList(), valueInputOption: 'RAW');
      // BloodSamples.resultUrl should contain a real URL, not summary text.
      return row['diffHsmsImageUrl']?.trim().isNotEmpty == true
          ? row['diffHsmsImageUrl']!
          : (row['pltImageUrl'] ?? '');
    } finally {
      await drive.close();
      await turso.close();
    }
  }

  Future<String> _saveManualResult({required BloodSample sample, required _ManualResultBatch result, required AppUser user}) async {
    final turso = TursoNativeService(applicationName: 'flutterlab');
    try {
      await _ensureResultSheetHeaders(turso: turso, sheetName: 'TestResults', range: 'TestResults!A1:K1', headers: _manualResultHeaders);
      await _deleteExistingResultRowsForSample(
        turso: turso,
        sheetName: 'TestResults',
        range: 'TestResults!A:Z',
        sampleId: sample.id,
      );
      final now = DateTime.now();
      var saved = 0;
      for (final entry in result.entries) {
        final id = 'RESULT-${_stableResultIdPart(sample.id)}-${_stableResultIdPart(entry.testName)}-${_stableResultIdPart(entry.parameter)}';
        final row = <String, String>{
          'id': id,
          'sampleId': sample.id,
          'testName': entry.testName,
          'parameter': entry.parameter,
          'patientName': sample.patientName,
          'resultValue': entry.value,
          'unit': entry.unit,
          'referenceRange': entry.referenceRange,
          'notes': entry.notes,
          'createdAt': now.toIso8601String(),
          'uploadedByUserId': user.id,
        };
        await turso.insertRow(
          range: 'TestResults!A:K',
          values: _manualResultHeaders.map((header) => row[header] ?? '').toList(),
          valueInputOption: 'RAW',
        );
        saved++;
      }
      return 'TestResults:${sample.id}\nManual result rows:$saved';
    } finally {
      await turso.close();
    }
  }

  Future<void> _ensureResultSheetHeaders({required TursoNativeService turso, required String sheetName, required String range, required List<String> headers}) async {
    await turso.ensureSheet(sheetName: sheetName);
    await turso.updateRow(range: range, values: headers);
  }

  Future<void> _deleteExistingResultRowsForSample({
    required TursoNativeService turso,
    required String sheetName,
    required String range,
    required String sampleId,
  }) async {
    final rows = await turso.fetchRows(range: range);
    if (rows.length < 2) return;
    final headers = rows.first.map((header) => _normalizeResultKey(header)).toList();
    final sampleIdIndex = headers.indexOf('sampleid');
    if (sampleIdIndex < 0) return;
    final targetSampleId = _normalizeResultKey(sampleId);
    final rowsToDelete = <int>[];
    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      final rowSampleId = sampleIdIndex < row.length ? _normalizeResultKey(row[sampleIdIndex]) : '';
      if (rowSampleId == targetSampleId) {
        rowsToDelete.add(i + 1);
      }
    }
    for (final rowIndex in rowsToDelete.reversed) {
      await turso.deleteRow(sheetName: sheetName, rowIndexOneBased: rowIndex);
    }
  }

  String _stableResultIdPart(String value) {
    final normalized = _normalizeResultKey(value);
    return normalized.isEmpty ? 'result' : normalized;
  }

  String _mimeTypeFor(String fileName) {
    final lower = fileName.toLowerCase();
    if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
    return 'image/png';
  }

  String _normalizeResultKey(String value) {
    return value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
  }

  Future<void> _deleteRelatedResultRowsForSample(
    TursoNativeService service, {
    required BloodSample sample,
  }) async {
    await _deleteExistingResultRowsForSample(
      turso: service,
      sheetName: 'TestResults',
      range: 'TestResults!A:Z',
      sampleId: sample.id,
    );
    await _deleteExistingResultRowsForSample(
      turso: service,
      sheetName: 'CBCResults',
      range: 'CBCResults!A:BZ',
      sampleId: sample.id,
    );
  }

  Future<void> _deleteBloodSampleRow(
    TursoNativeService service, {
    required BloodSample sample,
  }) async {
    final rows = await service.fetchRows(range: 'BloodSamples!A:Z');
    if (rows.length < 2) throw StateError('Sample row was not found.');
    final headers = rows.first.map((h) => _normalizeResultKey(h)).toList();
    final idIndex = headers.indexOf('id');
    final sampleIdIndex = headers.indexOf('sampleid');
    if (idIndex < 0 && sampleIdIndex < 0) {
      throw StateError('BloodSamples id column was not found.');
    }
    final targetId = _normalizeResultKey(sample.id);
    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      final possibleIds = <String>{};
      if (idIndex >= 0 && idIndex < row.length) possibleIds.add(_normalizeResultKey(row[idIndex]));
      if (sampleIdIndex >= 0 && sampleIdIndex < row.length) possibleIds.add(_normalizeResultKey(row[sampleIdIndex]));
      if (possibleIds.contains(targetId)) {
        await service.deleteRow(sheetName: 'BloodSamples', rowIndexOneBased: i + 1);
        return;
      }
    }
    throw StateError('Sample row was not found.');
  }

  Future<void> _updateBloodSampleRow(
    TursoNativeService service, {
    required BloodSample sample,
    required BloodSampleStatus status,
    String? resultUrl,
  }) async {
    const upsertHeaders = <String>[
      'id',
      'patientName',
      'status',
      'testIds',
      'registeredByUserId',
      'subCenterId',
      'resultUrl',
      'createdAt',
      'updatedAt',
      'patientAge',
      'patientSex',
      'patientAddress',
      'registrationId',
      'testId',
      'testName',
      'testPrice',
      'totalAmount',
      'referredPersonId',
      'referredPersonName',
      'referredFeePercent',
      'referredFeeAmount',
    ];

    final rows = await service.fetchRows(range: 'BloodSamples!A:Z');
    final headers = rows.isEmpty
        ? upsertHeaders.map(_normalizeResultKey).toList()
        : rows.first.map((h) => _normalizeResultKey(h)).toList();
    Map<String, String> existing = <String, String>{};
    final targetId = _normalizeResultKey(sample.id);
    for (final row in rows.skip(1)) {
      final map = <String, String>{};
      for (var i = 0; i < headers.length; i++) {
        map[headers[i]] = i < row.length ? row[i].trim() : '';
      }
      final id = _normalizeResultKey(map['id'] ?? map['sampleid'] ?? '');
      if (id == targetId) {
        existing = map;
        break;
      }
    }

    String pick(List<String> keys, String fallback) {
      for (final key in keys) {
        final value = existing[_normalizeResultKey(key)]?.trim() ?? '';
        if (value.isNotEmpty) return value;
      }
      return fallback;
    }

    final nowIso = DateTime.now().toIso8601String();
    final tests = sample.testIds.join(',');
    final resultValue = resultUrl?.trim().isNotEmpty == true
        ? resultUrl!.trim()
        : pick(const ['resultUrl', 'resultFileUrl', 'result'], sample.resultFileUrl ?? '');
    final row = <String, String>{
      'id': sample.id,
      'patientName': pick(const ['patientName', 'patient', 'name'], sample.patientName),
      'status': status.name,
      'testIds': pick(const ['testIds', 'tests'], tests),
      'registeredByUserId': pick(const ['registeredByUserId', 'registeredBy'], sample.registeredByUserId),
      'subCenterId': pick(const ['subCenterId', 'subcenter', 'center'], sample.subCenterId),
      'resultUrl': resultValue,
      'createdAt': pick(const ['createdAt', 'created'], sample.createdAt?.toIso8601String() ?? nowIso),
      'updatedAt': nowIso,
      'patientAge': pick(const ['patientAge', 'age'], ''),
      'patientSex': pick(const ['patientSex', 'sex', 'gender'], ''),
      'patientAddress': pick(const ['patientAddress', 'address'], ''),
      'registrationId': pick(const ['registrationId'], ''),
      'testId': pick(const ['testId'], sample.testIds.isEmpty ? '' : sample.testIds.first),
      'testName': pick(const ['testName'], tests),
      'testPrice': pick(const ['testPrice', 'price'], ''),
      'totalAmount': pick(const ['totalAmount', 'amount'], ''),
      'referredPersonId': pick(const ['referredPersonId', 'referedPersonId', 'referredById'], sample.referredPersonId ?? ''),
      'referredPersonName': pick(const ['referredPersonName', 'referedPersonName', 'referredByName'], sample.referredPersonName ?? ''),
      'referredFeePercent': pick(const ['referredFeePercent', 'referedFeePercent'], sample.referredFeePercent.toStringAsFixed(2)),
      'referredFeeAmount': pick(const ['referredFeeAmount', 'referedFeeAmount', 'referredFee'], sample.referredFeeAmount.toStringAsFixed(2)),
    };

    await service.insertRow(
      range: 'BloodSamples!A:Z',
      values: upsertHeaders.map((header) => row[header] ?? '').toList(),
      valueInputOption: 'RAW',
    );
  }

}


const _cbcResultHeaders = <String>[
  'id',
  'testName',
  'sampleId',
  'medRecNo',
  'firstName',
  'lastName',
  'gender',
  'age',
  'ageUnit',
  'sampleType',
  'samplingTime',
  'deliveryTime',
  'reportTime',
  'runTime',
  'mode',
  'WBC',
  'NeuPercent',
  'LymPercent',
  'MonPercent',
  'EosPercent',
  'BasPercent',
  'NeuCount',
  'LymCount',
  'MonCount',
  'EosCount',
  'BasCount',
  'ALYCount',
  'ALYPercent',
  'LICCount',
  'LICPercent',
  'NRBCCount',
  'NRBCPercent',
  'RBC',
  'HGB',
  'HCT',
  'MCV',
  'MCH',
  'MCHC',
  'RDWCV',
  'RDWSD',
  'PLT',
  'MPV',
  'PDW',
  'PCT',
  'PLCR',
  'PLCC',
  'WBCFlag',
  'RBCFlag',
  'PLTFlag',
  'CRPFlag',
  'diffHsmsImageUrl',
  'pltImageUrl',
  'wbcGraphBase64',
  'rbcGraphBase64',
  'pltGraphBase64',
  'diffHsmsBase64',
  'diffLshsBase64',
  'diffLsmsBase64',
  'createdAt',
  'uploadedByUserId',
];

const _manualResultHeaders = <String>[
  'id',
  'sampleId',
  'testName',
  'parameter',
  'patientName',
  'resultValue',
  'unit',
  'referenceRange',
  'notes',
  'createdAt',
  'uploadedByUserId',
];

class _AnalyzerExportData {
  const _AnalyzerExportData({required this.parsedValues, required this.graphBase64});

  final Map<String, String> parsedValues;
  final Map<String, String> graphBase64;
}

class _CbcCpUploadResult {
  const _CbcCpUploadResult({
    required this.parsedValues,
    required this.diffImageBytes,
    required this.diffImageName,
    required this.pltImageBytes,
    required this.pltImageName,
    required this.graphBase64,
  });

  final Map<String, String> parsedValues;
  final Uint8List? diffImageBytes;
  final String diffImageName;
  final Uint8List? pltImageBytes;
  final String pltImageName;
  final Map<String, String> graphBase64;
}

class _ManualResultBatch {
  const _ManualResultBatch({required this.entries, this.printAfterSave = false});

  final List<_ManualResultEntry> entries;
  final bool printAfterSave;
}

class _ManualResultEntry {
  const _ManualResultEntry({
    required this.testName,
    required this.parameter,
    required this.value,
    required this.unit,
    required this.referenceRange,
    required this.notes,
  });

  final String testName;
  final String parameter;
  final String value;
  final String unit;
  final String referenceRange;
  final String notes;
}

class _ManualDefaultParameter {
  const _ManualDefaultParameter({
    required this.testName,
    required this.parameter,
    required this.unit,
    required this.referenceRange,
    required this.notes,
  });

  final String testName;
  final String parameter;
  final String unit;
  final String referenceRange;
  final String notes;
}

class _ManualResultDialog extends StatefulWidget {
  const _ManualResultDialog({required this.sample});

  final BloodSample sample;

  @override
  State<_ManualResultDialog> createState() => _ManualResultDialogState();
}

class _ManualResultDialogState extends State<_ManualResultDialog> {
  final _formKey = GlobalKey<FormState>();
  final List<TextEditingController> _valueControllers = [];
  List<_ManualDefaultParameter> _defaults = const <_ManualDefaultParameter>[];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadDefaults();
  }

  @override
  void dispose() {
    for (final controller in _valueControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _loadDefaults() async {
    try {
      final defaults = await _fetchManualDefaults();
      if (!mounted) return;
      setState(() {
        _defaults = defaults.isEmpty ? _fallbackDefaults() : defaults;
        _valueControllers
          ..clear()
          ..addAll(List.generate(_defaults.length, (_) => TextEditingController()));
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = 'Could not load manual defaults: $error';
        _defaults = _fallbackDefaults();
        _valueControllers
          ..clear()
          ..addAll(List.generate(_defaults.length, (_) => TextEditingController()));
        _loading = false;
      });
    }
  }

  List<_ManualDefaultParameter> _fallbackDefaults() {
    final tests = widget.sample.testIds.isEmpty ? const ['Manual Test'] : widget.sample.testIds;
    return tests
        .map(
          (test) => _ManualDefaultParameter(
            testName: test,
            parameter: test,
            unit: '',
            referenceRange: '',
            notes: '',
          ),
        )
        .toList();
  }

  String _normalize(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  Future<List<_ManualDefaultParameter>> _fetchManualDefaults() async {
    final turso = TursoNativeService(applicationName: 'flutterlab');
    try {
      final rows = await turso.fetchRows(
        range: 'ManualTestDefaults!A:G',
      );
      if (rows.length < 2) return const <_ManualDefaultParameter>[];
      final headers = rows.first.map((h) => _normalize(h)).toList();
      int indexOf(List<String> keys) {
        for (final key in keys) {
          final index = headers.indexOf(key);
          if (index >= 0) return index;
        }
        return -1;
      }

      final testIdIndex = indexOf(const ['testid']);
      final testNameIndex = indexOf(const ['testname', 'name']);
      final parameterIndex = indexOf(const ['parameter', 'parametername']);
      final unitIndex = indexOf(const ['unit']);
      final referenceIndex = indexOf(const ['referencerange', 'refrange', 'reference']);
      final noteIndex = indexOf(const ['note', 'notes']);
      final sampleTests = widget.sample.testIds.map(_normalize).toSet();
      final defaults = <_ManualDefaultParameter>[];
      for (final row in rows.skip(1)) {
        String cell(int index) => index >= 0 && index < row.length ? row[index].trim() : '';
        final testId = cell(testIdIndex);
        final testName = cell(testNameIndex);
        final keyMatches = sampleTests.contains(_normalize(testId)) || sampleTests.contains(_normalize(testName));
        if (!keyMatches) continue;
        defaults.add(
          _ManualDefaultParameter(
            testName: testName.isEmpty ? testId : testName,
            parameter: cell(parameterIndex).isEmpty ? (testName.isEmpty ? testId : testName) : cell(parameterIndex),
            unit: cell(unitIndex),
            referenceRange: cell(referenceIndex),
            notes: cell(noteIndex),
          ),
        );
      }
      return defaults;
    } finally {
      await turso.close();
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final isMobile = size.width < 600;
    final maxDialogHeight = size.height * (isMobile ? 0.88 : 0.82);

    Widget body() {
      if (_loading) {
        return const Center(child: CircularProgressIndicator());
      }
      return Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.zero,
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          children: [
            Container(
              padding: EdgeInsets.all(isMobile ? 10 : 12),
              decoration: BoxDecoration(
                color: const Color(0xFFF8FAFC),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final compactInfo = constraints.maxWidth < 520;
                  final gap = compactInfo ? 6.0 : 8.0;
                  final rowItemWidth = compactInfo ? constraints.maxWidth : (constraints.maxWidth - gap * 2) / 3;
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Wrap(
                        spacing: gap,
                        runSpacing: 6,
                        children: [
                          SizedBox(
                            width: rowItemWidth,
                            child: _ManualResultInfoLine(
                              icon: Icons.person_outline_rounded,
                              label: 'Name',
                              value: widget.sample.patientName.trim().isEmpty ? '-' : widget.sample.patientName.trim(),
                            ),
                          ),
                          SizedBox(
                            width: rowItemWidth,
                            child: _ManualResultInfoLine(
                              icon: Icons.cake_outlined,
                              label: 'Age',
                              value: widget.sample.patientAge.trim().isEmpty ? '-' : widget.sample.patientAge.trim(),
                            ),
                          ),
                          SizedBox(
                            width: rowItemWidth,
                            child: _ManualResultInfoLine(
                              icon: Icons.home_outlined,
                              label: 'Address',
                              value: widget.sample.patientAddress.trim().isEmpty ? '-' : widget.sample.patientAddress.trim(),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 7),
                      _ManualResultInfoLine(
                        icon: Icons.science_rounded,
                        label: 'Test',
                        value: widget.sample.testIds.join(', '),
                        maxLines: isMobile ? 3 : 2,
                      ),
                    ],
                  );
                },
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ],
            const SizedBox(height: 12),
            for (var i = 0; i < _defaults.length; i++) ...[
              _ManualResultInputCard(
                defaultParameter: _defaults[i],
                controller: _valueControllers[i],
              ),
              const SizedBox(height: 12),
            ],
          ],
        ),
      );
    }

    void save({bool printAfterSave = false}) {
      if (_loading) return;
      if (!_formKey.currentState!.validate()) return;
      Navigator.of(context).pop(
        _ManualResultBatch(
          printAfterSave: printAfterSave,
          entries: [
            for (var i = 0; i < _defaults.length; i++)
              _ManualResultEntry(
                testName: _defaults[i].testName,
                parameter: _defaults[i].parameter,
                value: _valueControllers[i].text.trim(),
                unit: _isQualitativeManualDefault(_defaults[i]) ? '' : _defaults[i].unit,
                referenceRange: _isQualitativeManualDefault(_defaults[i]) ? '' : _defaults[i].referenceRange,
                notes: _defaults[i].notes,
              ),
          ],
        ),
      );
    }

    return Dialog(
      insetPadding: EdgeInsets.symmetric(horizontal: isMobile ? 12 : 24, vertical: isMobile ? 14 : 24),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(isMobile ? 20 : 24)),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 640, maxHeight: maxDialogHeight),
        child: Padding(
          padding: EdgeInsets.fromLTRB(isMobile ? 14 : 20, isMobile ? 14 : 20, isMobile ? 14 : 20, isMobile ? 12 : 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      'Enter result: ${widget.sample.id}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
                    ),
                  ),
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Flexible(child: body()),
              const SizedBox(height: 8),
              const Divider(height: 1),
              const SizedBox(height: 10),
              if (isMobile)
                Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    FilledButton.icon(
                      onPressed: _loading ? null : save,
                      icon: const Icon(Icons.save_rounded),
                      label: const Text('Save Result'),
                    ),
                    const SizedBox(height: 8),
                    FilledButton.tonalIcon(
                      onPressed: _loading ? null : () => save(printAfterSave: true),
                      icon: const Icon(Icons.print_rounded),
                      label: const Text('Save & Print'),
                    ),
                    const SizedBox(height: 8),
                    TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
                  ],
                )
              else
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
                    const SizedBox(width: 8),
                    FilledButton.tonalIcon(
                      onPressed: _loading ? null : () => save(printAfterSave: true),
                      icon: const Icon(Icons.print_rounded),
                      label: const Text('Save & Print'),
                    ),
                    const SizedBox(width: 8),
                    FilledButton.icon(
                      onPressed: _loading ? null : save,
                      icon: const Icon(Icons.save_rounded),
                      label: const Text('Save Result'),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}


bool _hasNumericReferenceRange(String value) {
  return RegExp(r'(-?\d+(?:\.\d+)?)\s*-\s*(-?\d+(?:\.\d+)?)').hasMatch(value.replaceAll(',', ''));
}

bool _isQualitativeManualDefault(_ManualDefaultParameter parameter) {
  return parameter.unit.trim().isEmpty && !_hasNumericReferenceRange(parameter.referenceRange);
}

bool _isQualitativePrintableRow(_PrintableResultRow row) {
  return row.unit.trim().isEmpty && !_hasNumericReferenceRange(row.referenceRange);
}

class _ManualResultInfoLine extends StatelessWidget {
  const _ManualResultInfoLine({
    required this.icon,
    required this.label,
    required this.value,
    this.maxLines = 1,
  });

  final IconData icon;
  final String label;
  final String value;
  final int maxLines;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: const Color(0xFF2563EB), size: 18),
        const SizedBox(width: 8),
        Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w900)),
        Expanded(
          child: Text(
            value.trim().isEmpty ? '-' : value.trim(),
            maxLines: maxLines,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
      ],
    );
  }
}

class _ManualResultInputCard extends StatelessWidget {
  const _ManualResultInputCard({required this.defaultParameter, required this.controller});

  final _ManualDefaultParameter defaultParameter;
  final TextEditingController controller;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final qualitative = _isQualitativeManualDefault(defaultParameter);
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 360;
        Widget choiceButtons() {
          final negative = FilledButton.icon(
            onPressed: () => controller.text = 'Negative',
            icon: const Icon(Icons.remove_circle_outline_rounded),
            label: const Text('Negative'),
          );
          final positive = FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFFDC2626),
              foregroundColor: Colors.white,
            ),
            onPressed: () => controller.text = 'Positive',
            icon: const Icon(Icons.add_circle_outline_rounded),
            label: const Text('Positive'),
          );
          if (compact) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [negative, const SizedBox(height: 8), positive],
            );
          }
          return Row(
            children: [Expanded(child: negative), const SizedBox(width: 10), Expanded(child: positive)],
          );
        }

        return Container(
          padding: EdgeInsets.all(compact ? 12 : 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: theme.colorScheme.outlineVariant),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 6,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Text(
                    defaultParameter.parameter,
                    style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
                  ),
                  if (qualitative)
                    Chip(
                      visualDensity: VisualDensity.compact,
                      label: const Text('Qualitative'),
                      avatar: const Icon(Icons.check_circle_outline_rounded, size: 16),
                    ),
                ],
              ),
              if (defaultParameter.testName.trim().isNotEmpty && defaultParameter.testName.trim() != defaultParameter.parameter.trim()) ...[
                const SizedBox(height: 4),
                Text(
                  'Test: ${defaultParameter.testName}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.bodySmall?.copyWith(color: const Color(0xFF64748B), fontWeight: FontWeight.w700),
                ),
              ],
              const SizedBox(height: 10),
              if (qualitative) ...[
                choiceButtons(),
                const SizedBox(height: 10),
              ],
              TextFormField(
                controller: controller,
                readOnly: qualitative,
                decoration: InputDecoration(
                  labelText: qualitative ? 'Select Negative or Positive' : 'Result value',
                  helperText: qualitative
                      ? 'Qualitative test. Ref range and unit are hidden in view/print.'
                      : [
                          if (defaultParameter.unit.trim().isNotEmpty) 'Unit: ${defaultParameter.unit}',
                          if (defaultParameter.referenceRange.trim().isNotEmpty) 'Ref: ${defaultParameter.referenceRange}',
                        ].join('   '),
                  helperMaxLines: 4,
                  border: const OutlineInputBorder(),
                ),
                validator: (value) => value == null || value.trim().isEmpty ? 'Enter result value' : null,
              ),
              if (defaultParameter.notes.trim().isNotEmpty) ...[
                const SizedBox(height: 8),
                Text('Default note: ${defaultParameter.notes}', style: theme.textTheme.bodySmall),
              ],
            ],
          ),
        );
      },
    );
  }
}

class _CbcCpUploadDialog extends StatefulWidget {
  const _CbcCpUploadDialog({required this.sample});

  final BloodSample sample;

  @override
  State<_CbcCpUploadDialog> createState() => _CbcCpUploadDialogState();
}

class _CbcCpUploadDialogState extends State<_CbcCpUploadDialog> {
  PlatformFile? _csvFile;
  PlatformFile? _diffImage;
  PlatformFile? _pltImage;
  PlatformFile? _exportZip;
  final Map<String, String> _graphBase64 = {};
  Map<String, String>? _preview;
  String? _error;

  Future<void> _pickCsv() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['csv'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final file = result.files.single;
    final bytes = file.bytes;
    if (bytes == null || bytes.isEmpty) {
      setState(() => _error = 'CSV is empty or cannot be read.');
      return;
    }
    try {
      final parsed = _parseCbcCsv(utf8.decode(bytes, allowMalformed: true));
      setState(() {
        _csvFile = file;
        _preview = parsed;
        _error = null;
      });
    } catch (error) {
      setState(() => _error = 'CSV parse failed: $error');
    }
  }

  Future<void> _pickImage({required bool isDiff}) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['png', 'jpg', 'jpeg'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    setState(() {
      if (isDiff) {
        _diffImage = result.files.single;
      } else {
        _pltImage = result.files.single;
      }
      _error = null;
    });
  }

  Future<void> _pickAnalyzerZip() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['zip'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final file = result.files.single;
    final bytes = file.bytes;
    if (bytes == null || bytes.isEmpty) {
      setState(() => _error = 'Analyzer ZIP is empty or cannot be read.');
      return;
    }
    try {
      final extracted = _extractAnalyzerExport(bytes);
      setState(() {
        _exportZip = file;
        _csvFile = file;
        _preview = extracted.parsedValues;
        _graphBase64
          ..clear()
          ..addAll(extracted.graphBase64);
        _error = null;
      });
    } catch (error) {
      setState(() => _error = 'Analyzer ZIP parse failed: $error');
    }
  }

  _AnalyzerExportData _extractAnalyzerExport(Uint8List zipBytes) {
    final archive = ZipDecoder().decodeBytes(zipBytes);
    String? csvText;
    final graphs = <String, String>{};
    for (final file in archive.files) {
      if (!file.isFile) continue;
      final name = file.name.split('/').last;
      final lower = name.toLowerCase();
      final data = file.readBytes();
      if (data == null || data.isEmpty) continue;
      if (lower.endsWith('.csv')) {
        csvText = utf8.decode(data, allowMalformed: true);
      } else if (lower.endsWith('.png')) {
        final key = _graphKeyFor(name);
        if (key != null) graphs[key] = base64Encode(data);
      }
    }
    if (csvText == null || csvText.trim().isEmpty) {
      throw StateError('No CSV file found inside ZIP.');
    }
    return _AnalyzerExportData(parsedValues: _parseCbcCsv(csvText), graphBase64: graphs);
  }

  String? _graphKeyFor(String fileName) {
    final upper = fileName.toUpperCase();
    if (upper.contains('WBC')) return 'wbcGraphBase64';
    if (upper.contains('RBC')) return 'rbcGraphBase64';
    if (upper.contains('PLT')) return 'pltGraphBase64';
    if (upper.contains('DIFF_HSMS')) return 'diffHsmsBase64';
    if (upper.contains('DIFF_LSHS')) return 'diffLshsBase64';
    if (upper.contains('DIFF_LSMS')) return 'diffLsmsBase64';
    return null;
  }

  Map<String, String> _parseCbcCsv(String csvText) {
    final rows = _parseCsvRows(csvText).where((row) => row.any((cell) => cell.trim().isNotEmpty)).toList();
    if (rows.length < 2) throw StateError('CSV must contain header row and one data row.');
    final headers = rows.first.map((value) => value.trim().toLowerCase()).toList();
    final row = rows[1];
    final source = <String, String>{};
    for (var i = 0; i < headers.length; i++) {
      source[headers[i]] = i < row.length ? row[i].trim() : '';
    }

    String get(List<String> keys) {
      for (final key in keys) {
        final value = source[key.toLowerCase()]?.trim() ?? '';
        if (value.isNotEmpty) return value;
      }
      return '';
    }

    final sampleId = get(['Sample ID']);
    return <String, String>{
      'id': 'CBC-${sampleId.isEmpty ? DateTime.now().microsecondsSinceEpoch : sampleId}-${DateTime.now().millisecondsSinceEpoch}',
      'testName': 'CBC / CP(Auto)',
      'sampleId': sampleId,
      'medRecNo': get(['Med Rec. No.']),
      'firstName': get(['First Name']),
      'lastName': get(['Last Name']),
      'gender': get(['Gender']),
      'age': get(['Age']),
      'ageUnit': get(['Age Unit']),
      'sampleType': get(['Sample Type']),
      'samplingTime': get(['Sampling Time']),
      'deliveryTime': get(['Delivery Time']),
      'reportTime': get(['Report Time']),
      'runTime': get(['Run Time']),
      'mode': get(['Mode']),
      'WBC': get(['WBC']),
      'NeuPercent': get(['Neu%']),
      'LymPercent': get(['Lym%']),
      'MonPercent': get(['Mon%']),
      'EosPercent': get(['Eos%']),
      'BasPercent': get(['Bas%']),
      'NeuCount': get(['Neu#']),
      'LymCount': get(['Lym#']),
      'MonCount': get(['Mon#']),
      'EosCount': get(['Eos#']),
      'BasCount': get(['Bas#']),
      'ALYCount': get(['ALY#']),
      'ALYPercent': get(['ALY%']),
      'LICCount': get(['LIC#']),
      'LICPercent': get(['LIC%']),
      'NRBCCount': get(['NRBC#']),
      'NRBCPercent': get(['NRBC%']),
      'RBC': get(['RBC']),
      'HGB': get(['HGB']),
      'HCT': get(['HCT']),
      'MCV': get(['MCV']),
      'MCH': get(['MCH']),
      'MCHC': get(['MCHC']),
      'RDWCV': get(['RDW-CV']),
      'RDWSD': get(['RDW-SD']),
      'PLT': get(['PLT']),
      'MPV': get(['MPV']),
      'PDW': get(['PDW']),
      'PCT': get(['PCT']),
      'PLCR': get(['P-LCR']),
      'PLCC': get(['P-LCC']),
      'WBCFlag': get(['WBC Flag']),
      'RBCFlag': get(['RBC Flag']),
      'PLTFlag': get(['PLT Flag']),
      'CRPFlag': get(['CRP Flag']),
    };
  }

  List<List<String>> _parseCsvRows(String text) {
    final rows = <List<String>>[];
    final currentRow = <String>[];
    final currentCell = StringBuffer();
    var inQuotes = false;
    for (var i = 0; i < text.length; i++) {
      final char = text[i];
      final next = i + 1 < text.length ? text[i + 1] : '';
      if (char == '"') {
        if (inQuotes && next == '"') {
          currentCell.write('"');
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char == ',' && !inQuotes) {
        currentRow.add(currentCell.toString().replaceAll('\t', '').trim());
        currentCell.clear();
      } else if ((char == '\n' || char == '\r') && !inQuotes) {
        if (char == '\r' && next == '\n') i++;
        currentRow.add(currentCell.toString().replaceAll('\t', '').trim());
        currentCell.clear();
        rows.add(List<String>.from(currentRow));
        currentRow.clear();
      } else {
        currentCell.write(char);
      }
    }
    if (currentCell.isNotEmpty || currentRow.isNotEmpty) {
      currentRow.add(currentCell.toString().replaceAll('\t', '').trim());
      rows.add(List<String>.from(currentRow));
    }
    return rows;
  }

  void _submit() {
    if (_preview == null) {
      setState(() => _error = 'Choose the CBC / CP(Auto) CSV file.');
      return;
    }
    if (_diffImage?.bytes == null && (_graphBase64['diffHsmsBase64'] ?? '').isEmpty) {
      setState(() => _error = 'Choose the DIFF image or analyzer ZIP.');
      return;
    }
    if (_pltImage?.bytes == null && (_graphBase64['pltGraphBase64'] ?? '').isEmpty) {
      setState(() => _error = 'Choose the PLT image or analyzer ZIP.');
      return;
    }
    Navigator.of(context).pop(
      _CbcCpUploadResult(
        parsedValues: _preview!,
        diffImageBytes: _diffImage?.bytes == null ? null : Uint8List.fromList(_diffImage!.bytes!),
        diffImageName: _diffImage?.name ?? '',
        pltImageBytes: _pltImage?.bytes == null ? null : Uint8List.fromList(_pltImage!.bytes!),
        pltImageName: _pltImage?.name ?? '',
        graphBase64: Map<String, String>.from(_graphBase64),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final preview = _preview;
    return AlertDialog(
      title: Text('CBC / CP(Auto) result: ${widget.sample.id}'),
      content: SizedBox(
        width: 650,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Upload analyzer ZIP, or CSV plus DIFF/PLT image for ${widget.sample.testIds.join(', ')}.'),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  FilledButton.tonalIcon(onPressed: _pickAnalyzerZip, icon: const Icon(Icons.folder_zip_rounded), label: Text(_exportZip == null ? 'Analyzer ZIP' : _exportZip!.name)),
                  FilledButton.tonalIcon(onPressed: _pickCsv, icon: const Icon(Icons.table_chart_rounded), label: Text(_csvFile == null ? 'CSV' : _csvFile!.name)),
                  FilledButton.tonalIcon(onPressed: () => _pickImage(isDiff: true), icon: const Icon(Icons.scatter_plot_rounded), label: Text(_diffImage == null ? 'DIFF image' : _diffImage!.name)),
                  FilledButton.tonalIcon(onPressed: () => _pickImage(isDiff: false), icon: const Icon(Icons.area_chart_rounded), label: Text(_pltImage == null ? 'PLT image' : _pltImage!.name)),
                ],
              ),
              if (_error != null) ...[
                const SizedBox(height: 10),
                Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ],
              if (preview != null) ...[
                const SizedBox(height: 14),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: ['sampleId', 'mode', 'WBC', 'RBC', 'HGB', 'HCT', 'PLT', 'WBCFlag', 'RBCFlag', 'PLTFlag']
                      .map((key) => Chip(label: Text('$key: ${preview[key] ?? '-'}')))
                      .toList(),
                ),
              ],
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
        FilledButton.icon(onPressed: _submit, icon: const Icon(Icons.save_rounded), label: const Text('Upload + Save')),
      ],
    );
  }
}

class _MobileInfoPill extends StatelessWidget {
  const _MobileInfoPill({required this.icon, required this.label});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final scale = (width / 390).clamp(0.78, 1.12).toDouble();
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10 * scale, vertical: 7 * scale),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(999),
        color: const Color(0xFFF0F6FF),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15 * scale, color: const Color(0xFF0B6BD3)),
          SizedBox(width: 6 * scale),
          Text(label, style: TextStyle(color: const Color(0xFF405064), fontSize: 11.5 * scale, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}


class _DesktopTabletBloodSampleDeck extends StatelessWidget {
  const _DesktopTabletBloodSampleDeck({
    required this.samples,
    required this.totalSamples,
    required this.selectedStatus,
    required this.onStatusFilterChanged,
    required this.user,
    required this.tests,
    required this.pricings,
    required this.selectedSampleIds,
    required this.busySampleId,
    required this.isBusy,
    required this.isPrintingSelected,
    required this.onSelectSample,
    required this.onPrintSample,
    required this.onReview,
    required this.onCancelSample,
    required this.onDeleteSample,
    required this.onViewResult,
    required this.onPrintSelected,
    required this.onSelectAllCompleted,
    required this.onClearSelection,
    required this.canCancelSample,
    required this.canDeleteSample,
  });

  final List<BloodSample> samples;
  final int totalSamples;
  final BloodSampleStatus? selectedStatus;
  final ValueChanged<BloodSampleStatus?> onStatusFilterChanged;
  final AppUser? user;
  final List<LabTest> tests;
  final List<SubCenterPricing> pricings;
  final Set<String> selectedSampleIds;
  final String? busySampleId;
  final bool isBusy;
  final bool isPrintingSelected;
  final void Function(BloodSample sample, bool selected) onSelectSample;
  final Future<void> Function(BloodSample sample) onPrintSample;
  final Future<void> Function(BloodSample sample) onReview;
  final Future<void> Function(BloodSample sample) onCancelSample;
  final Future<void> Function(BloodSample sample) onDeleteSample;
  final void Function(BloodSample sample) onViewResult;
  final Future<void> Function() onPrintSelected;
  final void Function() onSelectAllCompleted;
  final void Function() onClearSelection;
  final bool Function(BloodSample sample) canCancelSample;
  final bool Function(BloodSample sample) canDeleteSample;

  int get _completedCount => samples.where((sample) => sample.status == BloodSampleStatus.completed).length;
  int get _selectedCount => selectedSampleIds.length;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _DesktopTabletSampleDeckHeader(
              total: totalSamples,
              shown: samples.length,
              completed: _completedCount,
              selectedStatus: selectedStatus,
              onStatusFilterChanged: onStatusFilterChanged,
              selected: _selectedCount,
              isBusy: isBusy,
              isPrintingSelected: isPrintingSelected,
              onPrintSelected: onPrintSelected,
              onSelectAllCompleted: onSelectAllCompleted,
              onClearSelection: onClearSelection,
            ),
            const SizedBox(height: 16),
            if (samples.isEmpty)
              const _DesktopTabletEmptySamplesCard()
            else
              LayoutBuilder(
                builder: (context, constraints) {
                  final spacing = constraints.maxWidth < 980 ? 10.0 : 12.0;
                  final columns = _desktopTabletCardColumnCount(constraints.maxWidth);
                  final cardWidth = (constraints.maxWidth - spacing * (columns - 1)) / columns;
                  return Wrap(
                    spacing: spacing,
                    runSpacing: spacing,
                    children: [
                      for (final sample in samples)
                        SizedBox(
                          width: cardWidth,
                          child: _DesktopTabletBloodSampleCard(
                            sample: sample,
                            user: user,
                            tests: tests,
                            pricings: pricings,
                            selected: selectedSampleIds.contains(sample.id),
                            busy: isBusy || busySampleId == sample.id,
                            onSelectSample: onSelectSample,
                            onPrintSample: onPrintSample,
                            onReview: onReview,
                            onCancelSample: onCancelSample,
                            onDeleteSample: onDeleteSample,
                            onViewResult: onViewResult,
                            canCancelSample: canCancelSample(sample),
                            canDeleteSample: canDeleteSample(sample),
                          ),
                        ),
                    ],
                  );
                },
              ),
            if (_selectedCount > 0) ...[
              const SizedBox(height: 14),
              _DesktopTabletSelectedPrintBar(
                selected: _selectedCount,
                isBusy: isBusy,
                isPrintingSelected: isPrintingSelected,
                onClearSelection: onClearSelection,
                onPrintSelected: onPrintSelected,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _DesktopTabletSampleDeckHeader extends StatelessWidget {
  const _DesktopTabletSampleDeckHeader({
    required this.total,
    required this.shown,
    required this.completed,
    required this.selectedStatus,
    required this.onStatusFilterChanged,
    required this.selected,
    required this.isBusy,
    required this.isPrintingSelected,
    required this.onPrintSelected,
    required this.onSelectAllCompleted,
    required this.onClearSelection,
  });

  final int total;
  final int shown;
  final int completed;
  final BloodSampleStatus? selectedStatus;
  final ValueChanged<BloodSampleStatus?> onStatusFilterChanged;
  final int selected;
  final bool isBusy;
  final bool isPrintingSelected;
  final Future<void> Function() onPrintSelected;
  final void Function() onSelectAllCompleted;
  final void Function() onClearSelection;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 760;
        final title = Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                gradient: LinearGradient(colors: [theme.colorScheme.primary, theme.colorScheme.tertiary]),
              ),
              child: const Icon(Icons.bloodtype_rounded, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Blood Samples', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 3),
                  Text('$shown of $total sample records shown', style: const TextStyle(color: Color(0xFF64748B), fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ],
        );
        final actions = Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _DesktopTabletHeaderPill(icon: Icons.verified_rounded, label: 'Completed', value: '$completed', color: const Color(0xFF16A34A)),
            _DesktopTabletHeaderPill(icon: Icons.checklist_rounded, label: 'Selected', value: '$selected', color: selected > 0 ? theme.colorScheme.primary : const Color(0xFF64748B)),
            _DesktopTabletStatusFilterChips(
              selectedStatus: selectedStatus,
              onChanged: onStatusFilterChanged,
            ),
            FilledButton.icon(
              onPressed: selected > 0 && !isBusy ? () { onPrintSelected(); } : null,
              icon: isPrintingSelected
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.print_rounded),
              label: Text(selected == 0 ? 'Print selected' : 'Print selected ($selected)'),
            ),
            FilledButton.tonalIcon(
              onPressed: completed > 0 && !isBusy ? onSelectAllCompleted : null,
              icon: const Icon(Icons.done_all_rounded),
              label: const Text('Select all'),
            ),
            if (selected > 0)
              OutlinedButton.icon(
                onPressed: isBusy ? null : onClearSelection,
                icon: const Icon(Icons.clear_rounded),
                label: const Text('Clear'),
              ),
          ],
        );

        if (compact) {
          return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [title, const SizedBox(height: 12), actions]);
        }
        return Row(children: [Expanded(child: title), const SizedBox(width: 16), Flexible(child: Align(alignment: Alignment.centerRight, child: actions))]);
      },
    );
  }
}

class _DesktopTabletBloodSampleCard extends StatelessWidget {
  const _DesktopTabletBloodSampleCard({
    required this.sample,
    required this.user,
    required this.tests,
    required this.pricings,
    required this.selected,
    required this.busy,
    required this.onSelectSample,
    required this.onPrintSample,
    required this.onReview,
    required this.onCancelSample,
    required this.onDeleteSample,
    required this.onViewResult,
    required this.canCancelSample,
    required this.canDeleteSample,
  });

  final BloodSample sample;
  final AppUser? user;
  final List<LabTest> tests;
  final List<SubCenterPricing> pricings;
  final bool selected;
  final bool busy;
  final void Function(BloodSample sample, bool selected) onSelectSample;
  final Future<void> Function(BloodSample sample) onPrintSample;
  final Future<void> Function(BloodSample sample) onReview;
  final Future<void> Function(BloodSample sample) onCancelSample;
  final Future<void> Function(BloodSample sample) onDeleteSample;
  final void Function(BloodSample sample) onViewResult;
  final bool canCancelSample;
  final bool canDeleteSample;

  bool get _isCompleted => sample.status == BloodSampleStatus.completed;
  bool get _isLabTech => user?.role == AppUserRole.lab_tech;
  bool get _isStaff => user?.role == AppUserRole.staff;
  bool get _canReview => _isLabTech && sample.status != BloodSampleStatus.canceled;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final statusColor = _desktopTabletStatusColor(sample.status);
    final totalCost = _desktopTabletSampleTotalCost(sample, tests, pricings);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      curve: Curves.easeOut,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: selected ? theme.colorScheme.primary : theme.colorScheme.outlineVariant, width: selected ? 1.4 : 1),
        boxShadow: [
          BoxShadow(
            color: selected ? theme.colorScheme.primary.withValues(alpha: 0.14) : Colors.black.withValues(alpha: 0.035),
            blurRadius: selected ? 16 : 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Positioned.fill(left: 0, right: null, child: Container(width: 5, color: statusColor)),
          Padding(
            padding: const EdgeInsets.fromLTRB(13, 11, 11, 11),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _DesktopTabletCardHeader(sample: sample, selected: selected, busy: busy, onSelectSample: onSelectSample),
                const SizedBox(height: 8),
                _DesktopTabletPatientPanel(sample: sample),
                const SizedBox(height: 8),
                _DesktopTabletTestsPanel(sample: sample),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _DesktopTabletMetaPill(icon: Icons.storefront_rounded, label: 'Center', value: sample.subCenterId.trim().isEmpty ? 'GLOBAL' : sample.subCenterId.trim()),
                    _DesktopTabletMetaPill(icon: Icons.person_pin_circle_rounded, label: 'Refer', value: (sample.referredPersonName ?? '').trim().isEmpty ? '-' : sample.referredPersonName!.trim()),
                    _DesktopTabletMetaPill(icon: Icons.schedule_rounded, label: 'Date', value: _desktopTabletDateLabel(sample.createdAt)),
                    if (_isStaff) _DesktopTabletMetaPill(icon: Icons.payments_rounded, label: 'Total', value: _formatDashboardNumber(totalCost)),
                  ],
                ),
                const SizedBox(height: 10),
                _DesktopTabletActionStrip(
                  busy: busy,
                  selected: selected,
                  canView: _isCompleted,
                  canPrint: _isCompleted,
                  canSelect: _isCompleted,
                  canReview: _canReview,
                  reviewLabel: _reviewLabel(sample.status),
                  canCancel: canCancelSample,
                  canDelete: canDeleteSample,
                  onView: () => onViewResult(sample),
                  onPrint: () { onPrintSample(sample); },
                  onSelect: () => onSelectSample(sample, !selected),
                  onReview: () { onReview(sample); },
                  onCancel: () { onCancelSample(sample); },
                  onDelete: () { onDeleteSample(sample); },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DesktopTabletCardHeader extends StatelessWidget {
  const _DesktopTabletCardHeader({required this.sample, required this.selected, required this.busy, required this.onSelectSample});

  final BloodSample sample;
  final bool selected;
  final bool busy;
  final void Function(BloodSample sample, bool selected) onSelectSample;

  @override
  Widget build(BuildContext context) {
    final statusColor = _desktopTabletStatusColor(sample.status);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(12)),
          child: Icon(Icons.science_rounded, color: statusColor),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(sample.id.trim().isEmpty ? 'No sample ID' : sample.id.trim(), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF0F172A), fontWeight: FontWeight.w900, fontSize: 14)),
              const SizedBox(height: 5),
              _DesktopTabletStatusBadge(status: sample.status),
            ],
          ),
        ),
        if (sample.status == BloodSampleStatus.completed)
          Tooltip(
            message: selected ? 'Unselect sample' : 'Select sample',
            child: InkWell(
              borderRadius: BorderRadius.circular(999),
              onTap: busy ? null : () => onSelectSample(sample, !selected),
              child: Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: selected ? Theme.of(context).colorScheme.primary : const Color(0xFFF8FAFC),
                  border: Border.all(color: selected ? Theme.of(context).colorScheme.primary : const Color(0xFFE2E8F0)),
                ),
                child: Icon(selected ? Icons.check_rounded : Icons.add_rounded, color: selected ? Colors.white : const Color(0xFF64748B), size: 16),
              ),
            ),
          ),
      ],
    );
  }
}

class _DesktopTabletPatientPanel extends StatelessWidget {
  const _DesktopTabletPatientPanel({required this.sample});

  final BloodSample sample;

  @override
  Widget build(BuildContext context) {
    final patientName = sample.patientName.trim().isEmpty ? 'Unknown patient' : sample.patientName.trim();
    final patientAge = sample.patientAge.trim().isEmpty ? '-' : sample.patientAge.trim();
    final patientAddress = sample.patientAddress.trim().isEmpty ? '-' : sample.patientAddress.trim();
    return Container(
      padding: const EdgeInsets.all(9),
      decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE2E8F0))),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 420;
          final gap = compact ? 6.0 : 8.0;
          final itemWidth = compact ? constraints.maxWidth : (constraints.maxWidth - gap * 2) / 3;
          return Wrap(
            spacing: gap,
            runSpacing: 7,
            children: [
              SizedBox(width: itemWidth, child: _DesktopTabletPatientInfoTile(icon: Icons.person_outline_rounded, label: 'Name', value: patientName)),
              SizedBox(width: itemWidth, child: _DesktopTabletPatientInfoTile(icon: Icons.cake_outlined, label: 'Age', value: patientAge)),
              SizedBox(width: itemWidth, child: _DesktopTabletPatientInfoTile(icon: Icons.home_outlined, label: 'Address', value: patientAddress, maxLines: compact ? 2 : 1)),
            ],
          );
        },
      ),
    );
  }
}

class _DesktopTabletPatientInfoTile extends StatelessWidget {
  const _DesktopTabletPatientInfoTile({
    required this.icon,
    required this.label,
    required this.value,
    this.maxLines = 1,
  });

  final IconData icon;
  final String label;
  final String value;
  final int maxLines;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: const Color(0xFF0B57B7), size: 16),
        const SizedBox(width: 5),
        Flexible(
          child: RichText(
            maxLines: maxLines,
            overflow: TextOverflow.ellipsis,
            text: TextSpan(
              style: const TextStyle(color: Color(0xFF0F172A), fontSize: 12, height: 1.2),
              children: [
                TextSpan(text: '$label: ', style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF64748B))),
                TextSpan(text: value.trim().isEmpty ? '-' : value.trim(), style: const TextStyle(fontWeight: FontWeight.w900)),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _DesktopTabletTestsPanel extends StatelessWidget {
  const _DesktopTabletTestsPanel({required this.sample});

  final BloodSample sample;

  @override
  Widget build(BuildContext context) {
    final tests = sample.testIds.where((value) => value.trim().isNotEmpty).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Tests', style: TextStyle(color: Color(0xFF475569), fontSize: 12, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (tests.isEmpty)
          const Text('No tests', style: TextStyle(color: Color(0xFF94A3B8), fontWeight: FontWeight.w700))
        else
          Wrap(
            spacing: 7,
            runSpacing: 7,
            children: [
              for (final test in tests.take(4))
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                  decoration: BoxDecoration(color: const Color(0xFFEFF6FF), borderRadius: BorderRadius.circular(99), border: Border.all(color: const Color(0xFFD9E8FF))),
                  child: Text(test, style: const TextStyle(color: Color(0xFF0B57B7), fontSize: 11, fontWeight: FontWeight.w800)),
                ),
              if (tests.length > 4)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                  decoration: BoxDecoration(color: const Color(0xFFF1F5F9), borderRadius: BorderRadius.circular(99)),
                  child: Text('+${tests.length - 4} more', style: const TextStyle(color: Color(0xFF64748B), fontSize: 11, fontWeight: FontWeight.w800)),
                ),
            ],
          ),
      ],
    );
  }
}

class _DesktopTabletActionStrip extends StatelessWidget {
  const _DesktopTabletActionStrip({
    required this.busy,
    required this.selected,
    required this.canView,
    required this.canPrint,
    required this.canSelect,
    required this.canReview,
    required this.reviewLabel,
    required this.canCancel,
    required this.canDelete,
    required this.onView,
    required this.onPrint,
    required this.onSelect,
    required this.onReview,
    required this.onCancel,
    required this.onDelete,
  });

  final bool busy;
  final bool selected;
  final bool canView;
  final bool canPrint;
  final bool canSelect;
  final bool canReview;
  final String reviewLabel;
  final bool canCancel;
  final bool canDelete;
  final VoidCallback onView;
  final VoidCallback onPrint;
  final VoidCallback onSelect;
  final VoidCallback onReview;
  final VoidCallback onCancel;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        _DesktopTabletActionButton(icon: Icons.visibility_rounded, label: 'View', filled: true, enabled: !busy && canView, onPressed: onView),
        _DesktopTabletActionButton(icon: Icons.print_rounded, label: 'Print', enabled: !busy && canPrint, onPressed: onPrint),
        _DesktopTabletActionButton(icon: selected ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded, label: selected ? 'Selected' : 'Select', enabled: !busy && canSelect, onPressed: onSelect),
        if (canReview) _DesktopTabletActionButton(icon: Icons.fact_check_rounded, label: reviewLabel, filled: true, enabled: !busy, onPressed: onReview),
        if (canCancel) _DesktopTabletActionButton(icon: Icons.cancel_outlined, label: 'Cancel', danger: true, enabled: !busy, onPressed: onCancel),
        if (canDelete) _DesktopTabletActionButton(icon: Icons.delete_outline_rounded, label: 'Delete', danger: true, enabled: !busy, onPressed: onDelete),
      ],
    );
  }
}

class _DesktopTabletActionButton extends StatelessWidget {
  const _DesktopTabletActionButton({required this.icon, required this.label, required this.enabled, required this.onPressed, this.filled = false, this.danger = false});

  final IconData icon;
  final String label;
  final bool enabled;
  final VoidCallback onPressed;
  final bool filled;
  final bool danger;

  @override
  Widget build(BuildContext context) {
    final color = danger ? Theme.of(context).colorScheme.error : null;
    if (filled) {
      return FilledButton.icon(
        onPressed: enabled ? onPressed : null,
        icon: Icon(icon, size: 16),
        label: Text(label),
        style: FilledButton.styleFrom(minimumSize: const Size(82, 34), padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
      );
    }
    return OutlinedButton.icon(
      onPressed: enabled ? onPressed : null,
      icon: Icon(icon, size: 16),
      label: Text(label),
      style: OutlinedButton.styleFrom(foregroundColor: color, side: danger && color != null ? BorderSide(color: color.withValues(alpha: 0.55)) : null, minimumSize: const Size(82, 34), padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
    );
  }
}

class _DesktopTabletStatusBadge extends StatelessWidget {
  const _DesktopTabletStatusBadge({required this.status});

  final BloodSampleStatus status;

  @override
  Widget build(BuildContext context) {
    final color = _desktopTabletStatusColor(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.11), borderRadius: BorderRadius.circular(99), border: Border.all(color: color.withValues(alpha: 0.20))),
      child: Text(_desktopTabletStatusLabel(status), style: TextStyle(color: color, fontSize: 11.5, fontWeight: FontWeight.w900)),
    );
  }
}

class _DesktopTabletMetaPill extends StatelessWidget {
  const _DesktopTabletMetaPill({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 235),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(99), border: Border.all(color: const Color(0xFFE2E8F0))),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15, color: const Color(0xFF64748B)),
          const SizedBox(width: 6),
          Flexible(child: Text('$label: $value', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF475569), fontSize: 11.5, fontWeight: FontWeight.w800))),
        ],
      ),
    );
  }
}


class _DesktopTabletStatusFilterChips extends StatelessWidget {
  const _DesktopTabletStatusFilterChips({
    required this.selectedStatus,
    required this.onChanged,
  });

  final BloodSampleStatus? selectedStatus;
  final ValueChanged<BloodSampleStatus?> onChanged;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: [
        ChoiceChip(
          label: const Text('All'),
          selected: selectedStatus == null,
          onSelected: (_) => onChanged(null),
          visualDensity: VisualDensity.compact,
        ),
        for (final status in BloodSampleStatus.values)
          ChoiceChip(
            label: Text(_desktopTabletStatusLabel(status)),
            selected: selectedStatus == status,
            onSelected: (_) => onChanged(status),
            visualDensity: VisualDensity.compact,
            selectedColor: _desktopTabletStatusColor(status).withValues(alpha: 0.16),
            labelStyle: TextStyle(
              color: selectedStatus == status ? _desktopTabletStatusColor(status) : const Color(0xFF475569),
              fontWeight: FontWeight.w800,
              fontSize: 11,
            ),
          ),
      ],
    );
  }
}

class _DesktopTabletHeaderPill extends StatelessWidget {
  const _DesktopTabletHeaderPill({required this.icon, required this.label, required this.value, required this.color});

  final IconData icon;
  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(99), border: Border.all(color: color.withValues(alpha: 0.20))),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 17, color: color),
          const SizedBox(width: 7),
          Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w800)),
          Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _DesktopTabletSelectedPrintBar extends StatelessWidget {
  const _DesktopTabletSelectedPrintBar({required this.selected, required this.isBusy, required this.isPrintingSelected, required this.onClearSelection, required this.onPrintSelected});

  final int selected;
  final bool isBusy;
  final bool isPrintingSelected;
  final void Function() onClearSelection;
  final Future<void> Function() onPrintSelected;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: const Color(0xFF0B57B7), borderRadius: BorderRadius.circular(22), boxShadow: [BoxShadow(color: const Color(0xFF0B57B7).withValues(alpha: 0.20), blurRadius: 20, offset: const Offset(0, 10))]),
      child: Wrap(
        spacing: 10,
        runSpacing: 10,
        crossAxisAlignment: WrapCrossAlignment.center,
        alignment: WrapAlignment.spaceBetween,
        children: [
          Text('$selected completed sample${selected == 1 ? '' : 's'} selected', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              OutlinedButton.icon(onPressed: isBusy ? null : onClearSelection, icon: const Icon(Icons.clear_rounded), label: const Text('Clear'), style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white54))),
              FilledButton.icon(
                onPressed: isBusy ? null : () { onPrintSelected(); },
                icon: isPrintingSelected ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.print_rounded),
                label: const Text('Print selected'),
                style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: const Color(0xFF0B57B7)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _DesktopTabletEmptySamplesCard extends StatelessWidget {
  const _DesktopTabletEmptySamplesCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), border: Border.all(color: Theme.of(context).colorScheme.outlineVariant)),
      child: Column(
        children: [
          Icon(Icons.inbox_rounded, size: 48, color: Theme.of(context).colorScheme.outline),
          const SizedBox(height: 10),
          const Text('No blood samples found', style: TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          const Text('Try changing the search or status filter.'),
        ],
      ),
    );
  }
}

int _desktopTabletCardColumnCount(double width) {
  // Mobile widths below 760 px use the separate mobile sample-card branch.
  // This desktop/tablet branch should never drop below two columns, so tablet
  // users always see a denser Blood Samples card layout.
  if (width >= 1480) return 3;
  return 2;
}

Color _desktopTabletStatusColor(BloodSampleStatus status) {
  return switch (status) {
    BloodSampleStatus.pending => const Color(0xFFF59E0B),
    BloodSampleStatus.processing => const Color(0xFF2563EB),
    BloodSampleStatus.completed => const Color(0xFF16A34A),
    BloodSampleStatus.canceled => const Color(0xFF64748B),
  };
}

String _desktopTabletStatusLabel(BloodSampleStatus status) {
  return switch (status) {
    BloodSampleStatus.pending => 'Pending',
    BloodSampleStatus.processing => 'Processing',
    BloodSampleStatus.completed => 'Completed',
    BloodSampleStatus.canceled => 'Canceled',
  };
}

String _desktopTabletDateLabel(DateTime? value) {
  if (value == null) return '-';
  final local = value.toLocal();
  final year = local.year.toString().padLeft(4, '0');
  final month = local.month.toString().padLeft(2, '0');
  final day = local.day.toString().padLeft(2, '0');
  final hour = local.hour.toString().padLeft(2, '0');
  final minute = local.minute.toString().padLeft(2, '0');
  return '$year-$month-$day $hour:$minute';
}

double _desktopTabletSampleTotalCost(BloodSample sample, List<LabTest> tests, List<SubCenterPricing> pricings) {
  return sample.testIds.fold<double>(0, (sum, testIdOrName) => sum + _desktopTabletCustomerPriceFor(sample.subCenterId, testIdOrName, tests, pricings));
}

double _desktopTabletCustomerPriceFor(String subCenterId, String testIdOrName, List<LabTest> tests, List<SubCenterPricing> pricings) {
  final test = _desktopTabletTestFor(testIdOrName, tests);
  final normalizedCenter = _desktopTabletNormalize(subCenterId);
  final normalizedTestId = _desktopTabletNormalize(test.id);
  final normalizedTestName = _desktopTabletNormalize(test.testName);
  final normalizedOriginal = _desktopTabletNormalize(testIdOrName);
  for (final pricing in pricings) {
    if (_desktopTabletNormalize(pricing.subCenterId) != normalizedCenter) continue;
    final pricingTest = _desktopTabletNormalize(pricing.testId);
    if (pricingTest == normalizedTestId || pricingTest == normalizedTestName || pricingTest == normalizedOriginal) {
      return pricing.customPrice > 0 ? pricing.customPrice : test.defaultPrice;
    }
  }
  return test.defaultPrice;
}

LabTest _desktopTabletTestFor(String testIdOrName, List<LabTest> tests) {
  final normalizedInput = _desktopTabletNormalize(testIdOrName);
  for (final test in tests) {
    if (_desktopTabletNormalize(test.id) == normalizedInput || _desktopTabletNormalize(test.testName) == normalizedInput) return test;
  }
  return LabTest(id: testIdOrName, testName: testIdOrName, defaultPrice: 0);
}

String _desktopTabletNormalize(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

class _SampleDataSource extends DataTableSource {
  _SampleDataSource(
    this._samples,
    this._isSuperadmin,
    this._isLabTech,
    this._isAdmin,
    this._isStaff,
    this._tests,
    this._pricings, {
    required this.selectedSampleIds,
    required this.busySampleId,
    required this.onSelectSample,
    required this.onPrintSample,
    required this.onReview,
    required this.onCancelSample,
    required this.onDeleteSample,
    required this.onViewResult,
  });

  final List<BloodSample> _samples;
  final bool _isSuperadmin;
  final bool _isLabTech;
  final bool _isAdmin;
  final bool _isStaff;
  final List<LabTest> _tests;
  final List<SubCenterPricing> _pricings;
  final Set<String> selectedSampleIds;
  final String? busySampleId;
  final void Function(BloodSample sample, bool selected) onSelectSample;
  final Future<void> Function(BloodSample sample) onPrintSample;
  final Future<void> Function(BloodSample sample) onReview;
  final Future<void> Function(BloodSample sample) onCancelSample;
  final Future<void> Function(BloodSample sample) onDeleteSample;
  final void Function(BloodSample sample) onViewResult;

  double _sampleTotalCost(BloodSample sample) {
    return sample.testIds.fold<double>(0, (sum, testIdOrName) {
      return sum + _customerPriceFor(sample.subCenterId, testIdOrName);
    });
  }

  double _customerPriceFor(String subCenterId, String testIdOrName) {
    final test = _testFor(testIdOrName);
    final normalizedCenter = _normalize(subCenterId);
    final normalizedTestId = _normalize(test.id);
    final normalizedTestName = _normalize(test.testName);
    final normalizedOriginal = _normalize(testIdOrName);

    for (final pricing in _pricings) {
      if (_normalize(pricing.subCenterId) != normalizedCenter) continue;
      final pricingTest = _normalize(pricing.testId);
      if (pricingTest == normalizedTestId ||
          pricingTest == normalizedTestName ||
          pricingTest == normalizedOriginal) {
        return pricing.customPrice > 0 ? pricing.customPrice : test.defaultPrice;
      }
    }

    return test.defaultPrice;
  }

  LabTest _testFor(String testIdOrName) {
    final normalizedInput = _normalize(testIdOrName);
    for (final test in _tests) {
      if (_normalize(test.id) == normalizedInput ||
          _normalize(test.testName) == normalizedInput) {
        return test;
      }
    }

    return LabTest(
      id: testIdOrName,
      testName: testIdOrName,
      defaultPrice: 0,
    );
  }

  String _normalize(String value) {
    return value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
  }

  @override
  DataRow? getRow(int index) {
    if (index >= _samples.length) return null;
    final sample = _samples[index];
    final dateLabel = sample.createdAt != null
        ? sample.createdAt!.toLocal().toString().split(' ').first
        : '-';
    final testsLabel = sample.testIds.join(', ');
    final canSelectForPrint = sample.status == BloodSampleStatus.completed;
    final canCancelPending = sample.status == BloodSampleStatus.pending && (_isSuperadmin || _isAdmin || _isStaff);
    final canDeleteBloodSample = _isSuperadmin;

    return DataRow.byIndex(
      index: index,
      selected: selectedSampleIds.contains(sample.id),
      onSelectChanged: canSelectForPrint ? (selected) => onSelectSample(sample, selected ?? false) : null,
      cells: [
        DataCell(Text(sample.id)),
        DataCell(Text(sample.patientName)),
        DataCell(Text(sample.subCenterId)),
        DataCell(Text(testsLabel)),
        DataCell(Text((sample.referredPersonName ?? '').trim().isEmpty ? '-' : sample.referredPersonName!.trim())),
        if (_isStaff)
          DataCell(Text(_formatDashboardNumber(_sampleTotalCost(sample)))),
        DataCell(_StatusChip(status: sample.status)),
        DataCell(Text(dateLabel)),
        DataCell(_GeneratedResultButton(sample: sample, onView: () => onViewResult(sample), onPrint: () => onPrintSample(sample))),
        if (_isLabTech || _isAdmin || _isSuperadmin || _isStaff)
          DataCell(
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_isLabTech)
                  TextButton.icon(
                    onPressed: busySampleId == null && sample.status != BloodSampleStatus.canceled
                        ? () => onReview(sample)
                        : null,
                    icon: busySampleId == sample.id
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : Icon(
                            sample.status == BloodSampleStatus.pending
                                ? Icons.play_arrow_rounded
                                : Icons.upload_file_rounded,
                          ),
                    label: Text(
                      busySampleId == sample.id
                          ? 'Working...'
                          : _reviewLabel(sample.status),
                    ),
                  ),
                if (_isAdmin)
                  TextButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.check_circle_outline_rounded),
                    label: const Text('Approve'),
                  ),
                if (canCancelPending)
                  TextButton.icon(
                    onPressed: busySampleId == null ? () => onCancelSample(sample) : null,
                    icon: const Icon(Icons.cancel_outlined),
                    label: const Text('Cancel'),
                    style: TextButton.styleFrom(foregroundColor: const Color(0xFFDC2626)),
                  ),
                if (canDeleteBloodSample)
                  TextButton.icon(
                    onPressed: busySampleId == null ? () => onDeleteSample(sample) : null,
                    icon: const Icon(Icons.delete_outline_rounded),
                    label: const Text('Delete'),
                    style: TextButton.styleFrom(foregroundColor: const Color(0xFF991B1B)),
                  ),
              ],
            ),
          ),
      ],
    );
  }

  @override
  bool get isRowCountApproximate => false;

  @override
  int get rowCount => _samples.length;

  @override
  int get selectedRowCount => selectedSampleIds.length;
}

class _PrintableSampleResult {
  const _PrintableSampleResult({required this.sample, required this.manualRows, required this.cbcRow});
  final BloodSample sample;
  final List<Map<String, String>> manualRows;
  final Map<String, String>? cbcRow;
}


class _CbcPrintParameterDef {
  const _CbcPrintParameterDef(this.parameter, this.key, this.referenceRange, this.unit);
  final String parameter;
  final String key;
  final String referenceRange;
  final String unit;
}

class _PrintableResultRow {
  const _PrintableResultRow({
    required this.sampleId,
    required this.patientName,
    required this.testName,
    required this.parameter,
    required this.result,
    required this.unit,
    required this.referenceRange,
    required this.notes,
  });

  final String sampleId;
  final String patientName;
  final String testName;
  final String parameter;
  final String result;
  final String unit;
  final String referenceRange;
  final String notes;
}

class _MultiPrintHeaderSettings {
  const _MultiPrintHeaderSettings({
    required this.subCenterId,
    required this.hospitalName,
    required this.departmentName,
    required this.township,
    required this.ministryName,
    required this.reportTitle,
    required this.accentColor,
    required this.footerText,
  });

  final String subCenterId;
  final String hospitalName;
  final String departmentName;
  final String township;
  final String ministryName;
  final String reportTitle;
  final String accentColor;
  final String footerText;

  factory _MultiPrintHeaderSettings.defaults({required String subCenterId}) {
    return _MultiPrintHeaderSettings(
      subCenterId: subCenterId,
      hospitalName: 'AungMyin Lab',
      departmentName: 'Laboratory Department',
      township: 'Kyouttaga Township',
      ministryName: 'Ministry of Health',
      reportTitle: 'LAB REPORT',
      accentColor: '#1D4ED8',
      footerText: '',
    );
  }

  factory _MultiPrintHeaderSettings.fromMap(Map<String, String> map, {required _MultiPrintHeaderSettings fallback}) {
    String pick(String key, String fallbackValue) {
      final value = map[key]?.trim() ?? '';
      return value.isEmpty ? fallbackValue : value;
    }
    return _MultiPrintHeaderSettings(
      subCenterId: pick('subcenterid', fallback.subCenterId),
      hospitalName: pick('hospitalname', fallback.hospitalName),
      departmentName: pick('departmentname', fallback.departmentName),
      township: pick('township', fallback.township),
      ministryName: pick('ministryname', fallback.ministryName),
      reportTitle: pick('reporttitle', fallback.reportTitle),
      accentColor: pick('accentcolor', fallback.accentColor),
      footerText: pick('footertext', fallback.footerText),
    );
  }
}

String _reviewLabel(BloodSampleStatus status) {
  return switch (status) {
    BloodSampleStatus.pending => 'Start Review',
    BloodSampleStatus.processing => 'Complete + Upload',
    BloodSampleStatus.completed => 'Replace Result',
    BloodSampleStatus.canceled => 'Canceled',
  };
}


class _GeneratedResultButton extends StatelessWidget {
  const _GeneratedResultButton({required this.sample, required this.onView, required this.onPrint});

  final BloodSample sample;
  final VoidCallback onView;
  final Future<void> Function() onPrint;

  @override
  Widget build(BuildContext context) {
    final completed = sample.status == BloodSampleStatus.completed;
    if (!completed) {
      return FilledButton.tonalIcon(
        onPressed: null,
        icon: const Icon(Icons.hourglass_empty_rounded),
        label: const Text('Not ready'),
      );
    }
    return Wrap(
      alignment: WrapAlignment.start,
      spacing: 8,
      runSpacing: 8,
      children: [
        FilledButton.tonalIcon(
          onPressed: onView,
          icon: const Icon(Icons.visibility_rounded),
          label: const Text('View'),
        ),
        FilledButton.icon(
          onPressed: () {
            onPrint();
          },
          icon: const Icon(Icons.print_rounded),
          label: const Text('Print'),
        ),
      ],
    );
  }
}

class _StatusChip extends StatelessWidget {
  const _StatusChip({required this.status});

  final BloodSampleStatus status;

  @override
  Widget build(BuildContext context) {
    final color = switch (status) {
      BloodSampleStatus.pending => Colors.orange,
      BloodSampleStatus.processing => Colors.blue,
      BloodSampleStatus.completed => Colors.green,
      BloodSampleStatus.canceled => Colors.grey,
    };

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        status.name,
        style: TextStyle(color: color, fontWeight: FontWeight.w800),
      ),
    );
  }
}

class _ErrorCard extends StatelessWidget {
  const _ErrorCard({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.error_outline_rounded,
                size: 48,
                color: Theme.of(context).colorScheme.error,
              ),
              const SizedBox(height: 12),
              Text(message, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Try again'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


String _formatDashboardNumber(num value) {
  final roundedValue = value.round();
  final sign = roundedValue < 0 ? '-' : '';
  final raw = roundedValue.abs().toString();
  final buffer = StringBuffer(sign);
  for (var i = 0; i < raw.length; i++) {
    final remaining = raw.length - i;
    buffer.write(raw[i]);
    if (remaining > 1 && remaining % 3 == 1) buffer.write(',');
  }
  return buffer.toString();
}
