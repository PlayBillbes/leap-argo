import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../models/app_user.dart';
import '../providers/auth_notifier.dart';
import '../services/turso_native_service.dart';
import '../widgets/app_sidebar.dart';

class SearchPage extends ConsumerStatefulWidget {
  const SearchPage({super.key});

  @override
  ConsumerState<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends ConsumerState<SearchPage> {
  final _nameController = TextEditingController();
  final _ageController = TextEditingController();
  DateTime? _selectedDate;
  String? _selectedSex;
  Future<List<_PatientSearchRecord>>? _future;
  bool _hasSearched = false;

  @override
  void dispose() {
    _nameController.dispose();
    _ageController.dispose();
    super.dispose();
  }

  Future<TursoNativeService> _newTursoService() async {
    return TursoNativeService(
      applicationName: 'flutterlab',
    );
  }

  Future<List<_PatientSearchRecord>> _loadPatients(AppUser? user) async {
    if (user == null) return const <_PatientSearchRecord>[];
    TursoNativeService? service;
    try {
      service = await _newTursoService();
      final rows = await service.fetchRows(
        range: 'BloodSamples!A:Z',
      );
      if (rows.isEmpty) return const <_PatientSearchRecord>[];

      final headers = rows.first
          .map((h) => h.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
          .toList();

      final records = <_PatientSearchRecord>[];
      for (final row in rows.skip(1).toList().reversed) {
        final map = <String, String>{};
        for (var i = 0; i < headers.length; i++) {
          map[headers[i]] = i < row.length ? row[i].toString().trim() : '';
        }
        final record = _PatientSearchRecord.fromMap(map);
        if (record.id.isEmpty && record.patientName.isEmpty) continue;
        records.add(record);
      }

      return _filterVisibleRecords(records, user);
    } finally {
      await service?.close();
    }
  }

  String _normalizeCenter(String value) {
    final cleaned = value
        .trim()
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9]'), '');
    return cleaned.replaceAllMapped(
      RegExp(r'([a-z]+)0+(\d+)$'),
      (match) => '${match.group(1)}${match.group(2)}',
    );
  }

  List<_PatientSearchRecord> _filterVisibleRecords(List<_PatientSearchRecord> records, AppUser user) {
    // Superadmin and lab tech can search all blood samples, including GLOBAL and every sub-center.
    if (_canSeeAllBloodSamples(user)) {
      return records;
    }

    // Referred person can search only blood samples referred by their account.
    if (user.role == AppUserRole.referred_person) {
      final userId = _normalizeReferralKey(user.id);
      final userName = _normalizeReferralKey(user.name);
      return records.where((record) {
        final referredId = _normalizeReferralKey(record.referredPersonId);
        final referredName = _normalizeReferralKey(record.referredPersonName);
        if (referredId == 'self' || referredName == 'self') return false;
        if (referredId.isNotEmpty && referredId == userId) return true;
        return userName.isNotEmpty && referredName == userName;
      }).toList();
    }

    // Admin and staff can search only registered samples from their own real sub-center.
    if (user.role == AppUserRole.admin || user.role == AppUserRole.staff) {
      final center = _normalizeCenter(user.subCenterId ?? '');
      if (center.isEmpty || center == 'global') return const <_PatientSearchRecord>[];
      return records.where((record) {
        final sampleCenter = _normalizeCenter(record.subCenterId);
        return sampleCenter.isNotEmpty && sampleCenter != 'global' && sampleCenter == center;
      }).toList();
    }

    return const <_PatientSearchRecord>[];
  }

  bool _canSeeAllBloodSamples(AppUser user) {
    return user.role == AppUserRole.superadmin || user.role == AppUserRole.lab_tech;
  }

  String _normalizeReferralKey(String value) {
    return value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
  }


  void _refresh() {
    setState(() {
      _future = null;
    });
  }

  Future<void> _pullToRefresh() async {
    setState(() {
      _future = null;
    });
    await Future<void>.delayed(const Duration(milliseconds: 350));
  }

  void _clearFilters() {
    setState(() {
      _nameController.clear();
      _ageController.clear();
      _selectedSex = null;
      _selectedDate = null;
      _hasSearched = false;
    });
  }

  void _searchPatients() {
    setState(() => _hasSearched = true);
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? now,
      firstDate: DateTime(now.year - 10),
      lastDate: DateTime(now.year + 1),
    );
    if (picked != null) {
      setState(() {
        _selectedDate = picked;
        _hasSearched = false;
      });
    }
  }

  List<_PatientSearchRecord> _applyFilters(List<_PatientSearchRecord> records) {
    final query = _normalizeSearchText(_nameController.text);
    final ageQuery = _ageController.text.trim();
    final sexQuery = _selectedSex?.trim().toLowerCase();
    final filtered = records.where((record) {
      final name = _normalizeSearchText(record.patientName);
      if (query.isNotEmpty) {
        final isPhraseSearch = query.contains(' ');
        final matchesName = isPhraseSearch
            // Example: typing "Moe Moe" shows "Moe Moe" and "Moe Moe Aung",
            // but avoids broader matches where the phrase appears later in the name.
            ? name == query || name.startsWith('$query ')
            // Example: typing "Moe" shows "Moe Moe", "Moe Aung", and "Aung Moe".
            : name.split(' ').any((part) => part.contains(query)) || name.contains(query);
        if (!matchesName) return false;
      }
      if (ageQuery.isNotEmpty && record.patientAge.trim() != ageQuery) {
        return false;
      }
      if (sexQuery != null && sexQuery.isNotEmpty && record.patientSex.toLowerCase() != sexQuery) {
        return false;
      }
      if (_selectedDate != null && !_sameLocalDay(record.createdAt, _selectedDate!)) {
        return false;
      }
      return true;
    }).toList();

    if (query.isNotEmpty) {
      filtered.sort((a, b) => _nameScore(a.patientName, query).compareTo(_nameScore(b.patientName, query)));
    }
    return filtered;
  }

  String _normalizeSearchText(String value) {
    return value.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');
  }

  int _nameScore(String name, String query) {
    final normalized = _normalizeSearchText(name);
    if (normalized == query) return 0;
    if (normalized.startsWith('$query ')) return 1;
    if (normalized.startsWith(query)) return 2;
    if (normalized.split(' ').any((part) => part.startsWith(query))) return 3;
    if (normalized.contains(query)) return 4;
    return 5;
  }

  bool _sameLocalDay(DateTime? value, DateTime date) {
    if (value == null) return false;
    final local = value.toLocal();
    return local.year == date.year && local.month == date.month && local.day == date.day;
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    _future ??= _loadPatients(user);

    return AppScaffold(
      title: 'Search',
      selectedRoute: '/search',
      user: user,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Refresh patients',
          onPressed: _refresh,
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: LayoutBuilder(
        builder: (context, constraints) {
          final isMobile = constraints.maxWidth < 760;
          return Padding(
            padding: EdgeInsets.fromLTRB(isMobile ? 20 : 24, isMobile ? 8 : 8, isMobile ? 20 : 24, isMobile ? 18 : 24),
            child: FutureBuilder<List<_PatientSearchRecord>>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return _ErrorCard(message: snapshot.error.toString(), onRetry: _refresh);
            }
            final records = snapshot.data ?? const <_PatientSearchRecord>[];
            final filtered = _hasSearched ? _applyFilters(records) : const <_PatientSearchRecord>[];
            final content = _SearchContent(
              user: user,
              records: records,
              filtered: filtered,
              hasSearched: _hasSearched,
              nameController: _nameController,
              ageController: _ageController,
              selectedSex: _selectedSex,
              selectedDate: _selectedDate,
              onNameChanged: (_) => setState(() => _hasSearched = false),
              onAgeChanged: (_) => setState(() => _hasSearched = false),
              onSexChanged: (value) => setState(() {
                _selectedSex = value;
                _hasSearched = false;
              }),
              onPickDate: _pickDate,
              onClearDate: () => setState(() {
                _selectedDate = null;
                _hasSearched = false;
              }),
              onClearFilters: _clearFilters,
              onSearch: _searchPatients,
            );
            return isMobile ? RefreshIndicator(onRefresh: _pullToRefresh, child: content) : content;
          },
            ),
          );
        },
      ),
    );
  }
}

class _SearchContent extends StatelessWidget {
  const _SearchContent({
    required this.user,
    required this.records,
    required this.filtered,
    required this.hasSearched,
    required this.nameController,
    required this.ageController,
    required this.selectedSex,
    required this.selectedDate,
    required this.onNameChanged,
    required this.onAgeChanged,
    required this.onSexChanged,
    required this.onPickDate,
    required this.onClearDate,
    required this.onClearFilters,
    required this.onSearch,
  });

  final AppUser? user;
  final List<_PatientSearchRecord> records;
  final List<_PatientSearchRecord> filtered;
  final bool hasSearched;
  final TextEditingController nameController;
  final TextEditingController ageController;
  final String? selectedSex;
  final DateTime? selectedDate;
  final ValueChanged<String> onNameChanged;
  final ValueChanged<String> onAgeChanged;
  final ValueChanged<String?> onSexChanged;
  final VoidCallback onPickDate;
  final VoidCallback onClearDate;
  final VoidCallback onClearFilters;
  final VoidCallback onSearch;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _SearchHero(user: user),
          const SizedBox(height: 18),
          _FilterPanel(
            total: records.length,
            shown: filtered.length,
            nameController: nameController,
            ageController: ageController,
            selectedSex: selectedSex,
            selectedDate: selectedDate,
            onNameChanged: onNameChanged,
            onAgeChanged: onAgeChanged,
            onSexChanged: onSexChanged,
            onPickDate: onPickDate,
            onClearDate: onClearDate,
            onClearFilters: onClearFilters,
            onSearch: onSearch,
          ),
          const SizedBox(height: 18),
          _ResultsPanel(records: filtered, hasSearched: hasSearched),
        ],
      ),
    );
  }
}

class _SearchHero extends StatelessWidget {
  const _SearchHero({required this.user});

  final AppUser? user;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final width = MediaQuery.sizeOf(context).width;
    final isMobile = width < 760;
    final access = switch (user?.role) {
      AppUserRole.superadmin || AppUserRole.lab_tech => 'All centers',
      AppUserRole.admin || AppUserRole.staff => user?.subCenterId ?? 'Your center',
      _ => 'No user',
    };
    return Container(
      padding: EdgeInsets.all(isMobile ? 24 : 24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(isMobile ? 28 : 30),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0B57B7), Color(0xFF2563EB), Color(0xFF35B7E8)],
        ),
        boxShadow: [BoxShadow(color: theme.colorScheme.primary.withValues(alpha: 0.22), blurRadius: 28, offset: const Offset(0, 16))],
      ),
      child: Row(
        children: [
          Container(
            width: isMobile ? 72 : 72,
            height: isMobile ? 72 : 72,
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(22)),
            child: const Icon(Icons.manage_search_rounded, color: Colors.white, size: 36),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Patient Search',
                    style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: -0.4),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Search by patient name and filter by date, age, and sex. Scope: $access.',
                  maxLines: isMobile ? 3 : 2,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white.withValues(alpha: 0.92), height: 1.35, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


class _FilterPanel extends StatelessWidget {
  const _FilterPanel({
    required this.total,
    required this.shown,
    required this.nameController,
    required this.ageController,
    required this.selectedSex,
    required this.selectedDate,
    required this.onNameChanged,
    required this.onAgeChanged,
    required this.onSexChanged,
    required this.onPickDate,
    required this.onClearDate,
    required this.onClearFilters,
    required this.onSearch,
  });

  final int total;
  final int shown;
  final TextEditingController nameController;
  final TextEditingController ageController;
  final String? selectedSex;
  final DateTime? selectedDate;
  final ValueChanged<String> onNameChanged;
  final ValueChanged<String> onAgeChanged;
  final ValueChanged<String?> onSexChanged;
  final VoidCallback onPickDate;
  final VoidCallback onClearDate;
  final VoidCallback onClearFilters;
  final VoidCallback onSearch;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isMobile = MediaQuery.sizeOf(context).width < 760;
    final dateLabel = selectedDate == null
        ? 'Any date'
        : '${selectedDate!.year}-${selectedDate!.month.toString().padLeft(2, '0')}-${selectedDate!.day.toString().padLeft(2, '0')}';
    final inputBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(isMobile ? 14 : 20),
      borderSide: const BorderSide(color: Color(0xFFD9E3F0)),
    );
    InputDecoration inputDecoration({required String label, String? hint, required IconData icon}) {
      return InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(icon, color: const Color(0xFF4B5563)),
        filled: true,
        fillColor: theme.colorScheme.surface,
        isDense: isMobile,
        contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: isMobile ? 13 : 16),
        border: inputBorder,
        enabledBorder: inputBorder,
        focusedBorder: inputBorder.copyWith(borderSide: const BorderSide(color: Color(0xFF0B57B7), width: 1.5)),
      );
    }

    final nameField = TextField(
      controller: nameController,
      onChanged: onNameChanged,
      textInputAction: TextInputAction.search,
      onSubmitted: (_) => onSearch(),
      decoration: inputDecoration(label: 'Patient name', hint: 'Type patient name', icon: Icons.person_search_rounded),
    );
    final ageField = TextField(
      controller: ageController,
      keyboardType: TextInputType.number,
      onChanged: onAgeChanged,
      textInputAction: TextInputAction.search,
      onSubmitted: (_) => onSearch(),
      decoration: inputDecoration(label: 'Age', hint: 'Exact age', icon: Icons.cake_rounded),
    );
    final sexField = DropdownButtonFormField<String>(
      value: selectedSex,
      decoration: inputDecoration(label: 'Sex', icon: Icons.wc_rounded),
      items: const [
        DropdownMenuItem(value: 'Male', child: Text('Male')),
        DropdownMenuItem(value: 'Female', child: Text('Female')),
        DropdownMenuItem(value: 'Other', child: Text('Other')),
      ],
      onChanged: onSexChanged,
    );
    final dateButton = _DateFilterButton(label: dateLabel, onPick: onPickDate, onClear: onClearDate, hasDate: selectedDate != null);

    final header = isMobile
        ? Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(17),
                      gradient: const LinearGradient(colors: [Color(0xFF0B57B7), Color(0xFF2563EB)]),
                      boxShadow: [BoxShadow(color: theme.colorScheme.primary.withValues(alpha: 0.20), blurRadius: 16, offset: const Offset(0, 8))],
                    ),
                    child: const Icon(Icons.tune_rounded, color: Colors.white, size: 26),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Search criteria', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900, letterSpacing: -0.3)),
                        const SizedBox(height: 4),
                        Text(
                          'Enter filters, then press Search Patients to show results.',
                          style: theme.textTheme.bodyMedium?.copyWith(color: const Color(0xFF526070), height: 1.35, fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Wrap(spacing: 8, runSpacing: 8, children: [_StatPill(label: 'Available', value: '$total'), _StatPill(label: 'Shown', value: '$shown')]),
            ],
          )
        : Row(
            children: [
              Container(
                padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: const LinearGradient(colors: [Color(0xFF0B57B7), Color(0xFF2563EB)]),
                  boxShadow: [BoxShadow(color: theme.colorScheme.primary.withValues(alpha: 0.20), blurRadius: 16, offset: const Offset(0, 8))],
                ),
                child: const Icon(Icons.tune_rounded, color: Colors.white),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Search criteria', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 4),
                    const Text('Enter filters, then press Search Patients to show results.'),
                  ],
                ),
              ),
              _StatPill(label: 'Available', value: '$total'),
              const SizedBox(width: 8),
              _StatPill(label: 'Shown', value: '$shown'),
            ],
          );

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface.withValues(alpha: 0.98),
        borderRadius: BorderRadius.circular(isMobile ? 24 : 30),
        border: Border.all(color: theme.colorScheme.primary.withValues(alpha: 0.13)),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [theme.colorScheme.primary.withValues(alpha: 0.06), theme.colorScheme.tertiary.withValues(alpha: 0.035), theme.colorScheme.surface.withValues(alpha: 0.01)],
        ),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.035), blurRadius: 18, offset: const Offset(0, 9))],
      ),
      padding: EdgeInsets.all(isMobile ? 16 : 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          header,
          SizedBox(height: isMobile ? 16 : 18),
          if (isMobile) ...[
            nameField,
            const SizedBox(height: 12),
            Row(children: [Expanded(child: ageField), const SizedBox(width: 12), Expanded(child: sexField)]),
            const SizedBox(height: 12),
            dateButton,
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(child: OutlinedButton.icon(onPressed: onClearFilters, icon: const Icon(Icons.clear_all_rounded), label: const Text('Clear'))),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: FilledButton.icon(
                    onPressed: onSearch,
                    icon: const Icon(Icons.search_rounded),
                    label: const Text('Search Patients'),
                    style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                  ),
                ),
              ],
            ),
          ] else ...[
            LayoutBuilder(builder: (context, constraints) {
              final compact = constraints.maxWidth < 920;
              if (compact) {
                return Column(
                  children: [nameField, const SizedBox(height: 12), Row(children: [Expanded(child: ageField), const SizedBox(width: 12), Expanded(child: sexField)]), const SizedBox(height: 12), Align(alignment: Alignment.centerLeft, child: dateButton)],
                );
              }
              return Row(children: [Expanded(flex: 3, child: nameField), const SizedBox(width: 12), Expanded(child: ageField), const SizedBox(width: 12), Expanded(child: sexField), const SizedBox(width: 12), dateButton]);
            }),
            const SizedBox(height: 18),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              alignment: WrapAlignment.end,
              children: [
                OutlinedButton.icon(onPressed: onClearFilters, icon: const Icon(Icons.clear_all_rounded), label: const Text('Clear filters')),
                FilledButton.icon(onPressed: onSearch, icon: const Icon(Icons.search_rounded), label: const Text('Search Patients'), style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)))),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _DateFilterButton extends StatelessWidget {
  const _DateFilterButton({required this.label, required this.onPick, required this.onClear, required this.hasDate});

  final String label;
  final VoidCallback onPick;
  final VoidCallback onClear;
  final bool hasDate;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        FilledButton.tonalIcon(onPressed: onPick, icon: const Icon(Icons.event_rounded), label: Text(label)),
        if (hasDate) IconButton.filledTonal(onPressed: onClear, icon: const Icon(Icons.close_rounded)),
      ],
    );
  }
}

class _ResultsPanel extends StatelessWidget {
  const _ResultsPanel({required this.records, required this.hasSearched});

  final List<_PatientSearchRecord> records;
  final bool hasSearched;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isMobile = MediaQuery.sizeOf(context).width < 760;
    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface.withValues(alpha: 0.96),
        borderRadius: BorderRadius.circular(isMobile ? 22 : 26),
        border: Border.all(color: const Color(0xFFE5EAF3)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 14, offset: const Offset(0, 7))],
      ),
      padding: EdgeInsets.all(isMobile ? 16 : 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text('Search Results', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900, letterSpacing: -0.3))),
              if (hasSearched) _StatPill(label: 'Found', value: '${records.length}'),
            ],
          ),
          SizedBox(height: isMobile ? 12 : 14),
          if (!hasSearched)
            const _SearchWaitingCard()
          else if (records.isEmpty)
            const _EmptyResults()
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: records.length,
              separatorBuilder: (_, __) => SizedBox(height: isMobile ? 10 : 10),
              itemBuilder: (context, index) => _PatientResultTile(record: records[index]),
            ),
        ],
      ),
    );
  }
}

class _PatientResultTile extends StatelessWidget {
  const _PatientResultTile({required this.record});

  final _PatientSearchRecord record;

  bool get _isCompleted => record.status.trim().toLowerCase() == 'completed';

  void _viewResult(BuildContext context) {
    context.go('/sample-result/${Uri.encodeComponent(record.id)}');
  }

  Color _statusColor(String status) {
    switch (status.trim().toLowerCase()) {
      case 'completed':
        return const Color(0xFF16A34A);
      case 'processing':
        return const Color(0xFF0B6BD3);
      default:
        return const Color(0xFFF59E0B);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final statusColor = _statusColor(record.status);
    final patientName = record.patientName.isEmpty ? 'Unknown patient' : record.patientName;
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: const Color(0xFFE5EAF3)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 12, offset: const Offset(0, 6))],
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Positioned.fill(left: 0, right: null, child: SizedBox(width: 4, child: DecoratedBox(decoration: BoxDecoration(color: statusColor)))),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 14, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 21,
                      backgroundColor: statusColor.withValues(alpha: 0.12),
                      foregroundColor: statusColor,
                      child: Text(patientName.characters.first.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w900)),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(patientName, maxLines: 1, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900, color: const Color(0xFF111827))),
                          const SizedBox(height: 3),
                          Text('${record.subCenterId} • ${record.dateLabel}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF64748B), fontWeight: FontWeight.w700, fontSize: 12)),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                      decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(99)),
                      child: Text(record.status.isEmpty ? 'Pending' : record.status, style: TextStyle(color: statusColor, fontSize: 11, fontWeight: FontWeight.w900)),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _InfoChip(icon: Icons.biotech_rounded, label: 'Tests', value: record.testIds.isEmpty ? '-' : record.testIds),
                    _InfoChip(icon: Icons.badge_rounded, label: 'Sample', value: record.id),
                    _InfoChip(icon: Icons.person_rounded, label: 'Age/Sex', value: record.sexAgeLabel),
                    if (record.patientAddress.isNotEmpty) _InfoChip(icon: Icons.home_rounded, label: 'Address', value: record.patientAddress),
                  ],
                ),
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerRight,
                  child: FilledButton.icon(
                    onPressed: _isCompleted ? () => _viewResult(context) : null,
                    icon: Icon(_isCompleted ? Icons.visibility_rounded : Icons.hourglass_empty_rounded),
                    label: Text(_isCompleted ? 'View Result' : 'Not Ready'),
                    style: FilledButton.styleFrom(
                      backgroundColor: _isCompleted ? const Color(0xFF0B6BD3) : null,
                      foregroundColor: _isCompleted ? Colors.white : null,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  const _InfoChip({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0xFFF0F6FF),
        borderRadius: BorderRadius.circular(99),
        border: Border.all(color: const Color(0xFFD9E8FF)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15, color: const Color(0xFF0B6BD3)),
          const SizedBox(width: 6),
          Flexible(
            child: Text('$label: $value', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF405064), fontSize: 11.5, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }
}

class _StatPill extends StatelessWidget {
  const _StatPill({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(99),
        color: color.withValues(alpha: 0.10),
        border: Border.all(color: color.withValues(alpha: 0.22)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w800)),
          Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}


class _SearchWaitingCard extends StatelessWidget {
  const _SearchWaitingCard();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.35),
        border: Border.all(color: theme.colorScheme.outlineVariant),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(colors: [Color(0xFF0B57B7), Color(0xFF2563EB)]),
              boxShadow: [
                BoxShadow(color: theme.colorScheme.primary.withValues(alpha: 0.20), blurRadius: 18, offset: const Offset(0, 8)),
              ],
            ),
            child: const Icon(Icons.manage_search_rounded, color: Colors.white, size: 34),
          ),
          const SizedBox(height: 16),
          Text('Ready to search', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          const Text('Set filters and click Search Patients to show matching patient records.'),
        ],
      ),
    );
  }
}

class _EmptyResults extends StatelessWidget {
  const _EmptyResults();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.search_off_rounded, size: 50, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 12),
            const Text('No patients found'),
            const SizedBox(height: 4),
            const Text('Try changing the search keyword or filters.'),
          ],
        ),
      ),
    );
  }
}

class _ErrorCard extends StatelessWidget {
  const _ErrorCard({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.error_outline_rounded, color: Theme.of(context).colorScheme.error, size: 48),
              const SizedBox(height: 12),
              const Text('Failed to load patients'),
              const SizedBox(height: 8),
              Text(message, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh_rounded), label: const Text('Try again')),
            ],
          ),
        ),
      ),
    );
  }
}

class _PatientSearchRecord {
  const _PatientSearchRecord({
    required this.id,
    required this.patientName,
    required this.patientAge,
    required this.patientSex,
    required this.patientAddress,
    required this.subCenterId,
    required this.referredPersonId,
    required this.referredPersonName,
    required this.registeredByUserId,
    required this.testIds,
    required this.status,
    required this.resultFileUrl,
    required this.createdAt,
  });

  final String id;
  final String patientName;
  final String patientAge;
  final String patientSex;
  final String patientAddress;
  final String subCenterId;
  final String referredPersonId;
  final String referredPersonName;
  final String registeredByUserId;
  final String testIds;
  final String status;
  final String resultFileUrl;
  final DateTime? createdAt;

  String get dateLabel => createdAt == null ? '-' : createdAt!.toLocal().toString().split(' ').first;
  String get sexAgeLabel {
    final parts = <String>[];
    if (patientAge.isNotEmpty) parts.add('$patientAge yrs');
    if (patientSex.isNotEmpty) parts.add(patientSex);
    return parts.isEmpty ? 'No age/sex' : parts.join(' • ');
  }

  factory _PatientSearchRecord.fromMap(Map<String, String> map) {
    return _PatientSearchRecord(
      id: map['id'] ?? map['sampleid'] ?? '',
      patientName: map['patientname'] ?? map['patient'] ?? map['name'] ?? '',
      patientAge: map['patientage'] ?? map['age'] ?? '',
      patientSex: map['patientsex'] ?? map['sex'] ?? map['gender'] ?? '',
      patientAddress: map['patientaddress'] ?? map['address'] ?? '',
      subCenterId: map['subcenterid'] ?? map['subcenter'] ?? map['center'] ?? 'GLOBAL',
      referredPersonId: map['referredpersonid'] ?? map['referedpersonid'] ?? map['referredbyid'] ?? '',
      referredPersonName: map['referredpersonname'] ?? map['referedpersonname'] ?? map['referredbyname'] ?? '',
      registeredByUserId: map['registeredbyuserid'] ?? map['registeredby'] ?? '',
      testIds: map['testids'] ?? map['tests'] ?? '',
      status: map['status'] ?? 'pending',
      resultFileUrl: map['resulturl'] ?? map['resultfileurl'] ?? map['result'] ?? '',
      createdAt: _parseDate(map['createdat'] ?? map['created'] ?? ''),
    );
  }

  static DateTime? _parseDate(String value) {
    final raw = value.trim();
    if (raw.isEmpty) return null;
    final direct = DateTime.tryParse(raw);
    if (direct != null) return direct;
    final match = RegExp(r'^(\d{4})[-/](\d{1,2})[-/](\d{1,2})[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?').firstMatch(raw);
    if (match == null) return null;
    final year = int.tryParse(match.group(1) ?? '');
    final month = int.tryParse(match.group(2) ?? '');
    final day = int.tryParse(match.group(3) ?? '');
    final hour = int.tryParse(match.group(4) ?? '') ?? 0;
    final minute = int.tryParse(match.group(5) ?? '') ?? 0;
    final second = int.tryParse(match.group(6) ?? '0') ?? 0;
    if (year == null || month == null || day == null) return null;
    return DateTime(year, month, day, hour, minute, second);
  }
}
