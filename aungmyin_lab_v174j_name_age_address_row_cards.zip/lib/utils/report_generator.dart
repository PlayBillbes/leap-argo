import '../models/blood_sample.dart';
import '../models/lab_test.dart';
import '../models/sub_center_pricing.dart';

class ReportGenerator {
  ReportGenerator({
    required this.samples,
    required this.tests,
    required this.pricings,
    this.useCustomerPrices = true,
  });

  final List<BloodSample> samples;
  final List<LabTest> tests;
  final List<SubCenterPricing> pricings;
  final bool useCustomerPrices;

  double totalDailyRevenue(DateTime date) {
    final normalizedDate = DateTime(date.year, date.month, date.day);
    return samples
        .where((sample) => sample.createdAt != null)
        .where((sample) {
          final created = sample.createdAt!.toLocal();
          final sampleDate = DateTime(created.year, created.month, created.day);
          return sampleDate == normalizedDate;
        })
        .fold(0.0, (sum, sample) => sum + _sampleRevenue(sample));
  }

  double totalMonthlyRevenue(DateTime date) {
    return samples
        .where((sample) => sample.createdAt != null)
        .where((sample) {
          final created = sample.createdAt!.toLocal();
          return created.year == date.year && created.month == date.month;
        })
        .fold(0.0, (sum, sample) => sum + _sampleRevenue(sample));
  }

  double totalYearlyRevenue(DateTime date) {
    return samples
        .where((sample) => sample.createdAt != null)
        .where((sample) => sample.createdAt!.toLocal().year == date.year)
        .fold(0.0, (sum, sample) => sum + _sampleRevenue(sample));
  }


  int totalDailyTests(DateTime date) {
    final normalizedDate = DateTime(date.year, date.month, date.day);
    return samples
        .where((sample) => sample.createdAt != null)
        .where((sample) {
          final created = sample.createdAt!.toLocal();
          final sampleDate = DateTime(created.year, created.month, created.day);
          return sampleDate == normalizedDate;
        })
        .fold<int>(0, (sum, sample) => sum + sample.testIds.length);
  }

  int totalMonthlyTests(DateTime date) {
    return samples
        .where((sample) => sample.createdAt != null)
        .where((sample) {
          final created = sample.createdAt!.toLocal();
          return created.year == date.year && created.month == date.month;
        })
        .fold<int>(0, (sum, sample) => sum + sample.testIds.length);
  }

  int totalYearlyTests(DateTime date) {
    return samples
        .where((sample) => sample.createdAt != null)
        .where((sample) => sample.createdAt!.toLocal().year == date.year)
        .fold<int>(0, (sum, sample) => sum + sample.testIds.length);
  }


  Map<String, int> totalTestCountByNameForDay(DateTime date) {
    final normalizedDate = DateTime(date.year, date.month, date.day);
    return _testCountByName(
      samples.where((sample) {
        if (sample.createdAt == null) return false;
        final created = sample.createdAt!.toLocal();
        final sampleDate = DateTime(created.year, created.month, created.day);
        return sampleDate == normalizedDate;
      }),
    );
  }

  Map<String, int> totalTestCountByNameForMonth(DateTime date) {
    return _testCountByName(
      samples.where((sample) {
        if (sample.createdAt == null) return false;
        final created = sample.createdAt!.toLocal();
        return created.year == date.year && created.month == date.month;
      }),
    );
  }

  Map<String, int> totalTestCountByNameForYear(DateTime date) {
    return _testCountByName(
      samples.where((sample) {
        if (sample.createdAt == null) return false;
        return sample.createdAt!.toLocal().year == date.year;
      }),
    );
  }


  Map<String, int> pendingTestCountByNameForDay(DateTime date) {
    final normalizedDate = DateTime(date.year, date.month, date.day);
    return _testCountByName(
      samples.where((sample) {
        if (sample.status != BloodSampleStatus.pending) return false;
        if (sample.createdAt == null) return false;
        final created = sample.createdAt!.toLocal();
        final sampleDate = DateTime(created.year, created.month, created.day);
        return sampleDate == normalizedDate;
      }),
    );
  }

  Map<String, int> pendingTestCountByNameForMonth(DateTime date) {
    return _testCountByName(
      samples.where((sample) {
        if (sample.status != BloodSampleStatus.pending) return false;
        if (sample.createdAt == null) return false;
        final created = sample.createdAt!.toLocal();
        return created.year == date.year && created.month == date.month;
      }),
    );
  }

  Map<String, int> pendingTestCountByNameForYear(DateTime date) {
    return _testCountByName(
      samples.where((sample) {
        if (sample.status != BloodSampleStatus.pending) return false;
        if (sample.createdAt == null) return false;
        return sample.createdAt!.toLocal().year == date.year;
      }),
    );
  }

  int pendingTestTotalForDay(DateTime date) {
    return pendingTestCountByNameForDay(date)
        .values
        .fold<int>(0, (sum, count) => sum + count);
  }

  int pendingTestTotalForMonth(DateTime date) {
    return pendingTestCountByNameForMonth(date)
        .values
        .fold<int>(0, (sum, count) => sum + count);
  }

  int pendingTestTotalForYear(DateTime date) {
    return pendingTestCountByNameForYear(date)
        .values
        .fold<int>(0, (sum, count) => sum + count);
  }

  Map<String, int> _testCountByName(Iterable<BloodSample> sourceSamples) {
    final counts = <String, int>{};
    for (final sample in sourceSamples) {
      for (final testIdOrName in sample.testIds) {
        final label = _testFor(testIdOrName).testName;
        counts[label] = (counts[label] ?? 0) + 1;
      }
    }

    final entries = counts.entries.toList()
      ..sort((a, b) {
        final byCount = b.value.compareTo(a.value);
        if (byCount != 0) return byCount;
        return a.key.compareTo(b.key);
      });

    return Map<String, int>.fromEntries(entries);
  }

  double totalReferredFee() {
    if (!useCustomerPrices) return 0.0;
    return samples.fold(0.0, (sum, sample) => sum + _sampleReferredFee(sample));
  }

  double totalDailyReferredFee(DateTime date) {
    if (!useCustomerPrices) return 0.0;
    final normalizedDate = DateTime(date.year, date.month, date.day);
    return samples
        .where((sample) => sample.createdAt != null)
        .where((sample) {
          final created = sample.createdAt!.toLocal();
          final sampleDate = DateTime(created.year, created.month, created.day);
          return sampleDate == normalizedDate;
        })
        .fold(0.0, (sum, sample) => sum + _sampleReferredFee(sample));
  }

  double totalMonthlyReferredFee(DateTime date) {
    if (!useCustomerPrices) return 0.0;
    return samples
        .where((sample) => sample.createdAt != null)
        .where((sample) {
          final created = sample.createdAt!.toLocal();
          return created.year == date.year && created.month == date.month;
        })
        .fold(0.0, (sum, sample) => sum + _sampleReferredFee(sample));
  }

  double totalYearlyReferredFee(DateTime date) {
    if (!useCustomerPrices) return 0.0;
    return samples
        .where((sample) => sample.createdAt != null)
        .where((sample) => sample.createdAt!.toLocal().year == date.year)
        .fold(0.0, (sum, sample) => sum + _sampleReferredFee(sample));
  }

  double totalDailyProfit(DateTime date) {
    if (!useCustomerPrices) return 0.0;
    final normalizedDate = DateTime(date.year, date.month, date.day);
    return samples
        .where((sample) => sample.createdAt != null)
        .where((sample) {
          final created = sample.createdAt!.toLocal();
          final sampleDate = DateTime(created.year, created.month, created.day);
          return sampleDate == normalizedDate;
        })
        .fold(0.0, (sum, sample) => sum + _sampleProfit(sample));
  }

  double totalMonthlyProfit(DateTime date) {
    if (!useCustomerPrices) return 0.0;
    return samples
        .where((sample) => sample.createdAt != null)
        .where((sample) {
          final created = sample.createdAt!.toLocal();
          return created.year == date.year && created.month == date.month;
        })
        .fold(0.0, (sum, sample) => sum + _sampleProfit(sample));
  }

  double totalYearlyProfit(DateTime date) {
    if (!useCustomerPrices) return 0.0;
    return samples
        .where((sample) => sample.createdAt != null)
        .where((sample) => sample.createdAt!.toLocal().year == date.year)
        .fold(0.0, (sum, sample) => sum + _sampleProfit(sample));
  }

  double subCenterProfit(String subCenterId) {
    if (!useCustomerPrices) return 0.0;
    return samples
        .where((sample) => _normalize(sample.subCenterId) == _normalize(subCenterId))
        .fold(0.0, (profit, sample) => profit + _sampleProfit(sample));
  }

  double _sampleRevenue(BloodSample sample) {
    return sample.testIds.fold(0.0, (sum, testId) {
      return sum +
          (useCustomerPrices
              ? _customerPriceFor(sample.subCenterId, testId)
              : _globalPriceFor(testId));
    });
  }

  double _sampleProfit(BloodSample sample) {
    if (!useCustomerPrices) return 0.0;
    final baseProfit = sample.testIds.fold(0.0, (sum, testId) {
      final global = _globalPriceFor(testId);
      final customer = _customerPriceFor(sample.subCenterId, testId);
      return sum + (customer - global);
    });
    return baseProfit - _sampleReferredFee(sample);
  }

  double _sampleReferredFee(BloodSample sample) {
    if (!useCustomerPrices || _isSelfReferral(sample)) return 0.0;
    if (sample.referredFeeAmount > 0) return sample.referredFeeAmount;
    return sample.testIds.fold(0.0, (sum, testId) {
      final customer = _customerPriceFor(sample.subCenterId, testId);
      final percent = _referredFeePercentFor(sample.subCenterId, testId);
      return sum + (customer * percent / 100);
    });
  }

  bool _isSelfReferral(BloodSample sample) {
    final id = _normalize(sample.referredPersonId ?? '');
    final name = _normalize(sample.referredPersonName ?? '');
    return id.isEmpty || id == 'self' || name == 'self';
  }

  double _globalPriceFor(String testIdOrName) => _testFor(testIdOrName).defaultPrice;

  double _customerPriceFor(String subCenterId, String testIdOrName) {
    final test = _testFor(testIdOrName);
    final global = test.defaultPrice;
    final pricing = _pricingFor(
      subCenterId: subCenterId,
      test: test,
      originalTestValue: testIdOrName,
    );
    return pricing != null && pricing.customPrice > 0 ? pricing.customPrice : global;
  }

  double _referredFeePercentFor(String subCenterId, String testIdOrName) {
    final test = _testFor(testIdOrName);
    final pricing = _pricingFor(
      subCenterId: subCenterId,
      test: test,
      originalTestValue: testIdOrName,
    );
    return pricing?.referredFeePercent ?? 0;
  }

  LabTest _testFor(String testIdOrName) {
    final normalizedInput = _normalize(testIdOrName);
    for (final test in tests) {
      if (_normalize(test.id) == normalizedInput || _normalize(test.testName) == normalizedInput) {
        return test;
      }
    }
    return LabTest(id: testIdOrName, testName: testIdOrName, defaultPrice: 0);
  }

  SubCenterPricing? _pricingFor({
    required String subCenterId,
    required LabTest test,
    required String originalTestValue,
  }) {
    final normalizedCenter = _normalize(subCenterId);
    final normalizedTestId = _normalize(test.id);
    final normalizedTestName = _normalize(test.testName);
    final normalizedOriginal = _normalize(originalTestValue);
    for (final pricing in pricings) {
      if (_normalize(pricing.subCenterId) != normalizedCenter) continue;
      final pricingTest = _normalize(pricing.testId);
      if (pricingTest == normalizedTestId || pricingTest == normalizedTestName || pricingTest == normalizedOriginal) {
        return pricing;
      }
    }
    return null;
  }

  String _normalize(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  Map<String, double> revenueBySubCenter() {
    final Map<String, double> revenueMap = {};
    for (final sample in samples) {
      final revenue = _sampleRevenue(sample);
      revenueMap[sample.subCenterId] = (revenueMap[sample.subCenterId] ?? 0.0) + revenue;
    }
    return revenueMap;
  }

  Map<String, double> profitBySubCenter() {
    final Map<String, double> profitMap = {};
    for (final sample in samples) {
      final profit = _sampleProfit(sample);
      profitMap[sample.subCenterId] = (profitMap[sample.subCenterId] ?? 0.0) + profit;
    }
    return profitMap;
  }

  Map<String, double> referredFeeBySubCenter() {
    final Map<String, double> feeMap = {};
    for (final sample in samples) {
      final fee = _sampleReferredFee(sample);
      feeMap[sample.subCenterId] = (feeMap[sample.subCenterId] ?? 0.0) + fee;
    }
    return feeMap;
  }

  Map<BloodSampleStatus, double> revenueByStatus() {
    final Map<BloodSampleStatus, double> revenueMap = {};
    for (final sample in samples) {
      final revenue = _sampleRevenue(sample);
      revenueMap[sample.status] = (revenueMap[sample.status] ?? 0.0) + revenue;
    }
    return revenueMap;
  }

  Map<BloodSampleStatus, double> profitByStatus() {
    final Map<BloodSampleStatus, double> profitMap = {};
    for (final sample in samples) {
      final profit = _sampleProfit(sample);
      profitMap[sample.status] = (profitMap[sample.status] ?? 0.0) + profit;
    }
    return profitMap;
  }

  Map<BloodSampleStatus, double> referredFeeByStatus() {
    final Map<BloodSampleStatus, double> feeMap = {};
    for (final sample in samples) {
      final fee = _sampleReferredFee(sample);
      feeMap[sample.status] = (feeMap[sample.status] ?? 0.0) + fee;
    }
    return feeMap;
  }

  Map<String, int> sampleCountBySubCenter() {
    final Map<String, int> countMap = {};
    for (final sample in samples) {
      countMap[sample.subCenterId] = (countMap[sample.subCenterId] ?? 0) + 1;
    }
    return countMap;
  }

  Map<BloodSampleStatus, int> sampleCountByStatus() {
    final Map<BloodSampleStatus, int> countMap = {};
    for (final sample in samples) {
      countMap[sample.status] = (countMap[sample.status] ?? 0) + 1;
    }
    return countMap;
  }

  RevenueSummary groupedRevenueSummary({bool includeCounts = false}) {
    return RevenueSummary(
      bySubCenter: revenueBySubCenter(),
      byStatus: revenueByStatus(),
      profitBySubCenter: profitBySubCenter(),
      profitByStatus: profitByStatus(),
      referredFeeBySubCenter: referredFeeBySubCenter(),
      referredFeeByStatus: referredFeeByStatus(),
      countBySubCenter: includeCounts ? sampleCountBySubCenter() : const <String, int>{},
      countByStatus: includeCounts ? sampleCountByStatus() : const <BloodSampleStatus, int>{},
    );
  }
}

class RevenueSummary {
  RevenueSummary({
    required this.bySubCenter,
    required this.byStatus,
    this.profitBySubCenter = const {},
    this.profitByStatus = const {},
    this.referredFeeBySubCenter = const {},
    this.referredFeeByStatus = const {},
    this.countBySubCenter = const {},
    this.countByStatus = const {},
  });

  final Map<String, double> bySubCenter;
  final Map<BloodSampleStatus, double> byStatus;
  final Map<String, double> profitBySubCenter;
  final Map<BloodSampleStatus, double> profitByStatus;
  final Map<String, double> referredFeeBySubCenter;
  final Map<BloodSampleStatus, double> referredFeeByStatus;
  final Map<String, int> countBySubCenter;
  final Map<BloodSampleStatus, int> countByStatus;
}
