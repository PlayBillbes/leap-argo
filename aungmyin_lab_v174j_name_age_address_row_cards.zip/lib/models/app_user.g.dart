// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_user.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_AppUser _$AppUserFromJson(Map<String, dynamic> json) => _AppUser(
  id: json['id'] as String,
  name: json['name'] as String,
  role: $enumDecode(_$AppUserRoleEnumMap, json['role']),
  subCenterId: json['subCenterId'] as String?,
);

Map<String, dynamic> _$AppUserToJson(_AppUser instance) => <String, dynamic>{
  'id': instance.id,
  'name': instance.name,
  'role': _$AppUserRoleEnumMap[instance.role]!,
  'subCenterId': instance.subCenterId,
};

const _$AppUserRoleEnumMap = {
  AppUserRole.superadmin: 'superadmin',
  AppUserRole.admin: 'admin',
  AppUserRole.lab_tech: 'lab_tech',
  AppUserRole.staff: 'staff',
  AppUserRole.referred_person: 'referred_person',
};
