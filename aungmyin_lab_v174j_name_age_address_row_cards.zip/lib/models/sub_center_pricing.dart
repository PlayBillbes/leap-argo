class SubCenterPricing {
  const SubCenterPricing({
    required this.subCenterId,
    required this.testId,
    required this.customPrice,
    this.referredFeePercent = 0,
  });

  final String subCenterId;
  final String testId;
  final double customPrice;
  final double referredFeePercent;

  factory SubCenterPricing.fromJson(Map<String, Object?> json) {
    return SubCenterPricing(
      subCenterId: (json['subCenterId'] ?? '').toString(),
      testId: (json['testId'] ?? '').toString(),
      customPrice: _toDouble(json['customPrice']),
      referredFeePercent: _toDouble(json['referredFeePercent']),
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'subCenterId': subCenterId,
        'testId': testId,
        'customPrice': customPrice,
        'referredFeePercent': referredFeePercent,
      };

  SubCenterPricing copyWith({
    String? subCenterId,
    String? testId,
    double? customPrice,
    double? referredFeePercent,
  }) {
    return SubCenterPricing(
      subCenterId: subCenterId ?? this.subCenterId,
      testId: testId ?? this.testId,
      customPrice: customPrice ?? this.customPrice,
      referredFeePercent: referredFeePercent ?? this.referredFeePercent,
    );
  }

  static double _toDouble(Object? value) {
    if (value is num) return value.toDouble();
    return double.tryParse((value ?? '0').toString()) ?? 0;
  }
}
