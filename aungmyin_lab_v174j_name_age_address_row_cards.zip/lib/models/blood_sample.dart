enum BloodSampleStatus { pending, processing, completed, canceled }

class BloodSample {
  const BloodSample({
    required this.id,
    required this.patientName,
    required this.subCenterId,
    required this.registeredByUserId,
    required this.testIds,
    required this.status,
    this.resultFileUrl,
    this.patientAge = '',
    this.patientAddress = '',
    this.createdAt,
    this.updatedAt,
    this.referredPersonId,
    this.referredPersonName,
    this.referredFeePercent = 0,
    this.referredFeeAmount = 0,
  });

  final String id;
  final String patientName;
  final String subCenterId;
  final String registeredByUserId;
  final List<String> testIds;
  final BloodSampleStatus status;
  final String? resultFileUrl;
  final String patientAge;
  final String patientAddress;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? referredPersonId;
  final String? referredPersonName;
  final double referredFeePercent;
  final double referredFeeAmount;

  factory BloodSample.fromJson(Map<String, Object?> json) {
    final statusRaw = (json['status'] ?? 'pending').toString();
    return BloodSample(
      id: (json['id'] ?? '').toString(),
      patientName: (json['patientName'] ?? '').toString(),
      subCenterId: (json['subCenterId'] ?? 'GLOBAL').toString(),
      registeredByUserId: (json['registeredByUserId'] ?? '').toString(),
      testIds: (json['testIds'] is List)
          ? (json['testIds'] as List).map((item) => item.toString()).toList()
          : (json['testIds'] ?? '').toString().split(',').map((item) => item.trim()).where((item) => item.isNotEmpty).toList(),
      status: BloodSampleStatus.values.firstWhere(
        (status) => status.name == statusRaw,
        orElse: () => BloodSampleStatus.pending,
      ),
      resultFileUrl: json['resultFileUrl']?.toString(),
      patientAge: (json['patientAge'] ?? json['age'] ?? '').toString(),
      patientAddress: (json['patientAddress'] ?? json['address'] ?? '').toString(),
      createdAt: _parseDate(json['createdAt']),
      updatedAt: _parseDate(json['updatedAt']),
      referredPersonId: json['referredPersonId']?.toString(),
      referredPersonName: json['referredPersonName']?.toString(),
      referredFeePercent: _toDouble(json['referredFeePercent']),
      referredFeeAmount: _toDouble(json['referredFeeAmount']),
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'patientName': patientName,
        'subCenterId': subCenterId,
        'registeredByUserId': registeredByUserId,
        'testIds': testIds,
        'status': status.name,
        'resultFileUrl': resultFileUrl,
        'patientAge': patientAge,
        'patientAddress': patientAddress,
        'createdAt': createdAt?.toIso8601String(),
        'updatedAt': updatedAt?.toIso8601String(),
        'referredPersonId': referredPersonId,
        'referredPersonName': referredPersonName,
        'referredFeePercent': referredFeePercent,
        'referredFeeAmount': referredFeeAmount,
      };

  static DateTime? _parseDate(Object? value) {
    final raw = value?.toString() ?? '';
    if (raw.isEmpty) return null;
    return DateTime.tryParse(raw);
  }

  static double _toDouble(Object? value) {
    if (value is num) return value.toDouble();
    return double.tryParse((value ?? '0').toString()) ?? 0;
  }
}
