import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'turso_native_service.dart';

class NativeFileService {
  NativeFileService({this.applicationName = 'flutterlab'});
  final String applicationName;

  Future<String> uploadPdfToSharedFolder({
    required File file,
    required String parentFolderId,
    String? fileName,
    void Function(int uploadedBytes, int totalBytes)? onProgress,
  }) async {
    if (!await file.exists()) throw NativeFileException(message: 'File does not exist: ${file.path}');
    final totalBytes = await file.length();
    onProgress?.call(totalBytes, totalBytes);
    return file.uri.toString();
  }

  Future<String> uploadPdfAndSaveLink({
    required File file,
    required String parentFolderId,
    required TursoNativeService tursoService,
    required String targetRange,
    required int rowIndex,
    required int columnIndex,
    String? fileName,
  }) async {
    final link = await uploadPdfToSharedFolder(file: file, parentFolderId: parentFolderId, fileName: fileName);
    final values = List<String>.filled(columnIndex + 1, '');
    values[columnIndex] = link;
    await tursoService.updateRow(range: '$targetRange${rowIndex + 1}', values: values);
    return link;
  }

  Future<String> uploadImageBytes({
    required Uint8List bytes,
    required String fileName,
    required String mimeType,
    String? parentFolderId,
  }) async {
    if (bytes.isEmpty) throw NativeFileException(message: 'Selected file is empty.');
    final encoded = base64Encode(bytes);
    return 'data:$mimeType;base64,$encoded';
  }

  Future<void> close() async {}
}

class NativeFileException implements Exception {
  NativeFileException({required this.message, this.cause});
  final String message;
  final Object? cause;
  @override
  String toString() => 'NativeFileException: $message${cause == null ? '' : ' ($cause)'}';
}
