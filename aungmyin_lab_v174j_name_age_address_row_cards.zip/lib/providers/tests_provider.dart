import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/lab_test.dart';
import '../models/sub_center_pricing.dart';
import '../services/turso_native_service.dart';

final testsProvider = AsyncNotifierProvider<TestsNotifier, List<LabTest>>(
  TestsNotifier.new,
);

final pricingsProvider =
    AsyncNotifierProvider<PricingsNotifier, List<SubCenterPricing>>(
      PricingsNotifier.new,
    );

class TestsNotifier extends AsyncNotifier<List<LabTest>> {
  TursoNativeService? _service;
  String _range = 'Tests!A:C';

  @override
  FutureOr<List<LabTest>> build() async {
    return fetchTests();
  }

  Future<List<LabTest>> fetchTests() async {
    state = const AsyncValue.loading();

    _service ??= TursoNativeService(
      applicationName: 'flutterlab',
    );

    final rows = await _service!.fetchRows(
      range: _range,
    );
    if (rows.isEmpty) return [];

    final headers = rows.first
        .map((h) => h.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();

    final tests = rows.skip(1).map((row) {
      final Map<String, String> map = {};
      for (var i = 0; i < headers.length; i++) {
        final key = headers[i];
        final value = i < row.length ? row[i].toString() : '';
        map[key] = value;
      }

      final id = map['id'] ?? '';
      final name = map['testname'] ?? map['name'] ?? '';
      final priceRaw = map['defaultprice'] ?? map['price'] ?? '0';
      final price = double.tryParse(priceRaw) ?? 0.0;

      return LabTest(id: id, testName: name, defaultPrice: price);
    }).toList();

    state = AsyncValue.data(tests);
    return tests;
  }
}

class PricingsNotifier extends AsyncNotifier<List<SubCenterPricing>> {
  TursoNativeService? _service;
  String _range = 'SubCenterPricings!A:D';

  @override
  FutureOr<List<SubCenterPricing>> build() async {
    return fetchPricings();
  }

  Future<List<SubCenterPricing>> fetchPricings() async {
    state = const AsyncValue.loading();

    _service ??= TursoNativeService(
      applicationName: 'flutterlab',
    );

    final rows = await _service!.fetchRows(
      range: _range,
    );
    if (rows.isEmpty) return [];

    final headers = rows.first
        .map((h) => h.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();

    final pricings = rows.skip(1).map((row) {
      final Map<String, String> map = {};
      for (var i = 0; i < headers.length; i++) {
        final key = headers[i];
        final value = i < row.length ? row[i].toString() : '';
        map[key] = value;
      }

      final subCenterId = map['subcenterid'] ?? map['subcenter'] ?? '';
      final testId = map['testid'] ?? '';
      final price = double.tryParse(map['customprice'] ?? map['price'] ?? '0') ?? 0.0;
      final referredFeePercent = double.tryParse(
            map['referredfeepercent'] ??
                map['referedfeepercent'] ??
                map['referredfee'] ??
                map['referedfee'] ??
                '0',
          ) ??
          0.0;

      return SubCenterPricing(
        subCenterId: subCenterId,
        testId: testId,
        customPrice: price,
        referredFeePercent: referredFeePercent,
      );
    }).toList();

    state = AsyncValue.data(pricings);
    return pricings;
  }
}
