import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/app_user.dart';
import '../models/blood_sample.dart';
import '../providers/auth_notifier.dart';
import '../services/turso_native_service.dart';

final sampleDashboardControllerProvider =
    AsyncNotifierProvider<SampleDashboardController, List<BloodSample>>(
      SampleDashboardController.new,
    );

class SampleDashboardController extends AsyncNotifier<List<BloodSample>> {
  TursoNativeService? _tursoService;
  String _range = 'BloodSamples!A:Z';

  @override
  FutureOr<List<BloodSample>> build() async {
    return fetchSamples();
  }

  Future<List<BloodSample>> fetchSamples() async {
    final user = ref.read(authNotifierProvider);

    if (user == null) {
      return [];
    }

    state = const AsyncValue.loading();

    // Lazily create the Turso service using the native Turso configuration
    _tursoService ??= (await (() async {
      return TursoNativeService(
        applicationName: 'flutterlab',
      );
    })());

    final rows = await _tursoService!.fetchRows(
      range: _range,
    );

    if (rows.isEmpty) {
      state = const AsyncValue.data(<BloodSample>[]);
      return <BloodSample>[];
    }

    // Parse header row to support flexible column ordering
    final headers = rows.first
        .map((h) => h.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();

    // Parse all rows first, then sort by createdAt descending so the latest
    // sample row appears at the top for every dashboard role.
    final sampleRows = rows.skip(1).toList();

    final samples = sampleRows
        .map((row) {
          final Map<String, String> map = {};
          for (var i = 0; i < headers.length; i++) {
            final key = headers[i];
            final value = i < row.length ? row[i].toString() : '';
            map[key] = value;
          }

          return _rowMapToBloodSample(map);
        })
        .whereType<BloodSample>()
        .toList()
      ..sort(_compareSamplesNewestFirst);

    final filteredSamples = _filterSamples(samples, user);
    state = AsyncValue.data(filteredSamples);
    return filteredSamples;
  }

  int _compareSamplesNewestFirst(BloodSample a, BloodSample b) {
    final aDate = a.createdAt ?? a.updatedAt;
    final bDate = b.createdAt ?? b.updatedAt;
    if (aDate != null && bDate != null) {
      final byDate = bDate.compareTo(aDate);
      if (byDate != 0) return byDate;
    } else if (aDate != null) {
      return -1;
    } else if (bDate != null) {
      return 1;
    }
    return b.id.compareTo(a.id);
  }

  List<BloodSample> _filterSamples(List<BloodSample> samples, AppUser user) {
    // Superadmin and lab tech have all-center visibility.
    // They must see GLOBAL rows and every sub-center row without center filtering.
    if (_canSeeAllBloodSamples(user)) {
      return samples;
    }

    // Referred-person users can see every blood sample referred by their
    // account, even when older rows have only the referred person name saved.
    if (user.role == AppUserRole.referred_person) {
      final userId = _normalizeMatchKey(user.id);
      final userName = _normalizeMatchKey(user.name);
      return samples.where((sample) {
        final referredId = _normalizeMatchKey(sample.referredPersonId ?? '');
        final referredName = _normalizeMatchKey(sample.referredPersonName ?? '');
        if (referredId == 'self' || referredName == 'self') return false;
        if (referredId.isNotEmpty && referredId == userId) return true;
        return userName.isNotEmpty && referredName == userName;
      }).toList();
    }

    // Admin and staff users can see registered blood samples from their
    // own real sub-center. GLOBAL/empty sample rows are hidden.
    if (user.role == AppUserRole.admin || user.role == AppUserRole.staff) {
      final userSubCenterId = _normalizeSubCenterId(user.subCenterId);
      if (userSubCenterId.isEmpty || _isGlobalSubCenter(userSubCenterId)) {
        return <BloodSample>[];
      }

      return samples.where((sample) {
        final sampleSubCenterId = _normalizeSubCenterId(sample.subCenterId);
        return sampleSubCenterId.isNotEmpty &&
            !_isGlobalSubCenter(sampleSubCenterId) &&
            sampleSubCenterId == userSubCenterId;
      }).toList();
    }

    return <BloodSample>[];
  }

  bool _canSeeAllBloodSamples(AppUser user) {
    return user.role == AppUserRole.superadmin || user.role == AppUserRole.lab_tech;
  }

  bool _isGlobalSubCenter(String normalizedValue) {
    return normalizedValue == 'global';
  }

  String _normalizeMatchKey(String? value) {
    return (value ?? '').trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
  }

  String _normalizeSubCenterId(String? value) {
    final cleaned = (value ?? '')
        .trim()
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9]'), '');

    // Treat CENTER-1, CENTER_1, center 1 and CENTER-01 as the same center.
    return cleaned.replaceAllMapped(
      RegExp(r'([a-z]+)0+(\d+)$'),
      (match) => '${match.group(1)}${match.group(2)}',
    );
  }


  DateTime? _parseSheetDate(String value) {
    final raw = value.trim();
    if (raw.isEmpty) return null;

    final direct = DateTime.tryParse(raw);
    if (direct != null) return direct;

    final match = RegExp(
      r'^(\d{4})[-/](\d{1,2})[-/](\d{1,2})[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?',
    ).firstMatch(raw);
    if (match == null) return null;

    final year = int.tryParse(match.group(1) ?? '');
    final month = int.tryParse(match.group(2) ?? '');
    final day = int.tryParse(match.group(3) ?? '');
    final hour = int.tryParse(match.group(4) ?? '');
    final minute = int.tryParse(match.group(5) ?? '');
    final second = int.tryParse(match.group(6) ?? '0') ?? 0;

    if (year == null ||
        month == null ||
        day == null ||
        hour == null ||
        minute == null) {
      return null;
    }

    return DateTime(year, month, day, hour, minute, second);
  }

  double _rowDouble(Map<String, String> row, List<String> keys) {
    for (final key in keys) {
      final value = row[key]?.trim() ?? '';
      if (value.isNotEmpty) return double.tryParse(value) ?? 0;
    }
    return 0;
  }

  BloodSample? _rowToBloodSample(List<String> row) {
    if (row.isEmpty) {
      return null;
    }

    try {
      return BloodSample(
        id: row[0].trim(),
        patientName: row[1].trim(),
        subCenterId: row[2].trim(),
        registeredByUserId: row[3].trim(),
        testIds: row[4]
            .split(',')
            .map((value) => value.trim())
            .where((value) => value.isNotEmpty)
            .toList(),
        status: BloodSampleStatus.values.firstWhere(
          (status) => status.name == row[5].trim(),
          orElse: () => BloodSampleStatus.pending,
        ),
        resultFileUrl: row.length > 6 ? row[6].trim() : null,
        patientAge: row.length > 9 ? row[9].trim() : '',
        patientAddress: row.length > 11 ? row[11].trim() : '',
        createdAt: row.length > 7 && row[7].trim().isNotEmpty
            ? _parseSheetDate(row[7].trim())
            : null,
        updatedAt: row.length > 8 && row[8].trim().isNotEmpty
            ? _parseSheetDate(row[8].trim())
            : null,
        referredPersonId: row.length > 17 ? row[17].trim() : null,
        referredPersonName: row.length > 18 ? row[18].trim() : null,
        referredFeePercent: row.length > 19 ? double.tryParse(row[19].trim()) ?? 0 : 0,
        referredFeeAmount: row.length > 20 ? double.tryParse(row[20].trim()) ?? 0 : 0,
      );
    } catch (_) {
      return null;
    }
  }

  BloodSample? _rowMapToBloodSample(Map<String, String> row) {
    if (row.isEmpty) return null;

    try {
      final id = row['id'] ?? row['sampleid'] ?? '';
      final patientName = row['patientname'] ?? row['patient'] ?? '';
      final subCenterId =
          row['subcenterid'] ?? row['center'] ?? row['subcenter'] ?? 'GLOBAL';
      final registeredBy =
          row['registeredbyuserid'] ?? row['registeredby'] ?? '';
      final testIdsRaw = row['testids'] ?? row['tests'] ?? '';
      final statusRaw = (row['status'] ?? 'pending').trim().toLowerCase();
      final resultUrl = row['resulturl'] ?? row['result'] ?? '';
      final patientAge = row['patientage'] ?? row['age'] ?? '';
      final patientAddress = row['patientaddress'] ?? row['address'] ?? '';
      final createdAtRaw = row['createdat'] ?? row['created'] ?? '';
      final updatedAtRaw = row['updatedat'] ?? row['updated'] ?? '';
      final referredPersonId = row['referredpersonid'] ?? row['referedpersonid'] ?? row['referredbyid'] ?? '';
      final referredPersonName = row['referredpersonname'] ?? row['referedpersonname'] ?? row['referredbyname'] ?? '';
      final referredFeePercent = _rowDouble(row, const ['referredfeepercent', 'referedfeepercent']);
      final referredFeeAmount = _rowDouble(row, const ['referredfeeamount', 'referedfeeamount', 'referredfee']);

      final testIds = testIdsRaw
          .split(',')
          .map((s) => s.trim())
          .where((s) => s.isNotEmpty)
          .toList();

      final status = BloodSampleStatus.values.firstWhere(
        (s) => s.name == statusRaw,
        orElse: () => BloodSampleStatus.pending,
      );

      return BloodSample(
        id: id,
        patientName: patientName,
        subCenterId: subCenterId,
        registeredByUserId: registeredBy,
        testIds: testIds,
        status: status,
        resultFileUrl: resultUrl.isNotEmpty ? resultUrl : null,
        patientAge: patientAge,
        patientAddress: patientAddress,
        createdAt: createdAtRaw.isNotEmpty
            ? _parseSheetDate(createdAtRaw)
            : null,
        updatedAt: updatedAtRaw.isNotEmpty
            ? _parseSheetDate(updatedAtRaw)
            : null,
        referredPersonId: referredPersonId.isNotEmpty ? referredPersonId : null,
        referredPersonName: referredPersonName.isNotEmpty ? referredPersonName : null,
        referredFeePercent: referredFeePercent,
        referredFeeAmount: referredFeeAmount,
      );
    } catch (_) {
      return null;
    }
  }
}
