import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../services/turso_native_service.dart';

final syncQueueProvider = AsyncNotifierProvider<SyncQueueNotifier, SyncQueueSnapshot>(
  SyncQueueNotifier.new,
);

class SyncQueueNotifier extends AsyncNotifier<SyncQueueSnapshot> {
  @override
  FutureOr<SyncQueueSnapshot> build() async {
    return TursoNativeService.syncSnapshot();
  }

  Future<SyncQueueSnapshot> refresh() async {
    final snapshot = await TursoNativeService.syncSnapshot();
    state = AsyncValue.data(snapshot);
    return snapshot;
  }

  Future<SyncQueueSnapshot> syncNow({bool silent = false}) async {
    final current = state.valueOrNull;
    if (!silent) {
      state = AsyncValue.data(
        SyncQueueSnapshot(
          pendingCount: current?.pendingCount ?? await TursoNativeService.pendingSyncCount(),
          isSyncing: true,
          lastSyncedAt: current?.lastSyncedAt,
          lastError: current?.lastError,
        ),
      );
    }
    final snapshot = await TursoNativeService.syncPending(applicationName: 'aungmyin_lab');
    state = AsyncValue.data(snapshot);
    return snapshot;
  }
}
