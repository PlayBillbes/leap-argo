import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/sync_queue_provider.dart';

class SyncNowButton extends ConsumerWidget {
  const SyncNowButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final snapshotAsync = ref.watch(syncQueueProvider);
    final snapshot = snapshotAsync.valueOrNull;
    final pending = snapshot?.pendingCount ?? 0;
    final syncing = snapshot?.isSyncing == true || snapshotAsync.isLoading;
    final hasError = (snapshot?.lastError ?? '').isNotEmpty;
    final theme = Theme.of(context);
    final icon = syncing
        ? SizedBox(
            width: 18,
            height: 18,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(theme.colorScheme.onPrimary),
            ),
          )
        : Icon(hasError ? Icons.sync_problem_rounded : Icons.sync_rounded);
    final button = IconButton(
      tooltip: pending == 0 ? 'Sync now' : 'Sync now ($pending pending)',
      onPressed: syncing
          ? null
          : () async {
              final messenger = ScaffoldMessenger.of(context);
              final result = await ref.read(syncQueueProvider.notifier).syncNow();
              if (!context.mounted) return;
              if ((result.lastError ?? '').isNotEmpty) {
                messenger.showSnackBar(
                  SnackBar(content: Text('Sync needs attention: ${result.pendingCount} pending item(s).')),
                );
              } else {
                messenger.showSnackBar(
                  SnackBar(content: Text(result.pendingCount == 0 ? 'Sync complete.' : '${result.pendingCount} item(s) still pending.')),
                );
              }
            },
      icon: icon,
    );
    if (pending <= 0) return button;
    return Badge(
      label: Text(pending > 99 ? '99+' : '$pending'),
      child: button,
    );
  }
}
