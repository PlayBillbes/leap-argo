# v114 responsive mobile size tuning

This build improves the screenshot-style mobile Lab Dashboard responsiveness while preserving the same UI design.

Changes:
- Font sizes, icon sizes, card heights, button sizes, spacing, and pill sizes now use bounded scaling for small and large phones.
- Summary cards scale down on narrow phones and scale up slightly on larger phones without breaking the four-card layout.
- Sample cards keep the same visual structure, but action buttons wrap below metadata pills when the screen is too narrow.
- Existing all-role mobile dashboard behavior from v113 is preserved.
- Existing v112 compile fix is preserved.
