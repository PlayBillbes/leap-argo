# v143 pure native Turso build

This build removes the legacy Google Sheets and Google Drive runtime dependencies from the app and keeps the data layer native to Turso.

Changes:
- Removed service-account JSON loading from runtime code.
- Removed `GoogleConfig.spreadsheetId` and all `spreadsheetId:` call arguments.
- Removed Google API dependencies from `pubspec.yaml`.
- Removed `assets/service-account.json` from Flutter assets.
- Replaced `GoogleSheetsAuthService` with `NativeAuthService`.
- Replaced Google Drive upload service with `NativeFileService` that stores selected image bytes as inline data URIs for Turso-backed rows.
- Updated `TursoNativeService` so `fetchRows`, `insertRow`, `updateRow`, `deleteRow`, and `ensureSheet` no longer require a spreadsheet id.
- Updated Alert, users, pricing, samples, reports, CBC, manual defaults, and dashboard flows to use native Turso calls without Google service-account setup.

Preserved from earlier builds:
- v142 one-time login alert behavior.
- v141 dashboard role sample-scope rules.
- v139 Advanced Analytics mobile rewrite.
- v138 Report Header footer load parse fix.

Implementation note:
Some method and range names such as `fetchRows` and `BloodSamples!A:Z` remain as internal compatibility labels for existing table mapping, but they no longer call Google Sheets or require a spreadsheet id. Data is routed through `TursoNativeService` and `TursoConfig`.
