## v171 all roles Blood Samples scroll fix

This build makes the desktop/tablet Blood Samples table scroll consistently for every role, not only admin and superadmin.

Changes:
- Removed the inner compact-width fallback that could switch tablet-sized desktop views back to mobile sample cards.
- The Blood Samples table now stays in the horizontal-scroll table layout for all desktop/tablet roles once the screen is 760 px or wider.
- Added role-aware minimum table widths so staff, lab tech, admin, and superadmin action columns have enough horizontal scroll space.
- Action buttons in table cells now use minimum width instead of stretching inside the cell.
- Preserved the v170 replace-result duplicate prevention and the v169 horizontal scrollbar behavior.

Updated file:
- lib/views/dashboard_view.dart
