# CBC payload_json NOT NULL fix

This patch fixes Turso error:
`NOT NULL constraint failed: cbc_results.payload_json`.

CBC result saves now write:
- `payload_json` full JSON snapshot
- all analyzer columns including Base64 graph fields
