## v174 Windows/tablet Blood Samples card rewrite

This build rewrites the Blood Samples area for Windows and tablet widths while preserving the existing mobile card flow.

Changes:
- Replaced the desktop/tablet PaginatedDataTable Blood Samples layout with responsive sample cards.
- Desktop/tablet cards automatically arrange into 1, 2, or 3 columns based on available width.
- Each card shows sample ID, patient, status, tests, sub-center, referred person, date, and staff total cost when relevant.
- Completed samples keep View, Print, and Select actions.
- Lab tech users keep Review actions for non-completed/non-canceled samples.
- Admin/staff/superadmin pending Cancel behavior is preserved.
- Superadmin Delete behavior, including related result deletion from v172/v173, is preserved.
- Multi-select print controls are preserved with a desktop/tablet toolbar and selected print bar.
- Mobile layout under 760 px is intentionally kept unchanged.

Updated file:
- lib/views/dashboard_view.dart
