# v145 mobile Users page rewrite

This build rewrites the mobile layout for the Users / Staff Accounts page.

Changes:
- Replaced the cramped mobile users screen with a phone-first dashboard layout.
- Added a gradient mobile hero with total, superadmin, lab tech, and referred-person count chips.
- Added a large full-width Add Staff / Add User action button.
- Removed the fixed-height mobile list area that caused user cards to feel cut off above the bottom navigation.
- Added a cleaner mobile search panel with a shown-count badge.
- Added new mobile user account cards with better spacing, role chips, center chips, and full-width Edit/Delete actions.
- Kept the desktop/tablet Users page layout unchanged.

Preserved:
- v144 native Turso compile fix.
- v143 pure native Turso runtime cleanup.
- v142 one-time login alert behavior.
- v141 dashboard role sample-scope rules.
