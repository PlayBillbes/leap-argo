# v139 Advanced Analytics mobile rewrite

This build completely rewrites the mobile layout for the Superadmin Advanced Analytics page while preserving the existing desktop/tablet experience.

Changes:
- Added a dedicated mobile-only Advanced Analytics view for screens under 760 px wide.
- Replaced the desktop-style stacked layout on mobile with a purpose-built phone dashboard.
- Added a compact gradient mobile hero with scope and row-count chips.
- Added a full-width sub-center selector designed for touch input.
- Added a two-column mobile KPI grid for Today, Month, Year, and Samples.
- Added mobile sections for workload, revenue trends, and network breakdown.
- Added compact mobile chart panels for day-by-day and month-by-month revenue.
- Added ranked mobile list cards for pending tests, revenue by sub-center, and most requested tests.
- Kept the v138 footer load parse fix and superadmin-only report header behavior.

Technical note:
The desktop layout remains active for wider screens. The new mobile branch is selected in `_AdvancedAnalyticsContentState.build` using `MediaQuery.sizeOf(context).width < 760`.
