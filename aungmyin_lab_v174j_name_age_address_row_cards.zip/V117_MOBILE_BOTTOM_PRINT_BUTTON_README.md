# v117 mobile bottom print button

This build updates the mobile multi-select print behavior.

Changes:
- The blue Print button now appears from the base/bottom of the mobile sample list only after at least one completed sample is selected.
- The old always-visible top print toolbar was removed from the mobile cards.
- The bottom print bar shows the selected count, Clear, and blue Print button.
- Lab tech users still only see Review and do not see View, Print, or Select actions.
- Other users keep View, single Print, and Select on completed samples.
