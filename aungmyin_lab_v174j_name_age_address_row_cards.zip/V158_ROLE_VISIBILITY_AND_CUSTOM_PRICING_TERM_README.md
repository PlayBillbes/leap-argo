# v158 role visibility and Custom Pricing term

This build updates blood sample visibility and visible pricing terminology.

Role visibility rules:
- Superadmin can see all blood samples.
- Lab tech can see all blood samples.
- Admin users can see only blood samples they registered from their own non-GLOBAL sub-center.
- Staff users can see only blood samples they registered from their own non-GLOBAL sub-center.
- Referred person users can see only blood samples referred by their account, matched by referred person id or fallback referred person name.

Applied to:
- Dashboard sample provider.
- Patient search results.
- Direct sample result access checks.

Terminology changes:
- Visible UI term `Sub-center Pricing` is changed to `Custom Pricing`.
- Existing internal route/model names are preserved for compatibility.

Preserved:
- v157 mobile sticky status tabs only.
- v156 mobileTopPadding compile fix.
- v155 lab tech offline result completion.
