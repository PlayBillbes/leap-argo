# v151 automatic sync queue for all users

This build adds an offline sync queue with automatic sync by default and a manual Sync now safety button.

Behavior:
- All authenticated users see a Sync now button in the app bar.
- The app attempts automatic pending-sync replay when an authenticated page opens.
- The app retries automatic sync every 30 seconds while an authenticated page is open.
- If insert, update, or delete operations cannot reach Turso, the operation is stored in a local sync queue instead of being discarded.
- Manual Sync now replays pending queued operations immediately.
- The Sync now button shows a badge with the pending queue count.
- Online reads cache the latest fetched rows by table name.
- Offline reads fall back to cached rows when available.

Files added:
- lib/providers/sync_queue_provider.dart
- lib/widgets/sync_now_button.dart

Files updated:
- lib/services/turso_native_service.dart
- lib/widgets/app_sidebar.dart

Preserved:
- v150 admin sub-center report header control.
- v149 referral PDF layout fix and AungMyin Lab branding.
- v148 mobile login About/Settings blue buttons.
- v147 strict blood sample visibility.

Note:
This version provides a lightweight local queue/cache using Dart local files. It does not add a full SQLite database yet.
