# v153 mobile dashboard stats overflow fix

This build fixes the red/yellow RenderFlex overflow shown on the mobile Lab Dashboard summary cards.

Changes:
- Increased the mobile summary card height enough for the icon, value, and label.
- Reduced icon, value, label, padding, and inter-card spacing slightly so the four-card row fits narrow phone widths.
- Added maxLines and ellipsis safety for the summary-card labels.
- Preserved the four-card layout: Processing, Pending, Completed, and Total Tests.

Preserved:
- v152 offline registered samples appear immediately on dashboard cache.
- v151 automatic sync queue and Sync now button.
- v150 admin sub-center report header control.
