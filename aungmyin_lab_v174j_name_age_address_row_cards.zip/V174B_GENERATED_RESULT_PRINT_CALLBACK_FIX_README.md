## v174b generated result print callback compile fix

This patch fixes the Linux build error in lib/views/dashboard_view.dart where _GeneratedResultButton expected a Future<void> Function() for onPrint, but the callback body did not return the Future from onPrintSample.

Fix:
- Changed the _GeneratedResultButton onPrint callback in _SampleDataSource from a block body to `() => onPrintSample(sample)`, so the required Future<void> is returned.

Preserved:
- v174 Windows/tablet Blood Samples responsive card rewrite.
- Existing mobile Blood Samples card behavior.
- Existing print, view, select, review, cancel, and delete behavior.
