# v138 report header footer load parse fix

This build fixes the Report Header page load failure shown by Turso SQL parse error near `RP,"None"`.

Changes:
- ReportHeaderSettings fetch no longer uses `coalesce(footer_text, footer, '')`.
- ReportHeaderSettings fetch now reads the Turso-managed `footer_text` column directly as `footerText`.
- Existing footer save behavior remains: the Report Header page writes footer text to `footer_text`.
- Superadmin-only Report Header access/editing from v136 remains unchanged.
- Mobile Advanced Analytics responsiveness from v137 remains unchanged.

Reason:
The previous fallback SQL caused a Turso parser error on load. Using `footer_text as footerText` avoids that parse failure and keeps the footer field compatible with the current schema.
