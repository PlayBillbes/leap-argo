# v126 referred person report year/month filters

This build adds year and month filters to the referred person analytic report page.

Changes:
- Referred person report is now stateful and keeps selected year/month.
- Added Year and Month dropdown filters on both desktop and mobile.
- Month supports `All months` or a specific month.
- KPI cards, status overview, tests referred, recent samples, and monthly summary all respect the selected filters.
- Available year options are derived from referred sample dates, with current year fallback when no data exists.
- Existing mobile pull-to-refresh behavior remains.
