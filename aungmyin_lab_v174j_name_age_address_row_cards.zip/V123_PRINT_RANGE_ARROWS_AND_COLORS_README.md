# v123 print range arrows and colors

This build updates the dashboard Print output to match the reference report behavior.

Changes:
- Result values are compared against their printed reference range.
- High values print with an up arrow `↑` and red text.
- Low values print with a down arrow `↓` and light blue text.
- Normal values remain dark text without arrows.
- Keeps v122 full CBC/CP(Auto) parameter printing and lab tech View/Print/Select/Review/Register access.
