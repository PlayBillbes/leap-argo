# v157 mobile dashboard sticky status tabs only

This build adjusts the mobile Lab Dashboard scroll behavior to match the requested layout.

Changes:
- The Processing/Pending/Completed/Total summary cards scroll normally.
- The Search and Filters row scrolls normally.
- Only the All / Processing / Pending / Completed status bar is pinned/sticky at the top while the sample list scrolls.
- The sticky status bar keeps a small top padding and background so it does not touch the app bar while scrolling.
- The mobile sample list now uses the parent dashboard scroll view in this layout, so the sticky bar is controlled by a SliverPersistentHeader.

Preserved:
- v156 mobileTopPadding compile fix.
- v155 lab tech offline result completion.
- v153 mobile dashboard summary-card overflow fix.
