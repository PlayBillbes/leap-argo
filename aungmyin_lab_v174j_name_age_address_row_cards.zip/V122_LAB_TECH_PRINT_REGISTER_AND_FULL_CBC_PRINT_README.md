# v122 lab tech print/register and full CBC parameter print

This build updates dashboard printing and lab tech permissions.

Changes:
- Dashboard Print now includes the full CBC/CP(Auto) parameter set instead of only a small subset.
- CBC/CP(Auto) print rows include default reference ranges and units for all configured parameters.
- Lab tech mobile sample cards now include View, Print, Select, and Review actions.
- Lab tech users can use multi-select print from the mobile floating bottom print bar.
- Lab tech users can access Register Sample from navigation and the dashboard register card.
- Router access rules now allow lab tech users to open `/register-sample`.
