# v111 exact mobile Lab Dashboard reference UI

This build tightens the mobile Lab Dashboard to better match the provided screenshot:
- Left-aligned blue app bar with hamburger, title, refresh icon and label.
- Four equal compact metric cards.
- Search field, Filters button, segmented status tabs.
- Sample cards without the desktop table container/header on mobile.
- Screenshot-style card layout: left status rail, ID and patient/test details, right status/time/menu, bottom pills and View/Review buttons.
