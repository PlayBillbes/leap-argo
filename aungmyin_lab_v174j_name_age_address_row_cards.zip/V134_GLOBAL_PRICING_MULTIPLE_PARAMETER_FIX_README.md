# v134 global pricing multiple parameter fix

This build fixes the Global Pricing parameter builder when adding multiple parameters.

Changes:
- Add/edit parameter now reads the latest controller value after the dialog closes, preventing stale-list overwrites.
- New parameter dialog no longer pre-fills the parameter name with the test name, so users do not accidentally save every row as the same test name.
- Parameter cards now show a visible count such as `3 parameters added`.
- Parameter names can wrap to two lines on mobile instead of hiding too much text.
- Added an Infection Screening preset that creates HCV Ab, HBsAg, and HIV Ag/Ab as qualitative parameters.
- Existing save/update flow and `ManualTestDefaults` storage remain compatible.
