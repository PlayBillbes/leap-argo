# Native Turso status

This workspace has completed the runtime cleanup to use the native Turso backend path.

Runtime data access now flows through:
- `lib/services/turso_native_service.dart`
- `lib/config/turso_config.dart`
- native service helpers such as `NativeAuthService` and `NativeFileService`

The app no longer loads a service-account JSON file at runtime and no longer depends on external sheet or drive API packages.
