# CBC / CP(Auto) BASO graph fix

This build adds BASO graph Base64 persistence for analyzer ZIP uploads.

New saved columns in `cbc_results`:
- `basoGraphBase64`
- `diffBasoBase64`

ZIP filename matching now detects graph files containing `BASO`, `DIFF_BASO`, or `DIFF_BAS`.
