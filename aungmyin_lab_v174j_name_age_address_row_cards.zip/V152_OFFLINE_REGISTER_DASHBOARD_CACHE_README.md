# v152 offline register shows immediately on dashboard

This build fixes the offline registration visibility problem for lab tech and other allowed register users.

Behavior:
- When a sample is registered while offline, the insert is still added to the local sync queue.
- The same offline insert is also written immediately into the local cached BloodSamples rows.
- Dashboard refresh/provider reload can now read the locally cached BloodSamples rows and show offline registered patients in Pending, Processing, Completed, and total dashboard sections.
- Header-row updates used by the register flow are cached locally too, so offline registration can proceed even when the BloodSamples header has not been fetched during that session.
- If no cached rows exist for a table while offline, fetchRows now returns the table header row instead of failing immediately. This allows empty/offline screens and offline registration setup to continue safely.
- Online insert, update, and delete operations also refresh the local cache, keeping online and offline behavior consistent.
- Queued offline changes still sync to Turso automatically when online, and users can still use Sync now as a safety button.

Updated file:
- lib/services/turso_native_service.dart

Preserved:
- v151 automatic sync queue and Sync now button.
- v150 admin sub-center report header control.
- v149 referral PDF layout fix and AungMyin Lab branding.
