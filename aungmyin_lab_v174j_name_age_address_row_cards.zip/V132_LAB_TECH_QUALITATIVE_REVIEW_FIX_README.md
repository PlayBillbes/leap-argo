# v132 lab tech qualitative review fix

This build improves the lab tech manual review dialog for qualitative tests.

Changes:
- Qualitative manual defaults are now detected when unit is blank and reference range is not a numeric range.
- This handles older/bad default rows such as a text value in the reference range column.
- Qualitative result cards now show large Negative and Positive buttons instead of a free typing-only field.
- The result field is read-only for qualitative tests, so lab tech users choose Negative or Positive.
- When saving a qualitative result, unit and reference range are saved blank, so result view and print show only Test and Result.
- Numeric manual tests still keep unit/ref range and arrow behavior.
