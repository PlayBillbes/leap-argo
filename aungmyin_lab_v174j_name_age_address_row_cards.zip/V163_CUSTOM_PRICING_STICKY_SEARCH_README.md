# v163 Custom Pricing sticky search box

This build updates the Custom Pricing page scroll behavior.

Changes:
- Only the Search tests box is pinned/sticky when scrolling down.
- The title and description scroll away normally.
- The sticky search box keeps top padding and a white field background while it is pinned.
- The tests list now uses the same page scroll with a SliverPersistentHeader for the search box.
- Empty search results show a simple message instead of an empty list.

Updated file:
- lib/views/sub_center_pricing_page.dart

Preserved:
- v162 superadmin delete blood sample row.
- v161 pending sample cancel.
- v160 superadmin/lab tech all blood samples visibility.
