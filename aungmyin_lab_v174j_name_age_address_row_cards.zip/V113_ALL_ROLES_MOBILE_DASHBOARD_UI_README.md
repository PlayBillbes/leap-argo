# v113 all roles mobile Lab Dashboard UI

This build applies the screenshot-style mobile Lab Dashboard UI to every mobile dashboard role, not only admin/superadmin.

Changes:
- Lab tech, staff, referred person, admin, and superadmin mobile dashboard views now use the same compact reference-style layout.
- Existing role-based data filtering is preserved before the mobile dashboard is rendered.
- Existing role-based actions in sample cards remain controlled by the current user role.
- Keeps the v112 compile fix: `Container(constraints: BoxConstraints(minHeight: ...))`.
