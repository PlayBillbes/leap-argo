# v118 floating bottom Print button

This build changes the mobile selected-print behavior so the blue Print button appears immediately as a floating bottom bar.

Changes:
- Mobile dashboard now uses fixed top controls with an Expanded sample list, so the print action can float at the bottom of the available mobile viewport.
- After selecting any completed sample, a floating bottom bar appears at once.
- The floating bottom bar contains selected count, Clear, and a blue Print button.
- Extra bottom padding is added to the sample list while the floating bar is visible, so the bar does not cover the last sample card.
- Lab tech users still only see Review.
