# v135 global pricing Turso parameter save fix

This build fixes Add New Test parameter persistence on the Global Pricing page when using the Turso backend.

Changes:
- ManualTestDefaults rows now use the Turso-native column order: id, testId, testName, parameter, unit, referenceRange, notes.
- Each parameter row now gets a unique deterministic id based on test id, sort order, and parameter name, so multiple parameters no longer overwrite each other in Turso.
- Add New Test now always runs the ManualTestDefaults save flow after saving the test, so parameters added in Step 3 are persisted.
- The defaults reader now supports the Turso `notes` column while remaining compatible with legacy `note` naming.
- Existing/malformed rows created by the previous shifted-column save are cleaned when their test id field contains the test name.

Reason:
The previous Global Pricing save flow inserted ManualTestDefaults values as if the backend did not include an `id` column. TursoNativeService expects `id` first, so values shifted into the wrong columns and multiple parameters could conflict on the same id. This version aligns the UI save payload with TursoNativeService.
