# v159 role visibility sub-center fix

This build corrects the role visibility interpretation from v158.

Role visibility rules now enforced:
- Superadmin can see all blood samples.
- Lab tech can see all blood samples.
- Admin users can see registered blood samples from their own non-GLOBAL sub-center.
- Staff users can see registered blood samples from their own non-GLOBAL sub-center.
- Referred person users can see only blood samples referred by their account, matched by referred person id or fallback referred person name.

Fix:
- v158 matched admin/staff samples by exact registeredByUserId. That can hide valid sub-center samples when older/offline rows use a different registeredBy value or an empty one.
- v159 uses the sample subCenterId for admin/staff visibility, while still excluding GLOBAL/empty sub-center rows.

Applied to:
- Dashboard sample provider.
- Patient search results.
- Direct sample result access checks.

Preserved:
- Visible term `Sub-center Pricing` remains changed to `Custom Pricing`.
- v157 mobile sticky status tabs only.
- v155 lab tech offline result completion.
