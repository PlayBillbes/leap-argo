## v174c compact Windows/tablet Blood Samples cards and status filter

This patch improves the v174 Windows/tablet Blood Samples card rewrite.

Changes:
- Reduced desktop/tablet card padding, icon sizes, chip sizes, action button sizes, and shadows so cards are more compact.
- Limited visible test chips on each card to 4, with a +more chip for long test lists.
- Added desktop/tablet status filters: All, Pending, Processing, Completed, and Canceled.
- Status filter updates the visible card list while preserving selected completed sample IDs.
- Header now shows how many records are shown out of the total records.

Preserved:
- Mobile Blood Samples layout remains unchanged.
- Existing View, Print, Select, Review, Cancel, Delete, and multi-select print behavior.
- v174b Future<void> print callback compile fix.
