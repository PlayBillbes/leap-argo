# v115 mobile dashboard semantics/render fix

This build fixes the blank mobile dashboard and repeated Flutter semantics assertion reported after v114.

Fixes:
- Removed the nested shrinkWrap ListView from the mobile sample-card section.
- Removed IntrinsicHeight from mobile sample cards.
- Rebuilt the card left status rail with a Stack and Positioned fill bar.
- Kept the v114 bounded responsive sizing for font sizes, card sizes, buttons, pills, and spacing.
- Kept all-role mobile dashboard support and the v112 BoxConstraints compile fix.
