### v174i lab tech review Save & Print button

This patch adds a Save & Print action to the lab tech manual review result popup.

Changes:
- The manual review popup now has three actions: Cancel, Save & Print, and Save Result on desktop/tablet.
- On mobile, Save Result, Save & Print, and Cancel are stacked full-width for easier touch use.
- Save & Print validates the form, saves the manual result, marks the BloodSample completed, then opens the print layout for that saved result.
- Existing Save Result behavior is preserved.

Updated file:
- lib/views/dashboard_view.dart

Preserved:
- v174h Patient, Age, Test details in the popup.
- v174h Positive red button and Positive/Negative print colors.
- v174g tablet/desktop Blood Samples minimum 2-column cards.
