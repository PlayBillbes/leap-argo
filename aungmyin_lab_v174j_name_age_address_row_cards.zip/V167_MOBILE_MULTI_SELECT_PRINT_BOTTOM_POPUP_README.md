# v167 mobile multi-select print bottom popup

This build fixes mobile multi-select print behavior.

Changes:
- When a user selects a completed blood sample on mobile, the multi-select print bar now appears as a fixed popup near the bottom of the screen.
- The popup is positioned above the mobile bottom navigation bar, matching the requested screenshot behavior.
- The popup shows selected count, Clear, and Print actions.
- The popup updates immediately when selecting/unselecting samples, clearing selection, selecting all completed samples, or after printing.
- The old in-list Positioned bar was removed so the popup no longer depends on the sample list height or parent scroll layout.
- Extra bottom padding remains in the sample list while the popup is visible so the last card is not hidden.

Updated file:
- lib/views/dashboard_view.dart

Preserved:
- v166 desktop Global Pricing and alert delete fix.
- v165 responsive pricing/tablet sample fixes.
