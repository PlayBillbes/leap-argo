# v156 mobileTopPadding compile fix

This build fixes the Linux/Flutter compile error introduced in v155.

Fixes:
- Removed the accidental `mobileTopPadding` field from `_MobileAdminDashboardContent`.
- Added `mobileTopPadding` to the correct `_SampleTable` widget class.
- Keeps the mobile floating status tabs behavior from v154/v155.
- Keeps lab tech offline result completion from v155.

Updated file:
- lib/views/dashboard_view.dart
