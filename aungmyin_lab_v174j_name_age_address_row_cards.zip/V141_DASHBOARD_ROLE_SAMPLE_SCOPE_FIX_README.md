# v141 dashboard role sample scope fix

This build corrects dashboard blood-sample visibility by role.

Rules now applied by `sampleDashboardControllerProvider`:
- Superadmin can view all blood samples.
- Lab tech can view all blood samples.
- Admin users can view only blood samples from their own non-GLOBAL sub-center.
- Staff users can view only blood samples from their own non-GLOBAL sub-center.
- Referred person users can view all blood samples referred by their account, matched by referred person id and fallback referred person name.

Updated file:
- lib/providers/sample_dashboard_controller.dart

Preserved from earlier builds:
- v139 Advanced Analytics mobile rewrite.
- v138 Report Header footer load parse fix.
