# v120 stylish manual result display

This build fixes the manual test result screen so dynamic titles like `ESR Result` still render with the styled report layout instead of raw key/value chips.

Changes:
- Manual result detection no longer depends only on the title containing `Manual`.
- Manual result rows with `resultValue`, `parameter`, and `testName` now use the styled report card.
- Manual result card now has a cleaner rounded container, subtle border/shadow, and a result title inside the card.
- Keeps v119 dynamic app bar/result title behavior.
