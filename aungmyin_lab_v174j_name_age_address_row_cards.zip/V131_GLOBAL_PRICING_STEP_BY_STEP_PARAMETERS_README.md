# v131 global pricing step-by-step parameters

This build improves the Superadmin Global Pricing page by replacing the raw manual-default text box with a guided parameter builder.

Changes:
- Add New Test now shows `Step 3: Add result parameters`.
- Parameters are added one at a time through a Stepper dialog.
- The dialog asks for parameter name, result type, unit/reference range, and optional note.
- Qualitative mode stores blank unit/ref range, so v130 Positive/Negative display and print logic works automatically.
- Added edit and delete actions for each parameter before saving the test.
- Existing `ManualTestDefaults` pipe format remains compatible internally.
