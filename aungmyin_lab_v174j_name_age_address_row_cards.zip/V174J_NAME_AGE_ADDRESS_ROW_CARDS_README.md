### v174j name, age, address row on review and sample cards

This patch updates the patient information cards shown in the lab tech result popup and the desktop/tablet Blood Samples cards.

Changes:
- The manual review popup patient summary now shows Name, Age, and Address in one responsive row, with Test shown below.
- The desktop/tablet Blood Samples patient panel now shows Name, Age, and Address in one responsive row.
- BloodSample now preserves patientAddress from BloodSamples rows so cards can display the address.
- Existing Patient Age support from v174h is preserved.

Updated files:
- lib/models/blood_sample.dart
- lib/providers/sample_dashboard_controller.dart
- lib/views/dashboard_view.dart

Preserved:
- v174i Save & Print action in the lab tech review popup.
- v174h Positive red button and Positive/Negative print colors.
- v174g tablet/desktop Blood Samples minimum 2-column cards.
