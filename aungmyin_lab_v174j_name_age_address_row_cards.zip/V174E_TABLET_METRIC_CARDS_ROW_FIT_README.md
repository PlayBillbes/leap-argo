## v174e tablet dashboard metric cards row fit

This patch fixes the desktop/tablet dashboard metric cards shown at the top of Lab Dashboard.

Changes:
- Metric cards stay in one row on desktop/tablet widths instead of switching into a vertical column.
- Card gap, icon box, padding, title font, value font, and subtitle font now shrink based on available card width.
- The card content uses FittedBox and text overflow limits so the row fits better on tablet screens.

Preserved:
- Mobile dashboard branch remains unchanged.
- v174d lab tech update/replace completed results behavior.
- v174c compact Blood Samples cards and status filter.
