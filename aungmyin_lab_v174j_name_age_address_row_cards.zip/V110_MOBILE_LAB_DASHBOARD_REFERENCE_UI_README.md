# v110 mobile Lab Dashboard reference UI

This build updates the mobile Lab Dashboard to more closely match the provided reference screen.

Changes:
- Compact 4-card status summary row: Processing, Pending, Completed, Total Tests.
- Search field and Filters button above the sample list.
- All / Processing / Pending / Completed segmented status tabs.
- Responsive font/card scaling for phone widths.
- Mobile sample cards with status-colored left rail, status chip, patient/test details, metadata pills, and View / Review actions.
