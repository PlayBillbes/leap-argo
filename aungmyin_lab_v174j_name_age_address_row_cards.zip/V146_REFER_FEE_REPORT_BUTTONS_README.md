# v146 refer fee report buttons

This build adds print/PDF refer-fee reports in the analytics screens.

Changes:
- Added shared `ReferFeeReportService` for printable PDF reports using the existing `pdf` and `printing` packages.
- Admin Analytics now has Yearly and Monthly Refer Fee Report buttons for the current sub-center.
- Referred Person report page now has Yearly and Monthly Refer Fee Report buttons for the signed-in referred person.
- Superadmin Advanced Analytics now has All Refer Fees / Year and All Refer Fees / Month buttons for all sub-centers or the selected sub-center filter.
- Reports include total fee, sample count, test count, referred-person summary, and sample detail rows.

Preserved:
- v145 mobile Users page rewrite.
- v144 native Turso compile fix.
- v143 pure native Turso runtime cleanup.
