## v170 replace result without duplicates

This build prevents duplicate result rows when a lab tech replaces or re-saves a result for the same blood sample.

Changes:
- Manual TestResults rows for the same sample are removed before saving the replacement result.
- CBC / CP(Auto) CBCResults rows for the same sample are removed before saving the replacement result.
- Manual result row IDs are deterministic by sample, test name, and parameter.
- CBC result row ID is deterministic by sample ID.
- Existing v169 Blood Samples horizontal scroll fix is preserved.

Updated file:
- lib/views/dashboard_view.dart
