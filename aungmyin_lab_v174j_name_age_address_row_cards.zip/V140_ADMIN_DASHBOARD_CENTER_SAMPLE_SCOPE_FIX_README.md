# v140 admin dashboard center sample scope fix

This build fixes blood-sample visibility on dashboards.

Changes:
- Only superadmin can see all blood samples across all centers.
- Admin dashboard users now see only blood samples from their own sub-center.
- GLOBAL or empty sub-center sample rows are excluded for non-superadmin dashboards.
- The same provider-level filtering also protects other non-superadmin dashboard roles that use the dashboard sample provider.
- Existing v139 Advanced Analytics mobile rewrite and v138 Report Header footer load fix are preserved.

Updated file:
- lib/providers/sample_dashboard_controller.dart

Reason:
The previous dashboard filter allowed lab tech/global queue visibility and could let GLOBAL sample rows appear outside superadmin. The filter is now strict: superadmin returns all samples; every other user must have a non-GLOBAL sub-center and only sees matching non-GLOBAL sample rows.
