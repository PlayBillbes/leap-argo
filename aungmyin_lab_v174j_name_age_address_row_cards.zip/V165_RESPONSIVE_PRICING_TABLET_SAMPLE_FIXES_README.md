# v165 responsive pricing and tablet sample fixes

This build fixes three UI issues.

Changes:
- Global Pricing is now responsive for mobile and tablet widths.
- Global Pricing uses a compact single-column scroll layout below tablet/phone widths instead of forcing the editor and test list into a fixed height.
- The Global Pricing hero header now adapts to small widths and avoids button/text overflow.
- The Global Pricing test list can shrink-wrap inside the page scroll on compact screens while keeping the desktop split layout unchanged.
- The Blood Samples card for tablet/desktop users, including superadmin, is now vertically scrollable while preserving horizontal table scrolling.
- Mobile blood sample cards no longer show the test name twice. The info pill now shows the sub-center name, while the main detail line keeps the test name(s).

Updated files:
- lib/views/global_pricing_page.dart
- lib/views/dashboard_view.dart

Preserved:
- v164 referral report lab tech style.
- v163 Custom Pricing sticky search box.
- v162 superadmin delete blood sample row.
