# v130 manual qualitative mode

This build adds qualitative-mode handling for manual tests such as Positive/Negative results.

Changes:
- Manual result entry detects qualitative manual defaults when both reference range and unit are blank.
- Qualitative entry cards show a Qualitative badge and quick Positive/Negative chips while still allowing custom text.
- Manual qualitative result views display only Test and Result columns.
- Manual qualitative PDF reports display only Test and Result columns.
- Dashboard single/multi-select print hides Ref. Range and Unit columns when all selected manual rows are qualitative.
- Numeric/manual rows with reference ranges still keep normal Ref. Range, Unit, and high/low arrow behavior.
