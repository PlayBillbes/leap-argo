# v168 mobile lab tech review parameter layout fix

This build fixes the mobile layout for lab tech manual result review.

Changes:
- The manual result entry window now uses a responsive Dialog instead of a fixed-width AlertDialog.
- On mobile, the dialog uses safe inset padding, constrained height, and a scrollable parameter list.
- The Save Result button is full-width on mobile and stays visible below the scrollable parameter list.
- Parameter cards now wrap long parameter names and qualitative chips instead of overflowing.
- Positive/Negative buttons stack vertically on very narrow screens.
- Each parameter card can show its related test name, so parameters are easier to identify when multiple tests are in one sample.
- Helper text for unit/reference range now supports multiple lines on mobile.

Updated file:
- lib/views/dashboard_view.dart

Preserved:
- v167 mobile multi-select print bottom popup.
- v166 desktop Global Pricing and alert delete fix.
