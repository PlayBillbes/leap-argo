# v127 refer name in print and view

This build adds the referred person's name to result views and printed reports across mobile, tablet, and desktop layouts.

Changes:
- Sample result page now loads `referredPersonName` and `referredPersonId` from BloodSamples.
- CBC/CP(Auto) and manual result PDF headers now show `Refer Name`.
- Desktop/tablet CBC and manual result cards now show `Refer Name`.
- Mobile result details label now uses `Refer Name`.
- Dashboard mobile sample cards now show referred person name when available.
- Dashboard desktop/tablet blood sample table now includes a `Refer Name` column.
- Dashboard single/multi print header now includes `Refer Name`.
