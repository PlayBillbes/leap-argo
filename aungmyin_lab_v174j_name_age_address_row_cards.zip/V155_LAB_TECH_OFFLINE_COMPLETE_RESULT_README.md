# v155 lab tech offline result completion

This build fixes lab tech result completion when the device is offline.

Behavior:
- Lab tech can move a sample from Pending to Processing while offline.
- Lab tech can save manual results while offline.
- Lab tech can save CBC / CP(Auto) results while offline.
- Completing a result now writes an optimistic BloodSamples upsert into the local cache immediately.
- Completed offline samples show as Completed on the dashboard after provider refresh/reload.
- The same completion change is queued and syncs to Turso when the device is online.
- Status updates no longer depend on row-number updates, so queued offline completion is safer when remote row ordering changes.
- CBC / CP(Auto) batch completion also uses BloodSamples upsert behavior instead of row-number status updates.

Updated files:
- lib/views/dashboard_view.dart
- lib/views/cbc_cp_result_upload_page.dart

Preserved:
- v154 mobile floating status tabs.
- v153 mobile dashboard stats overflow fix.
- v152 offline registered samples appear immediately on dashboard cache.
- v151 automatic sync queue and Sync now button.
