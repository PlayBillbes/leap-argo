# v116 mobile role actions: view, print, multi-select print

This build updates the mobile Lab Dashboard sample-card actions by role.

Changes:
- Lab tech mobile cards show only the Review button.
- Other mobile users show View, Print, and Select actions on completed samples.
- Other mobile users get a compact multi-select print toolbar with selected count, Select all, Clear, and Print selected.
- Single Print and multi-select printing use the existing dashboard print functions.
- Keeps responsive sizing, all-role mobile dashboard support, and the v115 semantics/render fix.
