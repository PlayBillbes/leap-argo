# v125 referred person analytic report

This build adds a dedicated analytic report for referred person users on both mobile and desktop.

Changes:
- Added `/referred-person-report` route and `ReferredPersonAnalyticsReportPage`.
- Referred person users now get a Referral Report navigation item.
- Desktop report includes hero section, KPI cards, monthly referral summary, status overview, test summary, and recent referred samples.
- Mobile report includes pull-to-refresh, compact KPI grid, monthly summary, and recent sample cards.
- Referral fee calculation uses saved referred fee amount when available, otherwise calculates from customer price and referred fee percent.
- Route guard restricts the report to referred person users.
