function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('LabOps')
    .addItem('Create Users Sheet', 'createUsersSheet')
    .addToUi();
}

function createUsersSheet() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = spreadsheet.getSheetByName('Users');

  if (!sheet) {
    sheet = spreadsheet.insertSheet('Users');
  }

  sheet.clear();

  const headers = ['id', 'username', 'passwordHash', 'name', 'role', 'subCenterId'];
  sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  sheet.getRange(1, 1, 1, headers.length).setFontWeight('bold');

  const rows = [
    ['admin-001', 'superadmin', 'CHANGE_ME_TO_HASHED_PASSWORD', 'Super Admin', 'superadmin', 'GLOBAL'],
    ['admin-002', 'admin', 'CHANGE_ME_TO_HASHED_PASSWORD', 'Lab Admin', 'admin', 'CENTER-01'],
    ['tech-001', 'tech', 'CHANGE_ME_TO_HASHED_PASSWORD', 'Lab Technician', 'lab_tech', 'CENTER-01'],
    ['staff-001', 'staff', 'CHANGE_ME_TO_HASHED_PASSWORD', 'Staff', 'staff', 'CENTER-02'],
  ];

  sheet.getRange(2, 1, rows.length, headers.length).setValues(rows);
  sheet.autoResizeColumns(1, headers.length);

  return { ok: true, sheetName: sheet.getName() };
}
