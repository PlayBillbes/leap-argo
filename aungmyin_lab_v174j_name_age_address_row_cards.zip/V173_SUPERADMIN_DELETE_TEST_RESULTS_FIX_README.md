### v173 superadmin delete TestResults fix

This build fixes the remaining superadmin delete issue where matching manual result rows were found but not removed from the native Turso `test_results` table.

Changes:
- Added the missing `testresults` branch to `TursoNativeService.deleteRow`.
- Deleting `TestResults` rows now executes `delete from test_results where id = ?`.
- Existing v172 dashboard delete flow is preserved: related `TestResults` and `CBCResults` rows are deleted before the `BloodSamples` row.
- Existing CBC result deletion behavior is preserved.

Updated file:
- lib/services/turso_native_service.dart
