# v137 mobile Advanced Analytics responsive UI

This build improves the Superadmin Advanced Analytics page for mobile screens.

Changes:
- Advanced Analytics page padding now adapts to phone widths.
- Hero header changes from a wide row to a compact stacked layout on mobile.
- Main KPI cards use a two-column mobile grid instead of a long single-column stack.
- KPI cards resize icons, padding, and text for narrow widths to prevent overflow.
- Sub-center filter card now uses a full-width mobile dropdown below the row-count pill.
- Chart cards use smaller mobile padding and shorter chart height.
- Chart summary pills wrap on small screens instead of overflowing.
- Day-by-day chart labels are reduced on mobile for readability.
- Existing desktop/tablet layout is preserved.
