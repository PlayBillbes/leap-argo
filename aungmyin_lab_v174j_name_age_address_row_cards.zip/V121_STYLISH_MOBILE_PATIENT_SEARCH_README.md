# v121 stylish mobile patient search

This build improves the Search patient page on mobile.

Changes:
- Mobile page padding is reduced and responsive.
- Patient Search hero keeps a polished blue gradient while fitting narrow screens.
- Search criteria card no longer squeezes the title into a narrow column; stats move below the header on mobile.
- Name, age, sex, date, clear, and search controls are arranged specifically for mobile.
- Search results now use modern patient cards with status color rail, avatar, soft info pills, and a clear View Result button.
- Waiting and empty states remain compact for mobile.
