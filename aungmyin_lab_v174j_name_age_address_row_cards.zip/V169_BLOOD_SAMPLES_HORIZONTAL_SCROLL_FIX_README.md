## v169 Blood Samples horizontal scroll fix

This build fixes the tablet/desktop Blood Samples card horizontal scrolling.

Changes:
- Added a dedicated horizontal ScrollController for the desktop/tablet Blood Samples table.
- Added a visible bottom horizontal scrollbar with thumb and track visibility so users can drag-scroll the wide table.
- Enabled mouse, touch, and stylus drag gestures for the horizontal table scroll area.
- Kept the existing mobile sample card layout unchanged.
- Preserved v168 mobile lab tech review parameter layout fixes.

Updated file:
- lib/views/dashboard_view.dart
