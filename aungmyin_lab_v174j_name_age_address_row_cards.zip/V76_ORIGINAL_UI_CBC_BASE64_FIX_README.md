# v76 original UI native backend, CBC Base64 fix

This build keeps the original FlutterLab UI and uses native Turso tables.

CBC/CP(Auto) fix:
- `CBCResults!A:BH` is mapped to native table `cbc_results`.
- All CBC analyzer fields are persisted as columns, including:
  - `pltGraphBase64`
  - `diffHsmsBase64`
  - `diffLshsBase64`
  - `diffLsmsBase64`
  - `wbcGraphBase64`
  - `rbcGraphBase64`
- Existing Turso databases are upgraded by adding missing CBC columns on startup.
