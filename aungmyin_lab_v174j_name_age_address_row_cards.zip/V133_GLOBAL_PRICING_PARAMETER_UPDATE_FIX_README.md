# v133 global pricing parameter/update fix

This build fixes Global Pricing parameter editing and test updating.

Changes:
- The parameter builder now listens directly to its controller, so added/edited/deleted parameters update the visible list immediately.
- The Manage Defaults dialog now uses the same step-by-step parameter builder instead of the old raw pipe-text editor.
- Editing an existing test can update test name, default price, and parameters from the same structured UI.
- The tests provider is invalidated before the form is cleared after save, improving refresh reliability.
- Existing `ManualTestDefaults` pipe format remains compatible internally.
