# v150 admin sub-center report header control

This build updates Report Header permissions and PDF/print header behavior.

Rules:
- Superadmin can edit the global report header and footer.
- Admin can open Report Header and edit only their own non-GLOBAL sub-center report header.
- Admin cannot edit footer text.
- Staff and referred-person PDF/print outputs use the custom header saved for the sample's sub-center when available.
- If a sub-center header is not available, PDF/print output falls back to the global header.

Changes:
- /report-header route now allows superadmin and admin.
- Sidebar Report Header navigation is visible to superadmin and admin.
- Report Header page saves admin changes under `scopeType = SUBCENTER` and the admin's own `subCenterId`.
- Footer field is hidden/locked for admin and preserved instead of being overwritten.
- Result PDFs, dashboard print PDFs, and referral report PDFs continue resolving headers by sample/sub-center.

Preserved:
- v149 referral PDF layout fix and AungMyin Lab branding.
- v148 mobile login About/Settings blue buttons.
- v147 strict blood sample visibility.
