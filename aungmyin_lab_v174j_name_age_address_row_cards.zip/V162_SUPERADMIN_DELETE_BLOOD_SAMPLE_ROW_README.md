# v162 superadmin delete blood sample row

This build adds a superadmin-only delete action for blood sample rows.

Rules:
- Superadmin can delete any BloodSamples row when needed.
- Admin and staff can still only cancel Pending samples; they cannot delete rows.
- Lab tech does not get the delete action.

Behavior:
- Delete shows a confirmation dialog before removing the row.
- Delete removes the matching row from `BloodSamples` using the sample id/sampleId column.
- Delete uses the existing `TursoNativeService.deleteRow` path, so offline delete is queued and local cache is updated by the existing sync/cache layer.
- Selected print state is cleared for the deleted sample, and the dashboard provider is refreshed.

Updated file:
- lib/views/dashboard_view.dart

Preserved:
- v161 pending sample cancel.
- v160 superadmin/lab tech all blood samples visibility.
- v157 mobile sticky status tabs only.
