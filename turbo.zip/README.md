# FlutterLab — Haematology Lab App

This workspace contains model classes, services for Google Sheets/Drive, Riverpod state, and a responsive Dashboard view.

Quick setup

1. Place your service account JSON somewhere local, e.g. `~/.config/flutterlab/service_account.json`.
2. Ensure the service account has access to the Google Sheet and Drive folder you will use for testing.
3. Set environment variables for quick testing (optional):

```bash
export SERVICE_ACCOUNT_JSON=~/.config/flutterlab/service_account.json
export TEST_SPREADSHEET_ID=your_sheet_id_here
export TEST_DRIVE_FOLDER_ID=your_drive_folder_id_here
```

Commands

Install deps & generate code:

```bash
dart pub get
dart run build_runner build --delete-conflicting-outputs
```

Run analyzer + format:

```bash
dart analyze
dart format .
```

Run the upload test script (ensure `test-result.pdf` exists):

```bash
dart run bin/upload_test.dart
```

Run the app (example):

```bash
flutter run -d windows
# or
flutter run -d emulator-5554
```

Testing ReportGenerator

Create a `test/report_generator_test.dart` and run:

```bash
flutter test
```

Notes

- Keep service account JSON private.
- Use a dedicated test spreadsheet/folder for development to avoid corrupting production data.
