import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/app_user.dart';

final authNotifierProvider = StateNotifierProvider<AuthNotifier, AppUser?>(
  (ref) => AuthNotifier(),
);

class AuthNotifier extends StateNotifier<AppUser?> {
  AuthNotifier() : super(null);

  final _streamController = StreamController<AppUser?>.broadcast();

  Stream<AppUser?> get stream => _streamController.stream;

  void setUser(AppUser user) {
    state = user;
    _streamController.add(state);
  }

  void clearUser() {
    state = null;
    _streamController.add(state);
  }

  bool get isAuthenticated => state != null;

  bool hasRole(AppUserRole role) => state?.role == role;

  @override
  void dispose() {
    _streamController.close();
    super.dispose();
  }
}
