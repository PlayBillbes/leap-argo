import 'dart:async';

import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../config/google_config.dart';
import '../models/app_user.dart';
import '../models/blood_sample.dart';
import '../providers/auth_notifier.dart';
import '../services/google_sheets_service.dart';

final sampleDashboardControllerProvider =
    AsyncNotifierProvider<SampleDashboardController, List<BloodSample>>(
      SampleDashboardController.new,
    );

class SampleDashboardController extends AsyncNotifier<List<BloodSample>> {
  GoogleSheetsService? _googleSheetsService;
  String _spreadsheetId = GoogleConfig.spreadsheetId;
  String _range = 'BloodSamples!A:Z';

  @override
  FutureOr<List<BloodSample>> build() async {
    return fetchSamples();
  }

  Future<List<BloodSample>> fetchSamples() async {
    final user = ref.read(authNotifierProvider);

    if (user == null) {
      return [];
    }

    state = const AsyncValue.loading();

    // Lazily create the Sheets service using the local asset service account JSON
    _googleSheetsService ??= (await (() async {
      final serviceAccountJson = await rootBundle.loadString(
        'assets/service-account.json',
      );
      return GoogleSheetsService(
        serviceAccountJson: serviceAccountJson,
        applicationName: 'flutterlab',
      );
    })());

    final rows = await _googleSheetsService!.fetchRows(
      spreadsheetId: _spreadsheetId,
      range: _range,
    );

    if (rows.isEmpty) {
      state = const AsyncValue.data(<BloodSample>[]);
      return <BloodSample>[];
    }

    // Parse header row to support flexible column ordering
    final headers = rows.first
        .map((h) => h.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();

    // Show the newest rows first: Google Sheets appends new samples at the bottom.
    final sampleRows = rows.skip(1).toList().reversed;

    final samples = sampleRows
        .map((row) {
          final Map<String, String> map = {};
          for (var i = 0; i < headers.length; i++) {
            final key = headers[i];
            final value = i < row.length ? row[i].toString() : '';
            map[key] = value;
          }

          return _rowMapToBloodSample(map);
        })
        .whereType<BloodSample>()
        .toList();

    final filteredSamples = _filterSamples(samples, user);
    state = AsyncValue.data(filteredSamples);
    return filteredSamples;
  }

  List<BloodSample> _filterSamples(List<BloodSample> samples, AppUser user) {
    // Superadmin and lab technicians can see the global sample queue.
    // Admin and staff users should only see samples from their own sub-center.
    if (user.role == AppUserRole.superadmin || user.role == AppUserRole.lab_tech) {
      return samples;
    }

    final userSubCenterId = _normalizeSubCenterId(user.subCenterId);
    if (userSubCenterId.isEmpty) {
      return <BloodSample>[];
    }

    return samples.where((sample) {
      return _normalizeSubCenterId(sample.subCenterId) == userSubCenterId;
    }).toList();
  }

  String _normalizeSubCenterId(String? value) {
    final cleaned = (value ?? '')
        .trim()
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9]'), '');

    // Treat CENTER-1, CENTER_1, center 1 and CENTER-01 as the same center.
    return cleaned.replaceAllMapped(
      RegExp(r'([a-z]+)0+(\d+)$'),
      (match) => '${match.group(1)}${match.group(2)}',
    );
  }


  DateTime? _parseSheetDate(String value) {
    final raw = value.trim();
    if (raw.isEmpty) return null;

    final direct = DateTime.tryParse(raw);
    if (direct != null) return direct;

    final match = RegExp(
      r'^(\d{4})[-/](\d{1,2})[-/](\d{1,2})[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?',
    ).firstMatch(raw);
    if (match == null) return null;

    final year = int.tryParse(match.group(1) ?? '');
    final month = int.tryParse(match.group(2) ?? '');
    final day = int.tryParse(match.group(3) ?? '');
    final hour = int.tryParse(match.group(4) ?? '');
    final minute = int.tryParse(match.group(5) ?? '');
    final second = int.tryParse(match.group(6) ?? '0') ?? 0;

    if (year == null ||
        month == null ||
        day == null ||
        hour == null ||
        minute == null) {
      return null;
    }

    return DateTime(year, month, day, hour, minute, second);
  }

  BloodSample? _rowToBloodSample(List<String> row) {
    if (row.isEmpty) {
      return null;
    }

    try {
      return BloodSample(
        id: row[0].trim(),
        patientName: row[1].trim(),
        subCenterId: row[2].trim(),
        registeredByUserId: row[3].trim(),
        testIds: row[4]
            .split(',')
            .map((value) => value.trim())
            .where((value) => value.isNotEmpty)
            .toList(),
        status: BloodSampleStatus.values.firstWhere(
          (status) => status.name == row[5].trim(),
          orElse: () => BloodSampleStatus.pending,
        ),
        resultFileUrl: row.length > 6 ? row[6].trim() : null,
        createdAt: row.length > 7 && row[7].trim().isNotEmpty
            ? _parseSheetDate(row[7].trim())
            : null,
        updatedAt: row.length > 8 && row[8].trim().isNotEmpty
            ? _parseSheetDate(row[8].trim())
            : null,
      );
    } catch (_) {
      return null;
    }
  }

  BloodSample? _rowMapToBloodSample(Map<String, String> row) {
    if (row.isEmpty) return null;

    try {
      final id = row['id'] ?? row['sampleid'] ?? '';
      final patientName = row['patientname'] ?? row['patient'] ?? '';
      final subCenterId =
          row['subcenterid'] ?? row['center'] ?? row['subcenter'] ?? 'GLOBAL';
      final registeredBy =
          row['registeredbyuserid'] ?? row['registeredby'] ?? '';
      final testIdsRaw = row['testids'] ?? row['tests'] ?? '';
      final statusRaw = (row['status'] ?? 'pending').trim().toLowerCase();
      final resultUrl = row['resulturl'] ?? row['result'] ?? '';
      final createdAtRaw = row['createdat'] ?? row['created'] ?? '';
      final updatedAtRaw = row['updatedat'] ?? row['updated'] ?? '';

      final testIds = testIdsRaw
          .split(',')
          .map((s) => s.trim())
          .where((s) => s.isNotEmpty)
          .toList();

      final status = BloodSampleStatus.values.firstWhere(
        (s) => s.name == statusRaw,
        orElse: () => BloodSampleStatus.pending,
      );

      return BloodSample(
        id: id,
        patientName: patientName,
        subCenterId: subCenterId,
        registeredByUserId: registeredBy,
        testIds: testIds,
        status: status,
        resultFileUrl: resultUrl.isNotEmpty ? resultUrl : null,
        createdAt: createdAtRaw.isNotEmpty
            ? _parseSheetDate(createdAtRaw)
            : null,
        updatedAt: updatedAtRaw.isNotEmpty
            ? _parseSheetDate(updatedAtRaw)
            : null,
      );
    } catch (_) {
      return null;
    }
  }
}
