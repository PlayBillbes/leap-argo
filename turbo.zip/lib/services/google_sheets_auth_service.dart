import 'dart:convert';

import 'package:crypto/crypto.dart';

import '../models/app_user.dart';
import 'google_sheets_service.dart';

class GoogleSheetsAuthService {
  GoogleSheetsAuthService({
    required this.serviceAccountJson,
    required this.applicationName,
    required this.spreadsheetId,
    this.sheetName = 'Users',
  });

  final String serviceAccountJson;
  final String applicationName;
  final String spreadsheetId;
  final String sheetName;

  Future<AppUser?> signIn({
    required String username,
    required String password,
  }) async {
    if (spreadsheetId.isEmpty) {
      throw StateError(
        'No spreadsheet ID configured. Pass --dart-define=GOOGLE_SPREADSHEET_ID=... when running the app.',
      );
    }

    final sheetsService = GoogleSheetsService(
      serviceAccountJson: serviceAccountJson,
      applicationName: applicationName,
    );

    try {
      final rows = await sheetsService.fetchRows(
        spreadsheetId: spreadsheetId,
        range: '$sheetName!A:F',
      );

      final users = _parseUsers(rows);
      final normalizedUsername = username.trim().toLowerCase();
      final passwordHash = _hashPassword(password);

      for (final user in users) {
        if (user.username.toLowerCase() == normalizedUsername &&
            user.passwordHash == passwordHash) {
          return AppUser(
            id: user.id.isNotEmpty ? user.id : user.username,
            name: user.name.isNotEmpty ? user.name : user.username,
            role: _parseRole(user.role),
            subCenterId: user.subCenterId.isNotEmpty
                ? user.subCenterId
                : 'GLOBAL',
          );
        }
      }

      return null;
    } finally {
      await sheetsService.close();
    }
  }

  List<_SheetUserRecord> _parseUsers(List<List<String>> rows) {
    if (rows.isEmpty) {
      return const <_SheetUserRecord>[];
    }

    final headers = rows.first
        .map((header) => header.trim().toLowerCase())
        .toList();
    final usernameIndex = headers.indexOf('username');
    final passwordHashIndex = headers.indexOf('passwordhash');
    final nameIndex = headers.indexOf('name');
    final roleIndex = headers.indexOf('role');
    final subCenterIdIndex = headers.indexOf('subcenterid');

    return rows
        .skip(1)
        .where((row) => row.isNotEmpty && row.first.trim().isNotEmpty)
        .map((row) {
          return _SheetUserRecord(
            username: usernameIndex >= 0 && usernameIndex < row.length
                ? row[usernameIndex]
                : '',
            passwordHash:
                passwordHashIndex >= 0 && passwordHashIndex < row.length
                ? row[passwordHashIndex]
                : '',
            name: nameIndex >= 0 && nameIndex < row.length
                ? row[nameIndex]
                : '',
            role: roleIndex >= 0 && roleIndex < row.length
                ? row[roleIndex]
                : 'staff',
            subCenterId: subCenterIdIndex >= 0 && subCenterIdIndex < row.length
                ? row[subCenterIdIndex]
                : 'GLOBAL',
            id: row.isNotEmpty ? row.first : '',
          );
        })
        .toList();
  }

  AppUserRole _parseRole(String role) {
    return AppUserRole.values.firstWhere(
      (value) => value.name == role.trim().toLowerCase(),
      orElse: () => AppUserRole.staff,
    );
  }

  String _hashPassword(String password) {
    return sha256.convert(utf8.encode(password)).toString();
  }
}

class _SheetUserRecord {
  const _SheetUserRecord({
    required this.username,
    required this.passwordHash,
    required this.name,
    required this.role,
    required this.subCenterId,
    required this.id,
  });

  final String username;
  final String passwordHash;
  final String name;
  final String role;
  final String subCenterId;
  final String id;
}
