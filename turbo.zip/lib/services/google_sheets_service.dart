import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/turso_config.dart';

/// Compatibility adapter that keeps the existing app code working while using
/// Turso SQL over HTTP instead of Google Sheets.
///
/// Existing pages still call fetchRows/insertRow/updateRow with Google-Sheets-like
/// ranges such as `BloodSamples!A:Z`. This adapter maps each sheet name to a
/// SQLite table and stores the sheet header order in `_app_sheet_headers`.
class GoogleSheetsService {
  GoogleSheetsService({
    required String serviceAccountJson,
    required this.applicationName,
    this.maxRetries = 3,
    this.initialDelayMs = 500,
  });

  final String applicationName;
  final int maxRetries;
  final int initialDelayMs;

  bool _bootstrapped = false;

  Future<void> _bootstrapMetaTables() async {
    if (_bootstrapped) return;
    await _executeSql('''
      create table if not exists _app_sheet_headers (
        sheet_name text primary key,
        headers_json text not null
      )
    ''');
    _bootstrapped = true;
  }

  Future<List<List<String>>> fetchRows({
    required String spreadsheetId,
    required String range,
  }) async {
    return _executeWithRetry(
      action: () async {
        await _bootstrapMetaTables();
        final sheetName = _sheetNameFromRange(range);
        final tableName = _tableName(sheetName);
        final headers = await _headersForSheet(sheetName);
        if (headers.isEmpty) return <List<String>>[];
        await _ensureTable(sheetName, headers);

        final columns = headers.map(_columnName).toList();
        final selected = columns.map((column) => '"$column"').join(', ');
        final rows = await _executeSql(
          'select $selected from "$tableName" order by _rowid',
        );
        return <List<String>>[
          headers,
          for (final row in rows)
            [for (final column in columns) (row[column] ?? '').toString()],
        ];
      },
      spreadsheetId: spreadsheetId,
      range: range,
    );
  }

  Future<void> insertRow({
    required String spreadsheetId,
    required String range,
    required List<String> values,
    String valueInputOption = 'USER_ENTERED',
  }) async {
    await _executeWithRetry(
      action: () async {
        await _bootstrapMetaTables();
        final sheetName = _sheetNameFromRange(range);
        var headers = await _headersForSheet(sheetName);
        if (headers.isEmpty) {
          headers = List.generate(values.length, (index) => 'column${index + 1}');
          await _saveHeaders(sheetName, headers);
        }
        await _ensureTable(sheetName, headers);

        final columns = headers.map(_columnName).toList();
        final insertColumns = columns.map((column) => '"$column"').join(', ');
        final insertValues = <String>[];
        for (var i = 0; i < columns.length; i++) {
          insertValues.add(_sqlString(i < values.length ? values[i] : ''));
        }
        await _executeSql(
          'insert into "${_tableName(sheetName)}" ($insertColumns) values (${insertValues.join(', ')})',
        );
      },
      spreadsheetId: spreadsheetId,
      range: range,
    );
  }

  Future<void> updateRow({
    required String spreadsheetId,
    required String range,
    required List<String> values,
  }) async {
    await _executeWithRetry(
      action: () async {
        await _bootstrapMetaTables();
        final parsed = _parseRange(range);
        final sheetName = parsed.sheetName;

        if (parsed.rowNumber == 1) {
          final headers = values.where((value) => value.trim().isNotEmpty).toList();
          await _saveHeaders(sheetName, headers);
          await _ensureTable(sheetName, headers);
          return;
        }

        final headers = await _headersForSheet(sheetName);
        if (headers.isEmpty) {
          throw GoogleSheetsException(message: 'No headers exist for table $sheetName.');
        }
        await _ensureTable(sheetName, headers);

        final rowId = await _rowIdForSheetRow(sheetName, parsed.rowNumber);
        if (rowId == null) {
          await _insertBlankRowsUntil(sheetName, headers, parsed.rowNumber);
          final newRowId = await _rowIdForSheetRow(sheetName, parsed.rowNumber);
          if (newRowId == null) return;
          await _updateDataRow(sheetName, headers, newRowId, parsed.startColumnIndex, values);
          return;
        }
        await _updateDataRow(sheetName, headers, rowId, parsed.startColumnIndex, values);
      },
      spreadsheetId: spreadsheetId,
      range: range,
    );
  }

  Future<void> ensureSheet({
    required String spreadsheetId,
    required String sheetName,
  }) async {
    await _executeWithRetry(
      action: () async {
        await _bootstrapMetaTables();
        final headers = await _headersForSheet(sheetName);
        await _ensureTable(sheetName, headers);
      },
      spreadsheetId: spreadsheetId,
      range: '$sheetName!A:A',
    );
  }

  Future<void> deleteRow({
    required String spreadsheetId,
    required String sheetName,
    required int rowIndexOneBased,
  }) async {
    await _executeWithRetry(
      action: () async {
        await _bootstrapMetaTables();
        if (rowIndexOneBased <= 1) return;
        final rowId = await _rowIdForSheetRow(sheetName, rowIndexOneBased);
        if (rowId == null) return;
        await _executeSql('delete from "${_tableName(sheetName)}" where _rowid = $rowId');
      },
      spreadsheetId: spreadsheetId,
      range: '$sheetName!$rowIndexOneBased:$rowIndexOneBased',
    );
  }

  Future<T> _executeWithRetry<T>({
    required Future<T> Function() action,
    required String spreadsheetId,
    required String range,
  }) async {
    Object? lastError;
    for (var attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        return await action();
      } catch (error) {
        lastError = error;
        if (attempt == maxRetries) {
          if (error is GoogleSheetsException) rethrow;
          throw GoogleSheetsException(
            message: 'Turso request failed for $range',
            cause: error,
          );
        }
        await Future.delayed(Duration(milliseconds: initialDelayMs * attempt));
      }
    }
    throw GoogleSheetsException(
      message: 'Turso request exhausted retries for $range',
      cause: lastError,
    );
  }

  Future<List<Map<String, dynamic>>> _executeSql(String sql) async {
    if (!TursoConfig.isConfigured) {
      throw GoogleSheetsException(
        message:
            'Turso is not configured. Run with --dart-define=TURSO_DATABASE_URL=... and --dart-define=TURSO_AUTH_TOKEN=...',
      );
    }

    final response = await http.post(
      Uri.parse(_pipelineUrl()),
      headers: <String, String>{
        'Authorization': 'Bearer ${TursoConfig.authToken}',
        'Content-Type': 'application/json',
      },
      body: jsonEncode(<String, Object>{
        'requests': <Object>[
          <String, Object>{
            'type': 'execute',
            'stmt': <String, String>{'sql': sql},
          },
          <String, String>{'type': 'close'},
        ],
      }),
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw GoogleSheetsException(
        message: 'Turso HTTP ${response.statusCode}: ${response.body}',
      );
    }

    final decoded = jsonDecode(response.body);
    if (decoded is! Map<String, dynamic>) return const <Map<String, dynamic>>[];
    final results = decoded['results'];
    if (results is! List || results.isEmpty) return const <Map<String, dynamic>>[];
    final first = results.first;
    if (first is! Map<String, dynamic>) return const <Map<String, dynamic>>[];
    if (first['type'] != 'ok') {
      throw GoogleSheetsException(message: 'Turso SQL error: ${jsonEncode(first)}');
    }
    final responseMap = first['response'];
    if (responseMap is! Map<String, dynamic>) return const <Map<String, dynamic>>[];
    final result = responseMap['result'];
    if (result is! Map<String, dynamic>) return const <Map<String, dynamic>>[];
    return _rowsFromResult(result);
  }

  List<Map<String, dynamic>> _rowsFromResult(Map<String, dynamic> result) {
    final rawCols = result['cols'];
    final rawRows = result['rows'];
    if (rawCols is! List || rawRows is! List) return const <Map<String, dynamic>>[];

    final columnNames = <String>[
      for (final col in rawCols)
        if (col is Map)
          (col['name'] ?? col['column'] ?? col['label'] ?? '').toString()
        else
          col.toString(),
    ];

    final mappedRows = <Map<String, dynamic>>[];
    for (final rawRow in rawRows) {
      if (rawRow is Map<String, dynamic>) {
        mappedRows.add(rawRow);
        continue;
      }
      if (rawRow is! List) continue;
      final row = <String, dynamic>{};
      for (var i = 0; i < columnNames.length && i < rawRow.length; i++) {
        row[columnNames[i]] = _valueFromSqlCell(rawRow[i]);
      }
      mappedRows.add(row);
    }
    return mappedRows;
  }

  dynamic _valueFromSqlCell(dynamic cell) {
    if (cell == null) return '';
    if (cell is Map) {
      final type = cell['type']?.toString();
      if (type == 'null') return '';
      if (cell.containsKey('value')) return cell['value'] ?? '';
      if (cell.containsKey('base64')) return cell['base64'] ?? '';
      return cell.values.isEmpty ? '' : cell.values.last;
    }
    return cell;
  }

  String _pipelineUrl() {
    var url = TursoConfig.databaseUrl.trim();
    if (url.startsWith('libsql://')) {
      url = 'https://${url.substring('libsql://'.length)}';
    }
    if (url.endsWith('/')) url = url.substring(0, url.length - 1);
    if (!url.endsWith('/v2/pipeline')) url = '$url/v2/pipeline';
    return url;
  }

  Future<List<String>> _headersForSheet(String sheetName) async {
    final rows = await _executeSql(
      'select headers_json from _app_sheet_headers where sheet_name = ${_sqlString(sheetName)} limit 1',
    );
    if (rows.isEmpty) return <String>[];
    final raw = rows.first['headers_json']?.toString() ?? '[]';
    final decoded = jsonDecode(raw);
    if (decoded is! List) return <String>[];
    return decoded.map((value) => value.toString()).toList();
  }

  Future<void> _saveHeaders(String sheetName, List<String> headers) async {
    final cleaned = <String>[];
    final seen = <String>{};
    for (final header in headers) {
      final value = header.trim();
      if (value.isEmpty) continue;
      final key = _columnName(value);
      if (seen.contains(key)) continue;
      seen.add(key);
      cleaned.add(value);
    }
    await _executeSql(
      'insert into _app_sheet_headers(sheet_name, headers_json) values (${_sqlString(sheetName)}, ${_sqlString(jsonEncode(cleaned))}) '
      'on conflict(sheet_name) do update set headers_json = excluded.headers_json',
    );
  }

  Future<void> _ensureTable(String sheetName, List<String> headers) async {
    final tableName = _tableName(sheetName);
    await _executeSql('create table if not exists "$tableName" (_rowid integer primary key autoincrement)');
    for (final header in headers) {
      final column = _columnName(header);
      try {
        await _executeSql('alter table "$tableName" add column "$column" text');
      } catch (_) {
        // Column already exists. SQLite has no ADD COLUMN IF NOT EXISTS.
      }
    }
  }

  Future<int?> _rowIdForSheetRow(String sheetName, int rowNumberOneBased) async {
    if (rowNumberOneBased <= 1) return null;
    final offset = rowNumberOneBased - 2;
    final rows = await _executeSql(
      'select _rowid from "${_tableName(sheetName)}" order by _rowid limit 1 offset $offset',
    );
    if (rows.isEmpty) return null;
    return int.tryParse(rows.first['_rowid'].toString());
  }

  Future<void> _insertBlankRowsUntil(String sheetName, List<String> headers, int rowNumberOneBased) async {
    final tableName = _tableName(sheetName);
    final rows = await _executeSql('select count(*) as count from "$tableName"');
    final count = rows.isEmpty ? 0 : int.tryParse(rows.first['count'].toString()) ?? 0;
    final targetDataRows = rowNumberOneBased - 1;
    for (var i = count; i < targetDataRows; i++) {
      await _executeSql('insert into "$tableName" default values');
    }
  }

  Future<void> _updateDataRow(
    String sheetName,
    List<String> headers,
    int rowId,
    int startColumnIndex,
    List<String> values,
  ) async {
    final assignments = <String>[];
    for (var i = 0; i < values.length; i++) {
      final headerIndex = startColumnIndex + i;
      if (headerIndex < 0 || headerIndex >= headers.length) continue;
      final column = _columnName(headers[headerIndex]);
      assignments.add('"$column" = ${_sqlString(values[i])}');
    }
    if (assignments.isEmpty) return;
    await _executeSql(
      'update "${_tableName(sheetName)}" set ${assignments.join(', ')} where _rowid = $rowId',
    );
  }

  _ParsedRange _parseRange(String range) {
    final parts = range.split('!');
    final sheetName = parts.first.trim();
    final cellRange = parts.length > 1 ? parts[1].trim() : 'A:A';
    final match = RegExp(r'^([A-Za-z]+)?(\d+)?').firstMatch(cellRange);
    final columnLetters = match?.group(1) ?? 'A';
    final rowNumber = int.tryParse(match?.group(2) ?? '') ?? 1;
    return _ParsedRange(
      sheetName: sheetName,
      rowNumber: rowNumber,
      startColumnIndex: _columnIndex(columnLetters),
    );
  }

  String _sheetNameFromRange(String range) => range.split('!').first.trim();

  int _columnIndex(String letters) {
    var value = 0;
    for (final codeUnit in letters.toUpperCase().codeUnits) {
      if (codeUnit < 65 || codeUnit > 90) continue;
      value = value * 26 + (codeUnit - 64);
    }
    return value <= 0 ? 0 : value - 1;
  }

  String _tableName(String sheetName) {
    final cleaned = sheetName.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9_]'), '_');
    return cleaned.isEmpty ? 'sheet' : 'sheet_$cleaned';
  }

  String _columnName(String header) {
    final cleaned = header.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9_]'), '');
    return cleaned.isEmpty ? 'column' : cleaned;
  }

  String _sqlString(String value) => "'${value.replaceAll("'", "''")}'";

  Future<void> close() async {}
}

class _ParsedRange {
  const _ParsedRange({
    required this.sheetName,
    required this.rowNumber,
    required this.startColumnIndex,
  });

  final String sheetName;
  final int rowNumber;
  final int startColumnIndex;
}

class GoogleSheetsException implements Exception {
  GoogleSheetsException({required this.message, this.cause});

  final String message;
  final Object? cause;

  @override
  String toString() =>
      'TursoBackendException: $message${cause == null ? '' : ' ($cause)'}';
}
