import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:googleapis/drive/v3.dart' as drive;
import 'package:googleapis_auth/auth_io.dart' as auth;

import 'google_sheets_service.dart';

class GoogleDriveService {
  GoogleDriveService({required String serviceAccountJson, required this.applicationName})
      : _serviceAccountJson = serviceAccountJson;

  final String _serviceAccountJson;
  final String applicationName;
  auth.AuthClient? _client;
  drive.DriveApi? _driveApi;

  Future<drive.DriveApi> _getDriveApi() async {
    if (_driveApi != null) return _driveApi!;
    final credentials = auth.ServiceAccountCredentials.fromJson(jsonDecode(_serviceAccountJson));
    _client = await auth.clientViaServiceAccount(credentials, [drive.DriveApi.driveScope]);
    _driveApi = drive.DriveApi(_client!);
    return _driveApi!;
  }

  Future<String> uploadPdfToSharedFolder({
    required File file,
    required String parentFolderId,
    String? fileName,
    void Function(int uploadedBytes, int totalBytes)? onProgress,
  }) async {
    if (!await file.exists()) throw GoogleDriveException(message: 'File does not exist: ${file.path}');
    final api = await _getDriveApi();
    await _verifyParentFolderAccess(api: api, parentFolderId: parentFolderId);
    final totalBytes = await file.length();
    final media = drive.Media(_withProgress(file.openRead(), totalBytes, onProgress), totalBytes);
    final driveFile = drive.File()
      ..name = fileName ?? file.uri.pathSegments.last
      ..parents = [parentFolderId]
      ..mimeType = 'application/pdf';
    return _uploadMedia(api: api, media: media, driveFile: driveFile);
  }

  Future<String> uploadPdfAndSaveLink({
    required File file,
    required String parentFolderId,
    required GoogleSheetsService sheetsService,
    required String spreadsheetId,
    required String targetRange,
    required int rowIndex,
    required int columnIndex,
    String? fileName,
  }) async {
    final webViewLink = await uploadPdfToSharedFolder(file: file, parentFolderId: parentFolderId, fileName: fileName);
    final cellValue = [for (var i = 0; i <= columnIndex; i++) if (i == columnIndex) webViewLink else ''];
    await sheetsService.updateRow(spreadsheetId: spreadsheetId, range: '$targetRange${rowIndex + 1}', values: cellValue);
    return webViewLink;
  }

  Future<String> uploadPdfBytesToSharedFolder({
    required Uint8List bytes,
    required String parentFolderId,
    required String fileName,
    void Function(int uploadedBytes, int totalBytes)? onProgress,
  }) async {
    if (bytes.isEmpty) throw GoogleDriveException(message: 'Selected PDF is empty.');
    final api = await _getDriveApi();
    await _verifyParentFolderAccess(api: api, parentFolderId: parentFolderId);
    final totalBytes = bytes.length;
    final media = drive.Media(_withProgress(Stream<List<int>>.value(bytes), totalBytes, onProgress), totalBytes);
    final driveFile = drive.File()
      ..name = fileName
      ..parents = [parentFolderId]
      ..mimeType = 'application/pdf';
    return _uploadMedia(api: api, media: media, driveFile: driveFile);
  }


  Future<String> uploadBytesToSharedFolder({
    required Uint8List bytes,
    required String parentFolderId,
    required String fileName,
    required String mimeType,
    void Function(int uploadedBytes, int totalBytes)? onProgress,
  }) async {
    if (bytes.isEmpty) throw GoogleDriveException(message: 'Selected file is empty.');
    final api = await _getDriveApi();
    await _verifyParentFolderAccess(api: api, parentFolderId: parentFolderId);
    final totalBytes = bytes.length;
    final media = drive.Media(_withProgress(Stream<List<int>>.value(bytes), totalBytes, onProgress), totalBytes);
    final driveFile = drive.File()
      ..name = fileName
      ..parents = [parentFolderId]
      ..mimeType = mimeType;
    return _uploadMedia(api: api, media: media, driveFile: driveFile);
  }

  Future<String> _uploadMedia({required drive.DriveApi api, required drive.Media media, required drive.File driveFile}) async {
    final uploaded = await api.files.create(driveFile, uploadMedia: media, $fields: 'id,webViewLink', supportsAllDrives: true);
    if (uploaded.id == null || uploaded.id!.isEmpty) {
      throw GoogleDriveException(message: 'Upload succeeded, but no file ID was returned.');
    }
    await api.permissions.create(drive.Permission()..type = 'anyone'..role = 'reader', uploaded.id!, supportsAllDrives: true);
    if (uploaded.webViewLink != null && uploaded.webViewLink!.isNotEmpty) return uploaded.webViewLink!;
    final fetched = await api.files.get(uploaded.id!, $fields: 'webViewLink', supportsAllDrives: true) as drive.File;
    final webViewLink = fetched.webViewLink;
    if (webViewLink == null || webViewLink.isEmpty) {
      throw GoogleDriveException(message: 'Upload succeeded, but no web view link was returned.');
    }
    return webViewLink;
  }

  Future<void> _verifyParentFolderAccess({required drive.DriveApi api, required String parentFolderId}) async {
    try {
      final folder = await api.files.get(parentFolderId, $fields: 'id,name,mimeType,driveId', supportsAllDrives: true) as drive.File;
      if (folder.mimeType != 'application/vnd.google-apps.folder') {
        throw GoogleDriveException(message: 'Configured Drive ID is not a folder. Use the folder ID from a /folders/ URL, not the Shared Drive root ID. ID: $parentFolderId');
      }
    } catch (error) {
      if (error is GoogleDriveException) rethrow;
      throw GoogleDriveException(
        message: 'Drive folder not found or service account cannot access it. Use the actual folder ID from a /folders/ URL, not the Shared Drive root ID. Add the service account as Shared Drive member or folder Editor/Contributor, and confirm external sharing is allowed. Folder ID: $parentFolderId',
        cause: error,
      );
    }
  }

  Stream<List<int>> _withProgress(Stream<List<int>> source, int totalBytes, void Function(int uploadedBytes, int totalBytes)? onProgress) async* {
    var uploadedBytes = 0;
    await for (final chunk in source) {
      uploadedBytes += chunk.length;
      onProgress?.call(uploadedBytes, totalBytes);
      yield chunk;
    }
    onProgress?.call(totalBytes, totalBytes);
  }

  Future<void> close() async {
    _client?.close();
    _client = null;
    _driveApi = null;
  }
}

class GoogleDriveException implements Exception {
  GoogleDriveException({required this.message, this.cause});
  final String message;
  final Object? cause;
  @override
  String toString() => 'GoogleDriveException: $message${cause == null ? '' : ' ($cause)'}';
}
