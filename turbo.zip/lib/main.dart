import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'routes/app_router.dart';
import 'providers/auth_notifier.dart';
import 'models/app_user.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  final container = ProviderContainer();
  runApp(UncontrolledProviderScope(container: container, child: const App()));
}

class App extends ConsumerWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(appRouterProvider);

    return MaterialApp.router(
      title: 'FlutterLab',
      debugShowCheckedModeBanner: false,
      routerConfig: router,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2563EB),
          brightness: Brightness.light,
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2563EB),
          brightness: Brightness.dark,
        ),
      ),
      themeMode: ThemeMode.system,
    );
  }
}

// Debug utility: call this at runtime to change the active test user
void seedTestUser(ProviderContainer container, {required String role, String? subCenterId}) {
  final user = AppUser(
    id: 'test-user',
    name: 'Test User',
    role: AppUserRole.values.firstWhere(
      (r) => r.name == role,
      orElse: () => AppUserRole.staff,
    ),
    subCenterId: subCenterId,
  );

  container.read(authNotifierProvider.notifier).setUser(user);
}
