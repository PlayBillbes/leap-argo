class TursoConfig {
  static const String databaseUrl = 'libsql://lab-network-modsbots.aws-ap-south-1.turso.io';
  static const String authToken = 'eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhIjoicnciLCJpYXQiOjE3ODQ3ODk1MjksImlkIjoiMDE5ZjhkYmQtYzIwMS03MzljLWEzMzktZjVmYWYzZjMyZTM3Iiwia2lkIjoiZWd3ZFFqVmUwUFR1ZnV2VnQ5WmFUN3hNMlNDMVh1S0MyQ3h3VzBhZFNaNCIsInJpZCI6ImRiNDM4ZDZmLWIzZWUtNGFhMS1iZjQ0LWM0MDQ1ZWI2YjYwMSJ9.3j7E8jEyjw-dY80ORn6IPtXgxccbPWf7aZsrSs3nm-Nx_q3atIuuU11tRoonU20mZIGPjmBcOb7sPZFU3-QfBw';

  static bool get isConfigured => databaseUrl.trim().isNotEmpty && authToken.trim().isNotEmpty;
}
