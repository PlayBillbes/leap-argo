class GoogleConfig {
  static const String spreadsheetId = '1tocrNazYx1UBXtQ_g4BAc4Z9q9W-nPYObsXEaJJjGT4';
  static const String driveFolderId = '0ANEyWUbLsliyUk9PVA';
  static const String usersSheetName = 'Users';
}
