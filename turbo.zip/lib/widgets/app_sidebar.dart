import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../models/app_user.dart';
import '../providers/auth_notifier.dart';
import '../providers/alert_provider.dart';


class AppScaffold extends StatefulWidget {
  const AppScaffold({
    super.key,
    required this.title,
    required this.selectedRoute,
    required this.user,
    required this.body,
    this.actions = const [],
  });

  final String title;
  final String selectedRoute;
  final AppUser? user;
  final Widget body;
  final List<Widget> actions;

  @override
  State<AppScaffold> createState() => _AppScaffoldState();
}

class _AppScaffoldState extends State<AppScaffold> {
  bool _expanded = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: Colors.transparent,
        actions: [
          ...widget.actions,
          const SizedBox(width: 12),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final forceCollapsed = constraints.maxWidth < 760;
          final expanded = !forceCollapsed && _expanded;
          return Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Theme.of(context).colorScheme.surface,
                  Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.20),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Row(
              children: [
                _CollapsibleSidebar(
                  user: widget.user,
                  selectedRoute: widget.selectedRoute,
                  expanded: expanded,
                  canToggle: !forceCollapsed,
                  onToggle: () => setState(() => _expanded = !_expanded),
                ),
                Expanded(
                  child: _GlobalLoginAlertGate(user: widget.user, child: widget.body),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _CollapsibleSidebar extends StatelessWidget {
  const _CollapsibleSidebar({
    required this.user,
    required this.selectedRoute,
    required this.expanded,
    required this.canToggle,
    required this.onToggle,
  });

  final AppUser? user;
  final String selectedRoute;
  final bool expanded;
  final bool canToggle;
  final VoidCallback onToggle;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      width: expanded ? 270 : 84,
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        color: theme.colorScheme.surface.withValues(alpha: 0.88),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 30, offset: const Offset(0, 16)),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: theme.colorScheme.primary,
                foregroundColor: theme.colorScheme.onPrimary,
                child: const Icon(Icons.local_hospital_rounded),
              ),
              if (expanded) ...[
                const SizedBox(width: 12),
                Expanded(child: Text('LabOps', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900))),
              ],
              if (canToggle)
                IconButton(
                  tooltip: expanded ? 'Collapse sidebar' : 'Expand sidebar',
                  onPressed: onToggle,
                  icon: Icon(expanded ? Icons.chevron_left_rounded : Icons.chevron_right_rounded),
                ),
            ],
          ),
          const SizedBox(height: 12),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: _items(),
            ),
          ),
          const SizedBox(height: 10),
          if (expanded)
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), color: theme.colorScheme.primaryContainer),
              child: Row(
                children: [
                  CircleAvatar(child: Text((user?.name ?? 'U').characters.first)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(user?.name ?? 'User', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
                        Text(user?.role.name ?? 'guest'),
                      ],
                    ),
                  ),
                ],
              ),
            )
          else
            Tooltip(message: '${user?.name ?? 'User'} • ${user?.role.name ?? 'guest'}', child: CircleAvatar(child: Text((user?.name ?? 'U').characters.first))),
          const SizedBox(height: 10),
          _SidebarLogoutButton(expanded: expanded),
        ],
      ),
    );
  }

  List<Widget> _items() {
    final items = <Widget>[
      _CollapsibleSidebarItem(icon: Icons.dashboard_rounded, label: 'Dashboard', route: '/', selected: selectedRoute == '/', expanded: expanded),
      _CollapsibleSidebarItem(icon: Icons.manage_search_rounded, label: 'Search', route: '/search', selected: selectedRoute == '/search', expanded: expanded),
    ];
    if (user?.role == AppUserRole.staff || user?.role == AppUserRole.admin || user?.role == AppUserRole.superadmin) {
      items.add(_CollapsibleSidebarItem(icon: Icons.addchart_rounded, label: 'Register Sample', route: '/register-sample', selected: selectedRoute == '/register-sample', expanded: expanded));
    }
    items.add(_CollapsibleSidebarItem(icon: Icons.account_circle_rounded, label: 'Profile', route: '/profile', selected: selectedRoute == '/profile', expanded: expanded));
    if (user?.role == AppUserRole.superadmin || user?.role == AppUserRole.admin) {
      items.add(_CollapsibleSidebarItem(icon: Icons.branding_watermark_rounded, label: 'Report Header', route: '/report-header', selected: selectedRoute == '/report-header', expanded: expanded));
    }
    if (user?.role == AppUserRole.lab_tech || user?.role == AppUserRole.superadmin) {
      items.addAll([
        _CollapsibleSidebarItem(icon: Icons.fact_check_rounded, label: 'Test Requirements', route: '/test-requirements', selected: selectedRoute == '/test-requirements', expanded: expanded),
        _CollapsibleSidebarItem(icon: Icons.bloodtype_rounded, label: 'CBC / CP Result', route: '/cbc-cp-result', selected: selectedRoute == '/cbc-cp-result', expanded: expanded),
      ]);
    }
    if (user?.role == AppUserRole.superadmin) {
      items.addAll([
        _CollapsibleSidebarItem(icon: Icons.rule_rounded, label: 'CBC Ref. Ranges', route: '/cbc-reference-ranges', selected: selectedRoute == '/cbc-reference-ranges', expanded: expanded),
        _CollapsibleSidebarItem(icon: Icons.group_rounded, label: 'Users', route: '/users', selected: selectedRoute == '/users', expanded: expanded),
        _CollapsibleSidebarItem(icon: Icons.price_change_rounded, label: 'Global Pricing', route: '/global-pricing', selected: selectedRoute == '/global-pricing', expanded: expanded),
        _CollapsibleSidebarItem(icon: Icons.analytics_rounded, label: 'Advanced Analytics', route: '/advanced-analytics', selected: selectedRoute == '/advanced-analytics', expanded: expanded),
        _CollapsibleSidebarItem(icon: Icons.campaign_rounded, label: 'Alerts', route: '/alerts', selected: selectedRoute == '/alerts', expanded: expanded),
      ]);
    }
    if (user?.role == AppUserRole.admin) {
      items.addAll([
        _CollapsibleSidebarItem(icon: Icons.group_rounded, label: 'Staff Accounts', route: '/users', selected: selectedRoute == '/users', expanded: expanded),
        _CollapsibleSidebarItem(icon: Icons.storefront_rounded, label: 'Sub-center Pricing', route: '/sub-center-pricing', selected: selectedRoute == '/sub-center-pricing', expanded: expanded),
        _CollapsibleSidebarItem(icon: Icons.query_stats_rounded, label: 'Admin Analytics', route: '/admin-analytics', selected: selectedRoute == '/admin-analytics', expanded: expanded),
      ]);
    }
    return items;
  }
}

class _CollapsibleSidebarItem extends StatelessWidget {
  const _CollapsibleSidebarItem({required this.icon, required this.label, required this.route, required this.selected, required this.expanded});
  final IconData icon;
  final String label;
  final String route;
  final bool selected;
  final bool expanded;
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Tooltip(
      message: label,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: selected ? theme.colorScheme.primary.withValues(alpha: 0.14) : Colors.transparent,
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => context.go(route),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: expanded ? 12 : 10, vertical: 11),
            child: Row(
              mainAxisAlignment: expanded ? MainAxisAlignment.start : MainAxisAlignment.center,
              children: [
                Icon(icon, color: selected ? theme.colorScheme.primary : null),
                if (expanded) ...[
                  const SizedBox(width: 12),
                  Expanded(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: selected ? FontWeight.w800 : FontWeight.w600))),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SidebarLogoutButton extends ConsumerWidget {
  const _SidebarLogoutButton({required this.expanded});
  final bool expanded;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final button = FilledButton.tonalIcon(
      style: FilledButton.styleFrom(
        foregroundColor: theme.colorScheme.error,
        backgroundColor: theme.colorScheme.errorContainer.withValues(alpha: 0.45),
        minimumSize: expanded ? const Size.fromHeight(46) : const Size(46, 46),
        padding: expanded ? null : EdgeInsets.zero,
      ),
      onPressed: () async {
        final shouldLogout = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Log out?'),
            content: const Text('You will return to the sign-in screen.'),
            actions: [
              TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Cancel')),
              FilledButton.icon(onPressed: () => Navigator.of(context).pop(true), icon: const Icon(Icons.logout_rounded), label: const Text('Log out')),
            ],
          ),
        );
        if (shouldLogout != true) return;
        ref.read(authNotifierProvider.notifier).clearUser();
        if (context.mounted) context.go('/login');
      },
      icon: const Icon(Icons.logout_rounded),
      label: expanded ? const Text('Log out') : const SizedBox.shrink(),
    );
    return Tooltip(message: 'Log out', child: expanded ? SizedBox(width: double.infinity, child: button) : button);
  }
}

class _GlobalLoginAlertGate extends ConsumerStatefulWidget {
  const _GlobalLoginAlertGate({required this.user, required this.child});

  final AppUser? user;
  final Widget child;

  @override
  ConsumerState<_GlobalLoginAlertGate> createState() => _GlobalLoginAlertGateState();
}

class _GlobalLoginAlertGateState extends ConsumerState<_GlobalLoginAlertGate> {
  String? _shownKey;
  String? _lastUserId;

  @override
  void initState() {
    super.initState();
    _lastUserId = widget.user?.id;
  }

  @override
  void didUpdateWidget(covariant _GlobalLoginAlertGate oldWidget) {
    super.didUpdateWidget(oldWidget);
    final currentUserId = widget.user?.id;
    if (currentUserId != _lastUserId) {
      _lastUserId = currentUserId;
      _shownKey = null;
      ref.invalidate(alertMessageProvider);
    }
  }

  void _maybeShowAlert(String? message) {
    final alert = message?.trim() ?? '';
    if (alert.isEmpty || widget.user == null) return;
    final key = '${widget.user!.id}::$alert';
    if (_shownKey == key) return;
    _shownKey = key;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Alert'),
          content: Text(alert),
          actions: [
            FilledButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final alertAsync = ref.watch(alertMessageProvider);
    _maybeShowAlert(alertAsync.valueOrNull);
    return widget.child;
  }
}
