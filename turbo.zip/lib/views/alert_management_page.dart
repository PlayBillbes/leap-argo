import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/app_user.dart';
import '../providers/alert_provider.dart';
import '../providers/auth_notifier.dart';
import '../widgets/app_sidebar.dart';

class AlertManagementPage extends ConsumerStatefulWidget {
  const AlertManagementPage({super.key});

  @override
  ConsumerState<AlertManagementPage> createState() => _AlertManagementPageState();
}

class _AlertManagementPageState extends ConsumerState<AlertManagementPage> {
  final _controller = TextEditingController();
  bool _saving = false;
  bool _loadedCurrent = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final message = _controller.text.trim();
    if (message.isEmpty) {
      _showSnack('Enter alert text or use Delete Alert to remove current alert.', isError: true);
      return;
    }
    setState(() => _saving = true);
    try {
      await ref.read(alertMessageProvider.notifier).saveAlert(message);
      _showSnack('Alert saved. Users will see it after login.');
    } catch (error) {
      _showSnack('Save failed: $error', isError: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _delete() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete alert?'),
        content: const Text('This will clear Alert!A2. Users will not see an alert after login.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Cancel')),
          FilledButton.icon(
            onPressed: () => Navigator.of(context).pop(true),
            icon: const Icon(Icons.delete_outline_rounded),
            label: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirm != true) return;
    setState(() => _saving = true);
    try {
      await ref.read(alertMessageProvider.notifier).deleteAlert();
      _controller.clear();
      _showSnack('Alert deleted.');
    } catch (error) {
      _showSnack('Delete failed: $error', isError: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _showSnack(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    final alertAsync = ref.watch(alertMessageProvider);

    return AppScaffold(
      title: 'Alert Management',
      selectedRoute: '/alerts',
      user: user,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Refresh alert',
          onPressed: _saving ? null : () {
            _loadedCurrent = false;
            ref.invalidate(alertMessageProvider);
          },
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        child: alertAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, _) => Center(child: Text('Alert load failed: $error')),
          data: (alertText) {
            if (!_loadedCurrent) {
              _controller.text = alertText ?? '';
              _loadedCurrent = true;
            }
            return SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _AlertHero(hasAlert: (alertText ?? '').trim().isNotEmpty),
                  const SizedBox(height: 18),
                  LayoutBuilder(
                    builder: (context, constraints) {
                      final compact = constraints.maxWidth < 900;
                      final editor = _EditorCard(
                        controller: _controller,
                        saving: _saving,
                        onChanged: (_) => setState(() {}),
                        onSave: _save,
                        onDelete: _delete,
                      );
                      final preview = _PreviewCard(alertText: _controller.text.trim());
                      if (compact) {
                        return Column(children: [editor, const SizedBox(height: 14), preview]);
                      }
                      return Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(flex: 2, child: editor),
                          const SizedBox(width: 14),
                          Expanded(child: preview),
                        ],
                      );
                    },
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _AlertHero extends StatelessWidget {
  const _AlertHero({required this.hasAlert});

  final bool hasAlert;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(colors: [Color(0xFF7C3AED), Color(0xFF2563EB)]),
        boxShadow: [BoxShadow(color: theme.colorScheme.primary.withValues(alpha: 0.22), blurRadius: 26, offset: const Offset(0, 16))],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(24)),
            child: const Icon(Icons.campaign_rounded, color: Colors.white, size: 36),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Login Alert', style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text(
                  hasAlert ? 'An alert is active. Users will see it after login.' : 'No alert is active. Alert!A2 is empty.',
                  style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white.withValues(alpha: 0.88)),
                ),
              ],
            ),
          ),
          Chip(
            avatar: Icon(hasAlert ? Icons.notifications_active_rounded : Icons.notifications_off_rounded, size: 18),
            label: Text(hasAlert ? 'Active' : 'Empty'),
          ),
        ],
      ),
    );
  }
}

class _EditorCard extends StatelessWidget {
  const _EditorCard({
    required this.controller,
    required this.saving,
    required this.onChanged,
    required this.onSave,
    required this.onDelete,
  });

  final TextEditingController controller;
  final bool saving;
  final ValueChanged<String> onChanged;
  final VoidCallback onSave;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.94),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Create / Update Alert', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            const Text('Google Sheet layout: Alert!A1 = alert, Alert!A2 = message text.'),
            const SizedBox(height: 16),
            TextField(
              controller: controller,
              enabled: !saving,
              maxLines: 7,
              onChanged: onChanged,
              decoration: InputDecoration(
                labelText: 'Alert message',
                hintText: 'Example: Maintenance tonight from 8 PM to 10 PM.',
                alignLabelWithHint: true,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
              ),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                FilledButton.icon(
                  onPressed: saving ? null : onSave,
                  icon: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_rounded),
                  label: Text(saving ? 'Saving...' : 'Save Alert'),
                ),
                FilledButton.tonalIcon(
                  onPressed: saving ? null : onDelete,
                  icon: const Icon(Icons.delete_outline_rounded),
                  label: const Text('Delete Alert'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _PreviewCard extends StatelessWidget {
  const _PreviewCard({required this.alertText});

  final String alertText;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final hasText = alertText.trim().isNotEmpty;
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.94),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('User Login Preview', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                color: hasText ? theme.colorScheme.primaryContainer.withValues(alpha: 0.55) : theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.40),
                border: Border.all(color: hasText ? theme.colorScheme.primary.withValues(alpha: 0.22) : theme.colorScheme.outlineVariant),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(hasText ? Icons.campaign_rounded : Icons.notifications_off_rounded),
                      const SizedBox(width: 8),
                      Text(hasText ? 'Alert' : 'No alert', style: const TextStyle(fontWeight: FontWeight.w900)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(hasText ? alertText : 'Users will not see an alert after login.'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
