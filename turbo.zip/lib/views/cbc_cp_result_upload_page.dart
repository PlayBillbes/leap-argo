import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../config/google_config.dart';
import '../models/app_user.dart';
import '../providers/auth_notifier.dart';
import '../providers/sample_dashboard_controller.dart';
import '../services/google_drive_service.dart';
import '../services/google_sheets_service.dart';
import '../widgets/app_sidebar.dart';

const _cbcSheetName = 'CBCResults';
const _cbcRange = 'CBCResults!A:BH';

const _cbcHeaders = <String>[
  'id',
  'testName',
  'sampleId',
  'medRecNo',
  'firstName',
  'lastName',
  'gender',
  'age',
  'ageUnit',
  'sampleType',
  'samplingTime',
  'deliveryTime',
  'reportTime',
  'runTime',
  'mode',
  'WBC',
  'NeuPercent',
  'LymPercent',
  'MonPercent',
  'EosPercent',
  'BasPercent',
  'NeuCount',
  'LymCount',
  'MonCount',
  'EosCount',
  'BasCount',
  'ALYCount',
  'ALYPercent',
  'LICCount',
  'LICPercent',
  'NRBCCount',
  'NRBCPercent',
  'RBC',
  'HGB',
  'HCT',
  'MCV',
  'MCH',
  'MCHC',
  'RDWCV',
  'RDWSD',
  'PLT',
  'MPV',
  'PDW',
  'PCT',
  'PLCR',
  'PLCC',
  'WBCFlag',
  'RBCFlag',
  'PLTFlag',
  'CRPFlag',
  'diffHsmsImageUrl',
  'pltImageUrl',
  'wbcGraphBase64',
  'rbcGraphBase64',
  'pltGraphBase64',
  'diffHsmsBase64',
  'diffLshsBase64',
  'diffLsmsBase64',
  'createdAt',
  'uploadedByUserId',
];

class _AnalyzerExportData {
  const _AnalyzerExportData({required this.rows});

  final List<Map<String, String>> rows;

  Map<String, String> get parsedValues => rows.isEmpty ? const <String, String>{} : rows.first;
  Map<String, String> get graphBase64 => parsedValues;
}

class CbcCpResultUploadPage extends ConsumerStatefulWidget {
  const CbcCpResultUploadPage({super.key});

  @override
  ConsumerState<CbcCpResultUploadPage> createState() => _CbcCpResultUploadPageState();
}

class _CbcCpResultUploadPageState extends ConsumerState<CbcCpResultUploadPage> {
  PlatformFile? _csvFile;
  PlatformFile? _diffImage;
  PlatformFile? _pltImage;
  PlatformFile? _exportZip;
  final Map<String, String> _graphBase64 = {};
  final List<Map<String, String>> _batchRows = [];
  Map<String, String>? _preview;
  bool _saving = false;
  String? _statusMessage;

  Future<void> _pickCsv() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['csv'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final file = result.files.single;
    final bytes = file.bytes;
    if (bytes == null || bytes.isEmpty) {
      _showSnackBar('Selected CSV is empty or cannot be read.', isError: true);
      return;
    }
    try {
      final csvText = utf8.decode(bytes, allowMalformed: true);
      final parsed = _parseCbcCsv(csvText);
      setState(() {
        _csvFile = file;
        _exportZip = null;
        _batchRows.clear();
        _graphBase64.clear();
        _preview = parsed;
        _statusMessage = 'CSV loaded: ${file.name}';
      });
    } catch (error) {
      _showSnackBar('CSV parse failed: $error', isError: true);
    }
  }

  Future<void> _pickImage({required bool isDiff}) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['png', 'jpg', 'jpeg'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    setState(() {
      if (isDiff) {
        _diffImage = result.files.single;
      } else {
        _pltImage = result.files.single;
      }
    });
  }

  Future<void> _pickAnalyzerZip() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['zip'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final file = result.files.single;
    final bytes = file.bytes;
    if (bytes == null || bytes.isEmpty) {
      _showSnackBar('Analyzer ZIP is empty or cannot be read.', isError: true);
      return;
    }
    try {
      final extracted = _extractAnalyzerExport(bytes);
      setState(() {
        _exportZip = file;
        _csvFile = file;
        _batchRows
          ..clear()
          ..addAll(extracted.rows);
        _preview = extracted.parsedValues;
        _graphBase64
          ..clear()
          ..addAll(extracted.graphBase64);
        _statusMessage = 'Analyzer ZIP loaded: ${_batchRows.length} rows. Med Rec. No. will be saved as sampleId.';
      });
    } catch (error) {
      _showSnackBar('Analyzer ZIP parse failed: $error', isError: true);
    }
  }

  _AnalyzerExportData _extractAnalyzerExport(Uint8List zipBytes) {
    final archive = ZipDecoder().decodeBytes(zipBytes);
    String? csvText;
    final graphsByAnalyzerSampleId = <String, Map<String, String>>{};
    for (final file in archive.files) {
      if (!file.isFile) continue;
      final name = file.name.split('/').last;
      final lower = name.toLowerCase();
      final data = file.readBytes();
      if (data == null || data.isEmpty) continue;
      if (lower.endsWith('.csv')) {
        csvText = utf8.decode(data, allowMalformed: true);
      } else if (lower.endsWith('.png')) {
        final analyzerSampleId = _analyzerSampleIdFromGraphName(name);
        final key = _graphKeyFor(name);
        if (analyzerSampleId != null && key != null) {
          graphsByAnalyzerSampleId.putIfAbsent(analyzerSampleId, () => <String, String>{});
          graphsByAnalyzerSampleId[analyzerSampleId]![key] = base64Encode(data);
        }
      }
    }
    if (csvText == null || csvText.trim().isEmpty) {
      throw StateError('No CSV file found inside ZIP.');
    }
    final rows = _parseCbcCsvRecords(csvText);
    for (final row in rows) {
      final analyzerSampleId = row['_analyzerSampleId'] ?? '';
      row.addAll(graphsByAnalyzerSampleId[analyzerSampleId] ?? const <String, String>{});
      row.remove('_analyzerSampleId');
    }
    return _AnalyzerExportData(rows: rows);
  }

  String? _analyzerSampleIdFromGraphName(String fileName) {
    final parts = fileName.split('_');
    if (parts.length < 3) return null;
    return parts[1].trim();
  }

  String? _graphKeyFor(String fileName) {
    final upper = fileName.toUpperCase();
    if (upper.contains('_WBC')) return 'wbcGraphBase64';
    if (upper.contains('_RBC')) return 'rbcGraphBase64';
    if (upper.contains('_PLT')) return 'pltGraphBase64';
    if (upper.contains('DIFF_HSMS')) return 'diffHsmsBase64';
    if (upper.contains('DIFF_LSHS')) return 'diffLshsBase64';
    if (upper.contains('DIFF_LSMS')) return 'diffLsmsBase64';
    return null;
  }

  Map<String, String> _parseCbcCsv(String csvText) {
    final records = _parseCbcCsvRecords(csvText);
    if (records.isEmpty) throw StateError('CSV must contain at least one data row.');
    final first = Map<String, String>.from(records.first);
    first.remove('_analyzerSampleId');
    return first;
  }

  List<Map<String, String>> _parseCbcCsvRecords(String csvText) {
    final rows = _parseCsvRows(csvText)
        .where((row) => row.any((cell) => cell.trim().isNotEmpty))
        .toList();
    if (rows.length < 2) throw StateError('CSV must contain header row and one data row.');
    final headers = rows.first.map((value) => value.trim().toLowerCase()).toList();
    final parsedRows = <Map<String, String>>[];
    for (final row in rows.skip(1)) {
      final source = <String, String>{};
      for (var i = 0; i < headers.length; i++) {
        source[headers[i]] = i < row.length ? row[i].trim() : '';
      }
      parsedRows.add(_parseCbcSourceRow(source));
    }
    return parsedRows;
  }

  Map<String, String> _parseCbcSourceRow(Map<String, String> source) {
    String get(List<String> keys) {
      for (final key in keys) {
        final value = source[key.toLowerCase()]?.trim() ?? '';
        if (value.isNotEmpty) return value;
      }
      return '';
    }

    final analyzerSampleId = get(['Sample ID']);
    final medRecNo = get(['Med Rec. No.']);
    final sampleId = medRecNo.isNotEmpty ? medRecNo : analyzerSampleId;
    final now = DateTime.now().toIso8601String();
    return <String, String>{
      '_analyzerSampleId': analyzerSampleId,
      'id': 'CBC-${sampleId.isEmpty ? DateTime.now().microsecondsSinceEpoch : sampleId}-${DateTime.now().millisecondsSinceEpoch}',
      'testName': 'CBC / CP(Auto)',
      'sampleId': sampleId,
      'medRecNo': medRecNo,
      'firstName': get(['First Name']),
      'lastName': get(['Last Name']),
      'gender': get(['Gender']),
      'age': get(['Age']),
      'ageUnit': get(['Age Unit']),
      'sampleType': get(['Sample Type']),
      'samplingTime': get(['Sampling Time']),
      'deliveryTime': get(['Delivery Time']),
      'reportTime': get(['Report Time']),
      'runTime': get(['Run Time']),
      'mode': get(['Mode']),
      'WBC': get(['WBC']),
      'NeuPercent': get(['Neu%']),
      'LymPercent': get(['Lym%']),
      'MonPercent': get(['Mon%']),
      'EosPercent': get(['Eos%']),
      'BasPercent': get(['Bas%']),
      'NeuCount': get(['Neu#']),
      'LymCount': get(['Lym#']),
      'MonCount': get(['Mon#']),
      'EosCount': get(['Eos#']),
      'BasCount': get(['Bas#']),
      'ALYCount': get(['ALY#']),
      'ALYPercent': get(['ALY%']),
      'LICCount': get(['LIC#']),
      'LICPercent': get(['LIC%']),
      'NRBCCount': get(['NRBC#']),
      'NRBCPercent': get(['NRBC%']),
      'RBC': get(['RBC']),
      'HGB': get(['HGB']),
      'HCT': get(['HCT']),
      'MCV': get(['MCV']),
      'MCH': get(['MCH']),
      'MCHC': get(['MCHC']),
      'RDWCV': get(['RDW-CV']),
      'RDWSD': get(['RDW-SD']),
      'PLT': get(['PLT']),
      'MPV': get(['MPV']),
      'PDW': get(['PDW']),
      'PCT': get(['PCT']),
      'PLCR': get(['P-LCR']),
      'PLCC': get(['P-LCC']),
      'WBCFlag': get(['WBC Flag']),
      'RBCFlag': get(['RBC Flag']),
      'PLTFlag': get(['PLT Flag']),
      'CRPFlag': get(['CRP Flag']),
      'diffHsmsImageUrl': '',
      'pltImageUrl': '',
      'createdAt': now,
      'uploadedByUserId': '',
    };
  }

  List<List<String>> _parseCsvRows(String text) {
    final rows = <List<String>>[];
    final currentRow = <String>[];
    final currentCell = StringBuffer();
    var inQuotes = false;

    for (var i = 0; i < text.length; i++) {
      final char = text[i];
      final next = i + 1 < text.length ? text[i + 1] : '';
      if (char == '"') {
        if (inQuotes && next == '"') {
          currentCell.write('"');
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char == ',' && !inQuotes) {
        currentRow.add(currentCell.toString().replaceAll('\t', '').trim());
        currentCell.clear();
      } else if ((char == '\n' || char == '\r') && !inQuotes) {
        if (char == '\r' && next == '\n') i++;
        currentRow.add(currentCell.toString().replaceAll('\t', '').trim());
        currentCell.clear();
        rows.add(List<String>.from(currentRow));
        currentRow.clear();
      } else {
        currentCell.write(char);
      }
    }

    if (currentCell.isNotEmpty || currentRow.isNotEmpty) {
      currentRow.add(currentCell.toString().replaceAll('\t', '').trim());
      rows.add(List<String>.from(currentRow));
    }
    return rows;
  }

  String _columnName(int indexOneBased) {
    var index = indexOneBased;
    final buffer = StringBuffer();
    while (index > 0) {
      final remainder = (index - 1) % 26;
      buffer.writeCharCode(65 + remainder);
      index = (index - 1) ~/ 26;
    }
    return buffer.toString().split('').reversed.join();
  }

  String _normalizeSheetKey(String value) {
    return value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
  }

  Future<int> _markMatchingBloodSamplesCompleted(
    GoogleSheetsService service,
    Iterable<Map<String, String>> cbcRows,
  ) async {
    final sampleIds = cbcRows
        .map((row) => (row['sampleId'] ?? row['medRecNo'] ?? '').trim())
        .where((value) => value.isNotEmpty)
        .map((value) => value.toLowerCase())
        .toSet();
    if (sampleIds.isEmpty) return 0;

    final rows = await service.fetchRows(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'BloodSamples!A:Z',
    );
    if (rows.isEmpty) return 0;

    final headers = rows.first
        .map((header) => _normalizeSheetKey(header))
        .toList();
    final idIndex = headers.indexOf('id');
    final sampleIdIndex = headers.indexOf('sampleid');
    final statusIndex = headers.indexOf('status');
    final updatedAtIndex = headers.indexOf('updatedat');
    if (statusIndex < 0 || (idIndex < 0 && sampleIdIndex < 0)) return 0;

    var updatedCount = 0;
    final nowIso = DateTime.now().toUtc().toIso8601String();
    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      final possibleIds = <String>{};
      if (idIndex >= 0 && idIndex < row.length) {
        final value = row[idIndex].trim();
        if (value.isNotEmpty) possibleIds.add(value.toLowerCase());
      }
      if (sampleIdIndex >= 0 && sampleIdIndex < row.length) {
        final value = row[sampleIdIndex].trim();
        if (value.isNotEmpty) possibleIds.add(value.toLowerCase());
      }
      if (!possibleIds.any(sampleIds.contains)) continue;

      final sheetRowNumber = i + 1;
      final statusColumn = _columnName(statusIndex + 1);
      await service.updateRow(
        spreadsheetId: GoogleConfig.spreadsheetId,
        range: 'BloodSamples!$statusColumn$sheetRowNumber:$statusColumn$sheetRowNumber',
        values: const ['completed'],
      );
      if (updatedAtIndex >= 0) {
        final updatedAtColumn = _columnName(updatedAtIndex + 1);
        await service.updateRow(
          spreadsheetId: GoogleConfig.spreadsheetId,
          range: 'BloodSamples!$updatedAtColumn$sheetRowNumber:$updatedAtColumn$sheetRowNumber',
          values: [nowIso],
        );
      }
      updatedCount++;
    }
    return updatedCount;
  }

  Future<void> _saveToGoogleSheets() async {
    final preview = _preview;
    final user = ref.read(authNotifierProvider);
    if (preview == null) {
      _showSnackBar('Please choose the CBC/CP(Auto) CSV file first.', isError: true);
      return;
    }
    if (_batchRows.isEmpty) {
      if (_diffImage?.bytes == null && (_graphBase64['diffHsmsBase64'] ?? '').isEmpty) {
        _showSnackBar('Please choose the DIFF image or analyzer ZIP.', isError: true);
        return;
      }
      if (_pltImage?.bytes == null && (_graphBase64['pltGraphBase64'] ?? '').isEmpty) {
        _showSnackBar('Please choose the PLT image or analyzer ZIP.', isError: true);
        return;
      }
    }

    setState(() {
      _saving = true;
      _statusMessage = 'Saving CBC / CP(Auto) result...';
    });

    GoogleSheetsService? sheetsService;
    GoogleDriveService? driveService;
    try {
      final serviceAccountJson = await rootBundle.loadString('assets/service-account.json');
      sheetsService = GoogleSheetsService(
        serviceAccountJson: serviceAccountJson,
        applicationName: 'flutterlab',
      );
      driveService = GoogleDriveService(
        serviceAccountJson: serviceAccountJson,
        applicationName: 'flutterlab',
      );

      await sheetsService.ensureSheet(
        spreadsheetId: GoogleConfig.spreadsheetId,
        sheetName: _cbcSheetName,
      );
      await sheetsService.updateRow(
        spreadsheetId: GoogleConfig.spreadsheetId,
        range: '$_cbcSheetName!A1:BH1',
        values: _cbcHeaders,
      );

      if (_batchRows.isNotEmpty) {
        var savedCount = 0;
        final insertedRows = <Map<String, String>>[];
        for (final batchRow in _batchRows) {
          final row = Map<String, String>.from(batchRow);
          row['uploadedByUserId'] = user?.id ?? '';
          await sheetsService.insertRow(
            spreadsheetId: GoogleConfig.spreadsheetId,
            range: _cbcRange,
            values: _cbcHeaders.map((header) => row[header] ?? '').toList(),
            valueInputOption: 'RAW',
          );
          insertedRows.add(row);
          savedCount++;
        }
        final completedCount = await _markMatchingBloodSamplesCompleted(
          sheetsService,
          insertedRows,
        );
        ref.invalidate(sampleDashboardControllerProvider);
        setState(() {
          _statusMessage = 'Batch upload saved $savedCount CBC / CP(Auto) results and marked $completedCount BloodSamples completed.';
          _csvFile = null;
          _diffImage = null;
          _pltImage = null;
          _exportZip = null;
          _batchRows.clear();
          _graphBase64.clear();
          _preview = null;
        });
        _showSnackBar('Batch upload saved $savedCount results. Marked $completedCount sample(s) completed.');
        return;
      }

      final row = Map<String, String>.from(preview);
      row['uploadedByUserId'] = user?.id ?? '';
      row.addAll(_graphBase64);
      if (_diffImage?.bytes != null) {
        setState(() => _statusMessage = 'Uploading DIFF image...');
        row['diffHsmsImageUrl'] = await driveService.uploadBytesToSharedFolder(
          bytes: _diffImage!.bytes!,
          parentFolderId: GoogleConfig.driveFolderId,
          fileName: _diffImage!.name,
          mimeType: _mimeTypeFor(_diffImage!.name),
        );
      }

      if (_pltImage?.bytes != null) {
        setState(() => _statusMessage = 'Uploading PLT image...');
        row['pltImageUrl'] = await driveService.uploadBytesToSharedFolder(
          bytes: _pltImage!.bytes!,
          parentFolderId: GoogleConfig.driveFolderId,
          fileName: _pltImage!.name,
          mimeType: _mimeTypeFor(_pltImage!.name),
        );
      }

      await sheetsService.insertRow(
        spreadsheetId: GoogleConfig.spreadsheetId,
        range: _cbcRange,
        values: _cbcHeaders.map((header) => row[header] ?? '').toList(),
        valueInputOption: 'RAW',
      );

      ref.invalidate(sampleDashboardControllerProvider);
      setState(() {
        _statusMessage = 'CBC / CP(Auto) result saved to Google Sheets.';
        _csvFile = null;
        _diffImage = null;
        _pltImage = null;
        _exportZip = null;
        _batchRows.clear();
        _graphBase64.clear();
        _preview = null;
      });
      _showSnackBar('CBC / CP(Auto) result saved successfully.');
    } catch (error) {
      _showSnackBar('Save failed: $error', isError: true);
    } finally {
      await sheetsService?.close();
      await driveService?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  String _mimeTypeFor(String fileName) {
    final lower = fileName.toLowerCase();
    if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
    return 'image/png';
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    final theme = Theme.of(context);
    return AppScaffold(
      title: 'CBC / CP(Auto) Result',
      selectedRoute: '/cbc-cp-result',
      user: user,
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _HeroCard(theme: theme),
              const SizedBox(height: 18),
              _FilePickerCard(
                csvFile: _csvFile,
                diffImage: _diffImage,
                pltImage: _pltImage,
                exportZip: _exportZip,
                batchCount: _batchRows.length,
                saving: _saving,
                statusMessage: _statusMessage,
                onPickAnalyzerZip: _pickAnalyzerZip,
                onPickCsv: _pickCsv,
                onPickDiff: () => _pickImage(isDiff: true),
                onPickPlt: () => _pickImage(isDiff: false),
              ),
              const SizedBox(height: 18),
              if (_preview != null) _PreviewCard(data: _preview!),
              const SizedBox(height: 18),
              Align(
                alignment: Alignment.centerRight,
                child: FilledButton.icon(
                  onPressed: _saving ? null : _saveToGoogleSheets,
                  icon: _saving
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.save_rounded),
                  label: Text(_saving ? 'Saving...' : 'Save Result'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard({required this.theme});

  final ThemeData theme;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(colors: [Color(0xFF0F766E), Color(0xFF2563EB), Color(0xFF7C3AED)]),
        boxShadow: [BoxShadow(color: theme.colorScheme.primary.withValues(alpha: 0.22), blurRadius: 26, offset: const Offset(0, 15))],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(24)),
            child: const Icon(Icons.bloodtype_rounded, color: Colors.white, size: 36),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('CBC / CP(Auto) Result Upload', style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text('Upload analyzer ZIP from CBC machine, or upload CSV plus DIFF/PLT images. PNG graphs from ZIP are stored as Base64 in CBCResults.', style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white.withValues(alpha: 0.88))),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FilePickerCard extends StatelessWidget {
  const _FilePickerCard({
    required this.csvFile,
    required this.diffImage,
    required this.pltImage,
    required this.exportZip,
    required this.batchCount,
    required this.saving,
    required this.statusMessage,
    required this.onPickAnalyzerZip,
    required this.onPickCsv,
    required this.onPickDiff,
    required this.onPickPlt,
  });

  final PlatformFile? csvFile;
  final PlatformFile? diffImage;
  final PlatformFile? pltImage;
  final PlatformFile? exportZip;
  final int batchCount;
  final bool saving;
  final String? statusMessage;
  final VoidCallback onPickAnalyzerZip;
  final VoidCallback onPickCsv;
  final VoidCallback onPickDiff;
  final VoidCallback onPickPlt;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.94),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Result Files', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 14),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                FilledButton.tonalIcon(
                  onPressed: saving ? null : onPickAnalyzerZip,
                  icon: const Icon(Icons.folder_zip_rounded),
                  label: Text(exportZip == null ? 'Batch Analyzer ZIP' : '${exportZip!.name} ($batchCount rows)'),
                ),
                FilledButton.tonalIcon(
                  onPressed: saving ? null : onPickCsv,
                  icon: const Icon(Icons.table_chart_rounded),
                  label: Text(csvFile == null ? 'Choose SampleExport CSV' : csvFile!.name),
                ),
                FilledButton.tonalIcon(
                  onPressed: saving ? null : onPickDiff,
                  icon: const Icon(Icons.scatter_plot_rounded),
                  label: Text(diffImage == null ? 'Choose DIFF Image' : diffImage!.name),
                ),
                FilledButton.tonalIcon(
                  onPressed: saving ? null : onPickPlt,
                  icon: const Icon(Icons.area_chart_rounded),
                  label: Text(pltImage == null ? 'Choose PLT Image' : pltImage!.name),
                ),
              ],
            ),
            if (statusMessage != null) ...[
              const SizedBox(height: 12),
              Text(statusMessage!),
            ],
          ],
        ),
      ),
    );
  }
}

class _PreviewCard extends StatelessWidget {
  const _PreviewCard({required this.data});

  final Map<String, String> data;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final important = <String>[
      'testName',
      'sampleId',
      'medRecNo',
      'firstName',
      'gender',
      'age',
      'mode',
      'WBC',
      'RBC',
      'HGB',
      'HCT',
      'PLT',
      'WBCFlag',
      'RBCFlag',
      'PLTFlag',
    ];
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.94),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Parsed Preview', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: important.map((key) => Chip(label: Text('$key: ${data[key] ?? '-'}'))).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
