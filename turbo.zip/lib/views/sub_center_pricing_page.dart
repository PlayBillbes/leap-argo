import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../config/google_config.dart';
import '../models/app_user.dart';
import '../models/lab_test.dart';
import '../models/sub_center_pricing.dart';
import '../providers/auth_notifier.dart';
import '../providers/tests_provider.dart';
import '../services/google_sheets_service.dart';
import '../widgets/app_sidebar.dart';

class SubCenterPricingPage extends ConsumerStatefulWidget {
  const SubCenterPricingPage({super.key});

  @override
  ConsumerState<SubCenterPricingPage> createState() => _SubCenterPricingPageState();
}

class _SubCenterPricingPageState extends ConsumerState<SubCenterPricingPage> {
  static const _sheetName = 'SubCenterPricings';
  static const _range = 'SubCenterPricings!A:C';
  final _searchController = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  String _normalize(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  Future<GoogleSheetsService> _newSheetsService() async {
    return GoogleSheetsService(
      serviceAccountJson: await rootBundle.loadString('assets/service-account.json'),
      applicationName: 'flutterlab',
    );
  }

  SubCenterPricing? _pricingFor(List<SubCenterPricing> pricings, String subCenterId, LabTest test) {
    final center = _normalize(subCenterId);
    final testId = _normalize(test.id);
    final testName = _normalize(test.testName);
    for (final pricing in pricings) {
      if (_normalize(pricing.subCenterId) != center) continue;
      final pricingTest = _normalize(pricing.testId);
      if (pricingTest == testId || pricingTest == testName) return pricing;
    }
    return null;
  }

  Future<int?> _findRow(GoogleSheetsService service, String subCenterId, LabTest test) async {
    final rows = await service.fetchRows(spreadsheetId: GoogleConfig.spreadsheetId, range: _range);
    if (rows.isEmpty) return null;
    final testId = _normalize(test.id);
    final testName = _normalize(test.testName);
    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      final rowCenter = row.isNotEmpty ? row[0] : '';
      final rowTest = row.length > 1 ? row[1] : '';
      if (_normalize(rowCenter) == _normalize(subCenterId) &&
          (_normalize(rowTest) == testId || _normalize(rowTest) == testName)) {
        return i + 1;
      }
    }
    return null;
  }

  Future<void> _savePrice(AppUser user, LabTest test, double price) async {
    final subCenterId = (user.subCenterId ?? '').trim().isEmpty ? 'GLOBAL' : user.subCenterId!.trim();
    if (price <= 0) {
      _showToast('Customer price must be greater than 0.', isError: true);
      return;
    }
    setState(() => _saving = true);
    GoogleSheetsService? service;
    try {
      service = await _newSheetsService();
      final row = await _findRow(service, subCenterId, test);
      final values = <String>[subCenterId, test.id, price.toStringAsFixed(2)];
      if (row == null) {
        await service.insertRow(spreadsheetId: GoogleConfig.spreadsheetId, range: _range, values: values);
      } else {
        await service.updateRow(spreadsheetId: GoogleConfig.spreadsheetId, range: '$_sheetName!A$row:C$row', values: values);
      }
      ref.invalidate(pricingsProvider);
      _showToast('${test.testName} customer price saved.');
    } catch (error) {
      _showToast('Save failed: $error', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _openDialog(AppUser user, LabTest test, double currentPrice) async {
    final controller = TextEditingController(text: currentPrice.toStringAsFixed(2));
    final result = await showDialog<double>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Set ${test.testName} customer price'),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(
            labelText: 'Customer price',
            helperText: 'Global price: ${test.defaultPrice.toStringAsFixed(2)}',
            border: const OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, double.tryParse(controller.text.trim())), child: const Text('Save')),
        ],
      ),
    );
    controller.dispose();
    if (result != null) await _savePrice(user, test, result);
  }

  void _showToast(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating, backgroundColor: isError ? Theme.of(context).colorScheme.error : null),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    final testsAsync = ref.watch(testsProvider);
    final pricingsAsync = ref.watch(pricingsProvider);
    return AppScaffold(
      title: 'Sub-center Pricing',
      selectedRoute: '/sub-center-pricing',
      user: user,
      actions: [IconButton.filledTonal(onPressed: _saving ? null : () { ref.invalidate(testsProvider); ref.invalidate(pricingsProvider); }, icon: const Icon(Icons.refresh_rounded))],
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: testsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('Tests load failed: $e')),
          data: (tests) => pricingsAsync.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, _) => Center(child: Text('Pricing load failed: $e')),
            data: (pricings) => _buildContent(context, user, tests, pricings),
          ),
        ),
      ),
    );
  }

  Widget _buildContent(BuildContext context, AppUser? user, List<LabTest> tests, List<SubCenterPricing> pricings) {
    if (user == null || user.role != AppUserRole.admin) {
      return const Center(child: Text('Only admin users can set sub-center pricing.'));
    }
    final subCenterId = (user.subCenterId ?? '').trim().isEmpty ? 'GLOBAL' : user.subCenterId!.trim();
    final query = _searchController.text.trim().toLowerCase();
    final filtered = query.isEmpty ? tests : tests.where((t) => t.testName.toLowerCase().contains(query) || t.id.toLowerCase().contains(query)).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Customer Pricing for $subCenterId', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        const Text('Set customer prices for your sub-center. Profit = customer price - global default price.'),
        const SizedBox(height: 16),
        TextField(
          controller: _searchController,
          onChanged: (_) => setState(() {}),
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), border: OutlineInputBorder(), hintText: 'Search tests...'),
        ),
        const SizedBox(height: 16),
        Expanded(
          child: ListView.separated(
            itemCount: filtered.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final test = filtered[index];
              final pricing = _pricingFor(pricings, subCenterId, test);
              final customerPrice = pricing?.customPrice ?? test.defaultPrice;
              final profit = customerPrice - test.defaultPrice;
              return Card(
                child: ListTile(
                  leading: const Icon(Icons.science_rounded),
                  title: Text(test.testName),
                  subtitle: Text('Global: ${test.defaultPrice.toStringAsFixed(2)}  •  Customer: ${customerPrice.toStringAsFixed(2)}  •  Profit: ${profit.toStringAsFixed(2)}'),
                  trailing: FilledButton.tonalIcon(
                    onPressed: _saving ? null : () => _openDialog(user, test, customerPrice),
                    icon: const Icon(Icons.edit_rounded),
                    label: const Text('Set Price'),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
