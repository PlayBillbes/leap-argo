import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../config/google_config.dart';
import '../providers/auth_notifier.dart';
import '../services/google_sheets_service.dart';
import '../widgets/app_sidebar.dart';

const _rangeSheetName = 'CbcReferenceRanges';
const _rangeSheetRange = 'CbcReferenceRanges!A:D';
const _rangeHeaders = ['ageGroup', 'parameter', 'refRange', 'unit'];
const _ageGroups = ['neonate', 'child', 'adult'];

class CbcReferenceRangesPage extends ConsumerStatefulWidget {
  const CbcReferenceRangesPage({super.key});

  @override
  ConsumerState<CbcReferenceRangesPage> createState() => _CbcReferenceRangesPageState();
}

class _CbcReferenceRangesPageState extends ConsumerState<CbcReferenceRangesPage> {
  String _selectedAgeGroup = 'adult';
  bool _loading = true;
  bool _saving = false;
  final Map<String, TextEditingController> _rangeControllers = {};
  final Map<String, TextEditingController> _unitControllers = {};

  @override
  void initState() {
    super.initState();
    for (final parameter in _cbcReferenceParameters) {
      _rangeControllers[parameter.parameter] = TextEditingController(text: parameter.defaultRange);
      _unitControllers[parameter.parameter] = TextEditingController(text: parameter.unit);
    }
    Future.microtask(_loadSelectedGroup);
  }

  @override
  void dispose() {
    for (final controller in _rangeControllers.values) {
      controller.dispose();
    }
    for (final controller in _unitControllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<GoogleSheetsService> _newSheetsService() async {
    return GoogleSheetsService(
      serviceAccountJson: await rootBundle.loadString('assets/service-account.json'),
      applicationName: 'flutterlab',
    );
  }

  void _applyDefaults() {
    for (final parameter in _cbcReferenceParameters) {
      _rangeControllers[parameter.parameter]?.text = parameter.defaultRange;
      _unitControllers[parameter.parameter]?.text = parameter.unit;
    }
  }

  Future<void> _loadSelectedGroup() async {
    setState(() => _loading = true);
    GoogleSheetsService? service;
    try {
      _applyDefaults();
      service = await _newSheetsService();
      await service.ensureSheet(spreadsheetId: GoogleConfig.spreadsheetId, sheetName: _rangeSheetName);
      final rows = await service.fetchRows(spreadsheetId: GoogleConfig.spreadsheetId, range: _rangeSheetRange);
      if (rows.isEmpty) {
        await service.updateRow(spreadsheetId: GoogleConfig.spreadsheetId, range: '$_rangeSheetName!A1:D1', values: _rangeHeaders);
        return;
      }
      final headers = rows.first
          .map((header) => header.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
          .toList();
      final ageIndex = headers.indexOf('agegroup');
      final parameterIndex = headers.indexOf('parameter');
      final refIndex = headers.indexOf('refrange');
      final unitIndex = headers.indexOf('unit');
      if (ageIndex < 0 || parameterIndex < 0 || refIndex < 0) return;

      for (final row in rows.skip(1)) {
        final ageGroup = ageIndex < row.length ? row[ageIndex].trim().toLowerCase() : '';
        if (ageGroup != _selectedAgeGroup) continue;
        final parameter = parameterIndex < row.length ? row[parameterIndex].trim() : '';
        if (!_rangeControllers.containsKey(parameter)) continue;
        _rangeControllers[parameter]?.text = refIndex < row.length ? row[refIndex].trim() : '';
        if (unitIndex >= 0 && unitIndex < row.length) {
          _unitControllers[parameter]?.text = row[unitIndex].trim();
        }
      }
    } catch (error) {
      _showSnackBar('Load reference ranges failed: $error', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _saveSelectedGroup() async {
    setState(() => _saving = true);
    GoogleSheetsService? service;
    try {
      service = await _newSheetsService();
      await service.ensureSheet(spreadsheetId: GoogleConfig.spreadsheetId, sheetName: _rangeSheetName);
      await service.updateRow(spreadsheetId: GoogleConfig.spreadsheetId, range: '$_rangeSheetName!A1:D1', values: _rangeHeaders);
      final rows = await service.fetchRows(spreadsheetId: GoogleConfig.spreadsheetId, range: _rangeSheetRange);
      if (rows.length > 1) {
        final headers = rows.first
            .map((header) => header.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
            .toList();
        final ageIndex = headers.indexOf('agegroup');
        if (ageIndex >= 0) {
          for (var rowIndex = rows.length - 1; rowIndex >= 1; rowIndex--) {
            final row = rows[rowIndex];
            final ageGroup = ageIndex < row.length ? row[ageIndex].trim().toLowerCase() : '';
            if (ageGroup == _selectedAgeGroup) {
              await service.deleteRow(
                spreadsheetId: GoogleConfig.spreadsheetId,
                sheetName: _rangeSheetName,
                rowIndexOneBased: rowIndex + 1,
              );
            }
          }
        }
      }
      for (final parameter in _cbcReferenceParameters) {
        await service.insertRow(
          spreadsheetId: GoogleConfig.spreadsheetId,
          range: _rangeSheetRange,
          values: [
            _selectedAgeGroup,
            parameter.parameter,
            _rangeControllers[parameter.parameter]?.text.trim() ?? '',
            _unitControllers[parameter.parameter]?.text.trim() ?? parameter.unit,
          ],
          valueInputOption: 'RAW',
        );
      }
      _showSnackBar('${_selectedAgeGroup.toUpperCase()} CBC reference ranges saved.');
    } catch (error) {
      _showSnackBar('Save reference ranges failed: $error', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    final theme = Theme.of(context);
    return AppScaffold(
      title: 'CBC Reference Ranges',
      selectedRoute: '/cbc-reference-ranges',
      user: user,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Reload ranges',
          onPressed: _loading || _saving ? null : _loadSelectedGroup,
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      gradient: LinearGradient(
                        colors: [theme.colorScheme.primary, theme.colorScheme.tertiary],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: theme.colorScheme.primary.withValues(alpha: 0.22),
                          blurRadius: 26,
                          offset: const Offset(0, 15),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.18),
                            borderRadius: BorderRadius.circular(24),
                          ),
                          child: const Icon(Icons.rule_rounded, color: Colors.white, size: 36),
                        ),
                        const SizedBox(width: 18),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'CBC / CP(Auto) Reference Ranges',
                                style: theme.textTheme.headlineSmall?.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                'Superadmin can set separate reference ranges for neonate, child, and adult reports.',
                                style: theme.textTheme.bodyMedium?.copyWith(
                                  color: Colors.white.withValues(alpha: 0.88),
                                ),
                              ),
                            ],
                          ),
                        ),
                        DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: _selectedAgeGroup,
                            dropdownColor: theme.colorScheme.surface,
                            items: const [
                              DropdownMenuItem(value: 'neonate', child: Text('Neonate < 28 days')),
                              DropdownMenuItem(value: 'child', child: Text('Child')),
                              DropdownMenuItem(value: 'adult', child: Text('Adult')),
                            ],
                            onChanged: _saving
                                ? null
                                : (value) async {
                                    if (value == null) return;
                                    setState(() => _selectedAgeGroup = value);
                                    await _loadSelectedGroup();
                                  },
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  Expanded(
                    child: Card(
                      elevation: 0,
                      color: theme.colorScheme.surface.withValues(alpha: 0.94),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                      child: Padding(
                        padding: const EdgeInsets.all(18),
                        child: ListView.separated(
                          itemCount: _cbcReferenceParameters.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 10),
                          itemBuilder: (context, index) {
                            final parameter = _cbcReferenceParameters[index];
                            return Row(
                              children: [
                                SizedBox(
                                  width: 110,
                                  child: Text(
                                    parameter.parameter,
                                    style: const TextStyle(fontWeight: FontWeight.w900),
                                  ),
                                ),
                                Expanded(
                                  flex: 3,
                                  child: TextField(
                                    controller: _rangeControllers[parameter.parameter],
                                    decoration: const InputDecoration(
                                      labelText: 'Reference range',
                                      border: OutlineInputBorder(),
                                      isDense: true,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  flex: 2,
                                  child: TextField(
                                    controller: _unitControllers[parameter.parameter],
                                    decoration: const InputDecoration(
                                      labelText: 'Unit',
                                      border: OutlineInputBorder(),
                                      isDense: true,
                                    ),
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Align(
                    alignment: Alignment.centerRight,
                    child: FilledButton.icon(
                      onPressed: _saving ? null : _saveSelectedGroup,
                      icon: _saving
                          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.save_rounded),
                      label: Text(_saving ? 'Saving...' : 'Save ${_selectedAgeGroup.toUpperCase()} ranges'),
                    ),
                  ),
                ],
              ),
      ),
    );
  }

}

class _CbcReferenceParameter {
  const _CbcReferenceParameter(this.parameter, this.defaultRange, this.unit);

  final String parameter;
  final String defaultRange;
  final String unit;
}

const _cbcReferenceParameters = <_CbcReferenceParameter>[
  _CbcReferenceParameter('WBC', '3.50-9.50', '10^3/uL'),
  _CbcReferenceParameter('Neu%', '40.0-75.0', '%'),
  _CbcReferenceParameter('Lym%', '20.0-50.0', '%'),
  _CbcReferenceParameter('Mon%', '3.0-10.0', '%'),
  _CbcReferenceParameter('Eos%', '0.4-8.0', '%'),
  _CbcReferenceParameter('Bas%', '0.0-1.0', '%'),
  _CbcReferenceParameter('Neu#', '1.80-6.30', '10^3/uL'),
  _CbcReferenceParameter('Lym#', '1.10-3.20', '10^3/uL'),
  _CbcReferenceParameter('Mon#', '0.10-0.60', '10^3/uL'),
  _CbcReferenceParameter('Eos#', '0.02-0.52', '10^3/uL'),
  _CbcReferenceParameter('Bas#', '0.00-0.06', '10^3/uL'),
  _CbcReferenceParameter('ALY#', '0.00-0.20', '10^3/uL'),
  _CbcReferenceParameter('ALY%', '0.0-2.0', '%'),
  _CbcReferenceParameter('LIC#', '0.00-0.20', '10^3/uL'),
  _CbcReferenceParameter('LIC%', '0.0-2.5', '%'),
  _CbcReferenceParameter('NRBC#', '0.000-9999.999', '10^9/L'),
  _CbcReferenceParameter('NRBC%', '0.00-9999.99', '%'),
  _CbcReferenceParameter('RBC', '3.80-5.80', '10^6/uL'),
  _CbcReferenceParameter('HGB', '11.5-17.5', 'g/dL'),
  _CbcReferenceParameter('HCT', '35.0-50.0', '%'),
  _CbcReferenceParameter('MCV', '82.0-100.0', 'fL'),
  _CbcReferenceParameter('MCH', '27.0-34.0', 'pg'),
  _CbcReferenceParameter('MCHC', '31.6-35.4', 'g/dL'),
  _CbcReferenceParameter('RDW-CV', '11.0-16.0', '%'),
  _CbcReferenceParameter('RDW-SD', '35.0-56.0', 'fL'),
  _CbcReferenceParameter('PLT', '125-350', '10^3/uL'),
  _CbcReferenceParameter('MPV', '6.5-12.0', 'fL'),
  _CbcReferenceParameter('PDW', '9.0-17.0', 'fL'),
  _CbcReferenceParameter('PCT', '0.108-0.282', '%'),
  _CbcReferenceParameter('P-LCR', '11.0-45.0', '%'),
  _CbcReferenceParameter('P-LCC', '30-90', '10^9/L'),
];
