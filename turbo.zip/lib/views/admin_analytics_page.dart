import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/app_user.dart';
import '../models/blood_sample.dart';
import '../models/lab_test.dart';
import '../models/sub_center_pricing.dart';
import '../providers/auth_notifier.dart';
import '../providers/sample_dashboard_controller.dart';
import '../providers/tests_provider.dart';
import '../widgets/app_sidebar.dart';

class AdminAnalyticsPage extends ConsumerWidget {
  const AdminAnalyticsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authNotifierProvider);
    final samplesAsync = ref.watch(sampleDashboardControllerProvider);
    final testsAsync = ref.watch(testsProvider);
    final pricingsAsync = ref.watch(pricingsProvider);

    return AppScaffold(
      title: 'Admin Analytics',
      selectedRoute: '/admin-analytics',
      user: user,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Refresh analytics',
          onPressed: () {
            ref.invalidate(sampleDashboardControllerProvider);
            ref.invalidate(testsProvider);
            ref.invalidate(pricingsProvider);
          },
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        child: samplesAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, _) => Center(child: Text('Failed to load analytics: $error')),
          data: (samples) {
            final tests = testsAsync.maybeWhen(data: (v) => v, orElse: () => const <LabTest>[]);
            final pricings = pricingsAsync.maybeWhen(data: (v) => v, orElse: () => const <SubCenterPricing>[]);
            return _AdminAnalyticsContent(user: user, samples: samples, tests: tests, pricings: pricings);
          },
        ),
      ),
    );
  }
}

class _AdminAnalyticsContent extends StatelessWidget {
  const _AdminAnalyticsContent({required this.user, required this.samples, required this.tests, required this.pricings});

  final AppUser? user;
  final List<BloodSample> samples;
  final List<LabTest> tests;
  final List<SubCenterPricing> pricings;

  @override
  Widget build(BuildContext context) {
    final centerId = ((user?.subCenterId ?? '').trim().isEmpty) ? 'GLOBAL' : user!.subCenterId!.trim();
    final analytics = _AdminAnalytics(centerId: centerId, samples: samples, tests: tests, pricings: pricings);
    final now = DateTime.now();
    final thisMonth = _monthName(now.month);
    final rows = analytics.monthlyRows(now.year);
    final visibleRows = rows.where((r) => r.revenue > 0 || r.tests > 0).toList();
    final testTotals = analytics.testsByName();

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Hero(centerId: centerId),
          const SizedBox(height: 18),
          LayoutBuilder(builder: (context, constraints) {
            final compact = constraints.maxWidth < 980;
            final cards = [
              _KpiCard(title: '$thisMonth Cost', value: analytics.costForMonth(now).toStringAsFixed(0), subtitle: 'Cost = revenue - profit', icon: Icons.account_balance_wallet_rounded, color: const Color(0xFFEF4444)),
              _KpiCard(title: '$thisMonth Profit', value: analytics.profitForMonth(now).toStringAsFixed(0), subtitle: 'Custom markup', icon: Icons.trending_up_rounded, color: const Color(0xFF10B981)),
              _KpiCard(title: '$thisMonth Revenue', value: analytics.revenueForMonth(now).toStringAsFixed(0), subtitle: 'Customer price total', icon: Icons.payments_rounded, color: const Color(0xFF3B82F6)),
              _KpiCard(title: 'Total Tests', value: analytics.totalTests().toString(), subtitle: '${analytics.testsForMonth(now)} this month', icon: Icons.biotech_rounded, color: const Color(0xFF8B5CF6)),
            ];
            if (compact) return Column(children: cards.map((c) => Padding(padding: const EdgeInsets.only(bottom: 12), child: c)).toList());
            return Row(children: [for (var i=0;i<cards.length;i++) ...[Expanded(child: cards[i]), if (i != cards.length-1) const SizedBox(width: 14)]]);
          }),
          const SizedBox(height: 18),
          LayoutBuilder(builder: (context, constraints) {
            final compact = constraints.maxWidth < 980;
            final left = _GlassPanel(
              title: 'Monthly Cost vs Profit',
              subtitle: 'Clean grouped graph with monthly comparison',
              icon: Icons.stacked_bar_chart_rounded,
              accent: const Color(0xFF14B8A6),
              child: SizedBox(
                height: 340,
                child: _PrettyCostProfitChart(rows: rows),
              ),
            );
            final right = _GlassPanel(
              title: 'Tests by Month',
              subtitle: 'Stylish test volume graph by month',
              icon: Icons.insights_rounded,
              accent: const Color(0xFF6366F1),
              child: SizedBox(
                height: 340,
                child: _PrettyTestsChart(rows: rows),
              ),
            );
            if (compact) return Column(children: [left, const SizedBox(height: 14), right]);
            return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: left), const SizedBox(width: 14), Expanded(child: right)]);
          }),
          const SizedBox(height: 18),
          LayoutBuilder(builder: (context, constraints) {
            final compact = constraints.maxWidth < 980;
            final trend = _GlassPanel(
              title: 'Monthly Summary',
              subtitle: 'Cost, profit, revenue and tests by month',
              icon: Icons.calendar_month_rounded,
              accent: const Color(0xFF0EA5E9),
              child: visibleRows.isEmpty ? const _Empty(message: 'No monthly data yet.') : Column(children: [for (final r in visibleRows) _MonthTile(row: r)]),
            );
            final testsCard = _GlassPanel(
              title: 'Total Tests by Test Name',
              subtitle: 'Example: Total CBC - 200, Total ESR - 100',
              icon: Icons.science_rounded,
              accent: const Color(0xFF8B5CF6),
              child: testTotals.isEmpty ? const _Empty(message: 'No test totals yet.') : Wrap(spacing: 10, runSpacing: 10, children: [for (final e in testTotals.entries) Chip(avatar: CircleAvatar(child: Text('${e.value}')), label: Text('Total ${e.key} - ${e.value}'))]),
            );
            if (compact) return Column(children: [trend, const SizedBox(height: 14), testsCard]);
            return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: trend), const SizedBox(width: 14), Expanded(child: testsCard)]);
          }),
        ],
      ),
    );
  }
}

class _AdminAnalytics {
  const _AdminAnalytics({required this.centerId, required this.samples, required this.tests, required this.pricings});
  final String centerId;
  final List<BloodSample> samples;
  final List<LabTest> tests;
  final List<SubCenterPricing> pricings;

  List<BloodSample> get centerSamples => samples.where((s) => _norm(s.subCenterId) == _norm(centerId)).toList();
  int totalTests() => centerSamples.fold(0, (sum, s) => sum + s.testIds.length);
  int testsForMonth(DateTime d) => centerSamples.where((s) => _sameMonth(s.createdAt, d)).fold(0, (sum, s) => sum + s.testIds.length);
  double revenueForMonth(DateTime d) => centerSamples.where((s) => _sameMonth(s.createdAt, d)).fold(0, (sum, s) => sum + _sampleRevenue(s));
  double profitForMonth(DateTime d) => centerSamples.where((s) => _sameMonth(s.createdAt, d)).fold(0, (sum, s) => sum + _sampleProfit(s));
  double costForMonth(DateTime d) => revenueForMonth(d) - profitForMonth(d);
  List<_MonthRow> monthlyRows(int year) => [for (var m=1;m<=12;m++) _MonthRow(month: m, cost: costForMonth(DateTime(year,m,1)), profit: profitForMonth(DateTime(year,m,1)), revenue: revenueForMonth(DateTime(year,m,1)), tests: testsForMonth(DateTime(year,m,1)))];
  Map<String,int> testsByName() {
    final map = <String,int>{};
    for (final s in centerSamples) {
      for (final t in s.testIds) {
        final name = _testFor(t).testName;
        map[name] = (map[name] ?? 0) + 1;
      }
    }
    final entries = map.entries.toList()..sort((a,b) => b.value.compareTo(a.value));
    return Map.fromEntries(entries);
  }
  double _sampleRevenue(BloodSample s) => s.testIds.fold(0, (sum, t) => sum + _customerPrice(s.subCenterId, t));
  double _sampleProfit(BloodSample s) => s.testIds.fold(0, (sum, t) => sum + (_customerPrice(s.subCenterId, t) - _testFor(t).defaultPrice));
  double _customerPrice(String center, String testText) {
    final test = _testFor(testText);
    for (final p in pricings) {
      final pt = _norm(p.testId);
      if (_norm(p.subCenterId) == _norm(center) && (pt == _norm(test.id) || pt == _norm(test.testName) || pt == _norm(testText))) {
        return p.customPrice > 0 ? p.customPrice : test.defaultPrice;
      }
    }
    return test.defaultPrice;
  }
  LabTest _testFor(String text) {
    for (final t in tests) {
      if (_norm(t.id) == _norm(text) || _norm(t.testName) == _norm(text)) return t;
    }
    return LabTest(id: text, testName: text, defaultPrice: 0);
  }
  bool _sameMonth(DateTime? value, DateTime d) { if (value == null) return false; final v = value.toLocal(); return v.year == d.year && v.month == d.month; }
  String _norm(String v) => v.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
}

class _MonthRow { const _MonthRow({required this.month, required this.cost, required this.profit, required this.revenue, required this.tests}); final int month; final double cost; final double profit; final double revenue; final int tests; }

class _Hero extends StatelessWidget { const _Hero({required this.centerId}); final String centerId; @override Widget build(BuildContext context) { final theme=Theme.of(context); return Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(borderRadius: BorderRadius.circular(30), gradient: const LinearGradient(colors: [Color(0xFF0F766E), Color(0xFF2563EB), Color(0xFF7C3AED)]), boxShadow: [BoxShadow(color: theme.colorScheme.primary.withValues(alpha: .24), blurRadius: 30, offset: const Offset(0,18))]), child: Row(children: [Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .18), borderRadius: BorderRadius.circular(24)), child: const Icon(Icons.query_stats_rounded, color: Colors.white, size: 36)), const SizedBox(width: 18), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Admin Analytics', style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w900)), const SizedBox(height: 6), Text('$centerId monthly cost, profits, revenue and test analytics.', style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white.withValues(alpha: .88)))]))])); } }

class _KpiCard extends StatelessWidget { const _KpiCard({required this.title, required this.value, required this.subtitle, required this.icon, required this.color}); final String title,value,subtitle; final IconData icon; final Color color; @override Widget build(BuildContext context){ final theme=Theme.of(context); return Card(elevation:0, color: theme.colorScheme.surface.withValues(alpha:.94), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)), child: Padding(padding: const EdgeInsets.all(22), child: Row(children: [Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: color.withValues(alpha:.13), borderRadius: BorderRadius.circular(20)), child: Icon(icon,color:color,size:30)), const SizedBox(width:16), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[Text(title, style: theme.textTheme.titleMedium), const SizedBox(height:6), Text(value, style: theme.textTheme.headlineSmall?.copyWith(color:color,fontWeight:FontWeight.w900)), Text(subtitle, style: theme.textTheme.bodySmall)]))]))); } }

class _GlassPanel extends StatelessWidget { const _GlassPanel({required this.title, required this.subtitle, required this.icon, required this.accent, required this.child}); final String title,subtitle; final IconData icon; final Color accent; final Widget child; @override Widget build(BuildContext context){ final theme=Theme.of(context); return Card(elevation:0, color: theme.colorScheme.surface.withValues(alpha:.94), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)), child: Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(30), border: Border.all(color: accent.withValues(alpha:.16)), gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [accent.withValues(alpha:.08), theme.colorScheme.surface.withValues(alpha:.02)])), padding: const EdgeInsets.all(22), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[Row(children:[Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: accent.withValues(alpha:.13)), child: Icon(icon,color:accent)), const SizedBox(width:12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[Text(title, style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)), const SizedBox(height:4), Text(subtitle)]))]), const SizedBox(height:18), child]))); } }


class _PrettyCostProfitChart extends StatelessWidget {
  const _PrettyCostProfitChart({required this.rows});

  final List<_MonthRow> rows;

  @override
  Widget build(BuildContext context) {
    final maxValue = rows.fold<double>(0, (max, row) {
      final localMax = row.cost > row.profit ? row.cost : row.profit;
      return localMax > max ? localMax : max;
    });
    return Column(
      children: [
        const _Legend(),
        const SizedBox(height: 14),
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              for (final row in rows)
                Expanded(
                  child: _MonthCostProfitColumn(
                    row: row,
                    maxValue: maxValue <= 0 ? 1.0 : maxValue,
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _PrettyTestsChart extends StatelessWidget {
  const _PrettyTestsChart({required this.rows});

  final List<_MonthRow> rows;

  @override
  Widget build(BuildContext context) {
    final maxTests = rows.fold<int>(0, (max, row) => row.tests > max ? row.tests : max);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        for (final row in rows)
          Expanded(
            child: _MonthTestsColumn(
              row: row,
              maxTests: maxTests <= 0 ? 1 : maxTests,
            ),
          ),
      ],
    );
  }
}

class _MonthCostProfitColumn extends StatelessWidget {
  const _MonthCostProfitColumn({required this.row, required this.maxValue});

  final _MonthRow row;
  final double maxValue;

  @override
  Widget build(BuildContext context) {
    final costHeight = (row.cost / maxValue).clamp(0.0, 1.0) * 170;
    final profitHeight = (row.profit / maxValue).clamp(0.0, 1.0) * 170;
    final hasData = row.cost > 0 || row.profit > 0 || row.tests > 0;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Text(
            hasData ? row.cost.toStringAsFixed(0) : '',
            maxLines: 1,
            overflow: TextOverflow.fade,
            style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w800, color: Color(0xFFEF4444)),
          ),
          const SizedBox(height: 4),
          Expanded(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _VerticalBar(
                    height: costHeight,
                    color: const Color(0xFFEF4444),
                    empty: !hasData,
                  ),
                  const SizedBox(width: 3),
                  _VerticalBar(
                    height: profitHeight,
                    color: const Color(0xFF10B981),
                    empty: !hasData,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 7),
          Text(
            _shortMonth(row.month),
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w900,
              color: hasData ? Theme.of(context).colorScheme.onSurface : Theme.of(context).colorScheme.outline,
            ),
          ),
        ],
      ),
    );
  }
}

class _MonthTestsColumn extends StatelessWidget {
  const _MonthTestsColumn({required this.row, required this.maxTests});

  final _MonthRow row;
  final int maxTests;

  @override
  Widget build(BuildContext context) {
    final height = (row.tests / maxTests).clamp(0.0, 1.0) * 190;
    final hasData = row.tests > 0;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(99),
              color: hasData ? const Color(0xFF8B5CF6).withValues(alpha: 0.16) : Colors.transparent,
            ),
            child: Text(
              hasData ? '${row.tests}' : '',
              style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: Color(0xFF8B5CF6)),
            ),
          ),
          const SizedBox(height: 6),
          Expanded(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: _VerticalBar(
                height: height,
                width: 18,
                color: const Color(0xFF8B5CF6),
                empty: !hasData,
              ),
            ),
          ),
          const SizedBox(height: 7),
          Text(
            _shortMonth(row.month),
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w900,
              color: hasData ? Theme.of(context).colorScheme.onSurface : Theme.of(context).colorScheme.outline,
            ),
          ),
        ],
      ),
    );
  }
}

class _VerticalBar extends StatelessWidget {
  const _VerticalBar({
    required this.height,
    required this.color,
    required this.empty,
    this.width = 12,
  });

  final double height;
  final double width;
  final Color color;
  final bool empty;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 450),
      width: width,
      height: empty ? 6 : height.clamp(8.0, 190.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(99),
        gradient: empty
            ? null
            : LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [color.withValues(alpha: 0.92), color.withValues(alpha: 0.50)],
              ),
        color: empty ? Theme.of(context).colorScheme.outlineVariant.withValues(alpha: 0.35) : null,
        boxShadow: empty
            ? []
            : [BoxShadow(color: color.withValues(alpha: 0.24), blurRadius: 10, offset: const Offset(0, 4))],
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  const _Legend();

  @override
  Widget build(BuildContext context) => const Row(
        children: [
          _Dot(label: 'Cost', color: Color(0xFFEF4444)),
          SizedBox(width: 14),
          _Dot(label: 'Profit', color: Color(0xFF10B981)),
        ],
      );
}

class _Dot extends StatelessWidget {
  const _Dot({required this.label, required this.color});

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
        ],
      );

}

class _MonthTile extends StatelessWidget { const _MonthTile({required this.row}); final _MonthRow row; @override Widget build(BuildContext context)=> Container(margin: const EdgeInsets.only(bottom:10), padding: const EdgeInsets.all(14), decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha:.42), border: Border.all(color: Theme.of(context).colorScheme.outlineVariant)), child: Row(children:[CircleAvatar(child: Text(_monthName(row.month).substring(0,1))), const SizedBox(width:12), Expanded(child: Text(_monthName(row.month), style: const TextStyle(fontWeight:FontWeight.w900))), Text('Cost ${row.cost.toStringAsFixed(0)}'), const SizedBox(width:12), Text('Profit ${row.profit.toStringAsFixed(0)}', style: const TextStyle(color:Color(0xFF10B981),fontWeight:FontWeight.w900)), const SizedBox(width:12), Text('${row.tests} tests', style: const TextStyle(fontWeight:FontWeight.w900))])); }
class _Empty extends StatelessWidget { const _Empty({required this.message}); final String message; @override Widget build(BuildContext context)=> Container(width:double.infinity,padding:const EdgeInsets.all(16),decoration:BoxDecoration(borderRadius:BorderRadius.circular(18),color:Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha:.4)), child:Text(message)); }
String _monthName(int m){const n=['January','February','March','April','May','June','July','August','September','October','November','December']; return n[m-1];}
String _shortMonth(int m){const n=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']; return n[m-1];}
