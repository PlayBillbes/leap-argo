// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'blood_sample.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$BloodSample {

 String get id; String get patientName; String get subCenterId; String get registeredByUserId; List<String> get testIds; BloodSampleStatus get status; String? get resultFileUrl; DateTime? get createdAt; DateTime? get updatedAt;
/// Create a copy of BloodSample
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$BloodSampleCopyWith<BloodSample> get copyWith => _$BloodSampleCopyWithImpl<BloodSample>(this as BloodSample, _$identity);

  /// Serializes this BloodSample to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is BloodSample&&(identical(other.id, id) || other.id == id)&&(identical(other.patientName, patientName) || other.patientName == patientName)&&(identical(other.subCenterId, subCenterId) || other.subCenterId == subCenterId)&&(identical(other.registeredByUserId, registeredByUserId) || other.registeredByUserId == registeredByUserId)&&const DeepCollectionEquality().equals(other.testIds, testIds)&&(identical(other.status, status) || other.status == status)&&(identical(other.resultFileUrl, resultFileUrl) || other.resultFileUrl == resultFileUrl)&&(identical(other.createdAt, createdAt) || other.createdAt == createdAt)&&(identical(other.updatedAt, updatedAt) || other.updatedAt == updatedAt));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,id,patientName,subCenterId,registeredByUserId,const DeepCollectionEquality().hash(testIds),status,resultFileUrl,createdAt,updatedAt);

@override
String toString() {
  return 'BloodSample(id: $id, patientName: $patientName, subCenterId: $subCenterId, registeredByUserId: $registeredByUserId, testIds: $testIds, status: $status, resultFileUrl: $resultFileUrl, createdAt: $createdAt, updatedAt: $updatedAt)';
}


}

/// @nodoc
abstract mixin class $BloodSampleCopyWith<$Res>  {
  factory $BloodSampleCopyWith(BloodSample value, $Res Function(BloodSample) _then) = _$BloodSampleCopyWithImpl;
@useResult
$Res call({
 String id, String patientName, String subCenterId, String registeredByUserId, List<String> testIds, BloodSampleStatus status, String? resultFileUrl, DateTime? createdAt, DateTime? updatedAt
});




}
/// @nodoc
class _$BloodSampleCopyWithImpl<$Res>
    implements $BloodSampleCopyWith<$Res> {
  _$BloodSampleCopyWithImpl(this._self, this._then);

  final BloodSample _self;
  final $Res Function(BloodSample) _then;

/// Create a copy of BloodSample
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? id = null,Object? patientName = null,Object? subCenterId = null,Object? registeredByUserId = null,Object? testIds = null,Object? status = null,Object? resultFileUrl = freezed,Object? createdAt = freezed,Object? updatedAt = freezed,}) {
  return _then(_self.copyWith(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,patientName: null == patientName ? _self.patientName : patientName // ignore: cast_nullable_to_non_nullable
as String,subCenterId: null == subCenterId ? _self.subCenterId : subCenterId // ignore: cast_nullable_to_non_nullable
as String,registeredByUserId: null == registeredByUserId ? _self.registeredByUserId : registeredByUserId // ignore: cast_nullable_to_non_nullable
as String,testIds: null == testIds ? _self.testIds : testIds // ignore: cast_nullable_to_non_nullable
as List<String>,status: null == status ? _self.status : status // ignore: cast_nullable_to_non_nullable
as BloodSampleStatus,resultFileUrl: freezed == resultFileUrl ? _self.resultFileUrl : resultFileUrl // ignore: cast_nullable_to_non_nullable
as String?,createdAt: freezed == createdAt ? _self.createdAt : createdAt // ignore: cast_nullable_to_non_nullable
as DateTime?,updatedAt: freezed == updatedAt ? _self.updatedAt : updatedAt // ignore: cast_nullable_to_non_nullable
as DateTime?,
  ));
}

}


/// Adds pattern-matching-related methods to [BloodSample].
extension BloodSamplePatterns on BloodSample {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _BloodSample value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _BloodSample() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _BloodSample value)  $default,){
final _that = this;
switch (_that) {
case _BloodSample():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _BloodSample value)?  $default,){
final _that = this;
switch (_that) {
case _BloodSample() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String id,  String patientName,  String subCenterId,  String registeredByUserId,  List<String> testIds,  BloodSampleStatus status,  String? resultFileUrl,  DateTime? createdAt,  DateTime? updatedAt)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _BloodSample() when $default != null:
return $default(_that.id,_that.patientName,_that.subCenterId,_that.registeredByUserId,_that.testIds,_that.status,_that.resultFileUrl,_that.createdAt,_that.updatedAt);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String id,  String patientName,  String subCenterId,  String registeredByUserId,  List<String> testIds,  BloodSampleStatus status,  String? resultFileUrl,  DateTime? createdAt,  DateTime? updatedAt)  $default,) {final _that = this;
switch (_that) {
case _BloodSample():
return $default(_that.id,_that.patientName,_that.subCenterId,_that.registeredByUserId,_that.testIds,_that.status,_that.resultFileUrl,_that.createdAt,_that.updatedAt);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String id,  String patientName,  String subCenterId,  String registeredByUserId,  List<String> testIds,  BloodSampleStatus status,  String? resultFileUrl,  DateTime? createdAt,  DateTime? updatedAt)?  $default,) {final _that = this;
switch (_that) {
case _BloodSample() when $default != null:
return $default(_that.id,_that.patientName,_that.subCenterId,_that.registeredByUserId,_that.testIds,_that.status,_that.resultFileUrl,_that.createdAt,_that.updatedAt);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _BloodSample implements BloodSample {
  const _BloodSample({required this.id, required this.patientName, required this.subCenterId, required this.registeredByUserId, required final  List<String> testIds, required this.status, this.resultFileUrl, this.createdAt, this.updatedAt}): _testIds = testIds;
  factory _BloodSample.fromJson(Map<String, dynamic> json) => _$BloodSampleFromJson(json);

@override final  String id;
@override final  String patientName;
@override final  String subCenterId;
@override final  String registeredByUserId;
 final  List<String> _testIds;
@override List<String> get testIds {
  if (_testIds is EqualUnmodifiableListView) return _testIds;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_testIds);
}

@override final  BloodSampleStatus status;
@override final  String? resultFileUrl;
@override final  DateTime? createdAt;
@override final  DateTime? updatedAt;

/// Create a copy of BloodSample
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$BloodSampleCopyWith<_BloodSample> get copyWith => __$BloodSampleCopyWithImpl<_BloodSample>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$BloodSampleToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _BloodSample&&(identical(other.id, id) || other.id == id)&&(identical(other.patientName, patientName) || other.patientName == patientName)&&(identical(other.subCenterId, subCenterId) || other.subCenterId == subCenterId)&&(identical(other.registeredByUserId, registeredByUserId) || other.registeredByUserId == registeredByUserId)&&const DeepCollectionEquality().equals(other._testIds, _testIds)&&(identical(other.status, status) || other.status == status)&&(identical(other.resultFileUrl, resultFileUrl) || other.resultFileUrl == resultFileUrl)&&(identical(other.createdAt, createdAt) || other.createdAt == createdAt)&&(identical(other.updatedAt, updatedAt) || other.updatedAt == updatedAt));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,id,patientName,subCenterId,registeredByUserId,const DeepCollectionEquality().hash(_testIds),status,resultFileUrl,createdAt,updatedAt);

@override
String toString() {
  return 'BloodSample(id: $id, patientName: $patientName, subCenterId: $subCenterId, registeredByUserId: $registeredByUserId, testIds: $testIds, status: $status, resultFileUrl: $resultFileUrl, createdAt: $createdAt, updatedAt: $updatedAt)';
}


}

/// @nodoc
abstract mixin class _$BloodSampleCopyWith<$Res> implements $BloodSampleCopyWith<$Res> {
  factory _$BloodSampleCopyWith(_BloodSample value, $Res Function(_BloodSample) _then) = __$BloodSampleCopyWithImpl;
@override @useResult
$Res call({
 String id, String patientName, String subCenterId, String registeredByUserId, List<String> testIds, BloodSampleStatus status, String? resultFileUrl, DateTime? createdAt, DateTime? updatedAt
});




}
/// @nodoc
class __$BloodSampleCopyWithImpl<$Res>
    implements _$BloodSampleCopyWith<$Res> {
  __$BloodSampleCopyWithImpl(this._self, this._then);

  final _BloodSample _self;
  final $Res Function(_BloodSample) _then;

/// Create a copy of BloodSample
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? id = null,Object? patientName = null,Object? subCenterId = null,Object? registeredByUserId = null,Object? testIds = null,Object? status = null,Object? resultFileUrl = freezed,Object? createdAt = freezed,Object? updatedAt = freezed,}) {
  return _then(_BloodSample(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,patientName: null == patientName ? _self.patientName : patientName // ignore: cast_nullable_to_non_nullable
as String,subCenterId: null == subCenterId ? _self.subCenterId : subCenterId // ignore: cast_nullable_to_non_nullable
as String,registeredByUserId: null == registeredByUserId ? _self.registeredByUserId : registeredByUserId // ignore: cast_nullable_to_non_nullable
as String,testIds: null == testIds ? _self._testIds : testIds // ignore: cast_nullable_to_non_nullable
as List<String>,status: null == status ? _self.status : status // ignore: cast_nullable_to_non_nullable
as BloodSampleStatus,resultFileUrl: freezed == resultFileUrl ? _self.resultFileUrl : resultFileUrl // ignore: cast_nullable_to_non_nullable
as String?,createdAt: freezed == createdAt ? _self.createdAt : createdAt // ignore: cast_nullable_to_non_nullable
as DateTime?,updatedAt: freezed == updatedAt ? _self.updatedAt : updatedAt // ignore: cast_nullable_to_non_nullable
as DateTime?,
  ));
}


}

// dart format on
