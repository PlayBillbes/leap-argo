// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'lab_test.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_LabTest _$LabTestFromJson(Map<String, dynamic> json) => _LabTest(
  id: json['id'] as String,
  testName: json['testName'] as String,
  defaultPrice: (json['defaultPrice'] as num).toDouble(),
);

Map<String, dynamic> _$LabTestToJson(_LabTest instance) => <String, dynamic>{
  'id': instance.id,
  'testName': instance.testName,
  'defaultPrice': instance.defaultPrice,
};
