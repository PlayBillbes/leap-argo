// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'sub_center_pricing.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$SubCenterPricing {

 String get subCenterId; String get testId; double get customPrice;
/// Create a copy of SubCenterPricing
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$SubCenterPricingCopyWith<SubCenterPricing> get copyWith => _$SubCenterPricingCopyWithImpl<SubCenterPricing>(this as SubCenterPricing, _$identity);

  /// Serializes this SubCenterPricing to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is SubCenterPricing&&(identical(other.subCenterId, subCenterId) || other.subCenterId == subCenterId)&&(identical(other.testId, testId) || other.testId == testId)&&(identical(other.customPrice, customPrice) || other.customPrice == customPrice));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,subCenterId,testId,customPrice);

@override
String toString() {
  return 'SubCenterPricing(subCenterId: $subCenterId, testId: $testId, customPrice: $customPrice)';
}


}

/// @nodoc
abstract mixin class $SubCenterPricingCopyWith<$Res>  {
  factory $SubCenterPricingCopyWith(SubCenterPricing value, $Res Function(SubCenterPricing) _then) = _$SubCenterPricingCopyWithImpl;
@useResult
$Res call({
 String subCenterId, String testId, double customPrice
});




}
/// @nodoc
class _$SubCenterPricingCopyWithImpl<$Res>
    implements $SubCenterPricingCopyWith<$Res> {
  _$SubCenterPricingCopyWithImpl(this._self, this._then);

  final SubCenterPricing _self;
  final $Res Function(SubCenterPricing) _then;

/// Create a copy of SubCenterPricing
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? subCenterId = null,Object? testId = null,Object? customPrice = null,}) {
  return _then(_self.copyWith(
subCenterId: null == subCenterId ? _self.subCenterId : subCenterId // ignore: cast_nullable_to_non_nullable
as String,testId: null == testId ? _self.testId : testId // ignore: cast_nullable_to_non_nullable
as String,customPrice: null == customPrice ? _self.customPrice : customPrice // ignore: cast_nullable_to_non_nullable
as double,
  ));
}

}


/// Adds pattern-matching-related methods to [SubCenterPricing].
extension SubCenterPricingPatterns on SubCenterPricing {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _SubCenterPricing value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _SubCenterPricing() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _SubCenterPricing value)  $default,){
final _that = this;
switch (_that) {
case _SubCenterPricing():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _SubCenterPricing value)?  $default,){
final _that = this;
switch (_that) {
case _SubCenterPricing() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String subCenterId,  String testId,  double customPrice)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _SubCenterPricing() when $default != null:
return $default(_that.subCenterId,_that.testId,_that.customPrice);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String subCenterId,  String testId,  double customPrice)  $default,) {final _that = this;
switch (_that) {
case _SubCenterPricing():
return $default(_that.subCenterId,_that.testId,_that.customPrice);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String subCenterId,  String testId,  double customPrice)?  $default,) {final _that = this;
switch (_that) {
case _SubCenterPricing() when $default != null:
return $default(_that.subCenterId,_that.testId,_that.customPrice);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _SubCenterPricing implements SubCenterPricing {
  const _SubCenterPricing({required this.subCenterId, required this.testId, required this.customPrice});
  factory _SubCenterPricing.fromJson(Map<String, dynamic> json) => _$SubCenterPricingFromJson(json);

@override final  String subCenterId;
@override final  String testId;
@override final  double customPrice;

/// Create a copy of SubCenterPricing
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$SubCenterPricingCopyWith<_SubCenterPricing> get copyWith => __$SubCenterPricingCopyWithImpl<_SubCenterPricing>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$SubCenterPricingToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _SubCenterPricing&&(identical(other.subCenterId, subCenterId) || other.subCenterId == subCenterId)&&(identical(other.testId, testId) || other.testId == testId)&&(identical(other.customPrice, customPrice) || other.customPrice == customPrice));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,subCenterId,testId,customPrice);

@override
String toString() {
  return 'SubCenterPricing(subCenterId: $subCenterId, testId: $testId, customPrice: $customPrice)';
}


}

/// @nodoc
abstract mixin class _$SubCenterPricingCopyWith<$Res> implements $SubCenterPricingCopyWith<$Res> {
  factory _$SubCenterPricingCopyWith(_SubCenterPricing value, $Res Function(_SubCenterPricing) _then) = __$SubCenterPricingCopyWithImpl;
@override @useResult
$Res call({
 String subCenterId, String testId, double customPrice
});




}
/// @nodoc
class __$SubCenterPricingCopyWithImpl<$Res>
    implements _$SubCenterPricingCopyWith<$Res> {
  __$SubCenterPricingCopyWithImpl(this._self, this._then);

  final _SubCenterPricing _self;
  final $Res Function(_SubCenterPricing) _then;

/// Create a copy of SubCenterPricing
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? subCenterId = null,Object? testId = null,Object? customPrice = null,}) {
  return _then(_SubCenterPricing(
subCenterId: null == subCenterId ? _self.subCenterId : subCenterId // ignore: cast_nullable_to_non_nullable
as String,testId: null == testId ? _self.testId : testId // ignore: cast_nullable_to_non_nullable
as String,customPrice: null == customPrice ? _self.customPrice : customPrice // ignore: cast_nullable_to_non_nullable
as double,
  ));
}


}

// dart format on
