import 'package:freezed_annotation/freezed_annotation.dart';

part 'blood_sample.freezed.dart';
part 'blood_sample.g.dart';

@JsonEnum(alwaysCreate: true)
enum BloodSampleStatus {
  @JsonValue('pending')
  pending,
  @JsonValue('processing')
  processing,
  @JsonValue('completed')
  completed,
}

@freezed
abstract class BloodSample with _$BloodSample {
  const factory BloodSample({
    required String id,
    required String patientName,
    required String subCenterId,
    required String registeredByUserId,
    required List<String> testIds,
    required BloodSampleStatus status,
    String? resultFileUrl,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) = _BloodSample;

  factory BloodSample.fromJson(Map<String, Object?> json) =>
      _$BloodSampleFromJson(json);
}
