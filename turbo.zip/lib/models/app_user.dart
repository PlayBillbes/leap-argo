import 'package:freezed_annotation/freezed_annotation.dart';

part 'app_user.freezed.dart';
part 'app_user.g.dart';

@JsonEnum(alwaysCreate: true)
enum AppUserRole {
  @JsonValue('superadmin')
  superadmin,
  @JsonValue('admin')
  admin,
  @JsonValue('lab_tech')
  lab_tech,
  @JsonValue('staff')
  staff,
}

@freezed
abstract class AppUser with _$AppUser {
  const factory AppUser({
    required String id,
    required String name,
    required AppUserRole role,
    String? subCenterId,
  }) = _AppUser;

  factory AppUser.fromJson(Map<String, Object?> json) =>
      _$AppUserFromJson(json);
}
