// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'blood_sample.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_BloodSample _$BloodSampleFromJson(Map<String, dynamic> json) => _BloodSample(
  id: json['id'] as String,
  patientName: json['patientName'] as String,
  subCenterId: json['subCenterId'] as String,
  registeredByUserId: json['registeredByUserId'] as String,
  testIds: (json['testIds'] as List<dynamic>).map((e) => e as String).toList(),
  status: $enumDecode(_$BloodSampleStatusEnumMap, json['status']),
  resultFileUrl: json['resultFileUrl'] as String?,
  createdAt: json['createdAt'] == null
      ? null
      : DateTime.parse(json['createdAt'] as String),
  updatedAt: json['updatedAt'] == null
      ? null
      : DateTime.parse(json['updatedAt'] as String),
);

Map<String, dynamic> _$BloodSampleToJson(_BloodSample instance) =>
    <String, dynamic>{
      'id': instance.id,
      'patientName': instance.patientName,
      'subCenterId': instance.subCenterId,
      'registeredByUserId': instance.registeredByUserId,
      'testIds': instance.testIds,
      'status': _$BloodSampleStatusEnumMap[instance.status]!,
      'resultFileUrl': instance.resultFileUrl,
      'createdAt': instance.createdAt?.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
    };

const _$BloodSampleStatusEnumMap = {
  BloodSampleStatus.pending: 'pending',
  BloodSampleStatus.processing: 'processing',
  BloodSampleStatus.completed: 'completed',
};
