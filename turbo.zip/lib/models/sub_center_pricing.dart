import 'package:freezed_annotation/freezed_annotation.dart';

part 'sub_center_pricing.freezed.dart';
part 'sub_center_pricing.g.dart';

@freezed
abstract class SubCenterPricing with _$SubCenterPricing {
  const factory SubCenterPricing({
    required String subCenterId,
    required String testId,
    required double customPrice,
  }) = _SubCenterPricing;

  factory SubCenterPricing.fromJson(Map<String, Object?> json) =>
      _$SubCenterPricingFromJson(json);
}
