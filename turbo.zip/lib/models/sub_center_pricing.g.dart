// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sub_center_pricing.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_SubCenterPricing _$SubCenterPricingFromJson(Map<String, dynamic> json) =>
    _SubCenterPricing(
      subCenterId: json['subCenterId'] as String,
      testId: json['testId'] as String,
      customPrice: (json['customPrice'] as num).toDouble(),
    );

Map<String, dynamic> _$SubCenterPricingToJson(_SubCenterPricing instance) =>
    <String, dynamic>{
      'subCenterId': instance.subCenterId,
      'testId': instance.testId,
      'customPrice': instance.customPrice,
    };
