// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'lab_test.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$LabTest {

 String get id; String get testName; double get defaultPrice;
/// Create a copy of LabTest
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$LabTestCopyWith<LabTest> get copyWith => _$LabTestCopyWithImpl<LabTest>(this as LabTest, _$identity);

  /// Serializes this LabTest to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is LabTest&&(identical(other.id, id) || other.id == id)&&(identical(other.testName, testName) || other.testName == testName)&&(identical(other.defaultPrice, defaultPrice) || other.defaultPrice == defaultPrice));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,id,testName,defaultPrice);

@override
String toString() {
  return 'LabTest(id: $id, testName: $testName, defaultPrice: $defaultPrice)';
}


}

/// @nodoc
abstract mixin class $LabTestCopyWith<$Res>  {
  factory $LabTestCopyWith(LabTest value, $Res Function(LabTest) _then) = _$LabTestCopyWithImpl;
@useResult
$Res call({
 String id, String testName, double defaultPrice
});




}
/// @nodoc
class _$LabTestCopyWithImpl<$Res>
    implements $LabTestCopyWith<$Res> {
  _$LabTestCopyWithImpl(this._self, this._then);

  final LabTest _self;
  final $Res Function(LabTest) _then;

/// Create a copy of LabTest
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? id = null,Object? testName = null,Object? defaultPrice = null,}) {
  return _then(_self.copyWith(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,testName: null == testName ? _self.testName : testName // ignore: cast_nullable_to_non_nullable
as String,defaultPrice: null == defaultPrice ? _self.defaultPrice : defaultPrice // ignore: cast_nullable_to_non_nullable
as double,
  ));
}

}


/// Adds pattern-matching-related methods to [LabTest].
extension LabTestPatterns on LabTest {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _LabTest value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _LabTest() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _LabTest value)  $default,){
final _that = this;
switch (_that) {
case _LabTest():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _LabTest value)?  $default,){
final _that = this;
switch (_that) {
case _LabTest() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String id,  String testName,  double defaultPrice)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _LabTest() when $default != null:
return $default(_that.id,_that.testName,_that.defaultPrice);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String id,  String testName,  double defaultPrice)  $default,) {final _that = this;
switch (_that) {
case _LabTest():
return $default(_that.id,_that.testName,_that.defaultPrice);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String id,  String testName,  double defaultPrice)?  $default,) {final _that = this;
switch (_that) {
case _LabTest() when $default != null:
return $default(_that.id,_that.testName,_that.defaultPrice);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _LabTest implements LabTest {
  const _LabTest({required this.id, required this.testName, required this.defaultPrice});
  factory _LabTest.fromJson(Map<String, dynamic> json) => _$LabTestFromJson(json);

@override final  String id;
@override final  String testName;
@override final  double defaultPrice;

/// Create a copy of LabTest
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$LabTestCopyWith<_LabTest> get copyWith => __$LabTestCopyWithImpl<_LabTest>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$LabTestToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _LabTest&&(identical(other.id, id) || other.id == id)&&(identical(other.testName, testName) || other.testName == testName)&&(identical(other.defaultPrice, defaultPrice) || other.defaultPrice == defaultPrice));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,id,testName,defaultPrice);

@override
String toString() {
  return 'LabTest(id: $id, testName: $testName, defaultPrice: $defaultPrice)';
}


}

/// @nodoc
abstract mixin class _$LabTestCopyWith<$Res> implements $LabTestCopyWith<$Res> {
  factory _$LabTestCopyWith(_LabTest value, $Res Function(_LabTest) _then) = __$LabTestCopyWithImpl;
@override @useResult
$Res call({
 String id, String testName, double defaultPrice
});




}
/// @nodoc
class __$LabTestCopyWithImpl<$Res>
    implements _$LabTestCopyWith<$Res> {
  __$LabTestCopyWithImpl(this._self, this._then);

  final _LabTest _self;
  final $Res Function(_LabTest) _then;

/// Create a copy of LabTest
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? id = null,Object? testName = null,Object? defaultPrice = null,}) {
  return _then(_LabTest(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,testName: null == testName ? _self.testName : testName // ignore: cast_nullable_to_non_nullable
as String,defaultPrice: null == defaultPrice ? _self.defaultPrice : defaultPrice // ignore: cast_nullable_to_non_nullable
as double,
  ));
}


}

// dart format on
