import 'package:freezed_annotation/freezed_annotation.dart';

part 'lab_test.freezed.dart';
part 'lab_test.g.dart';

@freezed
abstract class LabTest with _$LabTest {
  const factory LabTest({
    required String id,
    required String testName,
    required double defaultPrice,
  }) = _LabTest;

  factory LabTest.fromJson(Map<String, Object?> json) =>
      _$LabTestFromJson(json);
}
