# Turso backend migration

This build replaces the Google Sheets data layer with a Turso SQL over HTTP compatibility adapter.
Existing app code can still call `GoogleSheetsService.fetchRows`, `insertRow`, `updateRow`, `ensureSheet`, and `deleteRow`, but the data is now stored in Turso SQLite tables.

## Why v74 changed

The previous v73 build used `libsql_dart`, which can trigger a native-assets Rust build on Linux. This v74 build uses Turso SQL over HTTP through Dart `http`, so it does not require `rustup` for the Turso backend.

## Required runtime values

Run the app with:

```bash
flutter run -d linux \
  --dart-define=TURSO_DATABASE_URL=libsql://YOUR_DATABASE.turso.io \
  --dart-define=TURSO_AUTH_TOKEN=YOUR_TOKEN
```

## Data mapping

Each former sheet becomes a SQLite table:

```text
BloodSamples             -> sheet_bloodsamples
TestResults              -> sheet_testresults
CBCResults               -> sheet_cbcresults
Users                    -> sheet_users
Tests                    -> sheet_tests
SubCenterPricing         -> sheet_subcenterpricing
CbcReferenceRanges       -> sheet_cbcreferenceranges
ReportHeaderSettings     -> sheet_reportheadersettings
ManualTestDefaults       -> sheet_manualtestdefaults
```

Header order is stored in `_app_sheet_headers`. The adapter creates tables and text columns automatically when a page writes headers.

## Important

This does not automatically copy existing Google Sheets data into Turso. Export each Google Sheet tab as CSV and import it into the matching Turso table, or build a one-time importer using the same headers.
