# FlutterLab native Turso build

This workspace is configured for the native Turso data backend. Runtime data access is handled through `TursoNativeService` and `TursoConfig`; legacy external sheet service-account access has been removed from the app runtime.

See `V143_PURE_NATIVE_TURSO_BUILD_README.md` for the v143 cleanup details.
