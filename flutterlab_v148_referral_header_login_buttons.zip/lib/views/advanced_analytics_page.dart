import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/app_user.dart';
import '../models/blood_sample.dart';
import '../models/lab_test.dart';
import '../models/sub_center_pricing.dart';
import '../providers/auth_notifier.dart';
import '../providers/sample_dashboard_controller.dart';
import '../providers/tests_provider.dart';
import '../services/refer_fee_report_service.dart';
import '../widgets/app_sidebar.dart';

class AdvancedAnalyticsPage extends ConsumerWidget {
  const AdvancedAnalyticsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authNotifierProvider);
    final samplesAsync = ref.watch(sampleDashboardControllerProvider);
    final testsAsync = ref.watch(testsProvider);
    final pricingsAsync = ref.watch(pricingsProvider);

    return AppScaffold(
      title: 'Advanced Analytics',
      selectedRoute: '/advanced-analytics',
      user: user,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Refresh analytics',
          onPressed: () {
            ref.invalidate(sampleDashboardControllerProvider);
            ref.invalidate(testsProvider);
            ref.invalidate(pricingsProvider);
          },
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: LayoutBuilder(
        builder: (context, constraints) {
          final isMobile = constraints.maxWidth < 760;
          return Padding(
            padding: EdgeInsets.fromLTRB(
              isMobile ? 14 : 24,
              isMobile ? 8 : 8,
              isMobile ? 14 : 24,
              isMobile ? 16 : 24,
            ),
            child: samplesAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, stack) => _AnalyticsErrorCard(message: error.toString()),
              data: (samples) {
                final tests = testsAsync.maybeWhen(
                  data: (items) => items,
                  orElse: () => const <LabTest>[],
                );
                final pricings = pricingsAsync.maybeWhen(
                  data: (items) => items,
                  orElse: () => const <SubCenterPricing>[],
                );
                return _AdvancedAnalyticsContent(
                  samples: samples,
                  tests: tests,
                  pricings: pricings,
                );
              },
            ),
          );
        },
      ),
    );
  }
}

class _AdvancedAnalyticsContent extends StatefulWidget {
  const _AdvancedAnalyticsContent({
    required this.samples,
    required this.tests,
    required this.pricings,
  });

  final List<BloodSample> samples;
  final List<LabTest> tests;
  final List<SubCenterPricing> pricings;

  @override
  State<_AdvancedAnalyticsContent> createState() => _AdvancedAnalyticsContentState();
}

class _AdvancedAnalyticsContentState extends State<_AdvancedAnalyticsContent> {
  static const String _allCenters = 'ALL';
  String _selectedCenter = _allCenters;

  String _normalizeCenter(String value) {
    return value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
  }

  List<String> get _subCenters {
    final centers = <String>{};
    for (final sample in widget.samples) {
      final center = sample.subCenterId.trim().isEmpty ? 'GLOBAL' : sample.subCenterId.trim();
      centers.add(center);
    }
    final sorted = centers.toList()..sort();
    return sorted;
  }

  List<BloodSample> get _filteredSamples {
    if (_selectedCenter == _allCenters) return widget.samples;
    final selected = _normalizeCenter(_selectedCenter);
    return widget.samples
        .where((sample) => _normalizeCenter(sample.subCenterId) == selected)
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final samples = _filteredSamples;
    final tests = widget.tests;
    final analytics = _AnalyticsCalculator(samples: samples, tests: tests);
    final now = DateTime.now();
    final todayRevenue = analytics.revenueForDay(now);
    final monthRevenue = analytics.revenueForMonth(now);
    final yearRevenue = analytics.revenueForYear(now);
    final todayTests = analytics.testsForDay(now);
    final monthTests = analytics.testsForMonth(now);
    final yearTests = analytics.testsForYear(now);
    final pending = samples.where((s) => s.status == BloodSampleStatus.pending).length;
    final completed = samples.where((s) => s.status == BloodSampleStatus.completed).length;
    final dailyRevenue = analytics.dailyRevenueForMonth(now.year, now.month);
    final monthlyRevenue = analytics.monthlyRevenueForYear(now.year);
    final revenueByCenter = analytics.revenueBySubCenter();
    final topTests = analytics.testCountByName();
    final pendingToday = analytics.pendingTestCountByNameForDay(now);
    final isMobile = MediaQuery.sizeOf(context).width < 760;

    if (isMobile) {
      return _MobileAdvancedAnalyticsView(
        centers: _subCenters,
        selectedCenter: _selectedCenter,
        totalSamples: widget.samples.length,
        filteredSamples: samples.length,
        onCenterChanged: (value) {
          if (value == null) return;
          setState(() => _selectedCenter = value);
        },
        todayRevenue: todayRevenue,
        monthRevenue: monthRevenue,
        yearRevenue: yearRevenue,
        todayTests: todayTests,
        monthTests: monthTests,
        yearTests: yearTests,
        pending: pending,
        completed: completed,
        dailyRevenue: dailyRevenue,
        monthlyRevenue: monthlyRevenue,
        revenueByCenter: revenueByCenter,
        topTests: topTests,
        pendingToday: pendingToday,
        onYearlyReferFeeReport: () => _printAdvancedReferFeeReport(context, samples: samples, year: now.year, scopeLabel: _selectedCenter == _allCenters ? 'All sub-centers' : 'Sub-center: $_selectedCenter', headerScopeType: _selectedCenter == _allCenters ? 'GLOBAL' : 'SUBCENTER', headerSubCenterId: _selectedCenter == _allCenters ? 'GLOBAL' : _selectedCenter),
        onMonthlyReferFeeReport: () => _printAdvancedReferFeeReport(context, samples: samples, year: now.year, month: now.month, scopeLabel: _selectedCenter == _allCenters ? 'All sub-centers' : 'Sub-center: $_selectedCenter', headerScopeType: _selectedCenter == _allCenters ? 'GLOBAL' : 'SUBCENTER', headerSubCenterId: _selectedCenter == _allCenters ? 'GLOBAL' : _selectedCenter),
      );
    }

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _AnalyticsHero(),
          const SizedBox(height: 18),
          _SubCenterFilterCard(
            centers: _subCenters,
            selectedCenter: _selectedCenter,
            totalSamples: widget.samples.length,
            filteredSamples: samples.length,
            onChanged: (value) {
              if (value == null) return;
              setState(() => _selectedCenter = value);
            },
          ),
          const SizedBox(height: 12),
          _AdvancedReferFeeReportActions(
            onYearly: () => _printAdvancedReferFeeReport(context, samples: samples, year: now.year, scopeLabel: _selectedCenter == _allCenters ? 'All sub-centers' : 'Sub-center: $_selectedCenter', headerScopeType: _selectedCenter == _allCenters ? 'GLOBAL' : 'SUBCENTER', headerSubCenterId: _selectedCenter == _allCenters ? 'GLOBAL' : _selectedCenter),
            onMonthly: () => _printAdvancedReferFeeReport(context, samples: samples, year: now.year, month: now.month, scopeLabel: _selectedCenter == _allCenters ? 'All sub-centers' : 'Sub-center: $_selectedCenter', headerScopeType: _selectedCenter == _allCenters ? 'GLOBAL' : 'SUBCENTER', headerSubCenterId: _selectedCenter == _allCenters ? 'GLOBAL' : _selectedCenter),
          ),
          const SizedBox(height: 18),
          LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 980;
              final cards = [
                _AnalyticsMetricCard(
                  title: 'Revenue / Today',
                  value: todayRevenue.toStringAsFixed(2),
                  subtitle: 'Global default price',
                  icon: Icons.today_rounded,
                  color: const Color(0xFF2563EB),
                ),
                _AnalyticsMetricCard(
                  title: 'Revenue / This Month',
                  value: monthRevenue.toStringAsFixed(2),
                  subtitle: 'Network revenue',
                  icon: Icons.calendar_month_rounded,
                  color: const Color(0xFF059669),
                ),
                _AnalyticsMetricCard(
                  title: 'Revenue / This Year',
                  value: yearRevenue.toStringAsFixed(2),
                  subtitle: 'Network revenue',
                  icon: Icons.auto_graph_rounded,
                  color: const Color(0xFF2563EB),
                ),
                _AnalyticsMetricCard(
                  title: 'Samples',
                  value: samples.length.toString(),
                  subtitle: '$pending pending • $completed completed',
                  icon: Icons.science_rounded,
                  color: const Color(0xFFEA580C),
                ),
              ];

              if (constraints.maxWidth < 760) {
                return _MobileMetricGrid(children: cards);
              }

              if (compact) {
                return Column(
                  children: [
                    for (final card in cards) ...[
                      card,
                      if (card != cards.last) const SizedBox(height: 12),
                    ],
                  ],
                );
              }

              return Row(
                children: [
                  for (var i = 0; i < cards.length; i++) ...[
                    Expanded(child: cards[i]),
                    if (i != cards.length - 1) const SizedBox(width: 14),
                  ],
                ],
              );
            },
          ),
          const SizedBox(height: 18),
          LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 980;
              final testCard = _AnalyticsMetricCard(
                title: 'Tests / Today',
                value: todayTests.toString(),
                subtitle: '$monthTests this month • $yearTests this year',
                icon: Icons.biotech_rounded,
                color: const Color(0xFF0B57B7),
              );
              final pendingCard = _AnalyticsListCard(
                title: 'Pending Tests / Today',
                subtitle: 'Pending count / test name',
                items: pendingToday,
                emptyText: 'No pending tests today',
              );
              if (compact) {
                return Column(children: [testCard, const SizedBox(height: 14), pendingCard]);
              }
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: testCard),
                  const SizedBox(width: 14),
                  Expanded(flex: 2, child: pendingCard),
                ],
              );
            },
          ),
          const SizedBox(height: 18),
          LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 980;
              final monthChart = _ChartCard(
                title: 'Revenue Graph / Day by Day',
                subtitle: 'Current month daily revenue from global default prices',
                child: _LineChart(values: dailyRevenue),
              );
              final yearChart = _ChartCard(
                title: 'Revenue Graph / Month by Month',
                subtitle: 'Current year monthly revenue from global default prices',
                child: _BarChart(values: monthlyRevenue),
              );
              if (compact) {
                return Column(children: [monthChart, const SizedBox(height: 14), yearChart]);
              }
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: monthChart),
                  const SizedBox(width: 14),
                  Expanded(child: yearChart),
                ],
              );
            },
          ),
          const SizedBox(height: 18),
          LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 980;
              final centerCard = _AnalyticsListCard(
                title: 'Revenue by Sub-center',
                subtitle: 'Default price revenue by center',
                items: revenueByCenter,
                emptyText: 'No center revenue yet',
                money: true,
              );
              final testCard = _AnalyticsListCard(
                title: 'Most Requested Tests',
                subtitle: 'Total test volume by test name',
                items: topTests,
                emptyText: 'No test volume yet',
              );
              if (compact) {
                return Column(children: [centerCard, const SizedBox(height: 14), testCard]);
              }
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: centerCard),
                  const SizedBox(width: 14),
                  Expanded(child: testCard),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}





class _AdvancedReferFeeReportActions extends StatelessWidget {
  const _AdvancedReferFeeReportActions({required this.onYearly, required this.onMonthly, this.compact = false});

  final VoidCallback onYearly;
  final VoidCallback onMonthly;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final yearly = FilledButton.icon(
      onPressed: onYearly,
      icon: const Icon(Icons.picture_as_pdf_rounded),
      label: const Text('All Refer Fees / Year'),
    );
    final monthly = FilledButton.tonalIcon(
      onPressed: onMonthly,
      icon: const Icon(Icons.print_rounded),
      label: const Text('All Refer Fees / Month'),
    );
    if (compact) return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [yearly, const SizedBox(height: 8), monthly]);
    return Wrap(spacing: 10, runSpacing: 10, children: [yearly, monthly]);
  }
}

Future<void> _printAdvancedReferFeeReport(
  BuildContext context, {
  required List<BloodSample> samples,
  required int year,
  int? month,
  required String scopeLabel,
  String headerScopeType = 'GLOBAL',
  String headerSubCenterId = 'GLOBAL',
}) async {
  await ReferFeeReportService.printReport(
    title: month == null ? 'Superadmin Yearly Refer Fee Report' : 'Superadmin Monthly Refer Fee Report',
    periodLabel: month == null ? '$year' : '${_monthName(month)} $year',
    scopeLabel: scopeLabel,
    headerScopeType: headerScopeType,
    headerSubCenterId: headerSubCenterId,
    rows: _advancedReferFeeRows(samples, year: year, month: month),
  );
}

List<ReferFeeReportRow> _advancedReferFeeRows(List<BloodSample> samples, {required int year, int? month}) {
  final rows = <ReferFeeReportRow>[];
  for (final sample in samples) {
    final createdAt = sample.createdAt?.toLocal();
    if (createdAt == null || createdAt.year != year) continue;
    if (month != null && createdAt.month != month) continue;
    final referredId = (sample.referredPersonId ?? '').trim().toLowerCase();
    final referredName = (sample.referredPersonName ?? '').trim().toLowerCase();
    if ((referredId.isEmpty && referredName.isEmpty) || referredId == 'self' || referredName == 'self') continue;
    final amount = sample.referredFeeAmount;
    if (amount <= 0) continue;
    rows.add(ReferFeeReportRow(
      date: createdAt,
      sampleId: sample.id,
      patientName: sample.patientName,
      subCenterId: sample.subCenterId,
      referredPerson: _advancedReferredPersonLabel(sample),
      tests: sample.testIds.join(', '),
      amount: amount,
    ));
  }
  return rows;
}

String _advancedReferredPersonLabel(BloodSample sample) {
  final name = (sample.referredPersonName ?? '').trim();
  final id = (sample.referredPersonId ?? '').trim();
  if (name.isNotEmpty && name.toLowerCase() != 'self') return name;
  if (id.isNotEmpty && id.toLowerCase() != 'self') return id;
  return 'Unknown referral';
}

class _MobileAdvancedAnalyticsView extends StatelessWidget {
  const _MobileAdvancedAnalyticsView({
    required this.centers,
    required this.selectedCenter,
    required this.totalSamples,
    required this.filteredSamples,
    required this.onCenterChanged,
    required this.todayRevenue,
    required this.monthRevenue,
    required this.yearRevenue,
    required this.todayTests,
    required this.monthTests,
    required this.yearTests,
    required this.pending,
    required this.completed,
    required this.dailyRevenue,
    required this.monthlyRevenue,
    required this.revenueByCenter,
    required this.topTests,
    required this.pendingToday,
    required this.onYearlyReferFeeReport,
    required this.onMonthlyReferFeeReport,
  });

  final List<String> centers;
  final String selectedCenter;
  final int totalSamples;
  final int filteredSamples;
  final ValueChanged<String?> onCenterChanged;
  final double todayRevenue;
  final double monthRevenue;
  final double yearRevenue;
  final int todayTests;
  final int monthTests;
  final int yearTests;
  final int pending;
  final int completed;
  final List<double> dailyRevenue;
  final List<double> monthlyRevenue;
  final Map<String, double> revenueByCenter;
  final Map<String, int> topTests;
  final Map<String, int> pendingToday;
  final VoidCallback onYearlyReferFeeReport;
  final VoidCallback onMonthlyReferFeeReport;

  String _money(double value) => value.toStringAsFixed(0);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _MobileAnalyticsHero(
            selectedCenter: selectedCenter,
            totalSamples: totalSamples,
            filteredSamples: filteredSamples,
          ),
          const SizedBox(height: 14),
          _MobileCenterSelector(
            centers: centers,
            selectedCenter: selectedCenter,
            totalSamples: totalSamples,
            filteredSamples: filteredSamples,
            onChanged: onCenterChanged,
          ),
          const SizedBox(height: 12),
          _AdvancedReferFeeReportActions(
            compact: true,
            onYearly: onYearlyReferFeeReport,
            onMonthly: onMonthlyReferFeeReport,
          ),
          const SizedBox(height: 16),
          const _MobileSectionLabel(title: 'Revenue snapshot', subtitle: 'Default-price totals'),
          const SizedBox(height: 10),
          _MobileKpiGrid(
            children: [
              _MobileKpiCard(
                title: 'Today',
                value: _money(todayRevenue),
                subtitle: '$todayTests tests',
                icon: Icons.today_rounded,
                color: const Color(0xFF2563EB),
              ),
              _MobileKpiCard(
                title: 'Month',
                value: _money(monthRevenue),
                subtitle: '$monthTests tests',
                icon: Icons.calendar_month_rounded,
                color: const Color(0xFF059669),
              ),
              _MobileKpiCard(
                title: 'Year',
                value: _money(yearRevenue),
                subtitle: '$yearTests tests',
                icon: Icons.auto_graph_rounded,
                color: const Color(0xFF7C3AED),
              ),
              _MobileKpiCard(
                title: 'Samples',
                value: filteredSamples.toString(),
                subtitle: '$pending pending • $completed done',
                icon: Icons.science_rounded,
                color: const Color(0xFFEA580C),
              ),
            ],
          ),
          const SizedBox(height: 18),
          const _MobileSectionLabel(title: 'Workload today', subtitle: 'Pending test demand'),
          const SizedBox(height: 10),
          _MobileRankPanel(
            title: 'Pending tests',
            emptyText: 'No pending tests today',
            items: pendingToday,
            color: const Color(0xFFF59E0B),
          ),
          const SizedBox(height: 18),
          const _MobileSectionLabel(title: 'Revenue trend', subtitle: 'Scrollable-friendly compact charts'),
          const SizedBox(height: 10),
          _MobileChartPanel(
            title: 'This month',
            subtitle: 'Day by day revenue',
            child: _LineChart(values: dailyRevenue),
          ),
          const SizedBox(height: 12),
          _MobileChartPanel(
            title: 'This year',
            subtitle: 'Month by month revenue',
            child: _BarChart(values: monthlyRevenue),
          ),
          const SizedBox(height: 18),
          const _MobileSectionLabel(title: 'Network breakdown', subtitle: 'Top centers and tests'),
          const SizedBox(height: 10),
          _MobileRankPanel(
            title: 'Revenue by sub-center',
            emptyText: 'No center revenue yet',
            items: revenueByCenter,
            money: true,
            color: const Color(0xFF0B57B7),
          ),
          const SizedBox(height: 12),
          _MobileRankPanel(
            title: 'Most requested tests',
            emptyText: 'No test volume yet',
            items: topTests,
            color: const Color(0xFF16A34A),
          ),
        ],
      ),
    );
  }
}

class _MobileAnalyticsHero extends StatelessWidget {
  const _MobileAnalyticsHero({
    required this.selectedCenter,
    required this.totalSamples,
    required this.filteredSamples,
  });

  final String selectedCenter;
  final int totalSamples;
  final int filteredSamples;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scope = selectedCenter == 'ALL' ? 'All centers' : selectedCenter;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0B57B7), Color(0xFF2563EB), Color(0xFF38BDF8)],
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0B57B7).withValues(alpha: 0.22),
            blurRadius: 24,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.18),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.white.withValues(alpha: 0.22)),
                ),
                child: const Icon(Icons.analytics_rounded, color: Colors.white, size: 30),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Advanced Analytics',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.titleLarge?.copyWith(color: Colors.white, fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Superadmin mobile overview',
                      style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white.withValues(alpha: 0.86), fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _MobileHeroChip(label: 'Scope', value: scope),
              _MobileHeroChip(label: 'Rows', value: '$filteredSamples/$totalSamples'),
            ],
          ),
        ],
      ),
    );
  }
}

class _MobileHeroChip extends StatelessWidget {
  const _MobileHeroChip({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(99),
        border: Border.all(color: Colors.white.withValues(alpha: 0.24)),
      ),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12),
          children: [
            TextSpan(text: '$label: ', style: TextStyle(color: Colors.white.withValues(alpha: 0.76))),
            TextSpan(text: value),
          ],
        ),
      ),
    );
  }
}

class _MobileCenterSelector extends StatelessWidget {
  const _MobileCenterSelector({
    required this.centers,
    required this.selectedCenter,
    required this.totalSamples,
    required this.filteredSamples,
    required this.onChanged,
  });

  final List<String> centers;
  final String selectedCenter;
  final int totalSamples;
  final int filteredSamples;
  final ValueChanged<String?> onChanged;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final options = ['ALL', ...centers];
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: theme.colorScheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.storefront_rounded, color: theme.colorScheme.primary),
              const SizedBox(width: 8),
              Expanded(
                child: Text('Sub-center filter', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
              ),
              Text('$filteredSamples/$totalSamples', style: TextStyle(color: theme.colorScheme.primary, fontWeight: FontWeight.w900)),
            ],
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: options.contains(selectedCenter) ? selectedCenter : 'ALL',
            decoration: InputDecoration(
              labelText: 'Scope',
              prefixIcon: const Icon(Icons.filter_alt_rounded),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            ),
            items: [
              for (final option in options)
                DropdownMenuItem(value: option, child: Text(option == 'ALL' ? 'All sub-centers' : option)),
            ],
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

class _MobileSectionLabel extends StatelessWidget {
  const _MobileSectionLabel({required this.title, required this.subtitle});
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900, color: const Color(0xFF0F172A))),
              const SizedBox(height: 2),
              Text(subtitle, style: theme.textTheme.bodySmall?.copyWith(color: const Color(0xFF64748B), fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ],
    );
  }
}

class _MobileKpiGrid extends StatelessWidget {
  const _MobileKpiGrid({required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        for (var i = 0; i < children.length; i += 2) ...[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: children[i]),
              const SizedBox(width: 10),
              Expanded(child: i + 1 < children.length ? children[i + 1] : const SizedBox.shrink()),
            ],
          ),
          if (i + 2 < children.length) const SizedBox(height: 10),
        ],
      ],
    );
  }
}

class _MobileKpiCard extends StatelessWidget {
  const _MobileKpiCard({
    required this.title,
    required this.value,
    required this.subtitle,
    required this.icon,
    required this.color,
  });

  final String title;
  final String value;
  final String subtitle;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: color.withValues(alpha: 0.14)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.025), blurRadius: 12, offset: const Offset(0, 6))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(color: color.withValues(alpha: 0.11), borderRadius: BorderRadius.circular(15)),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(height: 10),
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: theme.textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w800, color: const Color(0xFF475569))),
          const SizedBox(height: 4),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(value, style: theme.textTheme.headlineSmall?.copyWith(color: color, fontWeight: FontWeight.w900, letterSpacing: -0.6)),
          ),
          const SizedBox(height: 3),
          Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.bodySmall?.copyWith(color: const Color(0xFF64748B), fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _MobileChartPanel extends StatelessWidget {
  const _MobileChartPanel({required this.title, required this.subtitle, required this.child});
  final String title;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: theme.colorScheme.primary.withValues(alpha: 0.12)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(color: theme.colorScheme.primary.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(14)),
                child: Icon(Icons.show_chart_rounded, color: theme.colorScheme.primary, size: 22),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
                    Text(subtitle, style: theme.textTheme.bodySmall?.copyWith(color: const Color(0xFF64748B), fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(height: 235, child: child),
        ],
      ),
    );
  }
}

class _MobileRankPanel extends StatelessWidget {
  const _MobileRankPanel({
    required this.title,
    required this.emptyText,
    required this.items,
    required this.color,
    this.money = false,
  });

  final String title;
  final String emptyText;
  final Map<String, num> items;
  final Color color;
  final bool money;

  String _value(num value) => money ? value.toStringAsFixed(0) : value.toString();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final entries = items.entries.toList();
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: color.withValues(alpha: 0.14)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.leaderboard_rounded, color: color),
              const SizedBox(width: 8),
              Expanded(child: Text(title, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900))),
            ],
          ),
          const SizedBox(height: 12),
          if (entries.isEmpty)
            Text(emptyText, style: TextStyle(color: theme.colorScheme.outline, fontWeight: FontWeight.w700))
          else
            Column(
              children: [
                for (var i = 0; i < entries.take(6).length; i++) ...[
                  _MobileRankRow(
                    rank: i + 1,
                    label: entries[i].key,
                    value: _value(entries[i].value),
                    color: color,
                  ),
                  if (i != entries.take(6).length - 1) const Divider(height: 16),
                ],
              ],
            ),
        ],
      ),
    );
  }
}

class _MobileRankRow extends StatelessWidget {
  const _MobileRankRow({required this.rank, required this.label, required this.value, required this.color});
  final int rank;
  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        CircleAvatar(
          radius: 15,
          backgroundColor: color.withValues(alpha: 0.12),
          foregroundColor: color,
          child: Text(rank.toString(), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900)),
        ),
        const SizedBox(width: 10),
        Expanded(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800))),
        const SizedBox(width: 8),
        Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w900)),
      ],
    );
  }
}

class _MobileMetricGrid extends StatelessWidget {
  const _MobileMetricGrid({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        for (var i = 0; i < children.length; i += 2) ...[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: children[i]),
              const SizedBox(width: 10),
              Expanded(
                child: i + 1 < children.length ? children[i + 1] : const SizedBox.shrink(),
              ),
            ],
          ),
          if (i + 2 < children.length) const SizedBox(height: 10),
        ],
      ],
    );
  }
}

class _SubCenterFilterCard extends StatelessWidget {
  const _SubCenterFilterCard({
    required this.centers,
    required this.selectedCenter,
    required this.totalSamples,
    required this.filteredSamples,
    required this.onChanged,
  });

  final List<String> centers;
  final String selectedCenter;
  final int totalSamples;
  final int filteredSamples;
  final ValueChanged<String?> onChanged;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final options = ['ALL', ...centers];
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.94),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: theme.colorScheme.primary.withValues(alpha: 0.14)),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              theme.colorScheme.primary.withValues(alpha: 0.06),
              theme.colorScheme.surface.withValues(alpha: 0.01),
            ],
          ),
        ),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final compact = constraints.maxWidth < 760;
            final title = Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primary.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Icon(Icons.filter_alt_rounded, color: theme.colorScheme.primary),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Filter by Sub-center',
                        style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        selectedCenter == 'ALL'
                            ? 'Showing all sub-centers'
                            : 'Showing analytics for $selectedCenter only',
                      ),
                    ],
                  ),
                ),
              ],
            );

            final dropdown = DropdownButtonFormField<String>(
              value: options.contains(selectedCenter) ? selectedCenter : 'ALL',
              decoration: InputDecoration(
                labelText: 'Sub-center',
                prefixIcon: const Icon(Icons.storefront_rounded),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
              ),
              items: [
                for (final option in options)
                  DropdownMenuItem(
                    value: option,
                    child: Text(option == 'ALL' ? 'All sub-centers' : option),
                  ),
              ],
              onChanged: onChanged,
            );

            final picker = compact
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: _FilterPill(label: 'Rows', value: '$filteredSamples / $totalSamples'),
                      ),
                      const SizedBox(height: 12),
                      dropdown,
                    ],
                  )
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _FilterPill(label: 'Rows', value: '$filteredSamples / $totalSamples'),
                      const SizedBox(width: 12),
                      ConstrainedBox(
                        constraints: const BoxConstraints(minWidth: 220, maxWidth: 320),
                        child: dropdown,
                      ),
                    ],
                  );

            if (compact) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  title,
                  const SizedBox(height: 16),
                  picker,
                ],
              );
            }

            return Row(
              children: [
                Expanded(child: title),
                const SizedBox(width: 16),
                picker,
              ],
            );
          },
        ),
      ),
    );
  }
}

class _FilterPill extends StatelessWidget {
  const _FilterPill({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(99),
        border: Border.all(color: color.withValues(alpha: 0.20)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w800)),
          Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _AnalyticsCalculator {
  const _AnalyticsCalculator({required this.samples, required this.tests});

  final List<BloodSample> samples;
  final List<LabTest> tests;

  double revenueForDay(DateTime date) {
    return samples
        .where((sample) => _isSameLocalDay(sample.createdAt, date))
        .fold<double>(0, (sum, sample) => sum + _sampleRevenue(sample));
  }

  double revenueForMonth(DateTime date) {
    return samples
        .where((sample) => _isSameLocalMonth(sample.createdAt, date))
        .fold<double>(0, (sum, sample) => sum + _sampleRevenue(sample));
  }

  double revenueForYear(DateTime date) {
    return samples
        .where((sample) => sample.createdAt?.toLocal().year == date.year)
        .fold<double>(0, (sum, sample) => sum + _sampleRevenue(sample));
  }

  int testsForDay(DateTime date) {
    return samples
        .where((sample) => _isSameLocalDay(sample.createdAt, date))
        .fold<int>(0, (sum, sample) => sum + sample.testIds.length);
  }

  int testsForMonth(DateTime date) {
    return samples
        .where((sample) => _isSameLocalMonth(sample.createdAt, date))
        .fold<int>(0, (sum, sample) => sum + sample.testIds.length);
  }

  int testsForYear(DateTime date) {
    return samples
        .where((sample) => sample.createdAt?.toLocal().year == date.year)
        .fold<int>(0, (sum, sample) => sum + sample.testIds.length);
  }

  List<double> dailyRevenueForMonth(int year, int month) {
    final days = DateTime(year, month + 1, 0).day;
    return [
      for (var day = 1; day <= days; day++)
        revenueForDay(DateTime(year, month, day)),
    ];
  }

  List<double> monthlyRevenueForYear(int year) {
    return [
      for (var month = 1; month <= 12; month++)
        revenueForMonth(DateTime(year, month, 1)),
    ];
  }

  Map<String, double> revenueBySubCenter() {
    final values = <String, double>{};
    for (final sample in samples) {
      values[sample.subCenterId] = (values[sample.subCenterId] ?? 0) + _sampleRevenue(sample);
    }
    return _sortedDoubleMap(values);
  }

  Map<String, int> testCountByName() {
    final values = <String, int>{};
    for (final sample in samples) {
      for (final testId in sample.testIds) {
        final label = _testFor(testId).testName;
        values[label] = (values[label] ?? 0) + 1;
      }
    }
    return _sortedIntMap(values);
  }

  Map<String, int> pendingTestCountByNameForDay(DateTime date) {
    final values = <String, int>{};
    for (final sample in samples) {
      if (sample.status != BloodSampleStatus.pending) continue;
      if (!_isSameLocalDay(sample.createdAt, date)) continue;
      for (final testId in sample.testIds) {
        final label = _testFor(testId).testName;
        values[label] = (values[label] ?? 0) + 1;
      }
    }
    return _sortedIntMap(values);
  }

  double _sampleRevenue(BloodSample sample) {
    return sample.testIds.fold<double>(0, (sum, testId) => sum + _testFor(testId).defaultPrice);
  }

  LabTest _testFor(String testIdOrName) {
    final normalizedInput = _normalize(testIdOrName);
    for (final test in tests) {
      if (_normalize(test.id) == normalizedInput || _normalize(test.testName) == normalizedInput) {
        return test;
      }
    }
    return LabTest(id: testIdOrName, testName: testIdOrName, defaultPrice: 0);
  }

  bool _isSameLocalDay(DateTime? value, DateTime date) {
    if (value == null) return false;
    final local = value.toLocal();
    return local.year == date.year && local.month == date.month && local.day == date.day;
  }

  bool _isSameLocalMonth(DateTime? value, DateTime date) {
    if (value == null) return false;
    final local = value.toLocal();
    return local.year == date.year && local.month == date.month;
  }

  String _normalize(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  Map<String, int> _sortedIntMap(Map<String, int> map) {
    final entries = map.entries.toList()
      ..sort((a, b) {
        final byValue = b.value.compareTo(a.value);
        if (byValue != 0) return byValue;
        return a.key.compareTo(b.key);
      });
    return Map<String, int>.fromEntries(entries.take(10));
  }

  Map<String, double> _sortedDoubleMap(Map<String, double> map) {
    final entries = map.entries.toList()
      ..sort((a, b) {
        final byValue = b.value.compareTo(a.value);
        if (byValue != 0) return byValue;
        return a.key.compareTo(b.key);
      });
    return Map<String, double>.fromEntries(entries.take(10));
  }
}

class _AnalyticsHero extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isMobile = MediaQuery.sizeOf(context).width < 760;
    final icon = Container(
      padding: EdgeInsets.all(isMobile ? 14 : 18),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.18),
        borderRadius: BorderRadius.circular(isMobile ? 20 : 24),
      ),
      child: Icon(Icons.analytics_rounded, color: Colors.white, size: isMobile ? 30 : 36),
    );
    final copy = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Superadmin Advanced Analytics',
          maxLines: isMobile ? 2 : 1,
          overflow: TextOverflow.ellipsis,
          style: (isMobile ? theme.textTheme.titleLarge : theme.textTheme.headlineSmall)?.copyWith(
            color: Colors.white,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'Network revenue, test volume, pending workload, and revenue graphs.',
          maxLines: isMobile ? 3 : 2,
          overflow: TextOverflow.ellipsis,
          style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white.withValues(alpha: 0.86), height: 1.35),
        ),
      ],
    );
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(isMobile ? 18 : 24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(isMobile ? 24 : 30),
        gradient: LinearGradient(colors: [theme.colorScheme.primary, theme.colorScheme.tertiary]),
        boxShadow: [
          BoxShadow(
            color: theme.colorScheme.primary.withValues(alpha: 0.24),
            blurRadius: 30,
            offset: const Offset(0, 18),
          ),
        ],
      ),
      child: isMobile
          ? Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                icon,
                const SizedBox(height: 14),
                copy,
              ],
            )
          : Row(
              children: [
                icon,
                const SizedBox(width: 18),
                Expanded(child: copy),
              ],
            ),
    );
  }
}

class _AnalyticsMetricCard extends StatelessWidget {
  const _AnalyticsMetricCard({
    required this.title,
    required this.value,
    required this.subtitle,
    required this.icon,
    required this.color,
  });

  final String title;
  final String value;
  final String subtitle;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return LayoutBuilder(
      builder: (context, constraints) {
        final narrow = constraints.maxWidth < 220;
        final iconBox = Container(
          padding: EdgeInsets.all(narrow ? 10 : 14),
          decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(narrow ? 16 : 20)),
          child: Icon(icon, color: color, size: narrow ? 23 : 30),
        );
        final copy = Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
            SizedBox(height: narrow ? 4 : 6),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(value, style: (narrow ? theme.textTheme.titleLarge : theme.textTheme.headlineSmall)?.copyWith(color: color, fontWeight: FontWeight.w900)),
            ),
            Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.bodySmall),
          ],
        );
        return Card(
          elevation: 0,
          color: theme.colorScheme.surface.withValues(alpha: 0.92),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(narrow ? 20 : 26)),
          child: Padding(
            padding: EdgeInsets.all(narrow ? 14 : 22),
            child: narrow
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      iconBox,
                      const SizedBox(height: 12),
                      copy,
                    ],
                  )
                : Row(
                    children: [
                      iconBox,
                      const SizedBox(width: 16),
                      Expanded(child: copy),
                    ],
                  ),
          ),
        );
      },
    );
  }
}

class _AnalyticsListCard extends StatelessWidget {
  const _AnalyticsListCard({
    required this.title,
    required this.subtitle,
    required this.items,
    required this.emptyText,
    this.money = false,
  });

  final String title;
  final String subtitle;
  final Map<String, num> items;
  final String emptyText;
  final bool money;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isMobile = MediaQuery.sizeOf(context).width < 760;
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.92),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      child: Padding(
        padding: EdgeInsets.all(isMobile ? 16 : 22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            Text(subtitle),
            const SizedBox(height: 14),
            if (items.isEmpty)
              Text(emptyText, style: TextStyle(color: theme.colorScheme.outline))
            else
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final entry in items.entries)
                    Chip(
                      avatar: CircleAvatar(child: Text(money ? entry.value.round().toString() : entry.value.toString())),
                      label: Text(money ? '${entry.key}: ${entry.value.toStringAsFixed(2)}' : '${entry.value} / ${entry.key}'),
                      visualDensity: VisualDensity.compact,
                    ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}


class _ChartCard extends StatelessWidget {
  const _ChartCard({required this.title, required this.subtitle, required this.child});

  final String title;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isMobile = MediaQuery.sizeOf(context).width < 760;
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.94),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: theme.colorScheme.primary.withValues(alpha: 0.13)),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              theme.colorScheme.primary.withValues(alpha: 0.06),
              theme.colorScheme.surface.withValues(alpha: 0.01),
            ],
          ),
        ),
        padding: EdgeInsets.all(isMobile ? 16 : 22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    color: theme.colorScheme.primary.withValues(alpha: 0.12),
                  ),
                  child: Icon(Icons.bar_chart_rounded, color: theme.colorScheme.primary),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
                      const SizedBox(height: 4),
                      Text(subtitle),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            SizedBox(height: isMobile ? 250 : 330, child: child),
          ],
        ),
      ),
    );
  }
}

class _LineChart extends StatelessWidget {
  const _LineChart({required this.values});
  final List<double> values;

  @override
  Widget build(BuildContext context) {
    return _DividedRevenueBars(
      values: values,
      color: const Color(0xFF60A5FA),
      labelMode: _ChartLabelMode.day,
      valueSuffix: '',
    );
  }
}

class _BarChart extends StatelessWidget {
  const _BarChart({required this.values});
  final List<double> values;

  @override
  Widget build(BuildContext context) {
    return _DividedRevenueBars(
      values: values,
      color: const Color(0xFFE879F9),
      labelMode: _ChartLabelMode.month,
      valueSuffix: '',
    );
  }
}

enum _ChartLabelMode { day, month }

class _DividedRevenueBars extends StatelessWidget {
  const _DividedRevenueBars({
    required this.values,
    required this.color,
    required this.labelMode,
    required this.valueSuffix,
  });

  final List<double> values;
  final Color color;
  final _ChartLabelMode labelMode;
  final String valueSuffix;

  @override
  Widget build(BuildContext context) {
    final maxValue = values.fold<double>(0, (max, value) => value > max ? value : max);
    final safeMax = maxValue <= 0 ? 1.0 : maxValue;
    final total = values.fold<double>(0, (sum, value) => sum + value);
    final activeCount = values.where((value) => value > 0).length;
    final isMobile = MediaQuery.sizeOf(context).width < 760;

    return Column(
      children: [
        Wrap(
          spacing: isMobile ? 8 : 10,
          runSpacing: 8,
          children: [
            _ChartStatPill(label: 'Total', value: total.toStringAsFixed(0), color: color),
            _ChartStatPill(label: labelMode == _ChartLabelMode.month ? 'Active months' : 'Active days', value: activeCount.toString(), color: color),
            _ChartStatPill(label: 'Peak', value: maxValue.toStringAsFixed(0), color: color),
          ],
        ),
        const SizedBox(height: 18),
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              for (var index = 0; index < values.length; index++)
                Expanded(
                  child: _RevenueBarColumn(
                    value: values[index],
                    maxValue: safeMax,
                    label: _labelFor(index),
                    color: color,
                    labelMode: labelMode,
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  String _labelFor(int index) {
    if (labelMode == _ChartLabelMode.month) return _shortMonth(index + 1);
    return '${index + 1}';
  }
}

class _RevenueBarColumn extends StatelessWidget {
  const _RevenueBarColumn({
    required this.value,
    required this.maxValue,
    required this.label,
    required this.color,
    required this.labelMode,
  });

  final double value;
  final double maxValue;
  final String label;
  final Color color;
  final _ChartLabelMode labelMode;

  @override
  Widget build(BuildContext context) {
    final hasData = value > 0;
    final isMobile = MediaQuery.sizeOf(context).width < 760;
    final maxBarHeight = isMobile ? 135.0 : 190.0;
    final height = (value / maxValue).clamp(0.0, 1.0) * maxBarHeight;
    final dayNumber = int.tryParse(label);
    final showDayLabel = !isMobile || labelMode == _ChartLabelMode.month || dayNumber == 1 || (dayNumber != null && dayNumber % 5 == 0);
    final showValue = hasData && (labelMode == _ChartLabelMode.month || height > (isMobile ? 42 : 55));
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: labelMode == _ChartLabelMode.month ? (isMobile ? 3 : 5) : (isMobile ? 1 : 2)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          SizedBox(
            height: 22,
            child: Center(
              child: Text(
                showValue ? value.toStringAsFixed(0) : '',
                maxLines: 1,
                overflow: TextOverflow.fade,
                style: TextStyle(
                  fontSize: labelMode == _ChartLabelMode.month ? 10 : 8,
                  fontWeight: FontWeight.w900,
                  color: color,
                ),
              ),
            ),
          ),
          Expanded(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 450),
                width: labelMode == _ChartLabelMode.month ? (isMobile ? 13 : 18) : (isMobile ? 7 : 10),
                height: hasData ? height.clamp(6.0, maxBarHeight) : 5,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(99),
                  gradient: hasData
                      ? LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [color, color.withValues(alpha: 0.46)],
                        )
                      : null,
                  color: hasData ? null : Theme.of(context).colorScheme.outlineVariant.withValues(alpha: 0.32),
                  boxShadow: hasData
                      ? [BoxShadow(color: color.withValues(alpha: 0.25), blurRadius: 10, offset: const Offset(0, 5))]
                      : [],
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 18,
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                showDayLabel ? label : '',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: hasData ? Theme.of(context).colorScheme.onSurface : Theme.of(context).colorScheme.outline,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ChartStatPill extends StatelessWidget {
  const _ChartStatPill({required this.label, required this.value, required this.color});

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(99),
        color: color.withValues(alpha: 0.11),
        border: Border.all(color: color.withValues(alpha: 0.20)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w800)),
          Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

String _shortMonth(int month) {
  const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return names[month - 1];
}

class _AnalyticsErrorCard extends StatelessWidget {
  const _AnalyticsErrorCard({required this.message});
  final String message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text('Failed to load analytics: $message'),
        ),
      ),
    );
  }
}


String _monthName(int month) {
  const names = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  if (month < 1 || month > 12) return 'Month $month';
  return names[month - 1];
}
