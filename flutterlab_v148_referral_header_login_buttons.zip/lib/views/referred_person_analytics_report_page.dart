import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/app_user.dart';
import '../models/blood_sample.dart';
import '../models/lab_test.dart';
import '../models/sub_center_pricing.dart';
import '../providers/auth_notifier.dart';
import '../providers/sample_dashboard_controller.dart';
import '../providers/tests_provider.dart';
import '../services/refer_fee_report_service.dart';
import '../widgets/app_sidebar.dart';

class ReferredPersonAnalyticsReportPage extends ConsumerStatefulWidget {
  const ReferredPersonAnalyticsReportPage({super.key});

  @override
  ConsumerState<ReferredPersonAnalyticsReportPage> createState() => _ReferredPersonAnalyticsReportPageState();
}

class _ReferredPersonAnalyticsReportPageState extends ConsumerState<ReferredPersonAnalyticsReportPage> {
  int _selectedYear = DateTime.now().year;
  int? _selectedMonth;

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    final samplesAsync = ref.watch(sampleDashboardControllerProvider);
    final tests = ref.watch(testsProvider).maybeWhen(data: (value) => value, orElse: () => const <LabTest>[]);
    final pricings = ref.watch(pricingsProvider).maybeWhen(data: (value) => value, orElse: () => const <SubCenterPricing>[]);

    Future<void> refresh() async {
      ref.invalidate(sampleDashboardControllerProvider);
      ref.invalidate(testsProvider);
      ref.invalidate(pricingsProvider);
      await Future<void>.delayed(const Duration(milliseconds: 350));
    }

    return AppScaffold(
      title: 'Referral Report',
      selectedRoute: '/referred-person-report',
      user: user,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Refresh report',
          onPressed: refresh,
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: LayoutBuilder(
        builder: (context, constraints) {
          final isMobile = constraints.maxWidth < 760;
          return Padding(
            padding: EdgeInsets.fromLTRB(isMobile ? 16 : 24, isMobile ? 12 : 8, isMobile ? 16 : 24, isMobile ? 18 : 24),
            child: samplesAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, _) => Center(child: Text('Referral report load failed: $error')),
              data: (samples) {
                if (user == null) return const Center(child: Text('Please sign in.'));
                final analytics = _ReferredPersonAnalytics(user: user, samples: samples, tests: tests, pricings: pricings);
                final yearOptions = analytics.availableYears();
                if (!yearOptions.contains(_selectedYear) && yearOptions.isNotEmpty) {
                  _selectedYear = yearOptions.first;
                }
                final content = isMobile
                    ? _MobileReferralReport(
                        analytics: analytics,
                        selectedYear: _selectedYear,
                        selectedMonth: _selectedMonth,
                        yearOptions: yearOptions,
                        onYearChanged: (value) => setState(() => _selectedYear = value),
                        onMonthChanged: (value) => setState(() => _selectedMonth = value),
                      )
                    : _DesktopReferralReport(
                        analytics: analytics,
                        selectedYear: _selectedYear,
                        selectedMonth: _selectedMonth,
                        yearOptions: yearOptions,
                        onYearChanged: (value) => setState(() => _selectedYear = value),
                        onMonthChanged: (value) => setState(() => _selectedMonth = value),
                      );
                return isMobile ? RefreshIndicator(onRefresh: refresh, child: content) : content;
              },
            ),
          );
        },
      ),
    );
  }
}

class _ReferredPersonAnalytics {
  const _ReferredPersonAnalytics({required this.user, required this.samples, required this.tests, required this.pricings});

  final AppUser user;
  final List<BloodSample> samples;
  final List<LabTest> tests;
  final List<SubCenterPricing> pricings;

  String _norm(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  List<BloodSample> get referredSamples {
    final userId = _norm(user.id);
    final userName = _norm(user.name);
    return samples.where((sample) {
      final referredId = _norm(sample.referredPersonId ?? '');
      final referredName = _norm(sample.referredPersonName ?? '');
      if (referredId == 'self' || referredName == 'self') return false;
      if (referredId.isNotEmpty && referredId == userId) return true;
      return userName.isNotEmpty && referredName == userName;
    }).toList();
  }

  List<int> availableYears() {
    final years = referredSamples.map((sample) => sample.createdAt?.toLocal().year).whereType<int>().toSet().toList()..sort((a, b) => b.compareTo(a));
    if (years.isEmpty) years.add(DateTime.now().year);
    return years;
  }

  List<BloodSample> filteredSamples(int year, int? month) {
    return referredSamples.where((sample) {
      final created = sample.createdAt?.toLocal();
      if (created == null || created.year != year) return false;
      if (month != null && created.month != month) return false;
      return true;
    }).toList();
  }

  int totalSamples(int year, int? month) => filteredSamples(year, month).length;
  int pendingSamples(int year, int? month) => filteredSamples(year, month).where((sample) => sample.status == BloodSampleStatus.pending).length;
  int processingSamples(int year, int? month) => filteredSamples(year, month).where((sample) => sample.status == BloodSampleStatus.processing).length;
  int completedSamples(int year, int? month) => filteredSamples(year, month).where((sample) => sample.status == BloodSampleStatus.completed).length;
  int totalTests(int year, int? month) => filteredSamples(year, month).fold<int>(0, (sum, sample) => sum + sample.testIds.length);
  double totalReferFee(int year, int? month) => filteredSamples(year, month).fold<double>(0, (sum, sample) => sum + _sampleReferFee(sample));

  List<_ReferralMonthRow> monthlyRows(int year) => [
        for (var month = 1; month <= 12; month++)
          _ReferralMonthRow(
            month: month,
            samples: totalSamples(year, month),
            tests: totalTests(year, month),
            referFee: totalReferFee(year, month),
          ),
      ];

  Map<String, int> testsByName(int year, int? month) {
    final result = <String, int>{};
    for (final sample in filteredSamples(year, month)) {
      for (final testId in sample.testIds) {
        final name = _testFor(testId).testName;
        result[name] = (result[name] ?? 0) + 1;
      }
    }
    final entries = result.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return Map.fromEntries(entries);
  }

  List<BloodSample> recentSamples(int year, int? month, [int limit = 8]) {
    final list = filteredSamples(year, month).toList()
      ..sort((a, b) {
        final av = a.createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
        final bv = b.createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
        return bv.compareTo(av);
      });
    return list.take(limit).toList();
  }

  double _sampleReferFee(BloodSample sample) {
    if (sample.referredFeeAmount > 0) return sample.referredFeeAmount;
    return sample.testIds.fold(0.0, (sum, testId) {
      final customerPrice = _customerPrice(sample.subCenterId, testId);
      final percent = sample.referredFeePercent > 0 ? sample.referredFeePercent : (_pricingFor(sample.subCenterId, testId)?.referredFeePercent ?? 0);
      return sum + (customerPrice * percent / 100);
    });
  }

  double _customerPrice(String center, String testText) {
    final test = _testFor(testText);
    final pricing = _pricingFor(center, testText);
    return pricing != null && pricing.customPrice > 0 ? pricing.customPrice : test.defaultPrice;
  }

  SubCenterPricing? _pricingFor(String center, String testText) {
    final test = _testFor(testText);
    final normalizedCenter = _norm(center);
    final normalizedInput = _norm(testText);
    for (final pricing in pricings) {
      if (_norm(pricing.subCenterId) != normalizedCenter) continue;
      final pricingTest = _norm(pricing.testId);
      if (pricingTest == _norm(test.id) || pricingTest == _norm(test.testName) || pricingTest == normalizedInput) return pricing;
    }
    return null;
  }

  LabTest _testFor(String testText) {
    final normalized = _norm(testText);
    for (final test in tests) {
      if (_norm(test.id) == normalized || _norm(test.testName) == normalized) return test;
    }
    return LabTest(id: testText, testName: testText, defaultPrice: 0);
  }
}

class _DesktopReferralReport extends StatelessWidget {
  const _DesktopReferralReport({required this.analytics, required this.selectedYear, required this.selectedMonth, required this.yearOptions, required this.onYearChanged, required this.onMonthChanged});
  final _ReferredPersonAnalytics analytics;
  final int selectedYear;
  final int? selectedMonth;
  final List<int> yearOptions;
  final ValueChanged<int> onYearChanged;
  final ValueChanged<int?> onMonthChanged;

  @override
  Widget build(BuildContext context) {
    final rows = selectedMonth == null ? analytics.monthlyRows(selectedYear).where((row) => row.samples > 0 || row.tests > 0 || row.referFee > 0).toList() : analytics.monthlyRows(selectedYear).where((row) => row.month == selectedMonth).toList();
    final testsByName = analytics.testsByName(selectedYear, selectedMonth);
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _ReferralHero(name: analytics.user.name, subtitle: 'Referral fee, sample, and test summary for referred patients.'),
          const SizedBox(height: 14),
          _ReferralFilterBar(yearOptions: yearOptions, selectedYear: selectedYear, selectedMonth: selectedMonth, onYearChanged: onYearChanged, onMonthChanged: onMonthChanged),
          const SizedBox(height: 12),
          _ReferralReportActions(
            onYearly: () => _printReferredPersonFeeReport(analytics: analytics, year: selectedYear),
            onMonthly: () => _printReferredPersonFeeReport(analytics: analytics, year: selectedYear, month: selectedMonth ?? DateTime.now().month),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(child: _ReferralMetricCard(title: 'Refer Fee', value: _formatReferralMoney(analytics.totalReferFee(selectedYear, selectedMonth)), icon: Icons.payments_rounded, color: const Color(0xFF16A34A))),
              const SizedBox(width: 14),
              Expanded(child: _ReferralMetricCard(title: 'Samples', value: '${analytics.totalSamples(selectedYear, selectedMonth)}', icon: Icons.bloodtype_rounded, color: const Color(0xFFF59E0B))),
              const SizedBox(width: 14),
              Expanded(child: _ReferralMetricCard(title: 'Tests', value: '${analytics.totalTests(selectedYear, selectedMonth)}', icon: Icons.science_rounded, color: const Color(0xFF8B5CF6))),
              const SizedBox(width: 14),
              Expanded(child: _ReferralMetricCard(title: 'Completed', value: '${analytics.completedSamples(selectedYear, selectedMonth)}', icon: Icons.verified_rounded, color: const Color(0xFF2563EB))),
            ],
          ),
          const SizedBox(height: 18),
          LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 980;
              final monthly = _ReferralPanel(title: selectedMonth == null ? 'Monthly Referral Summary' : '${_monthName(selectedMonth!)} $selectedYear Summary', icon: Icons.insights_rounded, child: rows.isEmpty ? const _ReferralEmpty('No referral activity for this filter.') : Column(children: [for (final row in rows) _ReferralMonthTile(row: row)]));
              final status = _ReferralPanel(title: 'Status Overview', icon: Icons.fact_check_rounded, child: _ReferralStatusOverview(analytics: analytics, year: selectedYear, month: selectedMonth));
              if (compact) return Column(children: [monthly, const SizedBox(height: 14), status]);
              return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: monthly), const SizedBox(width: 14), Expanded(child: status)]);
            },
          ),
          const SizedBox(height: 18),
          LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 980;
              final tests = _ReferralPanel(title: 'Tests Referred', icon: Icons.biotech_rounded, child: testsByName.isEmpty ? const _ReferralEmpty('No referred tests for this filter.') : Wrap(spacing: 10, runSpacing: 10, children: [for (final entry in testsByName.entries) Chip(avatar: CircleAvatar(child: Text('${entry.value}')), label: Text(entry.key))]));
              final recent = _ReferralPanel(title: 'Recent Referred Samples', icon: Icons.receipt_long_rounded, child: _RecentReferralSamples(samples: analytics.recentSamples(selectedYear, selectedMonth)));
              if (compact) return Column(children: [tests, const SizedBox(height: 14), recent]);
              return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: tests), const SizedBox(width: 14), Expanded(child: recent)]);
            },
          ),
        ],
      ),
    );
  }
}

class _MobileReferralReport extends StatelessWidget {
  const _MobileReferralReport({required this.analytics, required this.selectedYear, required this.selectedMonth, required this.yearOptions, required this.onYearChanged, required this.onMonthChanged});
  final _ReferredPersonAnalytics analytics;
  final int selectedYear;
  final int? selectedMonth;
  final List<int> yearOptions;
  final ValueChanged<int> onYearChanged;
  final ValueChanged<int?> onMonthChanged;

  @override
  Widget build(BuildContext context) {
    final rows = selectedMonth == null ? analytics.monthlyRows(selectedYear).where((row) => row.samples > 0 || row.tests > 0 || row.referFee > 0).toList() : analytics.monthlyRows(selectedYear).where((row) => row.month == selectedMonth).toList();
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        _ReferralHero(name: analytics.user.name, subtitle: 'Your referral fee, samples, and tests.'),
        const SizedBox(height: 12),
        _ReferralFilterBar(yearOptions: yearOptions, selectedYear: selectedYear, selectedMonth: selectedMonth, onYearChanged: onYearChanged, onMonthChanged: onMonthChanged, compact: true),
        const SizedBox(height: 10),
        _ReferralReportActions(
          compact: true,
          onYearly: () => _printReferredPersonFeeReport(analytics: analytics, year: selectedYear),
          onMonthly: () => _printReferredPersonFeeReport(analytics: analytics, year: selectedYear, month: selectedMonth ?? DateTime.now().month),
        ),
        const SizedBox(height: 14),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 1.35,
          children: [
            _ReferralMetricCard(title: 'Refer Fee', value: _formatReferralMoney(analytics.totalReferFee(selectedYear, selectedMonth)), icon: Icons.payments_rounded, color: const Color(0xFF16A34A), compact: true),
            _ReferralMetricCard(title: 'Samples', value: '${analytics.totalSamples(selectedYear, selectedMonth)}', icon: Icons.bloodtype_rounded, color: const Color(0xFFF59E0B), compact: true),
            _ReferralMetricCard(title: 'Tests', value: '${analytics.totalTests(selectedYear, selectedMonth)}', icon: Icons.science_rounded, color: const Color(0xFF8B5CF6), compact: true),
            _ReferralMetricCard(title: 'Completed', value: '${analytics.completedSamples(selectedYear, selectedMonth)}', icon: Icons.verified_rounded, color: const Color(0xFF2563EB), compact: true),
          ],
        ),
        const SizedBox(height: 14),
        _ReferralPanel(title: selectedMonth == null ? 'Monthly Summary' : '${_monthName(selectedMonth!)} Summary', icon: Icons.insights_rounded, child: rows.isEmpty ? const _ReferralEmpty('No referral activity for this filter.') : Column(children: [for (final row in rows) _ReferralMonthTile(row: row, compact: true)])),
        const SizedBox(height: 14),
        _ReferralPanel(title: 'Recent Samples', icon: Icons.receipt_long_rounded, child: _RecentReferralSamples(samples: analytics.recentSamples(selectedYear, selectedMonth, 6), compact: true)),
      ],
    );
  }
}


class _ReferralReportActions extends StatelessWidget {
  const _ReferralReportActions({required this.onYearly, required this.onMonthly, this.compact = false});

  final VoidCallback onYearly;
  final VoidCallback onMonthly;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final yearly = FilledButton.icon(
      onPressed: onYearly,
      icon: const Icon(Icons.picture_as_pdf_rounded),
      label: const Text('Yearly Refer Fee Report'),
    );
    final monthly = FilledButton.tonalIcon(
      onPressed: onMonthly,
      icon: const Icon(Icons.print_rounded),
      label: const Text('Monthly Refer Fee Report'),
    );
    if (compact) {
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [yearly, const SizedBox(height: 8), monthly]);
    }
    return Wrap(spacing: 10, runSpacing: 10, children: [yearly, monthly]);
  }
}

Future<void> _printReferredPersonFeeReport({required _ReferredPersonAnalytics analytics, required int year, int? month}) async {
  await ReferFeeReportService.printReport(
    title: month == null ? 'Yearly Refer Fee Report' : 'Monthly Refer Fee Report',
    periodLabel: month == null ? '$year' : '${_monthName(month)} $year',
    scopeLabel: 'Referred person: ${analytics.user.name}',
    generatedBy: analytics.user.name,
    headerScopeType: 'SUBCENTER',
    headerSubCenterId: analytics.user.subCenterId ?? 'GLOBAL',
    rows: _referredPersonReportRows(analytics, year: year, month: month),
  );
}

List<ReferFeeReportRow> _referredPersonReportRows(_ReferredPersonAnalytics analytics, {required int year, int? month}) {
  return [
    for (final sample in analytics.filteredSamples(year, month))
      if (analytics._sampleReferFee(sample) > 0)
        ReferFeeReportRow(
          date: sample.createdAt,
          sampleId: sample.id,
          patientName: sample.patientName,
          subCenterId: sample.subCenterId,
          referredPerson: analytics.user.name,
          tests: sample.testIds.join(', '),
          amount: analytics._sampleReferFee(sample),
        ),
  ];
}

class _ReferralFilterBar extends StatelessWidget {
  const _ReferralFilterBar({required this.yearOptions, required this.selectedYear, required this.selectedMonth, required this.onYearChanged, required this.onMonthChanged, this.compact = false});
  final List<int> yearOptions;
  final int selectedYear;
  final int? selectedMonth;
  final ValueChanged<int> onYearChanged;
  final ValueChanged<int?> onMonthChanged;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final yearField = DropdownButtonFormField<int>(
      value: selectedYear,
      decoration: _filterDecoration('Year', Icons.calendar_today_rounded),
      items: [for (final year in yearOptions) DropdownMenuItem(value: year, child: Text('$year'))],
      onChanged: (value) {
        if (value != null) onYearChanged(value);
      },
    );
    final monthField = DropdownButtonFormField<int?>(
      value: selectedMonth,
      decoration: _filterDecoration('Month', Icons.calendar_month_rounded),
      items: [const DropdownMenuItem<int?>(value: null, child: Text('All months')), for (var month = 1; month <= 12; month++) DropdownMenuItem<int?>(value: month, child: Text(_monthName(month)))],
      onChanged: onMonthChanged,
    );
    return Container(
      padding: EdgeInsets.all(compact ? 12 : 16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE5EAF3)), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.025), blurRadius: 12, offset: const Offset(0, 6))]),
      child: compact
          ? Column(children: [yearField, const SizedBox(height: 10), monthField])
          : Row(children: [Expanded(child: yearField), const SizedBox(width: 12), Expanded(child: monthField)]),
    );
  }

  InputDecoration _filterDecoration(String label, IconData icon) {
    return InputDecoration(labelText: label, prefixIcon: Icon(icon), filled: true, fillColor: const Color(0xFFF8FAFC), border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFD9E3F0))), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFD9E3F0))));
  }
}

class _ReferralHero extends StatelessWidget {
  const _ReferralHero({required this.name, required this.subtitle});
  final String name;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.sizeOf(context).width < 760;
    return Container(
      padding: EdgeInsets.all(isMobile ? 20 : 24),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(isMobile ? 26 : 30), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF0B57B7), Color(0xFF2563EB), Color(0xFF35B7E8)]), boxShadow: [BoxShadow(color: const Color(0xFF0B57B7).withValues(alpha: 0.22), blurRadius: 28, offset: const Offset(0, 16))]),
      child: Row(children: [
        Container(width: isMobile ? 58 : 68, height: isMobile ? 58 : 68, decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(22)), child: const Icon(Icons.person_pin_circle_rounded, color: Colors.white, size: 34)),
        const SizedBox(width: 16),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Referral Analytics', style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: -0.4)), const SizedBox(height: 6), Text(name.trim().isEmpty ? subtitle : '$name • $subtitle', maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, height: 1.35))])),
      ]),
    );
  }
}

class _ReferralMetricCard extends StatelessWidget {
  const _ReferralMetricCard({required this.title, required this.value, required this.icon, required this.color, this.compact = false});
  final String title;
  final String value;
  final IconData icon;
  final Color color;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(compact ? 14 : 18),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFFE5EAF3)), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.035), blurRadius: 14, offset: const Offset(0, 7))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: color, size: compact ? 22 : 28), SizedBox(height: compact ? 8 : 12), Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: color, fontSize: compact ? 18 : 24, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF526070), fontSize: 12, fontWeight: FontWeight.w800))]),
    );
  }
}

class _ReferralPanel extends StatelessWidget {
  const _ReferralPanel({required this.title, required this.icon, required this.child});
  final String title;
  final IconData icon;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(width: double.infinity, padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), border: Border.all(color: const Color(0xFFE5EAF3)), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 14, offset: const Offset(0, 7))]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(icon, color: const Color(0xFF0B57B7)), const SizedBox(width: 10), Expanded(child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Color(0xFF0F172A))))]), const SizedBox(height: 14), child]));
  }
}

class _ReferralStatusOverview extends StatelessWidget {
  const _ReferralStatusOverview({required this.analytics, required this.year, required this.month});
  final _ReferredPersonAnalytics analytics;
  final int year;
  final int? month;

  @override
  Widget build(BuildContext context) {
    return Column(children: [_StatusLine(label: 'Pending', value: analytics.pendingSamples(year, month), color: const Color(0xFFF59E0B)), _StatusLine(label: 'Processing', value: analytics.processingSamples(year, month), color: const Color(0xFF2563EB)), _StatusLine(label: 'Completed', value: analytics.completedSamples(year, month), color: const Color(0xFF16A34A))]);
  }
}

class _StatusLine extends StatelessWidget {
  const _StatusLine({required this.label, required this.value, required this.color});
  final String label;
  final int value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Padding(padding: const EdgeInsets.only(bottom: 12), child: Row(children: [Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)), const SizedBox(width: 10), Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF334155)))), Text('$value', style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF0F172A)))]));
  }
}

class _ReferralMonthTile extends StatelessWidget {
  const _ReferralMonthTile({required this.row, this.compact = false});
  final _ReferralMonthRow row;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(margin: const EdgeInsets.only(bottom: 10), padding: EdgeInsets.all(compact ? 12 : 14), decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE2E8F0))), child: Row(children: [CircleAvatar(radius: compact ? 17 : 20, backgroundColor: const Color(0xFFEFF6FF), foregroundColor: const Color(0xFF0B57B7), child: Text(_shortMonth(row.month), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(_monthName(row.month), style: const TextStyle(fontWeight: FontWeight.w900)), Text('${row.samples} samples • ${row.tests} tests', style: const TextStyle(fontSize: 12, color: Color(0xFF64748B), fontWeight: FontWeight.w700))])), Text(_formatReferralMoney(row.referFee), style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF16A34A)))]));
  }
}

class _RecentReferralSamples extends StatelessWidget {
  const _RecentReferralSamples({required this.samples, this.compact = false});
  final List<BloodSample> samples;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    if (samples.isEmpty) return const _ReferralEmpty('No referred samples for this filter.');
    return Column(children: [for (final sample in samples) Container(margin: const EdgeInsets.only(bottom: 10), padding: EdgeInsets.all(compact ? 12 : 14), decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE2E8F0))), child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(sample.patientName.isEmpty ? 'Unknown patient' : sample.patientName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF0F172A))), const SizedBox(height: 4), Text('${sample.id} • ${sample.testIds.join(', ')}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Color(0xFF64748B), fontWeight: FontWeight.w700))])), _SmallStatusChip(status: sample.status)]))]);
  }
}

class _SmallStatusChip extends StatelessWidget {
  const _SmallStatusChip({required this.status});
  final BloodSampleStatus status;

  @override
  Widget build(BuildContext context) {
    final label = switch (status) { BloodSampleStatus.pending => 'Pending', BloodSampleStatus.processing => 'Processing', BloodSampleStatus.completed => 'Completed' };
    final color = switch (status) { BloodSampleStatus.pending => const Color(0xFFF59E0B), BloodSampleStatus.processing => const Color(0xFF2563EB), BloodSampleStatus.completed => const Color(0xFF16A34A) };
    return Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6), decoration: BoxDecoration(color: color.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(99)), child: Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w900)));
  }
}

class _ReferralEmpty extends StatelessWidget {
  const _ReferralEmpty(this.message);
  final String message;

  @override
  Widget build(BuildContext context) => Container(width: double.infinity, padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE2E8F0))), child: Text(message, style: const TextStyle(color: Color(0xFF64748B), fontWeight: FontWeight.w700)));
}

class _ReferralMonthRow {
  const _ReferralMonthRow({required this.month, required this.samples, required this.tests, required this.referFee});
  final int month;
  final int samples;
  final int tests;
  final double referFee;
}

String _formatReferralMoney(num value) => 'Ks ${_formatReferralNumber(value.round())}';
String _formatReferralNumber(num value) {
  final raw = value.abs().round().toString();
  final buffer = StringBuffer(value < 0 ? '-' : '');
  for (var i = 0; i < raw.length; i++) {
    final remaining = raw.length - i;
    buffer.write(raw[i]);
    if (remaining > 1 && remaining % 3 == 1) buffer.write(',');
  }
  return buffer.toString();
}

String _monthName(int month) {
  const names = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  final index = month < 1 ? 0 : month > 12 ? 11 : month - 1;
  return names[index];
}

String _shortMonth(int month) {
  const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  final index = month < 1 ? 0 : month > 12 ? 11 : month - 1;
  return names[index];
}
