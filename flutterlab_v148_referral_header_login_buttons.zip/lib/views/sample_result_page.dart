import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/app_user.dart';
import '../providers/auth_notifier.dart';
import '../services/turso_native_service.dart';
import '../widgets/app_sidebar.dart';

String _formatReportDateTime(String value) {
  final raw = value.trim();
  if (raw.isEmpty) return '';

  DateTime? parsed = DateTime.tryParse(raw);
  parsed ??= _parseLooseDateTime(raw);
  if (parsed == null) return raw;

  final local = parsed.toLocal();
  final year = local.year.toString().padLeft(4, '0');
  final month = local.month.toString().padLeft(2, '0');
  final day = local.day.toString().padLeft(2, '0');
  final hour = local.hour.toString().padLeft(2, '0');
  final minute = local.minute.toString().padLeft(2, '0');
  return '$year-$month-$day $hour:$minute';
}

DateTime? _parseLooseDateTime(String raw) {
  final match = RegExp(r'^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?').firstMatch(raw.trim());
  if (match == null) return null;
  final year = int.tryParse(match.group(1) ?? '');
  final month = int.tryParse(match.group(2) ?? '');
  final day = int.tryParse(match.group(3) ?? '');
  final hour = int.tryParse(match.group(4) ?? '0') ?? 0;
  final minute = int.tryParse(match.group(5) ?? '0') ?? 0;
  final second = int.tryParse(match.group(6) ?? '0') ?? 0;
  if (year == null || month == null || day == null) return null;
  return DateTime(year, month, day, hour, minute, second);
}

String _cleanResultTestName(String raw) {
  var value = raw.trim();
  if (value.isEmpty) return '';
  value = value.replaceAll(RegExp(r'\s+'), ' ');
  value = value.replaceAll(RegExp(r'\s+Result$', caseSensitive: false), '');
  return value.trim();
}

String _firstNonEmptyMapValue(Map<String, String> row, List<String> keys) {
  for (final key in keys) {
    final value = row[key]?.trim() ?? '';
    if (value.isNotEmpty) return value;
  }
  return '';
}

String _firstTestNameFromRows(List<Map<String, String>> rows) {
  for (final row in rows) {
    final value = _firstNonEmptyMapValue(row, const ['testName', 'test', 'testId', 'parameter']);
    final cleaned = _cleanResultTestName(value);
    if (cleaned.isNotEmpty && cleaned.toLowerCase() != 'result') return cleaned;
  }
  return '';
}

String _sampleTestName(Map<String, String> sampleInfo) {
  final raw = _firstNonEmptyMapValue(sampleInfo, const ['testName', 'test', 'testId', 'testIds']);
  if (raw.trim().isEmpty) return '';
  final parts = raw
      .split(RegExp(r'[,;|]'))
      .map(_cleanResultTestName)
      .where((part) => part.isNotEmpty)
      .toList();
  if (parts.isEmpty) return _cleanResultTestName(raw);
  return parts.join(', ');
}

String _resultTitleFromParts({
  required Map<String, String> sampleInfo,
  required List<Map<String, String>> manualRows,
  required List<Map<String, String>> cbcRows,
}) {
  final sampleName = _sampleTestName(sampleInfo);
  final manualName = _firstTestNameFromRows(manualRows);
  final cbcName = _firstTestNameFromRows(cbcRows);
  final name = sampleName.isNotEmpty
      ? sampleName
      : manualName.isNotEmpty
          ? manualName
          : cbcName.isNotEmpty
              ? cbcName
              : cbcRows.isNotEmpty
                  ? 'CBC / CP(Auto)'
                  : manualRows.isNotEmpty
                      ? 'Manual Test'
                      : '';
  return name.isEmpty ? 'Result' : '$name Result';
}

String _manualSectionTitle(List<Map<String, String>> rows, Map<String, String> sampleInfo) {
  final name = _firstTestNameFromRows(rows).isNotEmpty ? _firstTestNameFromRows(rows) : _sampleTestName(sampleInfo);
  return name.isEmpty ? 'Manual Test Result' : '$name Result';
}

String _cbcSectionTitle(List<Map<String, String>> rows, Map<String, String> sampleInfo) {
  final name = _firstTestNameFromRows(rows).isNotEmpty ? _firstTestNameFromRows(rows) : _sampleTestName(sampleInfo);
  return name.isEmpty ? 'CBC / CP(Auto) Result' : '$name Result';
}

String _referNameFromSampleInfo(Map<String, String> sampleInfo, {String fallback = '-'}) {
  final raw = _firstNonEmptyMapValue(sampleInfo, const ['referredPersonName', 'referName', 'referrerName', 'referredName']);
  final cleaned = raw.trim();
  if (cleaned.isEmpty || cleaned.toLowerCase() == 'self') return fallback;
  return cleaned;
}

class SampleResultPage extends ConsumerStatefulWidget {
  const SampleResultPage({super.key, required this.sampleId});

  final String sampleId;

  @override
  ConsumerState<SampleResultPage> createState() => _SampleResultPageState();
}

class _SampleResultPageState extends ConsumerState<SampleResultPage> {
  late Future<_SampleResultBundle> _future;
  String _pageTitle = 'Result';

  @override
  void initState() {
    super.initState();
    _future = _loadResults();
  }

  Future<void> _refreshResult() async {
    final future = _loadResults();
    setState(() => _future = future);
    await future;
  }

  Future<_SampleResultBundle> _loadResults() async {
    final service = TursoNativeService(
      applicationName: 'flutterlab',
    );
    try {
      final sampleInfo = await _fetchBloodSampleInfo(service);
      final user = ref.read(authNotifierProvider);
      if (!_canUserViewSample(user, sampleInfo)) {
        throw StateError('You do not have access to this blood sample.');
      }
      final reportHeader = await _fetchReportHeaderSettings(service, sampleInfo);
      final referenceRanges = await _fetchCbcReferenceRanges(service);
      final manual = await _fetchRowsBySampleId(
        service: service,
        range: 'TestResults!A:Z',
      );
      final cbc = await _fetchRowsBySampleId(
        service: service,
        range: 'CBCResults!A:BH',
      );
      final ageGroup = _ageGroupFor(sampleInfo['patientAge'] ?? '');
      final bundle = _SampleResultBundle(
        sampleInfo: sampleInfo,
        ageGroup: ageGroup,
        reportHeader: reportHeader,
        referenceRanges: referenceRanges,
        manualResults: manual,
        cbcResults: cbc,
      );
      final title = _resultTitleFromParts(sampleInfo: sampleInfo, manualRows: manual, cbcRows: cbc);
      if (mounted && _pageTitle != title) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted && _pageTitle != title) setState(() => _pageTitle = title);
        });
      }
      return bundle;
    } finally {
      await service.close();
    }
  }

  bool _canUserViewSample(AppUser? user, Map<String, String> sampleInfo) {
    if (user == null || sampleInfo.isEmpty) return false;
    if (user.role == AppUserRole.superadmin || user.role == AppUserRole.lab_tech) {
      return true;
    }

    if (user.role == AppUserRole.referred_person) {
      final userId = _normalizeAccessKey(user.id);
      final userName = _normalizeAccessKey(user.name);
      final referredId = _normalizeAccessKey(sampleInfo['referredPersonId'] ?? '');
      final referredName = _normalizeAccessKey(sampleInfo['referredPersonName'] ?? '');
      if (referredId == 'self' || referredName == 'self') return false;
      if (referredId.isNotEmpty && referredId == userId) return true;
      return userName.isNotEmpty && referredName == userName;
    }

    final userCenter = _normalizeAccessCenter(user.subCenterId ?? '');
    final sampleCenter = _normalizeAccessCenter(sampleInfo['subCenterId'] ?? '');
    return userCenter.isNotEmpty &&
        userCenter != 'global' &&
        sampleCenter.isNotEmpty &&
        sampleCenter != 'global' &&
        sampleCenter == userCenter;
  }

  String _normalizeAccessKey(String value) {
    return value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
  }

  String _normalizeAccessCenter(String value) {
    final cleaned = _normalizeAccessKey(value);
    return cleaned.replaceAllMapped(
      RegExp(r'([a-z]+)0+(\d+)$'),
      (match) => '${match.group(1)}${match.group(2)}',
    );
  }

  Future<Map<String, String>> _fetchBloodSampleInfo(TursoNativeService service) async {
    final rows = await service.fetchRows(
      range: 'BloodSamples!A:Z',
    );
    if (rows.length < 2) return const <String, String>{};

    final normalizedHeaders = rows.first
        .map((header) => header.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();

    int indexOfAny(List<String> keys) {
      for (final key in keys) {
        final index = normalizedHeaders.indexOf(key);
        if (index >= 0) return index;
      }
      return -1;
    }

    final idIndex = indexOfAny(['id', 'sampleid']);
    if (idIndex < 0) return const <String, String>{};
    final targetId = widget.sampleId.trim().toLowerCase();

    for (final row in rows.skip(1)) {
      final rowId = idIndex < row.length ? row[idIndex].trim().toLowerCase() : '';
      if (rowId != targetId) continue;

      String valueOf(List<String> keys) {
        final index = indexOfAny(keys);
        return index >= 0 && index < row.length ? row[index].trim() : '';
      }

      return <String, String>{
        'sampleId': widget.sampleId,
        'patientName': valueOf(['patientname', 'patient', 'name']),
        'patientAge': valueOf(['patientage', 'age']),
        'patientSex': valueOf(['patientsex', 'sex', 'gender']),
        'patientAddress': valueOf(['patientaddress', 'address']),
        'subCenterId': valueOf(['subcenterid', 'subcenter']),
        'referredPersonId': valueOf(['referredpersonid', 'referpersonid', 'referrerid']),
        'referredPersonName': valueOf(['referredpersonname', 'referpersonname', 'refername', 'referrername']),
        'createdAt': valueOf(['createdat', 'created']),
        'updatedAt': valueOf(['updatedat', 'updated']),
      };
    }
    return const <String, String>{};
  }

  Future<_ReportHeaderSettings> _fetchReportHeaderSettings(
    TursoNativeService service,
    Map<String, String> sampleInfo,
  ) async {
    final subCenterId = (sampleInfo['subCenterId'] ?? '').trim();
    try {
      await service.ensureSheet(sheetName: 'ReportHeaderSettings');
      final rows = await service.fetchRows(
        range: 'ReportHeaderSettings!A:K',
      );
      if (rows.length < 2) {
        return _ReportHeaderSettings.defaults(subCenterId: subCenterId);
      }
      final headers = rows.first
          .map((header) => header.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
          .toList();
      Map<String, String>? global;
      Map<String, String>? subCenter;
      for (final row in rows.skip(1)) {
        final map = <String, String>{};
        for (var i = 0; i < headers.length; i++) {
          map[headers[i]] = i < row.length ? row[i].trim() : '';
        }
        final scope = _normalizeKey(map['scopetype'] ?? '');
        final center = _normalizeKey(map['subcenterid'] ?? '');
        if (scope == 'global' || center == 'global') {
          global ??= map;
        }
        if (subCenterId.isNotEmpty && center == _normalizeKey(subCenterId)) {
          subCenter = map;
        }
      }
      final defaults = _ReportHeaderSettings.defaults(subCenterId: subCenterId);
      final globalSettings = global == null ? defaults : _ReportHeaderSettings.fromMap(global, fallback: defaults);
      return subCenter == null ? globalSettings : _ReportHeaderSettings.fromMap(subCenter, fallback: globalSettings);
    } catch (_) {
      return _ReportHeaderSettings.defaults(subCenterId: subCenterId);
    }
  }

  String _normalizeKey(String raw) => raw.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  String _ageGroupFor(String rawAge) {
    final normalized = rawAge.trim().toLowerCase();
    final numberMatch = RegExp(r'(\d+(?:\.\d+)?)').firstMatch(normalized);
    final value = double.tryParse(numberMatch?.group(1) ?? '');
    if (value == null) return 'adult';
    final isDayValue = normalized.contains('day') || normalized.endsWith('d');
    final isMonthValue = normalized.contains('month') || normalized.endsWith('m');
    final isYearValue = normalized.contains('year') || normalized.endsWith('y');
    if (isDayValue && value < 28) return 'neonate';
    if (isMonthValue) return 'child';
    if (isYearValue) return value < 18 ? 'child' : 'adult';
    return value < 18 ? 'child' : 'adult';
  }

  Future<Map<String, Map<String, _CbcReferenceRange>>> _fetchCbcReferenceRanges(
    TursoNativeService service,
  ) async {
    final rows = await service.fetchRows(
      range: 'CbcReferenceRanges!A:D',
    );
    if (rows.length < 2) return const <String, Map<String, _CbcReferenceRange>>{};
    final headers = rows.first
        .map((header) => header.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();
    final ageIndex = headers.indexOf('agegroup');
    final parameterIndex = headers.indexOf('parameter');
    final refIndex = headers.indexOf('refrange');
    final unitIndex = headers.indexOf('unit');
    if (ageIndex < 0 || parameterIndex < 0 || refIndex < 0) {
      return const <String, Map<String, _CbcReferenceRange>>{};
    }

    final result = <String, Map<String, _CbcReferenceRange>>{};
    for (final row in rows.skip(1)) {
      final ageGroup = ageIndex < row.length ? row[ageIndex].trim().toLowerCase() : '';
      final parameter = parameterIndex < row.length ? row[parameterIndex].trim() : '';
      final refRange = refIndex < row.length ? row[refIndex].trim() : '';
      final unit = unitIndex >= 0 && unitIndex < row.length ? row[unitIndex].trim() : '';
      if (ageGroup.isEmpty || parameter.isEmpty) continue;
      result.putIfAbsent(ageGroup, () => <String, _CbcReferenceRange>{});
      result[ageGroup]![parameter] = _CbcReferenceRange(refRange: refRange, unit: unit);
    }
    return result;
  }

  Future<List<Map<String, String>>> _fetchRowsBySampleId({
    required TursoNativeService service,
    required String range,
  }) async {
    final rows = await service.fetchRows(
      range: range,
    );
    if (rows.length < 2) return const <Map<String, String>>[];

    final headers = rows.first
        .map((header) => header.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();
    final sampleIdIndex = headers.indexOf('sampleid');
    if (sampleIdIndex < 0) return const <Map<String, String>>[];

    final displayHeaders = rows.first.map((header) => header.trim()).toList();
    final normalizedTarget = widget.sampleId.trim().toLowerCase();
    final matches = <Map<String, String>>[];
    for (final row in rows.skip(1)) {
      final sampleId = sampleIdIndex < row.length ? row[sampleIdIndex].trim().toLowerCase() : '';
      if (sampleId != normalizedTarget) continue;
      final map = <String, String>{};
      for (var i = 0; i < displayHeaders.length; i++) {
        final key = displayHeaders[i].isEmpty ? 'column$i' : displayHeaders[i];
        map[key] = i < row.length ? row[i].trim() : '';
      }
      matches.add(map);
    }
    return matches;
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.tryParse(url.trim());
    if (uri == null) return;
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _printCurrentResult() async {
    try {
      final bundle = await _future;
      final hasResults = bundle.manualResults.isNotEmpty || bundle.cbcResults.isNotEmpty;
      if (!hasResults) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No generated result is available to print.')),
        );
        return;
      }
      await Printing.layoutPdf(
        name: 'sample_result_${widget.sampleId}.pdf',
        onLayout: (format) => _buildResultPdf(bundle, format),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Print failed: $error')),
      );
    }
  }

  Future<Uint8List> _buildResultPdf(_SampleResultBundle bundle, PdfPageFormat format) async {
    final regularFont = pw.Font.ttf(await rootBundle.load('assets/fonts/DejaVuSans.ttf'));
    final boldFont = pw.Font.ttf(await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf'));
    final pdfTheme = pw.ThemeData.withFont(base: regularFont, bold: boldFont);
    final logoImage = pw.MemoryImage((await rootBundle.load('assets/images/moh.png')).buffer.asUint8List());
    final pdf = pw.Document();
    final sampleInfo = bundle.sampleInfo;
    final cbcRowsForPrint = bundle.cbcResults.isEmpty
        ? const <Map<String, String>>[]
        : <Map<String, String>>[bundle.cbcResults.last];

    pdf.addPage(
      pw.MultiPage(
        theme: pdfTheme,
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.fromLTRB(28, 34, 28, 28),
        footer: (context) => _resultPdfFooter(bundle.reportHeader),
        build: (context) => [
          if (cbcRowsForPrint.isNotEmpty)
            _cbcAnalyzerPdfReport(cbcRowsForPrint.first, bundle, sampleInfo, logoImage)
          else if (bundle.manualResults.isNotEmpty)
            _manualAnalyzerPdfReport(bundle.manualResults, bundle, sampleInfo, logoImage),
        ],
      ),
    );
    return pdf.save();
  }

  pw.Widget _resultPdfFooter(_ReportHeaderSettings settings) {
    final footer = settings.footerText.trim();
    final center = settings.subCenterId.trim().toLowerCase();
    if (footer.isEmpty || center.isEmpty || center == 'global') return pw.SizedBox.shrink();
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.only(top: 6),
      decoration: const pw.BoxDecoration(border: pw.Border(top: pw.BorderSide(color: PdfColors.grey400, width: 0.4))),
      child: pw.Text(
        footer,
        textAlign: pw.TextAlign.center,
        style: const pw.TextStyle(fontSize: 7.5, color: PdfColors.grey700),
      ),
    );
  }

  pw.Widget _cbcAnalyzerPdfReport(
    Map<String, String> row,
    _SampleResultBundle bundle,
    Map<String, String> sampleInfo,
    pw.MemoryImage logoImage,
  ) {
    String value(String key) => row[key]?.trim() ?? '';
    String sampleValue(String key) => sampleInfo[key]?.trim() ?? '';
    final parameters = _cbcParameterRows(row, bundle.referenceRanges[bundle.ageGroup] ?? const <String, _CbcReferenceRange>{});
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.stretch,
      children: [
        _analyzerHeader(
          reportHeader: bundle.reportHeader,
          logoImage: logoImage,
          name: sampleValue('patientName'),
          gender: sampleValue('patientSex'),
          age: sampleValue('patientAge'),
          referName: _referNameFromSampleInfo(sampleInfo),
          sampleId: value('sampleId').isEmpty ? widget.sampleId : value('sampleId'),
          runTime: _formatReportDateTime(value('runTime').isEmpty ? value('createdAt') : value('runTime')),
        ),
        pw.SizedBox(height: 4),
        pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Expanded(flex: 64, child: _analyzerParameterTable(parameters)),
            pw.SizedBox(width: 12),
            pw.Expanded(
              flex: 36,
              child: _analyzerGraphPanel(row),
            ),
          ],
        ),
        pw.SizedBox(height: 6),
        _analyzerMessageRow(
          wbc: value('WBCFlag'),
          rbc: value('RBCFlag'),
          plt: value('PLTFlag'),
        ),
      ],
    );
  }

  pw.Widget _manualAnalyzerPdfReport(
    List<Map<String, String>> rows,
    _SampleResultBundle bundle,
    Map<String, String> sampleInfo,
    pw.MemoryImage logoImage,
  ) {
    String rowValue(Map<String, String> row, String key) => row[key]?.trim() ?? '';
    final firstRow = rows.isEmpty ? const <String, String>{} : rows.first;
    String value(String key) => rowValue(firstRow, key);
    String sampleValue(String key) => sampleInfo[key]?.trim() ?? '';
    final parameters = <_CbcParameterDisplayRow>[
      for (final row in rows)
        _CbcParameterDisplayRow(
          parameter: rowValue(row, 'parameter').isEmpty
              ? (rowValue(row, 'testName').isEmpty ? 'Result' : rowValue(row, 'testName'))
              : rowValue(row, 'parameter'),
          result: rowValue(row, 'resultValue'),
          referenceRange: rowValue(row, 'referenceRange'),
          unit: rowValue(row, 'unit'),
        ),
    ];
    final notes = rows
        .map((row) => rowValue(row, 'notes'))
        .where((note) => note.isNotEmpty)
        .toSet()
        .join('\n');
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.stretch,
      children: [
        _analyzerHeader(
          reportHeader: bundle.reportHeader,
          logoImage: logoImage,
          name: sampleValue('patientName').isEmpty ? value('patientName') : sampleValue('patientName'),
          gender: sampleValue('patientSex'),
          age: sampleValue('patientAge'),
          referName: _referNameFromSampleInfo(sampleInfo),
          sampleId: value('sampleId').isEmpty ? widget.sampleId : value('sampleId'),
          runTime: _formatReportDateTime(value('createdAt')),
        ),
        pw.SizedBox(height: 6),
        _analyzerParameterTable(parameters),
        if (notes.isNotEmpty) ...[
          pw.SizedBox(height: 10),
          _manualNoteBox(notes),
        ],
      ],
    );
  }

  pw.Widget _manualNoteBox(String notes) {
    final cleanNotes = notes.trim();
    if (cleanNotes.isEmpty) {
      return pw.SizedBox.shrink();
    }
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(8),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey600, width: 0.7),
        color: PdfColors.grey100,
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'Remarks',
            style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold),
          ),
          pw.SizedBox(height: 4),
          pw.Text(cleanNotes, style: const pw.TextStyle(fontSize: 8)),
        ],
      ),
    );
  }

  pw.Widget _analyzerHeader({
    required _ReportHeaderSettings reportHeader,
    required pw.MemoryImage logoImage,
    required String name,
    required String gender,
    required String age,
    required String referName,
    required String sampleId,
    required String runTime,
  }) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.stretch,
      children: [
        _modernBlueAccentLetterhead(reportHeader, logoImage),
        pw.SizedBox(height: 7),
        pw.Container(
          padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 7),
          decoration: pw.BoxDecoration(
            border: pw.Border.all(color: PdfColors.grey600, width: 0.6),
            color: PdfColors.grey100,
          ),
          child: pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    _headerLine('Name', name),
                    _headerLine('Gender', gender),
                  ],
                ),
              ),
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    _headerLine('Age', age),
                    _headerLine('Refer', referName),
                  ],
                ),
              ),
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    _headerLine('Sample ID', sampleId),
                    _headerLine('Run Time', runTime),
                  ],
                ),
              ),
            ],
          ),
        ),
        pw.SizedBox(height: 6),
        pw.Container(height: 0.7, color: PdfColors.grey700),
      ],
    );
  }

  pw.Widget _modernBlueAccentLetterhead(_ReportHeaderSettings settings, pw.MemoryImage logoImage) {
    final accent = _pdfColorFromHex(settings.accentColor);
    return pw.Container(
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        color: PdfColor(0.937, 0.965, 1.0),
        borderRadius: pw.BorderRadius.circular(8),
        border: pw.Border.all(color: PdfColor(0.576, 0.773, 0.992), width: 0.6),
      ),
      child: pw.Row(
        children: [
          pw.Container(
            width: 48,
            height: 48,
            padding: const pw.EdgeInsets.all(1.5),
            decoration: pw.BoxDecoration(
              shape: pw.BoxShape.circle,
              color: PdfColors.white,
              border: pw.Border.all(color: accent, width: 1.2),
            ),
            child: pw.Center(child: pw.Image(logoImage, fit: pw.BoxFit.contain)),
          ),
          pw.SizedBox(width: 10),
          pw.Container(width: 0.8, height: 48, color: PdfColor(0.576, 0.773, 0.992)),
          pw.SizedBox(width: 10),
          pw.Expanded(
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  settings.hospitalName.toUpperCase(),
                  style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold, color: PdfColors.grey900),
                ),
                pw.SizedBox(height: 2),
                pw.Text(settings.departmentName, style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold, color: accent)),
                pw.Text(settings.township, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
                pw.Text(settings.ministryName, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
              ],
            ),
          ),
          pw.SizedBox(width: 8),
          pw.Container(
            padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: pw.BoxDecoration(color: accent, borderRadius: pw.BorderRadius.circular(12)),
            child: pw.Text(settings.reportTitle, style: pw.TextStyle(fontSize: 7.5, fontWeight: pw.FontWeight.bold, color: PdfColors.white)),
          ),
        ],
      ),
    );
  }

  PdfColor _pdfColorFromHex(String raw) {
    final cleaned = raw.trim().replaceAll('#', '');
    if (!RegExp(r'^[0-9a-fA-F]{6}$').hasMatch(cleaned)) return PdfColor(0.114, 0.306, 0.847);
    final value = int.parse(cleaned, radix: 16);
    final r = ((value >> 16) & 0xFF) / 255.0;
    final g = ((value >> 8) & 0xFF) / 255.0;
    final b = (value & 0xFF) / 255.0;
    return PdfColor(r, g, b);
  }

  pw.Widget _headerLine(String label, String value) {
    return pw.Padding(
      padding: const pw.EdgeInsets.only(bottom: 2),
      child: pw.RichText(
        text: pw.TextSpan(
          children: [
            pw.TextSpan(text: '$label: ', style: pw.TextStyle(fontSize: 8.5, fontWeight: pw.FontWeight.bold)),
            pw.TextSpan(text: value.trim().isEmpty ? '' : value.trim(), style: const pw.TextStyle(fontSize: 8.5)),
          ],
        ),
      ),
    );
  }

  pw.Widget _analyzerParameterTable(List<_CbcParameterDisplayRow> rows) {
    final qualitativeOnly = rows.isNotEmpty && rows.every(_isQualitativeDisplayRow);
    return pw.Table(
      border: const pw.TableBorder(
        top: pw.BorderSide(color: PdfColors.grey700, width: 0.5),
        bottom: pw.BorderSide(color: PdfColors.grey700, width: 0.5),
        horizontalInside: pw.BorderSide(color: PdfColors.grey300, width: 0.25),
      ),
      columnWidths: qualitativeOnly
          ? const <int, pw.TableColumnWidth>{
              0: pw.FixedColumnWidth(24),
              1: pw.FlexColumnWidth(1.6),
              2: pw.FlexColumnWidth(1.0),
            }
          : const <int, pw.TableColumnWidth>{
              0: pw.FixedColumnWidth(20),
              1: pw.FlexColumnWidth(1.35),
              2: pw.FlexColumnWidth(0.9),
              3: pw.FlexColumnWidth(1.05),
              4: pw.FlexColumnWidth(0.75),
            },
      children: [
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: PdfColors.grey200),
          children: qualitativeOnly
              ? [_tableCell('', bold: true), _tableCell('Test', bold: true), _tableCell('Result', bold: true)]
              : [_tableCell('', bold: true), _tableCell('Parameter', bold: true), _tableCell('Result', bold: true), _tableCell('Ref. Range', bold: true), _tableCell('Unit', bold: true)],
        ),
        for (var i = 0; i < rows.length; i++)
          pw.TableRow(
            children: qualitativeOnly
                ? [
                    _tableCell('${i + 1}', align: pw.TextAlign.right),
                    _tableCell(rows[i].parameter, bold: true),
                    _tableCell(rows[i].result.trim().isEmpty ? '-' : rows[i].result.trim(), bold: true),
                  ]
                : [
                    _tableCell('${i + 1}', align: pw.TextAlign.right),
                    _tableCell(rows[i].parameter, bold: true),
                    _tableCell(_resultWithFlag(rows[i].result, rows[i].referenceRange), bold: true, color: _pdfColorForRangeStatus(_rangeStatus(rows[i].result, rows[i].referenceRange))),
                    _tableCell(_isBlankResultMeta(rows[i].referenceRange) ? '-' : rows[i].referenceRange),
                    _tableCell(_isBlankResultMeta(rows[i].unit) ? '-' : rows[i].unit),
                  ],
          ),
      ],
    );
  }

  String _resultWithFlag(String result, String referenceRange) {
    final raw = result.trim();
    if (raw.isEmpty) return '-';
    final status = _rangeStatus(raw, referenceRange);
    if (status == _ResultRangeStatus.low) return '$raw ↓';
    if (status == _ResultRangeStatus.high) return '$raw ↑';
    return raw;
  }

  PdfColor? _pdfColorForRangeStatus(_ResultRangeStatus status) {
    if (status == _ResultRangeStatus.high) return PdfColor(0.863, 0.149, 0.149);
    if (status == _ResultRangeStatus.low) return PdfColor(0.376, 0.647, 0.980);
    return null;
  }

  pw.Widget _tableCell(String value, {bool bold = false, pw.TextAlign align = pw.TextAlign.left, PdfColor? color}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(horizontal: 3, vertical: 2.3),
      child: pw.Text(
        value,
        textAlign: align,
        style: pw.TextStyle(
          fontSize: 7.2,
          fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal,
          color: color,
        ),
      ),
    );
  }

  pw.Widget _analyzerGraphPanel(Map<String, String> row) {
    String value(String key) => row[key]?.trim() ?? '';
    return pw.Row(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Expanded(
          child: pw.Column(
            children: [
              _graphImageBox('WBC', value('wbcGraphBase64'), fallback: _miniHistogram('WBC')),
              pw.SizedBox(height: 8),
              _graphImageBox('RBC', value('rbcGraphBase64'), fallback: _miniHistogram('RBC')),
              pw.SizedBox(height: 8),
              _graphImageBox('PLT', value('pltGraphBase64'), fallback: _miniHistogram('PLT')),
            ],
          ),
        ),
        pw.SizedBox(width: 8),
        pw.Expanded(
          child: pw.Column(
            children: [
              _graphImageBox('DIFF HS/MS', value('diffHsmsBase64'), fallback: _miniScatter('HS', 'DIFF', 'MS')),
              pw.SizedBox(height: 8),
              _graphImageBox('DIFF LS/HS', value('diffLshsBase64'), fallback: _miniScatter('LS', 'DIFF', 'HS')),
              pw.SizedBox(height: 8),
              _graphImageBox('DIFF LS/MS', value('diffLsmsBase64'), fallback: _miniScatter('LS', 'DIFF', 'MS')),
              pw.SizedBox(height: 8),
              _miniScatter('LS', 'BASO', 'MS'),
            ],
          ),
        ),
      ],
    );
  }

  pw.Widget _graphImageBox(String label, String base64Value, {required pw.Widget fallback}) {
    final image = _memoryImageFromBase64(base64Value);
    if (image == null) return fallback;
    return pw.Container(
      height: 58,
      decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey600, width: 0.5)),
      padding: const pw.EdgeInsets.all(2),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.stretch,
        children: [
          pw.Text(label, style: const pw.TextStyle(fontSize: 5.8)),
          pw.Expanded(child: pw.Center(child: pw.Image(image, fit: pw.BoxFit.contain))),
        ],
      ),
    );
  }

  pw.MemoryImage? _memoryImageFromBase64(String base64Value) {
    final raw = base64Value.trim();
    if (raw.isEmpty) return null;
    try {
      return pw.MemoryImage(base64Decode(raw));
    } catch (_) {
      return null;
    }
  }

  pw.Widget _miniHistogram(String label) {
    return pw.Row(
      children: [
        pw.SizedBox(width: 26, child: pw.Text(label, style: const pw.TextStyle(fontSize: 7))),
        pw.Expanded(
          child: pw.Container(
            height: 44,
            decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey600, width: 0.5)),
            child: pw.Padding(
              padding: const pw.EdgeInsets.all(4),
              child: pw.Column(
                mainAxisAlignment: pw.MainAxisAlignment.end,
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Container(width: 8, height: 30, decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey700, width: 0.5))),
                  pw.Container(height: 0.5, color: PdfColors.grey700),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  pw.Widget _miniScatter(String yLabel, String title, String xLabel) {
    return pw.Container(
      height: 58,
      decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey600, width: 0.5)),
      child: pw.Stack(
        children: [
          pw.Positioned(left: 3, top: 3, child: pw.Text(yLabel, style: const pw.TextStyle(fontSize: 6))),
          pw.Positioned(right: 3, top: 3, child: pw.Text(title, style: const pw.TextStyle(fontSize: 6))),
          pw.Positioned(right: 3, bottom: 3, child: pw.Text(xLabel, style: const pw.TextStyle(fontSize: 6))),
          pw.Center(child: pw.Text('scattergram', style: pw.TextStyle(fontSize: 6, color: PdfColors.grey600))),
        ],
      ),
    );
  }

  pw.Widget _manualPrintPanel({required String testName, required String notes}) {
    return pw.Container(
      height: 130,
      padding: const pw.EdgeInsets.all(8),
      decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey600, width: 0.5)),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text('Manual Result', style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 10),
          pw.Text(testName, style: const pw.TextStyle(fontSize: 9)),
          pw.SizedBox(height: 8),
          pw.Text(notes.trim().isEmpty ? 'No additional notes' : notes, style: const pw.TextStyle(fontSize: 8)),
        ],
      ),
    );
  }

  pw.Widget _analyzerMessageRow({required String wbc, required String rbc, required String plt}) {
    return pw.Row(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Expanded(child: _messageBox('WBC Message', wbc)),
        pw.SizedBox(width: 6),
        pw.Expanded(child: _messageBox('RBC Message', rbc)),
        pw.SizedBox(width: 6),
        pw.Expanded(child: _messageBox('PLT Message', plt)),
      ],
    );
  }

  pw.Widget _messageBox(String title, String value) {
    return pw.Container(
      height: 64,
      decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey600, width: 0.5)),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.stretch,
        children: [
          pw.Container(
            padding: const pw.EdgeInsets.symmetric(vertical: 2),
            decoration: const pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide(color: PdfColors.grey600, width: 0.5))),
            child: pw.Text(title, textAlign: pw.TextAlign.center, style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold)),
          ),
          pw.Padding(
            padding: const pw.EdgeInsets.all(4),
            child: pw.Text(value.trim().isEmpty ? '-' : value.trim(), style: const pw.TextStyle(fontSize: 7.3)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    final theme = Theme.of(context);
    return AppScaffold(
      title: _pageTitle,
      selectedRoute: '/search',
      user: user,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Print result',
          onPressed: _printCurrentResult,
          icon: const Icon(Icons.print_rounded),
        ),
        const SizedBox(width: 8),
        IconButton.filledTonal(
          tooltip: 'Refresh result',
          onPressed: _refreshResult,
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: Padding(
        padding: EdgeInsets.fromLTRB(
          MediaQuery.sizeOf(context).width < 760 ? 0 : 24,
          MediaQuery.sizeOf(context).width < 760 ? 0 : 8,
          MediaQuery.sizeOf(context).width < 760 ? 0 : 24,
          MediaQuery.sizeOf(context).width < 760 ? 0 : 24,
        ),
        child: FutureBuilder<_SampleResultBundle>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return Center(child: Text('Result load failed: ${snapshot.error}'));
            }
            final bundle = snapshot.data ?? const _SampleResultBundle();
            final hasResults = bundle.manualResults.isNotEmpty || bundle.cbcResults.isNotEmpty;
            final isMobile = MediaQuery.sizeOf(context).width < 760;
            if (isMobile && bundle.cbcResults.isNotEmpty) {
              return RefreshIndicator(
                onRefresh: _refreshResult,
                child: _MobileCbcCpResultView(
                  bundle: bundle,
                  sampleId: widget.sampleId,
                  onPrint: _printCurrentResult,
                  onOpenUrl: _openUrl,
                ),
              );
            }
            return SingleChildScrollView(
              physics: isMobile ? const AlwaysScrollableScrollPhysics() : null,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      gradient: LinearGradient(colors: [theme.colorScheme.primary, theme.colorScheme.tertiary]),
                      boxShadow: [
                        BoxShadow(color: theme.colorScheme.primary.withValues(alpha: 0.22), blurRadius: 26, offset: const Offset(0, 15)),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(24)),
                          child: const Icon(Icons.assignment_turned_in_rounded, color: Colors.white, size: 36),
                        ),
                        const SizedBox(width: 18),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(_resultTitleFromParts(sampleInfo: bundle.sampleInfo, manualRows: bundle.manualResults, cbcRows: bundle.cbcResults), style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w900)),
                              const SizedBox(height: 6),
                              Text('Sample ID: ${widget.sampleId}', style: theme.textTheme.bodyLarge?.copyWith(color: Colors.white.withValues(alpha: 0.9))),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  if (!hasResults)
                    Card(
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                      child: const Padding(
                        padding: EdgeInsets.all(24),
                        child: Text('No generated result was found for this completed sample.'),
                      ),
                    ),
                  if (bundle.manualResults.isNotEmpty)
                    _ResultSection(
                      title: _manualSectionTitle(bundle.manualResults, bundle.sampleInfo),
                      rows: bundle.manualResults,
                      sampleInfo: bundle.sampleInfo,
                      ageGroup: bundle.ageGroup,
                      referenceRanges: bundle.referenceRanges,
                      onOpenUrl: _openUrl,
                    ),
                  if (bundle.cbcResults.isNotEmpty)
                    _ResultSection(
                      title: _cbcSectionTitle(bundle.cbcResults, bundle.sampleInfo),
                      rows: bundle.cbcResults,
                      sampleInfo: bundle.sampleInfo,
                      ageGroup: bundle.ageGroup,
                      referenceRanges: bundle.referenceRanges,
                      onOpenUrl: _openUrl,
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}


class _MobileCbcCpResultView extends StatefulWidget {
  const _MobileCbcCpResultView({required this.bundle, required this.sampleId, required this.onPrint, required this.onOpenUrl});

  final _SampleResultBundle bundle;
  final String sampleId;
  final VoidCallback onPrint;
  final ValueChanged<String> onOpenUrl;

  @override
  State<_MobileCbcCpResultView> createState() => _MobileCbcCpResultViewState();
}

class _MobileCbcCpResultViewState extends State<_MobileCbcCpResultView> {
  int _tabIndex = 0;

  Map<String, String> get _row => widget.bundle.cbcResults.isEmpty ? const <String, String>{} : widget.bundle.cbcResults.last;
  Map<String, String> get _sample => widget.bundle.sampleInfo;

  String _value(String key) => _row[key]?.trim() ?? '';
  String _sampleValue(String key) => _sample[key]?.trim() ?? '';
  String _display(String value, {String fallback = '-'}) => value.trim().isEmpty ? fallback : value.trim();
  String _nameValue() {
    final fromSample = _sampleValue('patientName');
    if (fromSample.isNotEmpty) return fromSample;
    final first = _value('firstName');
    final last = _value('lastName');
    return [first, last].where((part) => part.trim().isNotEmpty).join(' ');
  }

  String _ageSex() {
    final age = _sampleValue('patientAge').isNotEmpty ? _sampleValue('patientAge') : _value('age');
    final sex = _sampleValue('patientSex').isNotEmpty ? _sampleValue('patientSex') : _value('gender');
    if (age.isEmpty && sex.isEmpty) return '-';
    return [age, sex].where((part) => part.trim().isNotEmpty).join(' / ');
  }

  List<_CbcParameterDisplayRow> get _parameters {
    return _cbcParameterRows(_row, widget.bundle.referenceRanges[widget.bundle.ageGroup] ?? const <String, _CbcReferenceRange>{});
  }

  List<_CbcParameterDisplayRow> get _wbcDiffRows {
    const names = {'Neu%', 'Lym%', 'Mon%', 'Eos%', 'Bas%', 'Neu#', 'Lym#', 'Mon#', 'Eos#', 'Bas#'};
    return _parameters.where((row) => names.contains(row.parameter)).toList();
  }

  List<_CbcParameterDisplayRow> get _hematologyRows {
    final diff = _wbcDiffRows.map((row) => row.parameter).toSet();
    return _parameters.where((row) => !diff.contains(row.parameter)).toList();
  }

  List<_CbcParameterDisplayRow> get _hematologyOverviewRows {
    const wantedOrder = ['WBC', 'HGB', 'HCT', 'PLT'];
    final rows = <_CbcParameterDisplayRow>[];
    for (final parameter in wantedOrder) {
      final matches = _parameters.where((row) => row.parameter.toUpperCase() == parameter);
      if (matches.isEmpty) continue;
      final row = matches.first;
      rows.add(
        _CbcParameterDisplayRow(
          parameter: parameter == 'HGB' ? 'Hb' : row.parameter,
          result: row.result,
          referenceRange: row.referenceRange,
          unit: row.unit,
        ),
      );
    }
    return rows;
  }

  int _countStatus(_ResultRangeStatus status) => _parameters.where((row) => _rangeStatus(row.result, row.referenceRange) == status).length;

  @override
  Widget build(BuildContext context) {
    final tabs = ['Overview', 'Hematology', 'WBC Diff', 'Histograms', 'Scatters', 'Details'];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _MobileResultTabs(tabs: tabs, selectedIndex: _tabIndex, onSelected: (index) => setState(() => _tabIndex = index)),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 118),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 180),
              child: _buildTab(context, key: ValueKey<int>(_tabIndex)),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTab(BuildContext context, {required Key key}) {
    return KeyedSubtree(
      key: key,
      child: switch (_tabIndex) {
        0 => _overview(context),
        1 => _parameterPage('Hematology', _hematologyRows),
        2 => _parameterPage('WBC Differential', _wbcDiffRows),
        3 => _histograms(),
        4 => _scatters(),
        _ => _details(context),
      },
    );
  }

  Widget _overview(BuildContext context) {
    final high = _countStatus(_ResultRangeStatus.high);
    final low = _countStatus(_ResultRangeStatus.low);
    final normal = _countStatus(_ResultRangeStatus.normal);
    final summaryRows = _hematologyOverviewRows;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _MobileSampleHeaderCard(
          sampleId: _display(_value('sampleId'), fallback: widget.sampleId),
          testName: _display(_value('testName').isEmpty ? _sampleTestName(widget.bundle.sampleInfo) : _value('testName'), fallback: 'CBC / CP (Auto)'),
          dateLabel: _display(_formatReportDateTime(_value('runTime').isEmpty ? _value('createdAt') : _value('runTime'))),
          status: 'Completed',
        ),
        const SizedBox(height: 12),
        _MobileInfoCard(
          title: 'Patient Information',
          rows: [
            _MobileInfoRow(Icons.person_outline_rounded, 'Name', _display(_nameValue())),
            _MobileInfoRow(Icons.cake_outlined, 'Age / Gender', _ageSex()),
            _MobileInfoRow(Icons.phone_outlined, 'Phone', _display(_sampleValue('phone'))),
            _MobileInfoRow(Icons.local_hospital_outlined, 'Sub-center', _display(_sampleValue('subCenterId'))),
            _MobileInfoRow(Icons.badge_outlined, 'Registered By', _display(_sampleValue('registeredByUserId'))),
            _MobileInfoRow(Icons.group_outlined, 'Refer', _display(_sampleValue('referredPersonName'), fallback: 'Self')),
          ],
        ),
        const SizedBox(height: 12),
        _MobileSummaryStatsCard(total: _parameters.length, high: high, low: low, normal: normal),
        const SizedBox(height: 12),
        _MobileResultTableCard(title: 'Hematology Overview', rows: summaryRows),
        const SizedBox(height: 12),
        const _MobileAnalyzerNote(),
      ],
    );
  }

  Widget _parameterPage(String title, List<_CbcParameterDisplayRow> rows) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _MobileResultTableCard(title: title, rows: rows),
        const SizedBox(height: 12),
        const _MobileLegend(),
        const SizedBox(height: 12),
        const _MobileAnalyzerNote(),
      ],
    );
  }

  Widget _histograms() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _MobileGraphCard(title: 'WBC Histogram', base64Key: 'wbcGraphBase64', row: _row, fullWidth: true),
        const SizedBox(height: 12),
        _MobileGraphCard(title: 'RBC Histogram', base64Key: 'rbcGraphBase64', row: _row, fullWidth: true),
        const SizedBox(height: 12),
        _MobileGraphCard(title: 'PLT Histogram', base64Key: 'pltGraphBase64', row: _row, fullWidth: true),
      ],
    );
  }

  Widget _scatters() {
    final cards = [
      _MobileGraphCard(title: 'DIFF (LSMS)', base64Key: 'diffLsmsBase64', row: _row),
      _MobileGraphCard(title: 'DIFF (LSHS)', base64Key: 'diffLshsBase64', row: _row),
      _MobileGraphCard(title: 'DIFF (HSMS)', base64Key: 'diffHsmsBase64', row: _row),
      _MobileGraphCard(title: 'BASO', base64Key: _value('basoGraphBase64').isNotEmpty ? 'basoGraphBase64' : 'diffBasoBase64', row: _row),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: cards.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.92),
          itemBuilder: (context, index) => cards[index],
        ),
        const SizedBox(height: 12),
        const _MobileScatterLegend(),
      ],
    );
  }

  Widget _details(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _MobileInfoCard(
          title: 'Sample Information',
          rows: [
            _MobileInfoRow(Icons.confirmation_number_outlined, 'Sample ID', _display(_value('sampleId'), fallback: widget.sampleId)),
            _MobileInfoRow(Icons.science_outlined, 'Test', _display(_value('testName').isEmpty ? _sampleTestName(widget.bundle.sampleInfo) : _value('testName'), fallback: 'CBC / CP (Auto)')),
            _MobileInfoRow(Icons.verified_outlined, 'Status', 'Completed'),
            _MobileInfoRow(Icons.event_outlined, 'Registered At', _display(_formatReportDateTime(_sampleValue('createdAt')))),
            _MobileInfoRow(Icons.done_all_outlined, 'Completed At', _display(_formatReportDateTime(_value('updatedAt').isEmpty ? _value('createdAt') : _value('updatedAt')))),
            _MobileInfoRow(Icons.local_hospital_outlined, 'Sub-center', _display(_sampleValue('subCenterId'))),
            _MobileInfoRow(Icons.badge_outlined, 'Registered By', _display(_sampleValue('registeredByUserId'))),
            _MobileInfoRow(Icons.group_outlined, 'Refer', _display(_sampleValue('referredPersonName'), fallback: 'Self')),
          ],
        ),
        const SizedBox(height: 12),
        _MobileActionsCard(
          onPrint: widget.onPrint,
          onRawData: () => _showRawData(context),
        ),
      ],
    );
  }

  void _showRawData(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        final entries = _row.entries.where((entry) => entry.value.trim().isNotEmpty).toList();
        return SafeArea(
          child: Container(
            height: MediaQuery.sizeOf(context).height * 0.78,
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [const Expanded(child: Text('Raw Data', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))), IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded))]),
                const SizedBox(height: 8),
                Expanded(
                  child: ListView.separated(
                    itemCount: entries.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, index) => ListTile(dense: true, title: Text(entries[index].key), subtitle: Text(entries[index].value)),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _MobileResultTabs extends StatelessWidget {
  const _MobileResultTabs({required this.tabs, required this.selectedIndex, required this.onSelected});
  final List<String> tabs;
  final int selectedIndex;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            for (var i = 0; i < tabs.length; i++)
              InkWell(
                onTap: () => onSelected(i),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                  decoration: BoxDecoration(border: Border(bottom: BorderSide(color: i == selectedIndex ? const Color(0xFF2563EB) : Colors.transparent, width: 2.2))),
                  child: Text(tabs[i], style: TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: i == selectedIndex ? const Color(0xFF2563EB) : const Color(0xFF475569))),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _MobileSampleHeaderCard extends StatelessWidget {
  const _MobileSampleHeaderCard({required this.sampleId, required this.testName, required this.dateLabel, required this.status});
  final String sampleId;
  final String testName;
  final String dateLabel;
  final String status;

  @override
  Widget build(BuildContext context) {
    return _MobileWhiteCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Sample ID', style: TextStyle(fontSize: 12, color: Color(0xFF64748B), fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(sampleId, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: Color(0xFF0F172A))),
              const SizedBox(height: 3),
              Text(testName, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF334155))),
              const SizedBox(height: 3),
              Text(dateLabel, style: const TextStyle(fontSize: 12, color: Color(0xFF64748B), fontWeight: FontWeight.w700)),
            ]),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: const Color(0xFFDCFCE7), borderRadius: BorderRadius.circular(8)),
            child: Text(status, style: const TextStyle(fontSize: 11, color: Color(0xFF166534), fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }
}

class _MobileInfoRow {
  const _MobileInfoRow(this.icon, this.label, this.value);
  final IconData icon;
  final String label;
  final String value;
}

class _MobileInfoCard extends StatelessWidget {
  const _MobileInfoCard({required this.title, required this.rows});
  final String title;
  final List<_MobileInfoRow> rows;

  @override
  Widget build(BuildContext context) {
    return _MobileWhiteCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [Expanded(child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: Color(0xFF0F172A)))), const Text('View all', style: TextStyle(color: Color(0xFF2563EB), fontSize: 12, fontWeight: FontWeight.w800))]),
          const SizedBox(height: 12),
          for (final row in rows)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(children: [Icon(row.icon, size: 17, color: const Color(0xFF64748B)), const SizedBox(width: 10), SizedBox(width: 108, child: Text(row.label, style: const TextStyle(fontSize: 12, color: Color(0xFF64748B), fontWeight: FontWeight.w700))), Expanded(child: Text(row.value.isEmpty ? '-' : row.value, textAlign: TextAlign.right, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: Color(0xFF0F172A))))]),
            ),
        ],
      ),
    );
  }
}

class _MobileSummaryStatsCard extends StatelessWidget {
  const _MobileSummaryStatsCard({required this.total, required this.high, required this.low, required this.normal});
  final int total;
  final int high;
  final int low;
  final int normal;

  @override
  Widget build(BuildContext context) {
    return _MobileWhiteCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Parameter Summary', style: TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF0F172A))),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _MobileSummaryTile(value: total.toString(), label: 'Total\nParameters', color: const Color(0xFF16A34A), bg: const Color(0xFFECFDF5))),
          const SizedBox(width: 8),
          Expanded(child: _MobileSummaryTile(value: high.toString(), label: 'High ↑', color: const Color(0xFFDC2626), bg: const Color(0xFFFEF2F2))),
          const SizedBox(width: 8),
          Expanded(child: _MobileSummaryTile(value: low.toString(), label: 'Low ↓', color: const Color(0xFF2563EB), bg: const Color(0xFFEFF6FF))),
          const SizedBox(width: 8),
          Expanded(child: _MobileSummaryTile(value: normal.toString(), label: 'Normal', color: const Color(0xFF059669), bg: const Color(0xFFF0FDF4))),
        ]),
      ]),
    );
  }
}

class _MobileSummaryTile extends StatelessWidget {
  const _MobileSummaryTile({required this.value, required this.label, required this.color, required this.bg});
  final String value;
  final String label;
  final Color color;
  final Color bg;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 78,
      padding: const EdgeInsets.all(9),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(14)),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(value, style: TextStyle(fontSize: 20, color: color, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Color(0xFF334155)))]),
    );
  }
}

class _MobileResultTableCard extends StatelessWidget {
  const _MobileResultTableCard({required this.title, required this.rows});
  final String title;
  final List<_CbcParameterDisplayRow> rows;

  @override
  Widget build(BuildContext context) {
    return _MobileWhiteCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: Color(0xFF0F172A))),
        const SizedBox(height: 12),
        Row(children: const [Expanded(flex: 9, child: Text('Parameter', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Color(0xFF475569)))), Expanded(flex: 7, child: Text('Result', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Color(0xFF475569)))), Expanded(flex: 7, child: Text('Ref. Range', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Color(0xFF475569)))), Expanded(flex: 5, child: Text('Unit', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Color(0xFF475569))))]),
        const Divider(height: 18),
        for (final row in rows)
          _MobileParameterRow(row: row),
      ]),
    );
  }
}

class _MobileParameterRow extends StatelessWidget {
  const _MobileParameterRow({required this.row});
  final _CbcParameterDisplayRow row;

  @override
  Widget build(BuildContext context) {
    final status = _rangeStatus(row.result, row.referenceRange);
    final color = switch (status) {
      _ResultRangeStatus.high => const Color(0xFFDC2626),
      _ResultRangeStatus.low => const Color(0xFF2563EB),
      _ => const Color(0xFF0F172A),
    };
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFFE5E7EB)))),
      child: Row(children: [
        Expanded(flex: 9, child: Text(row.parameter, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900))),
        Expanded(flex: 7, child: Text(row.result.trim().isEmpty ? '-' : row.result, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: color))),
        Expanded(flex: 7, child: Text(row.referenceRange, style: const TextStyle(fontSize: 11, color: Color(0xFF0F172A)))),
        Expanded(flex: 5, child: Text(row.unit, style: const TextStyle(fontSize: 11, color: Color(0xFF0F172A)))),
      ]),
    );
  }
}

class _MobileGraphCard extends StatelessWidget {
  const _MobileGraphCard({required this.title, required this.base64Key, this.row = const <String, String>{}, this.fullWidth = false});
  final String title;
  final String base64Key;
  final Map<String, String> row;
  final bool fullWidth;

  Uint8List? _decode() {
    final raw = row[base64Key]?.trim() ?? '';
    if (raw.isEmpty) return null;
    final payload = raw.contains(',') ? raw.split(',').last.trim() : raw;
    try {
      return base64Decode(payload);
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final bytes = _decode();
    return _MobileWhiteCard(
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900))), const Icon(Icons.open_in_full_rounded, size: 16, color: Color(0xFF2563EB))]),
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity,
          height: fullWidth ? 210 : 150,
          child: Container(
            decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFE5E7EB))),
            alignment: Alignment.center,
            child: bytes == null
                ? const Text('No image', style: TextStyle(color: Color(0xFF94A3B8), fontWeight: FontWeight.w700))
                : Image.memory(bytes, fit: BoxFit.contain, width: double.infinity, height: double.infinity, gaplessPlayback: true),
          ),
        ),
      ]),
    );
  }
}

class _MobileLegend extends StatelessWidget {
  const _MobileLegend();
  @override
  Widget build(BuildContext context) => const Row(children: [_MiniLegend(icon: Icons.arrow_upward_rounded, label: 'High', color: Color(0xFFDC2626)), SizedBox(width: 18), _MiniLegend(icon: Icons.arrow_downward_rounded, label: 'Low', color: Color(0xFF2563EB)), SizedBox(width: 18), _MiniLegend(icon: Icons.circle, label: 'Normal', color: Color(0xFF64748B))]);
}

class _MobileScatterLegend extends StatelessWidget {
  const _MobileScatterLegend();
  @override
  Widget build(BuildContext context) {
    const labels = [
      ('Neutrophils', Color(0xFFA855F7)),
      ('Lymphocytes', Color(0xFF3B82F6)),
      ('Eosinocytes', Color(0xFFEC4899)),
      ('Eosinophils', Color(0xFFEAB308)),
      ('Basophils', Color(0xFF8B5CF6)),
    ];
    return _MobileWhiteCard(
      child: Wrap(spacing: 12, runSpacing: 8, children: [for (final item in labels) _ColorLegend(label: item.$1, color: item.$2)]),
    );
  }
}

class _MiniLegend extends StatelessWidget {
  const _MiniLegend({required this.icon, required this.label, required this.color});
  final IconData icon;
  final String label;
  final Color color;
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 14, color: color), const SizedBox(width: 5), Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800))]);
}

class _ColorLegend extends StatelessWidget {
  const _ColorLegend({required this.label, required this.color});
  final String label;
  final Color color;
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [Container(width: 10, height: 10, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2))), const SizedBox(width: 6), Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700))]);
}

class _MobileAnalyzerNote extends StatelessWidget {
  const _MobileAnalyzerNote();
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFFEFF6FF), borderRadius: BorderRadius.circular(12)), child: const Text('Note: Results are auto verified by analyzer. Please correlate clinically.', style: TextStyle(fontSize: 12, color: Color(0xFF1D4ED8), fontWeight: FontWeight.w700)));
}

class _MobileActionsCard extends StatelessWidget {
  const _MobileActionsCard({required this.onPrint, required this.onRawData});
  final VoidCallback onPrint;
  final VoidCallback onRawData;
  @override
  Widget build(BuildContext context) {
    return _MobileWhiteCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Actions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        _MobileActionTile(icon: Icons.download_rounded, label: 'Download PDF Report', onTap: onPrint),
        _MobileActionTile(icon: Icons.share_rounded, label: 'Share Report', onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Use Download PDF Report, then share the PDF from your device.')))),
        _MobileActionTile(icon: Icons.article_outlined, label: 'View Raw Data', onTap: onRawData),
      ]),
    );
  }
}

class _MobileActionTile extends StatelessWidget {
  const _MobileActionTile({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => ListTile(contentPadding: EdgeInsets.zero, leading: Icon(icon, color: const Color(0xFF64748B)), title: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)), trailing: const Icon(Icons.chevron_right_rounded), onTap: onTap);
}

class _MobileWhiteCard extends StatelessWidget {
  const _MobileWhiteCard({required this.child, this.padding = const EdgeInsets.all(16)});
  final Widget child;
  final EdgeInsetsGeometry padding;
  @override
  Widget build(BuildContext context) => Container(width: double.infinity, padding: padding, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE5E7EB)), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.035), blurRadius: 12, offset: const Offset(0, 6))]), child: child);
}

class _SampleResultBundle {
  const _SampleResultBundle({
    this.sampleInfo = const {},
    this.ageGroup = 'adult',
    this.reportHeader = const _ReportHeaderSettings(),
    this.referenceRanges = const {},
    this.manualResults = const [],
    this.cbcResults = const [],
  });

  final Map<String, String> sampleInfo;
  final String ageGroup;
  final _ReportHeaderSettings reportHeader;
  final Map<String, Map<String, _CbcReferenceRange>> referenceRanges;
  final List<Map<String, String>> manualResults;
  final List<Map<String, String>> cbcResults;
}

class _ResultSection extends StatelessWidget {
  const _ResultSection({
    required this.title,
    required this.rows,
    required this.sampleInfo,
    required this.ageGroup,
    required this.referenceRanges,
    required this.onOpenUrl,
  });

  final String title;
  final List<Map<String, String>> rows;
  final Map<String, String> sampleInfo;
  final String ageGroup;
  final Map<String, Map<String, _CbcReferenceRange>> referenceRanges;
  final ValueChanged<String> onOpenUrl;

  bool _looksLikeUrl(String value) {
    final lower = value.trim().toLowerCase();
    return lower.startsWith('http://') || lower.startsWith('https://');
  }

  bool get _looksLikeManualResult {
    if (title.toLowerCase().contains('manual')) return true;
    return rows.any((row) {
      final normalizedKeys = row.keys.map((key) => key.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '')).toSet();
      return normalizedKeys.contains('resultvalue') ||
          (normalizedKeys.contains('parameter') &&
              normalizedKeys.contains('testname') &&
              !normalizedKeys.contains('wbc') &&
              !normalizedKeys.contains('rbc') &&
              !normalizedKeys.contains('plt'));
    });
  }

  @override
  Widget build(BuildContext context) {
    if (title.toLowerCase().contains('cbc')) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (var index = 0; index < rows.length; index++) ...[
            if (index > 0) const SizedBox(height: 18),
            _CbcReportCard(row: rows[index], sampleInfo: sampleInfo, ageGroup: ageGroup, referenceRanges: referenceRanges),
          ],
        ],
      );
    }

    if (_looksLikeManualResult) {
      return _ManualReportCard(rows: rows, sampleInfo: sampleInfo);
    }

    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.94),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 14),
            for (var rowIndex = 0; rowIndex < rows.length; rowIndex++) ...[
              if (rowIndex > 0) const Divider(height: 28),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: rows[rowIndex].entries.where((entry) => entry.value.trim().isNotEmpty).map((entry) {
                  final value = entry.value.trim();
                  if (_looksLikeUrl(value)) {
                    return ActionChip(
                      avatar: const Icon(Icons.open_in_new_rounded, size: 18),
                      label: Text(entry.key),
                      onPressed: () => onOpenUrl(value),
                    );
                  }
                  return Chip(label: Text('${entry.key}: $value'));
                }).toList(),
              ),
            ],
          ],
        ),
      ),
    );
  }
}


class _ManualReportCard extends StatelessWidget {
  const _ManualReportCard({required this.rows, required this.sampleInfo});

  final List<Map<String, String>> rows;
  final Map<String, String> sampleInfo;

  String _value(Map<String, String> row, String key) => row[key]?.trim() ?? '';
  String _sampleValue(String key) => sampleInfo[key]?.trim() ?? '';
  String _patientName() => _sampleValue('patientName');
  String _ageValue() => _sampleValue('patientAge');
  String _sexValue() => _sampleValue('patientSex');
  String _referNameValue() => _referNameFromSampleInfo(sampleInfo);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final firstRow = rows.isEmpty ? const <String, String>{} : rows.first;
    final testName = _value(firstRow, 'testName').isEmpty ? 'Manual Test' : _value(firstRow, 'testName');
    final displayRows = <_CbcParameterDisplayRow>[
      for (final row in rows)
        _CbcParameterDisplayRow(
          parameter: _value(row, 'parameter').isEmpty
              ? (_value(row, 'testName').isEmpty ? 'Result' : _value(row, 'testName'))
              : _value(row, 'parameter'),
          result: _value(row, 'resultValue'),
          referenceRange: _value(row, 'referenceRange'),
          unit: _value(row, 'unit'),
        ),
    ];
    final notes = rows
        .map((row) => _value(row, 'notes'))
        .where((note) => note.isNotEmpty)
        .toSet()
        .join('\n');

    final isMobile = MediaQuery.sizeOf(context).width < 760;
    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface.withValues(alpha: 0.98),
        borderRadius: BorderRadius.circular(isMobile ? 22 : 24),
        border: Border.all(color: const Color(0xFFE5EAF3)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.035), blurRadius: 16, offset: const Offset(0, 8))],
      ),
      child: Padding(
        padding: EdgeInsets.all(isMobile ? 18 : 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              '$testName Result',
              style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900, color: const Color(0xFF0F172A)),
            ),
            const SizedBox(height: 14),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(child: _ReportInfoBlock(title: 'Name', value: _patientName().isEmpty ? '-' : _patientName())),
                Expanded(child: _ReportInfoBlock(title: 'Age', value: _ageValue().isEmpty ? '-' : _ageValue())),
                Expanded(child: _ReportInfoBlock(title: 'Sample ID', value: _value(firstRow, 'sampleId').isEmpty ? _sampleValue('sampleId') : _value(firstRow, 'sampleId'))),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(child: _ReportInfoBlock(title: 'Gender', value: _sexValue().isEmpty ? '-' : _sexValue())),
                Expanded(child: _ReportInfoBlock(title: 'Refer', value: _referNameValue())),
                Expanded(child: _ReportInfoBlock(title: 'Report Time', value: _formatReportDateTime(_value(firstRow, 'createdAt')).isEmpty ? '-' : _formatReportDateTime(_value(firstRow, 'createdAt')))),
              ],
            ),
            const SizedBox(height: 8),
            _ReportInfoBlock(title: 'Test', value: testName),
            const Divider(height: 26),
            _CbcParameterTable(rows: displayRows),
            const SizedBox(height: 16),
            _MessageBox(title: 'Result Notes', value: notes),
          ],
        ),
      ),
    );
  }
}

class _CbcReportCard extends StatelessWidget {
  const _CbcReportCard({
    required this.row,
    required this.sampleInfo,
    required this.ageGroup,
    required this.referenceRanges,
  });

  final Map<String, String> row;
  final Map<String, String> sampleInfo;
  final String ageGroup;
  final Map<String, Map<String, _CbcReferenceRange>> referenceRanges;

  String _value(String key) => row[key]?.trim() ?? '';
  String _sampleValue(String key) => sampleInfo[key]?.trim() ?? '';

  String _nameValue() {
    final fromSample = _sampleValue('patientName');
    if (fromSample.isNotEmpty) return fromSample;
    final first = _value('firstName');
    final last = _value('lastName');
    return [first, last].where((part) => part.isNotEmpty).join(' ');
  }

  String _ageValue() => _sampleValue('patientAge').isNotEmpty ? _sampleValue('patientAge') : _value('age');
  String _sexValue() => _sampleValue('patientSex').isNotEmpty ? _sampleValue('patientSex') : _value('gender');
  String _referNameValue() => _referNameFromSampleInfo(sampleInfo);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final parameters = _cbcParameterRows(row, referenceRanges[ageGroup] ?? const <String, _CbcReferenceRange>{});
    return Card(
      elevation: 0,
      color: theme.colorScheme.surface.withValues(alpha: 0.96),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(child: _ReportInfoBlock(title: 'Name', value: _nameValue().isEmpty ? '-' : _nameValue())),
                Expanded(child: _ReportInfoBlock(title: 'Age', value: _ageValue().isEmpty ? '-' : _ageValue())),
                Expanded(child: _ReportInfoBlock(title: 'Sample ID', value: _value('sampleId'))),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(child: _ReportInfoBlock(title: 'Gender', value: _sexValue().isEmpty ? '-' : _sexValue())),
                Expanded(child: _ReportInfoBlock(title: 'Refer', value: _referNameValue())),
                Expanded(child: _ReportInfoBlock(title: 'Run Time', value: _formatReportDateTime(_value('runTime').isEmpty ? _value('createdAt') : _value('runTime')).isEmpty ? '-' : _formatReportDateTime(_value('runTime').isEmpty ? _value('createdAt') : _value('runTime')))),
              ],
            ),
            const SizedBox(height: 8),
            _ReportInfoBlock(title: 'Reference Group', value: ageGroup.toUpperCase()),
            const Divider(height: 26),
            LayoutBuilder(
              builder: (context, constraints) {
                final compact = constraints.maxWidth < 900;
                final table = _CbcParameterTable(rows: parameters);
                final charts = _CbcBase64ImageGrid(row: row);
                if (compact) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [table, const SizedBox(height: 16), charts],
                  );
                }
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(flex: 3, child: table),
                    const SizedBox(width: 18),
                    Expanded(child: charts),
                  ],
                );
              },
            ),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(child: _MessageBox(title: 'WBC Message', value: _value('WBCFlag'))),
                const SizedBox(width: 8),
                Expanded(child: _MessageBox(title: 'RBC Message', value: _value('RBCFlag'))),
                const SizedBox(width: 8),
                Expanded(child: _MessageBox(title: 'PLT Message', value: _value('PLTFlag'))),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ReportInfoBlock extends StatelessWidget {
  const _ReportInfoBlock({required this.title, required this.value});
  final String title;
  final String value;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 12, bottom: 4),
      child: RichText(
        text: TextSpan(
          style: DefaultTextStyle.of(context).style,
          children: [
            TextSpan(text: '$title: ', style: const TextStyle(fontWeight: FontWeight.w800)),
            TextSpan(text: value.isEmpty ? '-' : value),
          ],
        ),
      ),
    );
  }
}


bool _isBlankResultMeta(String value) {
  final cleaned = value.trim();
  return cleaned.isEmpty || cleaned == '-';
}

bool _isQualitativeDisplayRow(_CbcParameterDisplayRow row) {
  return _isBlankResultMeta(row.referenceRange) && _isBlankResultMeta(row.unit);
}

class _CbcParameterTable extends StatelessWidget {
  const _CbcParameterTable({required this.rows});
  final List<_CbcParameterDisplayRow> rows;
  @override
  Widget build(BuildContext context) {
    final qualitativeOnly = rows.isNotEmpty && rows.every(_isQualitativeDisplayRow);
    return DataTable(
      headingRowHeight: 34,
      dataRowMinHeight: 30,
      dataRowMaxHeight: 36,
      columnSpacing: qualitativeOnly ? 28 : 18,
      columns: qualitativeOnly
          ? const [
              DataColumn(label: Text('Test')),
              DataColumn(label: Text('Result')),
            ]
          : const [
              DataColumn(label: Text('Parameter')),
              DataColumn(label: Text('Result')),
              DataColumn(label: Text('Ref. Range')),
              DataColumn(label: Text('Unit')),
            ],
      rows: [
        for (final item in rows)
          DataRow(
            cells: qualitativeOnly
                ? [
                    DataCell(Text(item.parameter, style: const TextStyle(fontWeight: FontWeight.w700))),
                    DataCell(Text(item.result.trim().isEmpty ? '-' : item.result.trim(), style: const TextStyle(fontWeight: FontWeight.w900))),
                  ]
                : [
                    DataCell(Text(item.parameter, style: const TextStyle(fontWeight: FontWeight.w700))),
                    DataCell(_RangeAwareResultText(result: item.result, referenceRange: item.referenceRange)),
                    DataCell(Text(_isBlankResultMeta(item.referenceRange) ? '-' : item.referenceRange)),
                    DataCell(Text(_isBlankResultMeta(item.unit) ? '-' : item.unit)),
                  ],
          ),
      ],
    );
  }
}

class _RangeAwareResultText extends StatelessWidget {
  const _RangeAwareResultText({required this.result, required this.referenceRange});

  final String result;
  final String referenceRange;

  @override
  Widget build(BuildContext context) {
    final raw = result.trim();
    if (raw.isEmpty) {
      return const Text('-');
    }
    final status = _rangeStatus(raw, referenceRange);
    final color = switch (status) {
      _ResultRangeStatus.high => const Color(0xFFDC2626),
      _ResultRangeStatus.low => const Color(0xFF60A5FA),
      _ => null,
    };
    final suffix = switch (status) {
      _ResultRangeStatus.high => ' ↑',
      _ResultRangeStatus.low => ' ↓',
      _ => '',
    };
    return Text(
      '$raw$suffix',
      style: TextStyle(
        color: color,
        fontWeight: status == _ResultRangeStatus.normal || status == _ResultRangeStatus.unknown ? null : FontWeight.w800,
      ),
    );
  }
}

enum _ResultRangeStatus { low, normal, high, unknown }

_ResultRangeStatus _rangeStatus(String result, String referenceRange) {
  final raw = result.trim();
  if (raw.isEmpty) return _ResultRangeStatus.unknown;
  final numberMatch = RegExp(r'-?\d+(?:\.\d+)?').firstMatch(raw.replaceAll(',', ''));
  if (numberMatch == null) return _ResultRangeStatus.unknown;
  final value = double.tryParse(numberMatch.group(0) ?? '');
  final rangeMatch = RegExp(r'(-?\d+(?:\.\d+)?)\s*-\s*(-?\d+(?:\.\d+)?)').firstMatch(referenceRange.replaceAll(',', ''));
  if (value == null || rangeMatch == null) return _ResultRangeStatus.unknown;
  final low = double.tryParse(rangeMatch.group(1) ?? '');
  final high = double.tryParse(rangeMatch.group(2) ?? '');
  if (low == null || high == null) return _ResultRangeStatus.unknown;
  if (value < low) return _ResultRangeStatus.low;
  if (value > high) return _ResultRangeStatus.high;
  return _ResultRangeStatus.normal;
}

class _CbcBase64ImageGrid extends StatelessWidget {
  const _CbcBase64ImageGrid({required this.row});

  final Map<String, String> row;

  String _value(String key) => row[key]?.trim() ?? '';

  @override
  Widget build(BuildContext context) {
    final images = <_CbcImageSpec>[
      _CbcImageSpec(title: 'WBC Histogram', base64Value: _value('wbcGraphBase64')),
      _CbcImageSpec(title: 'RBC Histogram', base64Value: _value('rbcGraphBase64')),
      _CbcImageSpec(title: 'PLT Histogram', base64Value: _value('pltGraphBase64')),
      _CbcImageSpec(title: 'DIFF HS/MS', base64Value: _value('diffHsmsBase64')),
      _CbcImageSpec(title: 'DIFF LS/HS', base64Value: _value('diffLshsBase64')),
      _CbcImageSpec(title: 'DIFF LS/MS', base64Value: _value('diffLsmsBase64')),
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = constraints.maxWidth >= 520 ? 2 : 1;
        final spacing = 12.0;
        final itemWidth = columns == 1 ? constraints.maxWidth : (constraints.maxWidth - spacing) / 2;
        return Wrap(
          spacing: spacing,
          runSpacing: spacing,
          children: [
            for (final image in images)
              SizedBox(
                width: itemWidth,
                child: _Base64ImageBox(title: image.title, base64Value: image.base64Value),
              ),
          ],
        );
      },
    );
  }
}

class _CbcImageSpec {
  const _CbcImageSpec({required this.title, required this.base64Value});
  final String title;
  final String base64Value;
}

class _Base64ImageBox extends StatelessWidget {
  const _Base64ImageBox({required this.title, required this.base64Value});

  final String title;
  final String base64Value;

  Uint8List? _decodeImageBytes() {
    final raw = base64Value.trim();
    if (raw.isEmpty) return null;
    final payload = raw.contains(',') ? raw.split(',').last.trim() : raw;
    try {
      return base64Decode(payload);
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bytes = _decodeImageBytes();
    return Container(
      height: 178,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.28),
        border: Border.all(color: theme.colorScheme.outlineVariant),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Container(
                color: theme.colorScheme.surface,
                alignment: Alignment.center,
                child: bytes == null
                    ? Text(
                        'No image data',
                        style: TextStyle(color: theme.colorScheme.onSurfaceVariant),
                      )
                    : InteractiveViewer(
                        minScale: 0.8,
                        maxScale: 4,
                        child: Image.memory(bytes, fit: BoxFit.contain, gaplessPlayback: true),
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MessageBox extends StatelessWidget {
  const _MessageBox({required this.title, required this.value});
  final String title;
  final String value;
  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 92),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900))),
          const Divider(),
          Text(value.trim().isEmpty ? '-' : value.trim()),
        ],
      ),
    );
  }
}


class _ReportHeaderSettings {
  const _ReportHeaderSettings({
    this.subCenterId = '',
    this.hospitalName = 'Aung Myin Station Hospital',
    this.departmentName = 'Laboratory Department',
    this.township = 'Kyouttaga Township',
    this.ministryName = 'Ministry of Health',
    this.reportTitle = 'LAB REPORT',
    this.accentColor = '#1D4ED8',
    this.footerText = '',
  });

  final String subCenterId;
  final String hospitalName;
  final String departmentName;
  final String township;
  final String ministryName;
  final String reportTitle;
  final String accentColor;
  final String footerText;

  factory _ReportHeaderSettings.defaults({String subCenterId = ''}) {
    return _ReportHeaderSettings(subCenterId: subCenterId);
  }

  factory _ReportHeaderSettings.fromMap(Map<String, String> map, {required _ReportHeaderSettings fallback}) {
    String pick(String key, String fallbackValue) {
      final value = map[key]?.trim() ?? '';
      return value.isEmpty ? fallbackValue : value;
    }
    return _ReportHeaderSettings(
      subCenterId: pick('subcenterid', fallback.subCenterId),
      hospitalName: pick('hospitalname', fallback.hospitalName),
      departmentName: pick('departmentname', fallback.departmentName),
      township: pick('township', fallback.township),
      ministryName: pick('ministryname', fallback.ministryName),
      reportTitle: pick('reporttitle', fallback.reportTitle),
      accentColor: pick('accentcolor', fallback.accentColor),
      footerText: pick('footertext', fallback.footerText),
    );
  }
}

class _CbcReferenceRange {
  const _CbcReferenceRange({required this.refRange, required this.unit});

  final String refRange;
  final String unit;
}

class _CbcParameterRow {
  const _CbcParameterRow(this.parameter, this.key, this.referenceRange, this.unit);
  final String parameter;
  final String key;
  final String referenceRange;
  final String unit;
}

class _CbcParameterDisplayRow {
  const _CbcParameterDisplayRow({required this.parameter, required this.result, required this.referenceRange, required this.unit});
  final String parameter;
  final String result;
  final String referenceRange;
  final String unit;
}

List<_CbcParameterDisplayRow> _cbcParameterRows(Map<String, String> row, Map<String, _CbcReferenceRange> configuredRanges) {
  String value(String key) => row[key]?.trim() ?? '';
  const defs = [
    _CbcParameterRow('WBC', 'WBC', '3.50-9.50', '10^3/uL'),
    _CbcParameterRow('Neu%', 'NeuPercent', '40.0-75.0', '%'),
    _CbcParameterRow('Lym%', 'LymPercent', '20.0-50.0', '%'),
    _CbcParameterRow('Mon%', 'MonPercent', '3.0-10.0', '%'),
    _CbcParameterRow('Eos%', 'EosPercent', '0.4-8.0', '%'),
    _CbcParameterRow('Bas%', 'BasPercent', '0.0-1.0', '%'),
    _CbcParameterRow('Neu#', 'NeuCount', '1.80-6.30', '10^3/uL'),
    _CbcParameterRow('Lym#', 'LymCount', '1.10-3.20', '10^3/uL'),
    _CbcParameterRow('Mon#', 'MonCount', '0.10-0.60', '10^3/uL'),
    _CbcParameterRow('Eos#', 'EosCount', '0.02-0.52', '10^3/uL'),
    _CbcParameterRow('Bas#', 'BasCount', '0.00-0.06', '10^3/uL'),
    _CbcParameterRow('ALY#', 'ALYCount', '0.00-0.20', '10^3/uL'),
    _CbcParameterRow('ALY%', 'ALYPercent', '0.0-2.0', '%'),
    _CbcParameterRow('LIC#', 'LICCount', '0.00-0.20', '10^3/uL'),
    _CbcParameterRow('LIC%', 'LICPercent', '0.0-2.5', '%'),
    _CbcParameterRow('NRBC#', 'NRBCCount', '0.000-9999.999', '10^9/L'),
    _CbcParameterRow('NRBC%', 'NRBCPercent', '0.00-9999.99', '%'),
    _CbcParameterRow('RBC', 'RBC', '3.80-5.80', '10^6/uL'),
    _CbcParameterRow('HGB', 'HGB', '11.5-17.5', 'g/dL'),
    _CbcParameterRow('HCT', 'HCT', '35.0-50.0', '%'),
    _CbcParameterRow('MCV', 'MCV', '82.0-100.0', 'fL'),
    _CbcParameterRow('MCH', 'MCH', '27.0-34.0', 'pg'),
    _CbcParameterRow('MCHC', 'MCHC', '31.6-35.4', 'g/dL'),
    _CbcParameterRow('RDW-CV', 'RDWCV', '11.0-16.0', '%'),
    _CbcParameterRow('RDW-SD', 'RDWSD', '35.0-56.0', 'fL'),
    _CbcParameterRow('PLT', 'PLT', '125-350', '10^3/uL'),
    _CbcParameterRow('MPV', 'MPV', '6.5-12.0', 'fL'),
    _CbcParameterRow('PDW', 'PDW', '9.0-17.0', 'fL'),
    _CbcParameterRow('PCT', 'PCT', '0.108-0.282', '%'),
    _CbcParameterRow('P-LCR', 'PLCR', '11.0-45.0', '%'),
    _CbcParameterRow('P-LCC', 'PLCC', '30-90', '10^9/L'),
  ];
  return [
    for (final def in defs)
      _CbcParameterDisplayRow(
        parameter: def.parameter,
        result: value(def.key),
        referenceRange: configuredRanges[def.parameter]?.refRange.trim().isNotEmpty == true
            ? configuredRanges[def.parameter]!.refRange
            : def.referenceRange,
        unit: configuredRanges[def.parameter]?.unit.trim().isNotEmpty == true
            ? configuredRanges[def.parameter]!.unit
            : def.unit,
      ),
  ];
}
