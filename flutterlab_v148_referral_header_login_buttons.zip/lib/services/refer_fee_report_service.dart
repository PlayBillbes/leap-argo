import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import 'turso_native_service.dart';

class ReferFeeReportRow {
  const ReferFeeReportRow({
    required this.sampleId,
    required this.patientName,
    required this.subCenterId,
    required this.referredPerson,
    required this.tests,
    required this.amount,
    this.date,
  });

  final String sampleId;
  final String patientName;
  final String subCenterId;
  final String referredPerson;
  final String tests;
  final double amount;
  final DateTime? date;
}

class ReferFeeReportHeaderSettings {
  const ReferFeeReportHeaderSettings({
    required this.scopeType,
    required this.subCenterId,
    required this.hospitalName,
    required this.departmentName,
    required this.township,
    required this.ministryName,
    required this.reportTitle,
    required this.accentColor,
    required this.footerText,
  });

  final String scopeType;
  final String subCenterId;
  final String hospitalName;
  final String departmentName;
  final String township;
  final String ministryName;
  final String reportTitle;
  final String accentColor;
  final String footerText;

  factory ReferFeeReportHeaderSettings.defaults({String scopeType = 'GLOBAL', String subCenterId = 'GLOBAL'}) {
    return ReferFeeReportHeaderSettings(
      scopeType: scopeType,
      subCenterId: subCenterId,
      hospitalName: 'Aung Myin Station Hospital',
      departmentName: 'Laboratory Department',
      township: 'Kyouttaga Township',
      ministryName: 'Ministry of Health',
      reportTitle: 'LAB REPORT',
      accentColor: '#1D4ED8',
      footerText: '',
    );
  }

  factory ReferFeeReportHeaderSettings.fromMap(
    Map<String, String> map, {
    required ReferFeeReportHeaderSettings fallback,
  }) {
    String pick(String key, String fallbackValue) {
      final value = map[key]?.trim() ?? '';
      return value.isEmpty ? fallbackValue : value;
    }

    return ReferFeeReportHeaderSettings(
      scopeType: pick('scopetype', fallback.scopeType),
      subCenterId: pick('subcenterid', fallback.subCenterId),
      hospitalName: pick('hospitalname', fallback.hospitalName),
      departmentName: pick('departmentname', fallback.departmentName),
      township: pick('township', fallback.township),
      ministryName: pick('ministryname', fallback.ministryName),
      reportTitle: pick('reporttitle', fallback.reportTitle),
      accentColor: pick('accentcolor', fallback.accentColor),
      footerText: pick('footertext', fallback.footerText),
    );
  }
}

class ReferFeeReportService {
  const ReferFeeReportService._();

  static Future<void> printReport({
    required String title,
    required String periodLabel,
    required String scopeLabel,
    required List<ReferFeeReportRow> rows,
    String generatedBy = '',
    String headerScopeType = 'GLOBAL',
    String headerSubCenterId = 'GLOBAL',
  }) async {
    final doc = pw.Document();
    final header = await _loadReportHeaderSettings(
      scopeType: headerScopeType,
      subCenterId: headerSubCenterId,
    );
    final logoImage = await _loadLogoImage();
    final accent = _pdfColorFromHex(header.accentColor);

    final sortedRows = [...rows]
      ..sort((a, b) {
        final byPerson = a.referredPerson.toLowerCase().compareTo(b.referredPerson.toLowerCase());
        if (byPerson != 0) return byPerson;
        return (a.date ?? DateTime(1900)).compareTo(b.date ?? DateTime(1900));
      });
    final totalFee = sortedRows.fold<double>(0, (sum, row) => sum + row.amount);
    final totalSamples = sortedRows.length;
    final totalTests = sortedRows.fold<int>(0, (sum, row) {
      final tests = row.tests.split(',').map((item) => item.trim()).where((item) => item.isNotEmpty).length;
      return sum + (tests == 0 ? 1 : tests);
    });
    final personTotals = <String, double>{};
    for (final row in sortedRows) {
      personTotals[row.referredPerson] = (personTotals[row.referredPerson] ?? 0) + row.amount;
    }
    final personEntries = personTotals.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.fromLTRB(28, 34, 28, 28),
        footer: (context) => _reportFooter(header),
        build: (context) => [
          _modernBlueAccentLetterhead(header, logoImage),
          pw.SizedBox(height: 10),
          pw.Container(
            padding: const pw.EdgeInsets.all(14),
            decoration: pw.BoxDecoration(
              color: PdfColors.white,
              border: pw.Border.all(color: PdfColor.fromHex('#CBD5E1')),
              borderRadius: pw.BorderRadius.circular(12),
            ),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(title, style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold, color: PdfColors.grey900)),
                pw.SizedBox(height: 5),
                pw.Row(
                  children: [
                    _metaPill('Period', periodLabel, accent),
                    pw.SizedBox(width: 6),
                    _metaPill('Scope', scopeLabel, accent),
                  ],
                ),
                if (generatedBy.trim().isNotEmpty) ...[
                  pw.SizedBox(height: 6),
                  pw.Text('Generated by: $generatedBy', style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
                ],
              ],
            ),
          ),
          pw.SizedBox(height: 16),
          pw.Row(
            children: [
              _summaryBox('Total fee', _money(totalFee)),
              pw.SizedBox(width: 8),
              _summaryBox('Samples', '$totalSamples'),
              pw.SizedBox(width: 8),
              _summaryBox('Tests', '$totalTests'),
            ],
          ),
          pw.SizedBox(height: 14),
          pw.Text('Referral person summary', style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          if (personEntries.isEmpty)
            pw.Text('No referral fee data for this period.')
          else
            pw.TableHelper.fromTextArray(
              headers: const ['Referred person', 'Refer fee'],
              data: [for (final entry in personEntries) [entry.key, _money(entry.value)]],
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white),
              headerDecoration: pw.BoxDecoration(color: accent),
              cellStyle: const pw.TextStyle(fontSize: 9),
              cellAlignment: pw.Alignment.centerLeft,
              columnWidths: const {0: pw.FlexColumnWidth(3), 1: pw.FlexColumnWidth(1.4)},
            ),
          pw.SizedBox(height: 16),
          pw.Text('Referral sample details', style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          if (sortedRows.isEmpty)
            pw.Text('No sample rows to show.')
          else
            pw.TableHelper.fromTextArray(
              headers: const ['Date', 'Sample', 'Patient', 'Center', 'Referred person', 'Tests', 'Fee'],
              data: [
                for (final row in sortedRows)
                  [
                    _date(row.date),
                    row.sampleId,
                    row.patientName,
                    row.subCenterId,
                    row.referredPerson,
                    row.tests,
                    _money(row.amount),
                  ],
              ],
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white),
              headerDecoration: pw.BoxDecoration(color: PdfColor.fromHex('#0F172A')),
              cellStyle: const pw.TextStyle(fontSize: 8),
              cellAlignment: pw.Alignment.centerLeft,
              columnWidths: const {
                0: pw.FlexColumnWidth(1.1),
                1: pw.FlexColumnWidth(1.3),
                2: pw.FlexColumnWidth(1.7),
                3: pw.FlexColumnWidth(1.2),
                4: pw.FlexColumnWidth(1.8),
                5: pw.FlexColumnWidth(2.0),
                6: pw.FlexColumnWidth(1.1),
              },
            ),
        ],
      ),
    );

    await Printing.layoutPdf(
      onLayout: (format) async => doc.save(),
      name: '${_slug(title)}_${_slug(periodLabel)}.pdf',
    );
  }

  static Future<ReferFeeReportHeaderSettings> _loadReportHeaderSettings({required String scopeType, required String subCenterId}) async {
    final fallback = ReferFeeReportHeaderSettings.defaults(scopeType: scopeType, subCenterId: subCenterId);
    TursoNativeService? service;
    try {
      service = TursoNativeService(applicationName: 'flutterlab');
      final rows = await service.fetchRows(range: 'ReportHeaderSettings!A:K');
      if (rows.length < 2) return fallback;
      final headers = rows.first.map(_normalize).toList();
      final records = <Map<String, String>>[];
      for (final row in rows.skip(1)) {
        final map = <String, String>{};
        for (var i = 0; i < headers.length; i++) {
          map[headers[i]] = i < row.length ? row[i].trim() : '';
        }
        records.add(map);
      }

      Map<String, String>? match(String targetScope, String targetCenter) {
        for (final record in records) {
          if (_normalize(record['scopetype'] ?? '') == _normalize(targetScope) &&
              _normalize(record['subcenterid'] ?? '') == _normalize(targetCenter)) {
            return record;
          }
        }
        return null;
      }

      final requested = match(scopeType, subCenterId);
      if (requested != null) {
        return ReferFeeReportHeaderSettings.fromMap(requested, fallback: fallback);
      }

      final globalFallback = ReferFeeReportHeaderSettings.defaults(scopeType: 'GLOBAL', subCenterId: 'GLOBAL');
      final global = match('GLOBAL', 'GLOBAL');
      if (global != null) {
        return ReferFeeReportHeaderSettings.fromMap(global, fallback: globalFallback).copyForScope(scopeType: scopeType, subCenterId: subCenterId);
      }
      return fallback;
    } catch (_) {
      return fallback;
    } finally {
      await service?.close();
    }
  }

  static Future<pw.MemoryImage?> _loadLogoImage() async {
    try {
      final bytes = await rootBundle.load('assets/images/moh.png');
      return pw.MemoryImage(bytes.buffer.asUint8List());
    } catch (_) {
      return null;
    }
  }

  static pw.Widget _modernBlueAccentLetterhead(ReferFeeReportHeaderSettings settings, pw.MemoryImage? logoImage) {
    final accent = _pdfColorFromHex(settings.accentColor);
    return pw.Container(
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        color: PdfColor(0.937, 0.965, 1.0),
        borderRadius: pw.BorderRadius.circular(8),
        border: pw.Border.all(color: PdfColor(0.576, 0.773, 0.992), width: 0.6),
      ),
      child: pw.Row(
        children: [
          pw.Container(
            width: 48,
            height: 48,
            padding: const pw.EdgeInsets.all(1.5),
            decoration: pw.BoxDecoration(
              shape: pw.BoxShape.circle,
              color: PdfColors.white,
              border: pw.Border.all(color: accent, width: 1.2),
            ),
            child: pw.Center(
              child: logoImage == null
                  ? pw.Text('MOH', style: pw.TextStyle(color: accent, fontWeight: pw.FontWeight.bold, fontSize: 11))
                  : pw.Image(logoImage, fit: pw.BoxFit.contain),
            ),
          ),
          pw.SizedBox(width: 10),
          pw.Container(width: 0.8, height: 48, color: PdfColor(0.576, 0.773, 0.992)),
          pw.SizedBox(width: 10),
          pw.Expanded(
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  settings.hospitalName.toUpperCase(),
                  style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold, color: PdfColors.grey900),
                ),
                pw.SizedBox(height: 2),
                pw.Text(settings.departmentName, style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold, color: accent)),
                pw.Text(settings.township, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
                pw.Text(settings.ministryName, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
              ],
            ),
          ),
          pw.SizedBox(width: 8),
          pw.Container(
            padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: pw.BoxDecoration(color: accent, borderRadius: pw.BorderRadius.circular(12)),
            child: pw.Text(settings.reportTitle, style: pw.TextStyle(fontSize: 7.5, fontWeight: pw.FontWeight.bold, color: PdfColors.white)),
          ),
        ],
      ),
    );
  }

  static pw.Widget _metaPill(String label, String value, PdfColor accent) {
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: pw.BoxDecoration(
        color: PdfColors.white,
        borderRadius: pw.BorderRadius.circular(99),
        border: pw.Border.all(color: accent, width: 0.5),
      ),
      child: pw.RichText(
        text: pw.TextSpan(
          children: [
            pw.TextSpan(text: '$label: ', style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold, color: accent)),
            pw.TextSpan(text: value, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey800)),
          ],
        ),
      ),
    );
  }

  static pw.Widget _reportFooter(ReferFeeReportHeaderSettings settings) {
    final footer = settings.footerText.trim();
    final center = settings.subCenterId.trim().toLowerCase();
    if (footer.isEmpty || center.isEmpty || center == 'global') return pw.SizedBox.shrink();
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.only(top: 6),
      decoration: const pw.BoxDecoration(border: pw.Border(top: pw.BorderSide(color: PdfColors.grey400, width: 0.4))),
      child: pw.Text(
        footer,
        textAlign: pw.TextAlign.center,
        style: const pw.TextStyle(fontSize: 7.5, color: PdfColors.grey700),
      ),
    );
  }

  static pw.Widget _summaryBox(String label, String value) {
    return pw.Expanded(
      child: pw.Container(
        padding: const pw.EdgeInsets.all(10),
        decoration: pw.BoxDecoration(
          border: pw.Border.all(color: PdfColor.fromHex('#CBD5E1')),
          borderRadius: pw.BorderRadius.circular(10),
        ),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(label, style: const pw.TextStyle(color: PdfColors.grey700, fontSize: 9)),
            pw.SizedBox(height: 4),
            pw.Text(value, style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  static PdfColor _pdfColorFromHex(String raw) {
    final cleaned = raw.trim().replaceAll('#', '');
    if (!RegExp(r'^[0-9a-fA-F]{6}$').hasMatch(cleaned)) return PdfColor(0.114, 0.306, 0.847);
    final value = int.parse(cleaned, radix: 16);
    final r = ((value >> 16) & 0xFF) / 255.0;
    final g = ((value >> 8) & 0xFF) / 255.0;
    final b = (value & 0xFF) / 255.0;
    return PdfColor(r, g, b);
  }

  static String _date(DateTime? value) {
    if (value == null) return '-';
    final local = value.toLocal();
    return '${local.year}-${local.month.toString().padLeft(2, '0')}-${local.day.toString().padLeft(2, '0')}';
  }

  static String _money(num value) => 'Ks ${_number(value.round())}';

  static String _number(num value) {
    final raw = value.abs().round().toString();
    final buffer = StringBuffer(value < 0 ? '-' : '');
    for (var i = 0; i < raw.length; i++) {
      final remaining = raw.length - i;
      buffer.write(raw[i]);
      if (remaining > 1 && remaining % 3 == 1) buffer.write(',');
    }
    return buffer.toString();
  }

  static String _slug(String value) {
    final cleaned = value.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '_').replaceAll(RegExp(r'^_+|_+$'), '');
    return cleaned.isEmpty ? 'refer_fee_report' : cleaned;
  }

  static String _normalize(String raw) => raw.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
}

extension _ReferFeeReportHeaderScopeCopy on ReferFeeReportHeaderSettings {
  ReferFeeReportHeaderSettings copyForScope({required String scopeType, required String subCenterId}) {
    return ReferFeeReportHeaderSettings(
      scopeType: scopeType,
      subCenterId: subCenterId,
      hospitalName: hospitalName,
      departmentName: departmentName,
      township: township,
      ministryName: ministryName,
      reportTitle: reportTitle,
      accentColor: accentColor,
      footerText: footerText,
    );
  }
}
