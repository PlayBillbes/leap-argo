import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../models/app_user.dart';
import '../providers/auth_notifier.dart';
import '../services/native_auth_service.dart';
import '../views/dashboard_view.dart';
import '../views/search_page.dart';
import '../views/sample_result_page.dart';
import '../views/register_sample_page.dart';
import '../views/cbc_cp_result_upload_page.dart';
import '../views/cbc_reference_ranges_page.dart';
import '../views/test_requirements_page.dart';
import '../views/profile_page.dart';
import '../views/report_header_settings_page.dart';
import '../views/advanced_analytics_page.dart';
import '../views/alert_management_page.dart';
import '../views/admin_analytics_page.dart';
import '../views/lab_tech_analytics_report_page.dart';
import '../views/referred_person_analytics_report_page.dart';
import '../views/global_pricing_page.dart';
import '../views/sub_center_pricing_page.dart';
import '../views/users_page.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/',
    refreshListenable: GoRouterRefreshStream(
      ref.watch(authNotifierProvider.notifier).stream,
    ),
    redirect: (context, state) {
      final user = ref.read(authNotifierProvider);
      final path = state.uri.path;
      final loggingIn = path == '/login';

      if (user == null) {
        return loggingIn ? null : '/login';
      }

      if (path == '/login') {
        return '/';
      }

      if (path == '/global-pricing' ||
          path == '/advanced-analytics' ||
          path == '/alerts' ||
          path == '/cbc-reference-ranges') {
        return user.role == AppUserRole.superadmin ? null : '/';
      }

      if (path == '/users') {
        return user.role == AppUserRole.superadmin || user.role == AppUserRole.admin || user.role == AppUserRole.staff ? null : '/';
      }

      if (path == '/sub-center-pricing' || path == '/admin-analytics') {
        return user.role == AppUserRole.admin ? null : '/';
      }
      if (path == '/report-header') {
        return user.role == AppUserRole.superadmin ? null : '/';
      }

      if (path == '/register-sample') {
        return user.role == AppUserRole.staff || user.role == AppUserRole.admin || user.role == AppUserRole.superadmin || user.role == AppUserRole.lab_tech ? null : '/';
      }


      if (path == '/referred-person-report') {
        return user.role == AppUserRole.referred_person ? null : '/';
      }

      if (path == '/test-requirements' || path == '/cbc-cp-result' || path == '/lab-tech-report') {
        return user.role == AppUserRole.lab_tech || user.role == AppUserRole.superadmin ? null : '/';
      }

      return null;
    },
    routes: [
      GoRoute(path: '/login', builder: (context, state) => const LoginPage()),
      GoRoute(path: '/', builder: (context, state) => const DashboardView()),
      GoRoute(path: '/search', builder: (context, state) => const SearchPage()),
      GoRoute(
        path: '/sample-result/:sampleId',
        builder: (context, state) => SampleResultPage(sampleId: state.pathParameters['sampleId'] ?? ''),
      ),
      GoRoute(path: '/register-sample', builder: (context, state) => const RegisterSamplePage()),
      GoRoute(path: '/profile', builder: (context, state) => const ProfilePage()),
      GoRoute(path: '/report-header', builder: (context, state) => const ReportHeaderSettingsPage()),
      GoRoute(path: '/test-requirements', builder: (context, state) => const TestRequirementsPage()),
      GoRoute(path: '/cbc-cp-result', builder: (context, state) => const CbcCpResultUploadPage()),
      GoRoute(path: '/lab-tech-report', builder: (context, state) => const LabTechAnalyticsReportPage()),
      GoRoute(path: '/referred-person-report', builder: (context, state) => const ReferredPersonAnalyticsReportPage()),
      GoRoute(path: '/cbc-reference-ranges', builder: (context, state) => const CbcReferenceRangesPage()),
      GoRoute(path: '/users', builder: (context, state) => const UsersPage()),
      GoRoute(
        path: '/global-pricing',
        builder: (context, state) => const GlobalPricingPage(),
      ),
      GoRoute(
        path: '/advanced-analytics',
        builder: (context, state) => const AdvancedAnalyticsPage(),
      ),
      GoRoute(
        path: '/alerts',
        builder: (context, state) => const AlertManagementPage(),
      ),
      GoRoute(
        path: '/sub-center-pricing',
        builder: (context, state) => const SubCenterPricingPage(),
      ),
      GoRoute(
        path: '/admin-analytics',
        builder: (context, state) => const AdminAnalyticsPage(),
      ),
    ],
  );
});

class GoRouterRefreshStream extends ChangeNotifier {
  GoRouterRefreshStream(this._stream) {
    _subscription = _stream.listen((_) => notifyListeners());
  }

  final Stream<AppUser?> _stream;
  late final StreamSubscription<AppUser?> _subscription;

  @override
  void dispose() {
    _subscription.cancel();
    super.dispose();
  }
}

class LoginPage extends ConsumerStatefulWidget {
  const LoginPage({super.key});

  @override
  ConsumerState<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends ConsumerState<LoginPage> {
  final _usernameController = TextEditingController(text: '');
  final _passwordController = TextEditingController(text: '');
  bool _isLoading = false;
  String? _errorMessage;

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _signIn() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final authService = NativeAuthService(applicationName: 'FlutterLab');

      final user = await authService.signIn(
        username: _usernameController.text,
        password: _passwordController.text,
      );

      if (!mounted) return;

      if (user == null) {
        setState(() {
          _errorMessage = 'Invalid username or password.';
        });
      } else {
        ref.read(authNotifierProvider.notifier).setUser(user);
        context.go('/');
      }
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _errorMessage = error.toString();
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: Stack(
        children: [
          Container(
            color: const Color(0xFFF6F8FC),
          ),
          Positioned(
            top: -90,
            left: -80,
            child: Container(
              width: 240,
              height: 240,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(140),
                color: const Color(0xFFEFF6FF),
              ),
            ),
          ),
          Positioned(
            bottom: -90,
            right: -60,
            child: Container(
              width: 220,
              height: 220,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(120),
                color: const Color(0xFFDCEBFF),
              ),
            ),
          ),
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 540),
              child: Card(
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 32,
                    vertical: 32,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: theme.colorScheme.primary.withValues(
                                alpha: 0.12,
                              ),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Icon(
                              Icons.medical_services_rounded,
                              size: 30,
                              color: theme.colorScheme.primary,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'LabOps',
                                  style: theme.textTheme.headlineSmall
                                      ?.copyWith(fontWeight: FontWeight.w800),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  'Secure sign in to your mobile lab workspace.',
                                  style: theme.textTheme.bodyMedium?.copyWith(
                                    color: theme.colorScheme.onSurface
                                        .withValues(alpha: 0.72),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 28),
                      _buildInputField(
                        controller: _usernameController,
                        label: 'Username',
                        icon: Icons.person_outline,
                      ),
                      const SizedBox(height: 18),
                      _buildInputField(
                        controller: _passwordController,
                        label: 'Password',
                        icon: Icons.lock_outline,
                        obscureText: true,
                      ),
                      const SizedBox(height: 18),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TextButton(
                            onPressed: () {},
                            child: const Text('Forgot password?'),
                          ),
                          TextButton(
                            onPressed: () {},
                            child: const Text('Need help?'),
                          ),
                        ],
                      ),
                      if (_errorMessage != null) ...[
                        const SizedBox(height: 8),
                        Text(
                          _errorMessage!,
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: theme.colorScheme.error,
                          ),
                        ),
                      ],
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton(
                          style: FilledButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                          ),
                          onPressed: _isLoading ? null : _signIn,
                          child: _isLoading
                              ? const SizedBox(
                                  height: 20,
                                  width: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                  ),
                                )
                              : const Text('Sign in securely'),
                        ),
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: Divider(
                              color: theme.colorScheme.onSurface.withValues(
                                alpha: 0.12,
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: Text('OR', style: theme.textTheme.bodySmall),
                          ),
                          Expanded(
                            child: Divider(
                              color: theme.colorScheme.onSurface.withValues(
                                alpha: 0.12,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _buildSubtleButton(
                            context,
                            icon: Icons.info_outline,
                            label: 'About',
                          ),
                          _buildSubtleButton(
                            context,
                            icon: Icons.settings_suggest_outlined,
                            label: 'Settings',
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool obscureText = false,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        filled: true,
        fillColor: Colors.white.withValues(alpha: 0.06),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  Widget _buildSubtleButton(
    BuildContext context, {
    required IconData icon,
    required String label,
  }) {
    final theme = Theme.of(context);
    final isMobile = MediaQuery.sizeOf(context).width < 760;
    return FilledButton.tonalIcon(
      style: FilledButton.styleFrom(
        backgroundColor: isMobile ? theme.colorScheme.primary : theme.colorScheme.surfaceContainerHighest,
        foregroundColor: isMobile ? Colors.white : theme.colorScheme.primary,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      onPressed: () {},
      icon: Icon(icon),
      label: Text(label),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: Center(child: Text('Home')));
  }
}
