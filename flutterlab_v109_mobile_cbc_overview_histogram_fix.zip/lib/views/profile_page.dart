import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../config/google_config.dart';
import '../models/app_user.dart';
import '../providers/auth_notifier.dart';
import '../services/turso_native_service.dart';
import '../widgets/app_sidebar.dart';

class ProfilePage extends ConsumerStatefulWidget {
  const ProfilePage({super.key});

  @override
  ConsumerState<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends ConsumerState<ProfilePage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _loading = true;
  bool _saving = false;
  String? _passwordHash;
  AppUserRole? _role;
  String _subCenterId = 'GLOBAL';
  int? _rowNumber;

  @override
  void initState() {
    super.initState();
    Future.microtask(_loadProfile);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<TursoNativeService> _newSheetsService() async {
    return TursoNativeService(
      serviceAccountJson: await rootBundle.loadString('assets/service-account.json'),
      applicationName: 'flutterlab',
    );
  }

  String _hashPassword(String password) => sha256.convert(utf8.encode(password)).toString();

  Future<void> _loadProfile() async {
    final activeUser = ref.read(authNotifierProvider);
    if (activeUser == null) return;
    TursoNativeService? service;
    try {
      service = await _newSheetsService();
      final rows = await service.fetchRows(
        spreadsheetId: GoogleConfig.spreadsheetId,
        range: 'Users!A:F',
      );
      for (var i = 1; i < rows.length; i++) {
        final row = rows[i];
        if (row.isNotEmpty && row.first.trim() == activeUser.id) {
          _rowNumber = i + 1;
          _usernameController.text = row.length > 1 ? row[1].trim() : '';
          _passwordHash = row.length > 2 ? row[2].trim() : '';
          _nameController.text = row.length > 3 ? row[3].trim() : activeUser.name;
          _role = AppUserRole.values.firstWhere(
            (role) => role.name == (row.length > 4 ? row[4].trim().toLowerCase() : activeUser.role.name),
            orElse: () => activeUser.role,
          );
          _subCenterId = row.length > 5 && row[5].trim().isNotEmpty ? row[5].trim() : (activeUser.subCenterId ?? 'GLOBAL');
          break;
        }
      }
      _nameController.text = _nameController.text.trim().isEmpty ? activeUser.name : _nameController.text;
      _role ??= activeUser.role;
      _subCenterId = _subCenterId.trim().isEmpty ? 'GLOBAL' : _subCenterId;
    } catch (error) {
      _showSnackBar('Load profile failed: $error', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _saveProfile() async {
    if (!_formKey.currentState!.validate()) return;
    final activeUser = ref.read(authNotifierProvider);
    if (activeUser == null) return;
    if (_rowNumber == null) {
      _showSnackBar('Your user row was not found. Please sign out and sign in again.', isError: true);
      return;
    }

    setState(() => _saving = true);
    TursoNativeService? service;
    try {
      service = await _newSheetsService();
      final name = _nameController.text.trim();
      final username = _usernameController.text.trim().toLowerCase();
      final passwordHash = _passwordController.text.trim().isEmpty
          ? (_passwordHash ?? '')
          : _hashPassword(_passwordController.text.trim());

      await service.updateRow(
        spreadsheetId: GoogleConfig.spreadsheetId,
        range: 'Users!A$_rowNumber:F$_rowNumber',
        values: [activeUser.id, username, passwordHash, name, (_role ?? activeUser.role).name, _subCenterId],
      );

      ref.read(authNotifierProvider.notifier).setUser(
            AppUser(
              id: activeUser.id,
              name: name,
              role: _role ?? activeUser.role,
              subCenterId: _subCenterId,
            ),
          );
      _passwordController.clear();
      _passwordHash = passwordHash;
      _showSnackBar('Profile updated successfully');
    } catch (error) {
      _showSnackBar('Save profile failed: $error', isError: true);
    } finally {
      await service?.close();
      if (mounted) setState(() => _saving = false);
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    final theme = Theme.of(context);
    return AppScaffold(
      title: 'Profile',
      selectedRoute: '/profile',
      user: user,
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        gradient: const LinearGradient(colors: [Color(0xFF2563EB), Color(0xFF2563EB)]),
                        boxShadow: [BoxShadow(color: theme.colorScheme.primary.withValues(alpha: 0.22), blurRadius: 26, offset: const Offset(0, 15))],
                      ),
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 32,
                            backgroundColor: Colors.white.withValues(alpha: 0.20),
                            foregroundColor: Colors.white,
                            child: Text((user?.name ?? 'U').characters.first.toUpperCase(), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                          ),
                          const SizedBox(width: 18),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Update Profile', style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w900)),
                                const SizedBox(height: 6),
                                Text('Change your name, username, or password.', style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white.withValues(alpha: 0.88))),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                    Card(
                      elevation: 0,
                      color: theme.colorScheme.surface.withValues(alpha: 0.94),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
                      child: Padding(
                        padding: const EdgeInsets.all(22),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Account Details', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
                              const SizedBox(height: 16),
                              TextFormField(
                                controller: _nameController,
                                decoration: const InputDecoration(labelText: 'Name', prefixIcon: Icon(Icons.badge_rounded), border: OutlineInputBorder()),
                                validator: (value) => value == null || value.trim().isEmpty ? 'Enter name' : null,
                              ),
                              const SizedBox(height: 12),
                              TextFormField(
                                controller: _usernameController,
                                decoration: const InputDecoration(labelText: 'Username', prefixIcon: Icon(Icons.alternate_email_rounded), border: OutlineInputBorder()),
                                validator: (value) => value == null || value.trim().isEmpty ? 'Enter username' : null,
                              ),
                              const SizedBox(height: 12),
                              TextFormField(
                                controller: _passwordController,
                                obscureText: true,
                                decoration: const InputDecoration(labelText: 'New password optional', helperText: 'Leave empty to keep current password.', prefixIcon: Icon(Icons.lock_rounded), border: OutlineInputBorder()),
                              ),
                              const SizedBox(height: 14),
                              Wrap(
                                spacing: 10,
                                runSpacing: 10,
                                children: [
                                  Chip(avatar: const Icon(Icons.security_rounded), label: Text('Role: ${(_role ?? user?.role)?.name ?? '-'}')),
                                  Chip(avatar: const Icon(Icons.storefront_rounded), label: Text('Center: $_subCenterId')),
                                ],
                              ),
                              const SizedBox(height: 18),
                              Align(
                                alignment: Alignment.centerRight,
                                child: FilledButton.icon(
                                  onPressed: _saving ? null : _saveProfile,
                                  icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_rounded),
                                  label: Text(_saving ? 'Saving...' : 'Save Profile'),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}
