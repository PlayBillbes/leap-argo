import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../config/google_config.dart';
import '../models/app_user.dart';
import '../providers/auth_notifier.dart';
import '../providers/tests_provider.dart';
import '../services/turso_native_service.dart';
import '../widgets/app_sidebar.dart';

final testRequirementsProvider = AsyncNotifierProvider<TestRequirementsNotifier, List<TestRequirement>>(
  TestRequirementsNotifier.new,
);

class TestRequirement {
  const TestRequirement({
    required this.rowNumber,
    required this.id,
    required this.testName,
    required this.defaultPrice,
    required this.collectingMethod,
    required this.minimumAmount,
    required this.shakeable,
  });

  final int rowNumber;
  final String id;
  final String testName;
  final String defaultPrice;
  final String collectingMethod;
  final String minimumAmount;
  final String shakeable;

  bool get hasRequirement =>
      collectingMethod.trim().isNotEmpty ||
      minimumAmount.trim().isNotEmpty ||
      shakeable.trim().isNotEmpty;
}

class TestRequirementsNotifier extends AsyncNotifier<List<TestRequirement>> {
  TursoNativeService? _service;
  static const _range = 'Tests!A:F';

  @override
  Future<List<TestRequirement>> build() async => fetchRequirements();

  Future<TursoNativeService> _getService() async {
    _service ??= TursoNativeService(
      serviceAccountJson: await rootBundle.loadString('assets/service-account.json'),
      applicationName: 'flutterlab',
    );
    return _service!;
  }

  Future<List<TestRequirement>> fetchRequirements() async {
    state = const AsyncValue.loading();
    final service = await _getService();
    final rows = await service.fetchRows(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: _range,
    );
    if (rows.isEmpty) {
      state = const AsyncValue.data(<TestRequirement>[]);
      return <TestRequirement>[];
    }

    final headers = rows.first
        .map((h) => h.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''))
        .toList();

    String cell(List<String> row, int index) => index < row.length ? row[index].trim() : '';
    String mapped(Map<String, String> map, List<String> keys) {
      for (final key in keys) {
        final value = map[key]?.trim() ?? '';
        if (value.isNotEmpty) return value;
      }
      return '';
    }

    final requirements = <TestRequirement>[];
    for (var i = 1; i < rows.length; i++) {
      final row = rows[i];
      final map = <String, String>{};
      for (var col = 0; col < headers.length; col++) {
        map[headers[col]] = cell(row, col);
      }

      final id = mapped(map, const ['id', 'testid']).isNotEmpty ? mapped(map, const ['id', 'testid']) : cell(row, 0);
      final name = mapped(map, const ['testname', 'name']).isNotEmpty ? mapped(map, const ['testname', 'name']) : cell(row, 1);
      final price = mapped(map, const ['defaultprice', 'price']).isNotEmpty ? mapped(map, const ['defaultprice', 'price']) : cell(row, 2);
      if (id.isEmpty && name.isEmpty) continue;

      requirements.add(
        TestRequirement(
          rowNumber: i + 1,
          id: id,
          testName: name,
          defaultPrice: price,
          collectingMethod: mapped(map, const ['collectingmethod', 'collectionmethod', 'tube']).isNotEmpty
              ? mapped(map, const ['collectingmethod', 'collectionmethod', 'tube'])
              : cell(row, 3),
          minimumAmount: mapped(map, const ['minimumamount', 'minimumsample', 'amount']).isNotEmpty
              ? mapped(map, const ['minimumamount', 'minimumsample', 'amount'])
              : cell(row, 4),
          shakeable: mapped(map, const ['shakeable', 'shakable', 'shake']).isNotEmpty
              ? mapped(map, const ['shakeable', 'shakable', 'shake'])
              : cell(row, 5),
        ),
      );
    }

    state = AsyncValue.data(requirements);
    return requirements;
  }

  Future<void> _ensureHeaders(TursoNativeService service) async {
    final rows = await service.fetchRows(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'Tests!A1:F1',
    );
    final existing = rows.isNotEmpty ? List<String>.from(rows.first) : <String>[];
    final headers = <String>[
      existing.isNotEmpty && existing[0].trim().isNotEmpty ? existing[0] : 'id',
      existing.length > 1 && existing[1].trim().isNotEmpty ? existing[1] : 'testName',
      existing.length > 2 && existing[2].trim().isNotEmpty ? existing[2] : 'defaultPrice',
      'collectingMethod',
      'minimumAmount',
      'shakeable',
    ];
    await service.updateRow(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'Tests!A1:F1',
      values: headers,
    );
  }

  Future<void> saveRequirement({
    required TestRequirement test,
    required String collectingMethod,
    required String minimumAmount,
    required String shakeable,
  }) async {
    final service = await _getService();
    await _ensureHeaders(service);
    await service.updateRow(
      spreadsheetId: GoogleConfig.spreadsheetId,
      range: 'Tests!A${test.rowNumber}:F${test.rowNumber}',
      values: [
        test.id,
        test.testName,
        test.defaultPrice,
        collectingMethod.trim(),
        minimumAmount.trim(),
        shakeable.trim(),
      ],
    );
    await fetchRequirements();
  }
}

class TestRequirementsPage extends ConsumerStatefulWidget {
  const TestRequirementsPage({super.key});

  @override
  ConsumerState<TestRequirementsPage> createState() => _TestRequirementsPageState();
}

class _TestRequirementsPageState extends ConsumerState<TestRequirementsPage> {
  final _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _openEditor(TestRequirement test) async {
    final methodController = TextEditingController(text: test.collectingMethod);
    final amountController = TextEditingController(text: test.minimumAmount);
    final rawShakeable = test.shakeable.trim().toLowerCase();
    String shakeable = rawShakeable == 'yes' || rawShakeable == 'shakeable'
        ? 'Shakeable'
        : 'Not Shakeable';
    final formKey = GlobalKey<FormState>();

    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text('Requirements: ${test.testName}'),
          content: Form(
            key: formKey,
            child: SizedBox(
              width: 520,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: methodController,
                    decoration: const InputDecoration(
                      labelText: 'Collecting Method',
                      hintText: 'Plain Tube, EDTA Tube, Serum Tube...',
                      prefixIcon: Icon(Icons.science_rounded),
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) => value == null || value.trim().isEmpty
                        ? 'Enter collecting method'
                        : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: amountController,
                    decoration: const InputDecoration(
                      labelText: 'Minimum Amount',
                      hintText: '5cc, 2ml, 1 tube...',
                      prefixIcon: Icon(Icons.water_drop_rounded),
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) => value == null || value.trim().isEmpty
                        ? 'Enter minimum amount'
                        : null,
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: shakeable,
                    decoration: const InputDecoration(
                      labelText: 'Shakeable',
                      prefixIcon: Icon(Icons.sync_rounded),
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      DropdownMenuItem(value: 'Shakeable', child: Text('Shakeable')),
                      DropdownMenuItem(value: 'Not Shakeable', child: Text('Not Shakeable')),
                    ],
                    onChanged: (value) => setDialogState(() => shakeable = value ?? 'Not Shakeable'),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      ActionChip(
                        avatar: const Icon(Icons.local_drink_rounded, size: 18),
                        label: const Text('Plain Tube'),
                        onPressed: () => methodController.text = 'Plain Tube',
                      ),
                      ActionChip(
                        avatar: const Icon(Icons.biotech_rounded, size: 18),
                        label: const Text('EDTA Tube'),
                        onPressed: () => methodController.text = 'EDTA Tube',
                      ),
                      ActionChip(
                        avatar: const Icon(Icons.water_drop_rounded, size: 18),
                        label: const Text('5cc'),
                        onPressed: () => amountController.text = '5cc',
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Cancel')),
            FilledButton.icon(
              onPressed: () {
                if (!formKey.currentState!.validate()) return;
                Navigator.of(context).pop(true);
              },
              icon: const Icon(Icons.save_rounded),
              label: const Text('Save'),
            ),
          ],
        ),
      ),
    );

    if (saved != true) return;
    try {
      await ref.read(testRequirementsProvider.notifier).saveRequirement(
            test: test,
            collectingMethod: methodController.text,
            minimumAmount: amountController.text,
            shakeable: shakeable,
          );
      if (!mounted) return;
      ref.invalidate(testsProvider);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Test requirements saved.')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Save failed: $error'), backgroundColor: Theme.of(context).colorScheme.error),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authNotifierProvider);
    final requirementsAsync = ref.watch(testRequirementsProvider);
    return AppScaffold(
      title: 'Test Requirements',
      selectedRoute: '/test-requirements',
      user: user,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Refresh requirements',
          onPressed: () => ref.invalidate(testRequirementsProvider),
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        child: requirementsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, _) => Center(child: Text('Requirements load failed: $error')),
          data: (requirements) => _buildContent(context, requirements),
        ),
      ),
    );
  }

  Widget _buildContent(BuildContext context, List<TestRequirement> requirements) {
    final theme = Theme.of(context);
    final query = _searchController.text.trim().toLowerCase();
    final filtered = query.isEmpty
        ? requirements
        : requirements.where((test) {
            return test.testName.toLowerCase().contains(query) ||
                test.id.toLowerCase().contains(query) ||
                test.collectingMethod.toLowerCase().contains(query);
          }).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            gradient: const LinearGradient(colors: [Color(0xFF0B57B7), Color(0xFF2563EB), Color(0xFF2563EB)]),
            boxShadow: [
              BoxShadow(
                color: theme.colorScheme.primary.withValues(alpha: 0.22),
                blurRadius: 26,
                offset: const Offset(0, 15),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.18),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: const Icon(Icons.fact_check_rounded, color: Colors.white, size: 36),
              ),
              const SizedBox(width: 18),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Test Sample Requirements', style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 6),
                    Text('Lab tech can define collection method, minimum sample amount, and shake instruction for every test.', style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white.withValues(alpha: 0.88))),
                  ],
                ),
              ),
              Chip(
                avatar: const Icon(Icons.assignment_turned_in_rounded, size: 18),
                label: Text('${requirements.where((test) => test.hasRequirement).length}/${requirements.length} set'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        TextField(
          controller: _searchController,
          onChanged: (_) => setState(() {}),
          decoration: InputDecoration(
            hintText: 'Search test name, ID, or tube method...',
            prefixIcon: const Icon(Icons.search_rounded),
            suffixIcon: _searchController.text.isEmpty
                ? null
                : IconButton(
                    onPressed: () {
                      _searchController.clear();
                      setState(() {});
                    },
                    icon: const Icon(Icons.clear_rounded),
                  ),
            filled: true,
            fillColor: theme.colorScheme.surface.withValues(alpha: 0.94),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
          ),
        ),
        const SizedBox(height: 16),
        Expanded(
          child: filtered.isEmpty
              ? const Center(child: Text('No tests found.'))
              : ListView.separated(
                  itemCount: filtered.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final test = filtered[index];
                    return _RequirementTile(
                      test: test,
                      onEdit: () => _openEditor(test),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

class _RequirementTile extends StatelessWidget {
  const _RequirementTile({required this.test, required this.onEdit});

  final TestRequirement test;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        color: theme.colorScheme.surface.withValues(alpha: 0.94),
        border: Border.all(
          color: test.hasRequirement
              ? theme.colorScheme.primary.withValues(alpha: 0.24)
              : theme.colorScheme.outlineVariant,
        ),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 14, offset: const Offset(0, 7))],
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: test.hasRequirement ? theme.colorScheme.primaryContainer : theme.colorScheme.surfaceContainerHighest,
            child: Icon(test.hasRequirement ? Icons.check_rounded : Icons.tune_rounded),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(test.testName.isEmpty ? test.id : test.testName, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _InfoChip(icon: Icons.science_rounded, label: 'Method', value: test.collectingMethod.isEmpty ? '-' : test.collectingMethod),
                    _InfoChip(icon: Icons.water_drop_rounded, label: 'Minimum', value: test.minimumAmount.isEmpty ? '-' : test.minimumAmount),
                    _InfoChip(icon: Icons.sync_rounded, label: 'Shake', value: test.shakeable.isEmpty ? '-' : test.shakeable),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          FilledButton.tonalIcon(
            onPressed: onEdit,
            icon: const Icon(Icons.edit_rounded),
            label: const Text('Edit'),
          ),
        ],
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  const _InfoChip({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Chip(
      avatar: Icon(icon, size: 18),
      label: Text('$label: $value'),
      visualDensity: VisualDensity.compact,
    );
  }
}
