import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../models/app_user.dart';
import '../models/blood_sample.dart';
import '../models/lab_test.dart';
import '../models/sub_center_pricing.dart';
import '../providers/auth_notifier.dart';
import '../providers/sample_dashboard_controller.dart';
import '../providers/tests_provider.dart';
import '../widgets/app_sidebar.dart';

class AdminAnalyticsPage extends ConsumerWidget {
  const AdminAnalyticsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authNotifierProvider);
    final samplesAsync = ref.watch(sampleDashboardControllerProvider);
    final testsAsync = ref.watch(testsProvider);
    final pricingsAsync = ref.watch(pricingsProvider);

    return AppScaffold(
      title: 'Analytics',
      selectedRoute: '/admin-analytics',
      user: user,
      actions: [
        IconButton.filledTonal(
          tooltip: 'Refresh analytics',
          onPressed: () {
            ref.invalidate(sampleDashboardControllerProvider);
            ref.invalidate(testsProvider);
            ref.invalidate(pricingsProvider);
          },
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      body: LayoutBuilder(
        builder: (context, constraints) {
          final isMobile = constraints.maxWidth < 760;
          return Padding(
            padding: EdgeInsets.fromLTRB(isMobile ? 12 : 24, 8, isMobile ? 12 : 24, isMobile ? 16 : 24),
            child: samplesAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, _) => Center(child: Text('Failed to load analytics: $error')),
              data: (samples) {
                final tests = testsAsync.maybeWhen(data: (v) => v, orElse: () => const <LabTest>[]);
                final pricings = pricingsAsync.maybeWhen(data: (v) => v, orElse: () => const <SubCenterPricing>[]);
                return _AdminAnalyticsContent(user: user, samples: samples, tests: tests, pricings: pricings);
              },
            ),
          );
        },
      ),
    );
  }
}

class _AdminAnalyticsContent extends StatelessWidget {
  const _AdminAnalyticsContent({required this.user, required this.samples, required this.tests, required this.pricings});

  final AppUser? user;
  final List<BloodSample> samples;
  final List<LabTest> tests;
  final List<SubCenterPricing> pricings;

  @override
  Widget build(BuildContext context) {
    final centerId = ((user?.subCenterId ?? '').trim().isEmpty) ? 'GLOBAL' : user!.subCenterId!.trim();
    final analytics = _AdminAnalytics(centerId: centerId, samples: samples, tests: tests, pricings: pricings);
    final now = DateTime.now();
    final thisMonth = _monthName(now.month);
    final rows = analytics.monthlyRows(now.year);
    final visibleRows = rows.where((r) => r.revenue > 0 || r.tests > 0).toList();
    final testTotals = analytics.testsByName();
    if (MediaQuery.sizeOf(context).width < 760) {
      return _MobileAdminDashboard(analytics: analytics, now: now, thisMonth: thisMonth);
    }

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Hero(centerId: centerId),
          const SizedBox(height: 18),
          LayoutBuilder(builder: (context, constraints) {
            final compact = constraints.maxWidth < 980;
            final cards = [
              _KpiCard(title: '$thisMonth Cost', value: analytics.costForMonth(now).toStringAsFixed(0), subtitle: 'Global cost + refer fee', icon: Icons.account_balance_wallet_rounded, color: const Color(0xFFEF4444)),
              _KpiCard(title: '$thisMonth Profit', value: analytics.profitForMonth(now).toStringAsFixed(0), subtitle: 'Custom - global - refer fee', icon: Icons.trending_up_rounded, color: const Color(0xFF10B981)),
              _KpiCard(title: '$thisMonth Refer Fee', value: analytics.referredFeeForMonth(now).toStringAsFixed(0), subtitle: 'Paid when not Self', icon: Icons.person_pin_circle_rounded, color: const Color(0xFFF59E0B)),
              _KpiCard(title: '$thisMonth Revenue', value: analytics.revenueForMonth(now).toStringAsFixed(0), subtitle: 'Customer price total', icon: Icons.payments_rounded, color: const Color(0xFF3B82F6)),
              _KpiCard(title: 'Total Tests', value: analytics.totalTests().toString(), subtitle: '${analytics.testsForMonth(now)} this month', icon: Icons.biotech_rounded, color: const Color(0xFF8B5CF6)),
            ];
            if (compact) return Column(children: cards.map((c) => Padding(padding: const EdgeInsets.only(bottom: 12), child: c)).toList());
            return Row(children: [for (var i=0;i<cards.length;i++) ...[Expanded(child: cards[i]), if (i != cards.length-1) const SizedBox(width: 14)]]);
          }),
          const SizedBox(height: 18),
          LayoutBuilder(builder: (context, constraints) {
            final compact = constraints.maxWidth < 980;
            final left = _GlassPanel(
              title: 'Monthly Cost vs Profit',
              subtitle: 'Clean grouped graph with monthly comparison',
              icon: Icons.stacked_bar_chart_rounded,
              accent: const Color(0xFF14B8A6),
              child: SizedBox(
                height: 340,
                child: _PrettyCostProfitChart(rows: rows),
              ),
            );
            final right = _GlassPanel(
              title: 'Tests by Month',
              subtitle: 'Stylish test volume graph by month',
              icon: Icons.insights_rounded,
              accent: const Color(0xFF2563EB),
              child: SizedBox(
                height: 340,
                child: _PrettyTestsChart(rows: rows),
              ),
            );
            if (compact) return Column(children: [left, const SizedBox(height: 14), right]);
            return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: left), const SizedBox(width: 14), Expanded(child: right)]);
          }),
          const SizedBox(height: 18),
          LayoutBuilder(builder: (context, constraints) {
            final compact = constraints.maxWidth < 980;
            final trend = _GlassPanel(
              title: 'Monthly Summary',
              subtitle: 'Cost, profit, refer fee, revenue and tests by month',
              icon: Icons.calendar_month_rounded,
              accent: const Color(0xFF0EA5E9),
              child: visibleRows.isEmpty ? const _Empty(message: 'No monthly data yet.') : Column(children: [for (final r in visibleRows) _MonthTile(row: r)]),
            );
            final testsCard = _GlassPanel(
              title: 'Total Tests by Test Name',
              subtitle: 'Example: Total CBC - 200, Total ESR - 100',
              icon: Icons.science_rounded,
              accent: const Color(0xFF8B5CF6),
              child: testTotals.isEmpty ? const _Empty(message: 'No test totals yet.') : Wrap(spacing: 10, runSpacing: 10, children: [for (final e in testTotals.entries) Chip(avatar: CircleAvatar(child: Text('${e.value}')), label: Text('Total ${e.key} - ${e.value}'))]),
            );
            if (compact) return Column(children: [trend, const SizedBox(height: 14), testsCard]);
            return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: trend), const SizedBox(width: 14), Expanded(child: testsCard)]);
          }),
        ],
      ),
    );
  }
}


class _MobileAdminDashboard extends StatefulWidget {
  const _MobileAdminDashboard({required this.analytics, required this.now, required this.thisMonth});

  final _AdminAnalytics analytics;
  final DateTime now;
  final String thisMonth;

  @override
  State<_MobileAdminDashboard> createState() => _MobileAdminDashboardState();
}

class _MobileAdminDashboardState extends State<_MobileAdminDashboard> {
  late int _selectedYear;
  late int _selectedMonth;
  int _selectedSection = 0;

  @override
  void initState() {
    super.initState();
    _selectedYear = widget.now.year;
    _selectedMonth = 0;
  }

  List<int> get _years {
    final values = <int>{widget.now.year};
    for (final sample in widget.analytics.centerSamples) {
      final createdAt = sample.createdAt?.toLocal();
      if (createdAt != null) values.add(createdAt.year);
    }
    final list = values.toList()..sort((a, b) => b.compareTo(a));
    return list;
  }

  @override
  Widget build(BuildContext context) {
    final rows = widget.analytics.monthlyRows(_selectedYear);
    final filteredRows = _selectedMonth == 0 ? rows : rows.where((row) => row.month == _selectedMonth).toList();
    final periodLabel = _selectedMonth == 0 ? 'All Months' : _monthName(_selectedMonth);
    final totalRevenue = filteredRows.fold<double>(0, (sum, row) => sum + row.revenue);
    final totalReferFee = filteredRows.fold<double>(0, (sum, row) => sum + row.referredFee);
    final totalCost = filteredRows.fold<double>(0, (sum, row) => sum + row.cost);
    final totalProfit = filteredRows.fold<double>(0, (sum, row) => sum + row.profit);
    final referItems = _referFeeItems(year: _selectedYear, month: _selectedMonth);

    return SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 110),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _MobileAnalyticsSectionTabs(
            selectedIndex: _selectedSection,
            onSelected: (index) => setState(() => _selectedSection = index),
          ),
          const SizedBox(height: 14),
          _MobileAnalyticsFilterRow(
            years: _years,
            selectedYear: _selectedYear,
            selectedMonth: _selectedMonth,
            onYearChanged: (value) => setState(() => _selectedYear = value ?? _selectedYear),
            onMonthChanged: (value) => setState(() => _selectedMonth = value ?? 0),
          ),
          const SizedBox(height: 16),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 220),
            switchInCurve: Curves.easeOutCubic,
            switchOutCurve: Curves.easeInCubic,
            child: _selectedSection == 0
                ? _MobileOverviewSection(
                    key: const ValueKey('overview'),
                    periodLabel: periodLabel,
                    totalProfit: totalProfit,
                    revenue: totalRevenue,
                    globalCost: totalCost,
                    referFee: totalReferFee,
                    rows: rows,
                  )
                : _MobileReferFeeSection(
                    key: const ValueKey('refer-fee'),
                    periodLabel: periodLabel,
                    totalReferFee: totalReferFee,
                    items: referItems,
                  ),
          ),
        ],
      ),
    );
  }

  List<_ReferFeePersonItem> _referFeeItems({required int year, required int month}) {
    final totals = <String, _ReferFeePersonAccumulator>{};
    for (final sample in widget.analytics.centerSamples) {
      final createdAt = sample.createdAt?.toLocal();
      if (createdAt == null || createdAt.year != year) continue;
      if (month != 0 && createdAt.month != month) continue;
      final fee = widget.analytics._sampleReferredFee(sample);
      if (fee <= 0) continue;
      final rawName = (sample.referredPersonName ?? '').trim();
      final rawId = (sample.referredPersonId ?? '').trim();
      final label = rawName.isNotEmpty && rawName.toLowerCase() != 'self'
          ? rawName
          : (rawId.isNotEmpty && rawId.toLowerCase() != 'self' ? rawId : 'Unknown referral');
      final key = label.toLowerCase();
      final current = totals[key] ?? _ReferFeePersonAccumulator(label: label);
      current.total += fee;
      current.count += 1;
      totals[key] = current;
    }
    final items = totals.values
        .map((item) => _ReferFeePersonItem(label: item.label, amount: item.total, samples: item.count))
        .toList()
      ..sort((a, b) => b.amount.compareTo(a.amount));
    return items;
  }

  Future<void> _showFilterSheet() async {
    var tempYear = _selectedYear;
    var tempMonth = _selectedMonth;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return SafeArea(
              child: Container(
                padding: const EdgeInsets.fromLTRB(18, 12, 18, 18),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        const Expanded(child: Text('Filter Monthly Summary', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
                        IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<int>(
                      value: tempYear,
                      decoration: _mobileAdminFilterInput('Year', Icons.calendar_today_rounded),
                      items: [for (final year in _years) DropdownMenuItem(value: year, child: Text(year.toString()))],
                      onChanged: (value) {
                        if (value == null) return;
                        setSheetState(() => tempYear = value);
                      },
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<int>(
                      value: tempMonth,
                      decoration: _mobileAdminFilterInput('Month', Icons.event_rounded),
                      items: [for (var month = 1; month <= 12; month++) DropdownMenuItem(value: month, child: Text(_monthName(month)))],
                      onChanged: (value) {
                        if (value == null) return;
                        setSheetState(() => tempMonth = value);
                      },
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () {
                              setSheetState(() {
                                tempYear = widget.now.year;
                                tempMonth = widget.now.month;
                              });
                            },
                            child: const Text('Reset'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: FilledButton(
                            onPressed: () {
                              setState(() {
                                _selectedYear = tempYear;
                                _selectedMonth = tempMonth;
                              });
                              Navigator.pop(context);
                            },
                            child: const Text('Apply Filter'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  InputDecoration _mobileAdminFilterInput(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon),
      filled: true,
      fillColor: const Color(0xFFF8FAFC),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFE5E7EB))),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFF0B57B7), width: 1.5)),
    );
  }
}


class _MobileAnalyticsSectionTabs extends StatelessWidget {
  const _MobileAnalyticsSectionTabs({required this.selectedIndex, required this.onSelected});

  final int selectedIndex;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    const labels = ['Overview', 'Refer Fee'];
    return Container(
      decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: Color(0xFFE5E7EB)))),
      child: Row(
        children: [
          for (var i = 0; i < labels.length; i++)
            Expanded(
              child: InkWell(
                onTap: () => onSelected(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  decoration: BoxDecoration(
                    border: Border(bottom: BorderSide(color: selectedIndex == i ? const Color(0xFF2563EB) : Colors.transparent, width: 2.2)),
                  ),
                  child: Text(
                    labels[i],
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      color: selectedIndex == i ? const Color(0xFF2563EB) : const Color(0xFF64748B),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _MobileAnalyticsFilterRow extends StatelessWidget {
  const _MobileAnalyticsFilterRow({
    required this.years,
    required this.selectedYear,
    required this.selectedMonth,
    required this.onYearChanged,
    required this.onMonthChanged,
  });

  final List<int> years;
  final int selectedYear;
  final int selectedMonth;
  final ValueChanged<int?> onYearChanged;
  final ValueChanged<int?> onMonthChanged;

  @override
  Widget build(BuildContext context) {
    final inputBorder = OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFE5E7EB)));
    return Row(
      children: [
        Expanded(
          child: DropdownButtonFormField<int>(
            value: selectedYear,
            decoration: InputDecoration(labelText: 'Year', filled: true, fillColor: Colors.white, border: inputBorder, enabledBorder: inputBorder),
            items: [for (final year in years) DropdownMenuItem(value: year, child: Text(year.toString()))],
            onChanged: onYearChanged,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: DropdownButtonFormField<int>(
            value: selectedMonth,
            decoration: InputDecoration(labelText: 'Month', filled: true, fillColor: Colors.white, border: inputBorder, enabledBorder: inputBorder),
            items: const [
              DropdownMenuItem(value: 0, child: Text('All Months')),
              DropdownMenuItem(value: 1, child: Text('January')),
              DropdownMenuItem(value: 2, child: Text('February')),
              DropdownMenuItem(value: 3, child: Text('March')),
              DropdownMenuItem(value: 4, child: Text('April')),
              DropdownMenuItem(value: 5, child: Text('May')),
              DropdownMenuItem(value: 6, child: Text('June')),
              DropdownMenuItem(value: 7, child: Text('July')),
              DropdownMenuItem(value: 8, child: Text('August')),
              DropdownMenuItem(value: 9, child: Text('September')),
              DropdownMenuItem(value: 10, child: Text('October')),
              DropdownMenuItem(value: 11, child: Text('November')),
              DropdownMenuItem(value: 12, child: Text('December')),
            ],
            onChanged: onMonthChanged,
          ),
        ),
      ],
    );
  }
}

class _MobileOverviewSection extends StatelessWidget {
  const _MobileOverviewSection({
    super.key,
    required this.periodLabel,
    required this.totalProfit,
    required this.revenue,
    required this.globalCost,
    required this.referFee,
    required this.rows,
  });

  final String periodLabel;
  final double totalProfit;
  final double revenue;
  final double globalCost;
  final double referFee;
  final List<_MonthRow> rows;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _MobileProfitOverviewCard(
          periodLabel: periodLabel,
          totalProfit: totalProfit,
          revenue: revenue,
          globalCost: globalCost,
          referFee: referFee,
        ),
        const SizedBox(height: 16),
        _MobileProfitTrendCard(rows: rows),
      ],
    );
  }
}

class _MobileReferFeeSection extends StatelessWidget {
  const _MobileReferFeeSection({super.key, required this.periodLabel, required this.totalReferFee, required this.items});

  final String periodLabel;
  final double totalReferFee;
  final List<_ReferFeePersonItem> items;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _MobileAnalyticsCard(
          title: 'Refer Fee Overview',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(periodLabel, style: const TextStyle(fontSize: 12, color: Color(0xFF64748B), fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              const Text('Total Refer Fee', style: TextStyle(fontSize: 13, color: Color(0xFF334155), fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(_formatMoney(totalReferFee), style: const TextStyle(fontSize: 28, color: Color(0xFFF59E0B), fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              const Text('Paid only when referral is not Self.', style: TextStyle(fontSize: 12, color: Color(0xFF64748B), fontWeight: FontWeight.w700)),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _MobileAnalyticsCard(
          title: 'Refer Fee by Person',
          child: items.isEmpty
              ? const Padding(padding: EdgeInsets.symmetric(vertical: 10), child: Text('No refer fee data for this filter.'))
              : Column(
                  children: [
                    for (var i = 0; i < items.length; i++)
                      Padding(
                        padding: EdgeInsets.only(bottom: i == items.length - 1 ? 0 : 12),
                        child: Row(
                          children: [
                            Container(
                              width: 24,
                              height: 24,
                              alignment: Alignment.center,
                              decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFFFFFBEB)),
                              child: Text('${i + 1}', style: const TextStyle(fontSize: 11, color: Color(0xFFF59E0B), fontWeight: FontWeight.w900)),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(items[i].label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF0F172A))),
                                  Text('${items[i].samples} samples', style: const TextStyle(fontSize: 11, color: Color(0xFF64748B), fontWeight: FontWeight.w700)),
                                ],
                              ),
                            ),
                            Text(_formatMoney(items[i].amount), style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF0F172A))),
                          ],
                        ),
                      ),
                  ],
                ),
        ),
      ],
    );
  }
}

class _MobileProfitOverviewCard extends StatelessWidget {
  const _MobileProfitOverviewCard({
    required this.periodLabel,
    required this.totalProfit,
    required this.revenue,
    required this.globalCost,
    required this.referFee,
  });

  final String periodLabel;
  final double totalProfit;
  final double revenue;
  final double globalCost;
  final double referFee;

  @override
  Widget build(BuildContext context) {
    return _MobileAnalyticsCard(
      title: 'Profit Overview',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(periodLabel, style: const TextStyle(fontSize: 12, color: Color(0xFF64748B), fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          const Text('Total Profit', style: TextStyle(fontSize: 13, color: Color(0xFF334155), fontWeight: FontWeight.w800)),
          const SizedBox(height: 5),
          Text(_formatMoney(totalProfit), style: const TextStyle(fontSize: 28, color: Color(0xFF16A34A), fontWeight: FontWeight.w900, letterSpacing: -0.5)),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(child: _MobileMoneyColumn(label: 'Revenue', value: revenue)),
              Expanded(child: _MobileMoneyColumn(label: 'Global Cost', value: globalCost)),
              Expanded(child: _MobileMoneyColumn(label: 'Refer Fee', value: referFee)),
            ],
          ),
          const SizedBox(height: 14),
          const Text('Profit = Custom Price - Global Price - Refer Fee', style: TextStyle(fontSize: 12, color: Color(0xFF64748B), fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _MobileMoneyColumn extends StatelessWidget {
  const _MobileMoneyColumn({required this.label, required this.value});
  final String label;
  final double value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 11, color: Color(0xFF64748B), fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        Text(_formatMoney(value), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Color(0xFF0F172A))),
      ],
    );
  }
}

class _MobileProfitTrendCard extends StatelessWidget {
  const _MobileProfitTrendCard({required this.rows});
  final List<_MonthRow> rows;

  @override
  Widget build(BuildContext context) {
    return _MobileAnalyticsCard(
      title: 'Monthly Profit Trend',
      child: SizedBox(height: 210, child: _MobileProfitLineChart(rows: rows)),
    );
  }
}

class _MobileProfitLineChart extends StatelessWidget {
  const _MobileProfitLineChart({required this.rows});
  final List<_MonthRow> rows;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _MobileProfitLinePainter(rows),
      child: Padding(
        padding: const EdgeInsets.only(top: 12, bottom: 4),
        child: Align(
          alignment: Alignment.bottomCenter,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              for (final row in rows)
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Text(_shortMonth(row.month), textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Color(0xFF64748B))),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MobileProfitLinePainter extends CustomPainter {
  const _MobileProfitLinePainter(this.rows);
  final List<_MonthRow> rows;

  @override
  void paint(Canvas canvas, Size size) {
    const topPadding = 12.0;
    const bottomPadding = 38.0;
    final chartHeight = size.height - topPadding - bottomPadding;
    final gridPaint = Paint()..color = const Color(0xFFE5E7EB)..strokeWidth = 1;
    for (var i = 0; i < 4; i++) {
      final y = topPadding + (chartHeight * i / 3);
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }
    final maxProfit = rows.fold<double>(0, (max, row) => row.profit > max ? row.profit : max);
    final safeMax = maxProfit <= 0 ? 1.0 : maxProfit;
    final points = <Offset>[];
    for (var i = 0; i < rows.length; i++) {
      final x = rows.length == 1 ? size.width / 2 : (size.width * i / (rows.length - 1));
      final normalized = (rows[i].profit / safeMax).clamp(0.0, 1.0);
      final y = topPadding + chartHeight - normalized * (chartHeight - 18);
      points.add(Offset(x, y));
    }
    if (points.length < 2) return;
    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (final point in points.skip(1)) {
      path.lineTo(point.dx, point.dy);
    }
    final linePaint = Paint()
      ..color = const Color(0xFF15803D)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(path, linePaint);
    for (final point in points) {
      canvas.drawCircle(point, 5.2, Paint()..color = const Color(0xFFBBF7D0).withValues(alpha: 0.75));
      canvas.drawCircle(point, 3.0, Paint()..color = const Color(0xFF15803D));
    }
  }

  @override
  bool shouldRepaint(covariant _MobileProfitLinePainter oldDelegate) => oldDelegate.rows != rows;
}

class _MobileAnalyticsCard extends StatelessWidget {
  const _MobileAnalyticsCard({required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFE5E7EB)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 16, offset: const Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: Color(0xFF0F172A))),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class _ReferFeePersonAccumulator {
  _ReferFeePersonAccumulator({required this.label});
  final String label;
  double total = 0;
  int count = 0;
}

class _ReferFeePersonItem {
  const _ReferFeePersonItem({required this.label, required this.amount, required this.samples});
  final String label;
  final double amount;
  final int samples;
}

class _MobileSectionTitle extends StatelessWidget {
  const _MobileSectionTitle(this.title);
  final String title;

  @override
  Widget build(BuildContext context) {
    return Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900, color: const Color(0xFF0F172A)));
  }
}

class _MobileAdminMetricCard extends StatelessWidget {
  const _MobileAdminMetricCard({required this.value, required this.title, required this.subtitle, required this.color, required this.background});

  final String value;
  final String title;
  final String subtitle;
  final Color color;
  final Color background;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 126),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE5E7EB)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.035), blurRadius: 12, offset: const Offset(0, 6))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: color, fontSize: 26, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Color(0xFF1F2937))),
          const SizedBox(height: 3),
          Text(subtitle, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Color(0xFF374151))),
        ],
      ),
    );
  }
}

class _SummaryLine {
  const _SummaryLine({required this.label, required this.value});
  final String label;
  final String value;
}

class _MobileSummaryCard extends StatelessWidget {
  const _MobileSummaryCard({required this.title, required this.rows, required this.onFilter});
  final String title;
  final List<_SummaryLine> rows;
  final VoidCallback onFilter;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 10),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFFE5E7EB))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Color(0xFF0F172A)))),
              IconButton.filledTonal(
                style: IconButton.styleFrom(backgroundColor: const Color(0xFFEFF6FF), foregroundColor: const Color(0xFF0B57B7)),
                tooltip: 'Filter monthly summary',
                onPressed: onFilter,
                icon: const Icon(Icons.filter_alt_rounded),
              ),
            ],
          ),
          const SizedBox(height: 12),
          for (final row in rows)
            Container(
              padding: const EdgeInsets.symmetric(vertical: 13),
              decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFFE5E7EB)))),
              child: Row(
                children: [
                  Expanded(child: Text(row.label, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF374151)))),
                  Text(row.value, style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF0F172A))),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _MobileRecentSamplesCard extends StatelessWidget {
  const _MobileRecentSamplesCard({required this.samples});
  final List<BloodSample> samples;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 8),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFFE5E7EB))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(child: Text('Recent Samples', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Color(0xFF0F172A)))),
              TextButton(onPressed: () => context.go('/search'), child: const Text('View all')),
            ],
          ),
          const SizedBox(height: 6),
          if (samples.isEmpty)
            const Padding(padding: EdgeInsets.symmetric(vertical: 14), child: Text('No recent samples yet.'))
          else
            for (final sample in samples)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(sample.id, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF111827))),
                          const SizedBox(height: 4),
                          Text(sample.patientName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF374151), fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                    _MobileStatusBadge(status: sample.status),
                  ],
                ),
              ),
        ],
      ),
    );
  }
}

class _MobileStatusBadge extends StatelessWidget {
  const _MobileStatusBadge({required this.status});
  final BloodSampleStatus status;

  @override
  Widget build(BuildContext context) {
    final label = switch (status) {
      BloodSampleStatus.pending => 'Pending',
      BloodSampleStatus.processing => 'Processing',
      BloodSampleStatus.completed => 'Completed',
    };
    final color = switch (status) {
      BloodSampleStatus.pending => const Color(0xFFD97706),
      BloodSampleStatus.processing => const Color(0xFF2563EB),
      BloodSampleStatus.completed => const Color(0xFF059669),
    };
    final bg = switch (status) {
      BloodSampleStatus.pending => const Color(0xFFFFF7ED),
      BloodSampleStatus.processing => const Color(0xFFEFF6FF),
      BloodSampleStatus.completed => const Color(0xFFECFDF5),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10)),
      child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12)),
    );
  }
}


String _formatMoney(num value) => 'Ks ${_formatNumber(value)}';

String _formatNumber(num value) {
  final roundedValue = value.round();
  final sign = roundedValue < 0 ? '-' : '';
  final raw = roundedValue.abs().toString();
  final buffer = StringBuffer(sign);
  for (var i = 0; i < raw.length; i++) {
    final remaining = raw.length - i;
    buffer.write(raw[i]);
    if (remaining > 1 && remaining % 3 == 1) buffer.write(',');
  }
  return buffer.toString();
}


class _AdminAnalytics {
  const _AdminAnalytics({required this.centerId, required this.samples, required this.tests, required this.pricings});
  final String centerId;
  final List<BloodSample> samples;
  final List<LabTest> tests;
  final List<SubCenterPricing> pricings;

  List<BloodSample> get centerSamples => samples.where((s) => _norm(s.subCenterId) == _norm(centerId)).toList();
  int totalTests() => centerSamples.fold(0, (sum, s) => sum + s.testIds.length);
  int samplesForDay(DateTime d) => centerSamples.where((s) => _sameDay(s.createdAt, d)).length;
  int completedTestsForDay(DateTime d) => centerSamples.where((s) => s.status == BloodSampleStatus.completed && _sameDay(s.createdAt, d)).fold(0, (sum, s) => sum + s.testIds.length);
  double revenueForDay(DateTime d) => centerSamples.where((s) => _sameDay(s.createdAt, d)).fold(0, (sum, s) => sum + _sampleRevenue(s));
  double profitForDay(DateTime d) => centerSamples.where((s) => _sameDay(s.createdAt, d)).fold(0, (sum, s) => sum + _sampleProfit(s));
  int testsForMonth(DateTime d) => centerSamples.where((s) => _sameMonth(s.createdAt, d)).fold(0, (sum, s) => sum + s.testIds.length);
  double revenueForMonth(DateTime d) => centerSamples.where((s) => _sameMonth(s.createdAt, d)).fold(0, (sum, s) => sum + _sampleRevenue(s));
  double profitForMonth(DateTime d) => centerSamples.where((s) => _sameMonth(s.createdAt, d)).fold(0, (sum, s) => sum + _sampleProfit(s));
  double referredFeeForMonth(DateTime d) => centerSamples.where((s) => _sameMonth(s.createdAt, d)).fold(0, (sum, s) => sum + _sampleReferredFee(s));
  double costForMonth(DateTime d) => revenueForMonth(d) - profitForMonth(d);
  List<_MonthRow> monthlyRows(int year) => [for (var m=1;m<=12;m++) _MonthRow(month: m, cost: costForMonth(DateTime(year,m,1)), profit: profitForMonth(DateTime(year,m,1)), revenue: revenueForMonth(DateTime(year,m,1)), referredFee: referredFeeForMonth(DateTime(year,m,1)), tests: testsForMonth(DateTime(year,m,1)))];
  Map<String,int> testsByName() {
    final map = <String,int>{};
    for (final s in centerSamples) {
      for (final t in s.testIds) {
        final name = _testFor(t).testName;
        map[name] = (map[name] ?? 0) + 1;
      }
    }
    final entries = map.entries.toList()..sort((a,b) => b.value.compareTo(a.value));
    return Map.fromEntries(entries);
  }
  double _sampleRevenue(BloodSample s) => s.testIds.fold(0, (sum, t) => sum + _customerPrice(s.subCenterId, t));
  double _sampleProfit(BloodSample s) {
    final baseProfit = s.testIds.fold(0.0, (sum, t) => sum + (_customerPrice(s.subCenterId, t) - _testFor(t).defaultPrice));
    return baseProfit - _sampleReferredFee(s);
  }
  double _sampleReferredFee(BloodSample s) {
    if (_isSelfReferral(s)) return 0;
    if (s.referredFeeAmount > 0) return s.referredFeeAmount;
    return s.testIds.fold(0.0, (sum, t) => sum + (_customerPrice(s.subCenterId, t) * _referredFeePercent(s.subCenterId, t) / 100));
  }
  bool _isSelfReferral(BloodSample s) {
    final id = _norm(s.referredPersonId ?? '');
    final name = _norm(s.referredPersonName ?? '');
    return id.isEmpty || id == 'self' || name == 'self';
  }
  double _customerPrice(String center, String testText) {
    final test = _testFor(testText);
    final pricing = _pricingFor(center, testText);
    return pricing != null && pricing.customPrice > 0 ? pricing.customPrice : test.defaultPrice;
  }
  double _referredFeePercent(String center, String testText) => _pricingFor(center, testText)?.referredFeePercent ?? 0;
  SubCenterPricing? _pricingFor(String center, String testText) {
    final test = _testFor(testText);
    for (final p in pricings) {
      final pt = _norm(p.testId);
      if (_norm(p.subCenterId) == _norm(center) && (pt == _norm(test.id) || pt == _norm(test.testName) || pt == _norm(testText))) {
        return p;
      }
    }
    return null;
  }
  LabTest _testFor(String text) {
    for (final t in tests) {
      if (_norm(t.id) == _norm(text) || _norm(t.testName) == _norm(text)) return t;
    }
    return LabTest(id: text, testName: text, defaultPrice: 0);
  }
  bool _sameDay(DateTime? value, DateTime d) { if (value == null) return false; final v = value.toLocal(); return v.year == d.year && v.month == d.month && v.day == d.day; }
  bool _sameMonth(DateTime? value, DateTime d) { if (value == null) return false; final v = value.toLocal(); return v.year == d.year && v.month == d.month; }
  String _norm(String v) => v.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
}

class _MonthRow { const _MonthRow({required this.month, required this.cost, required this.profit, required this.revenue, required this.referredFee, required this.tests}); final int month; final double cost; final double profit; final double revenue; final double referredFee; final int tests; }

class _Hero extends StatelessWidget { const _Hero({required this.centerId}); final String centerId; @override Widget build(BuildContext context) { final theme=Theme.of(context); return Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(borderRadius: BorderRadius.circular(30), gradient: const LinearGradient(colors: [Color(0xFF0B57B7), Color(0xFF2563EB), Color(0xFF2563EB)]), boxShadow: [BoxShadow(color: theme.colorScheme.primary.withValues(alpha: .24), blurRadius: 30, offset: const Offset(0,18))]), child: Row(children: [Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .18), borderRadius: BorderRadius.circular(24)), child: const Icon(Icons.query_stats_rounded, color: Colors.white, size: 36)), const SizedBox(width: 18), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Admin Analytics', style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w900)), const SizedBox(height: 6), Text('$centerId monthly cost, profits, revenue and test analytics.', style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white.withValues(alpha: .88)))]))])); } }

class _KpiCard extends StatelessWidget { const _KpiCard({required this.title, required this.value, required this.subtitle, required this.icon, required this.color}); final String title,value,subtitle; final IconData icon; final Color color; @override Widget build(BuildContext context){ final theme=Theme.of(context); return Card(elevation:0, color: theme.colorScheme.surface.withValues(alpha:.94), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)), child: Padding(padding: const EdgeInsets.all(22), child: Row(children: [Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: color.withValues(alpha:.13), borderRadius: BorderRadius.circular(20)), child: Icon(icon,color:color,size:30)), const SizedBox(width:16), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[Text(title, style: theme.textTheme.titleMedium), const SizedBox(height:6), Text(value, style: theme.textTheme.headlineSmall?.copyWith(color:color,fontWeight:FontWeight.w900)), Text(subtitle, style: theme.textTheme.bodySmall)]))]))); } }

class _GlassPanel extends StatelessWidget { const _GlassPanel({required this.title, required this.subtitle, required this.icon, required this.accent, required this.child}); final String title,subtitle; final IconData icon; final Color accent; final Widget child; @override Widget build(BuildContext context){ final theme=Theme.of(context); return Card(elevation:0, color: theme.colorScheme.surface.withValues(alpha:.94), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)), child: Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(30), border: Border.all(color: accent.withValues(alpha:.16)), gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [accent.withValues(alpha:.08), theme.colorScheme.surface.withValues(alpha:.02)])), padding: const EdgeInsets.all(22), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[Row(children:[Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: accent.withValues(alpha:.13)), child: Icon(icon,color:accent)), const SizedBox(width:12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[Text(title, style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)), const SizedBox(height:4), Text(subtitle)]))]), const SizedBox(height:18), child]))); } }


class _PrettyCostProfitChart extends StatelessWidget {
  const _PrettyCostProfitChart({required this.rows});

  final List<_MonthRow> rows;

  @override
  Widget build(BuildContext context) {
    final maxValue = rows.fold<double>(0, (max, row) {
      final localMax = row.cost > row.profit ? row.cost : row.profit;
      return localMax > max ? localMax : max;
    });
    return Column(
      children: [
        const _Legend(),
        const SizedBox(height: 14),
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              for (final row in rows)
                Expanded(
                  child: _MonthCostProfitColumn(
                    row: row,
                    maxValue: maxValue <= 0 ? 1.0 : maxValue,
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _PrettyTestsChart extends StatelessWidget {
  const _PrettyTestsChart({required this.rows});

  final List<_MonthRow> rows;

  @override
  Widget build(BuildContext context) {
    final maxTests = rows.fold<int>(0, (max, row) => row.tests > max ? row.tests : max);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        for (final row in rows)
          Expanded(
            child: _MonthTestsColumn(
              row: row,
              maxTests: maxTests <= 0 ? 1 : maxTests,
            ),
          ),
      ],
    );
  }
}

class _MonthCostProfitColumn extends StatelessWidget {
  const _MonthCostProfitColumn({required this.row, required this.maxValue});

  final _MonthRow row;
  final double maxValue;

  @override
  Widget build(BuildContext context) {
    final costHeight = (row.cost / maxValue).clamp(0.0, 1.0) * 170;
    final profitHeight = (row.profit / maxValue).clamp(0.0, 1.0) * 170;
    final hasData = row.cost > 0 || row.profit > 0 || row.tests > 0;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Text(
            hasData ? row.cost.toStringAsFixed(0) : '',
            maxLines: 1,
            overflow: TextOverflow.fade,
            style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w800, color: Color(0xFFEF4444)),
          ),
          const SizedBox(height: 4),
          Expanded(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _VerticalBar(
                    height: costHeight,
                    color: const Color(0xFFEF4444),
                    empty: !hasData,
                  ),
                  const SizedBox(width: 3),
                  _VerticalBar(
                    height: profitHeight,
                    color: const Color(0xFF10B981),
                    empty: !hasData,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 7),
          Text(
            _shortMonth(row.month),
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w900,
              color: hasData ? Theme.of(context).colorScheme.onSurface : Theme.of(context).colorScheme.outline,
            ),
          ),
        ],
      ),
    );
  }
}

class _MonthTestsColumn extends StatelessWidget {
  const _MonthTestsColumn({required this.row, required this.maxTests});

  final _MonthRow row;
  final int maxTests;

  @override
  Widget build(BuildContext context) {
    final height = (row.tests / maxTests).clamp(0.0, 1.0) * 190;
    final hasData = row.tests > 0;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(99),
              color: hasData ? const Color(0xFF8B5CF6).withValues(alpha: 0.16) : Colors.transparent,
            ),
            child: Text(
              hasData ? '${row.tests}' : '',
              style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: Color(0xFF8B5CF6)),
            ),
          ),
          const SizedBox(height: 6),
          Expanded(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: _VerticalBar(
                height: height,
                width: 18,
                color: const Color(0xFF8B5CF6),
                empty: !hasData,
              ),
            ),
          ),
          const SizedBox(height: 7),
          Text(
            _shortMonth(row.month),
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w900,
              color: hasData ? Theme.of(context).colorScheme.onSurface : Theme.of(context).colorScheme.outline,
            ),
          ),
        ],
      ),
    );
  }
}

class _VerticalBar extends StatelessWidget {
  const _VerticalBar({
    required this.height,
    required this.color,
    required this.empty,
    this.width = 12,
  });

  final double height;
  final double width;
  final Color color;
  final bool empty;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 450),
      width: width,
      height: empty ? 6 : height.clamp(8.0, 190.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(99),
        gradient: empty
            ? null
            : LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [color.withValues(alpha: 0.92), color.withValues(alpha: 0.50)],
              ),
        color: empty ? Theme.of(context).colorScheme.outlineVariant.withValues(alpha: 0.35) : null,
        boxShadow: empty
            ? []
            : [BoxShadow(color: color.withValues(alpha: 0.24), blurRadius: 10, offset: const Offset(0, 4))],
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  const _Legend();

  @override
  Widget build(BuildContext context) => const Row(
        children: [
          _Dot(label: 'Cost', color: Color(0xFFEF4444)),
          SizedBox(width: 14),
          _Dot(label: 'Profit', color: Color(0xFF10B981)),
        ],
      );
}

class _Dot extends StatelessWidget {
  const _Dot({required this.label, required this.color});

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
        ],
      );

}

class _MonthTile extends StatelessWidget { const _MonthTile({required this.row}); final _MonthRow row; @override Widget build(BuildContext context)=> Container(margin: const EdgeInsets.only(bottom:10), padding: const EdgeInsets.all(14), decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha:.42), border: Border.all(color: Theme.of(context).colorScheme.outlineVariant)), child: Row(children:[CircleAvatar(child: Text(_monthName(row.month).substring(0,1))), const SizedBox(width:12), Expanded(child: Text(_monthName(row.month), style: const TextStyle(fontWeight:FontWeight.w900))), Text('Cost ${row.cost.toStringAsFixed(0)}'), const SizedBox(width:12), Text('Profit ${row.profit.toStringAsFixed(0)}', style: const TextStyle(color:Color(0xFF10B981),fontWeight:FontWeight.w900)), const SizedBox(width:12), Text('Refer Fee ${row.referredFee.toStringAsFixed(0)}', style: const TextStyle(color:Color(0xFFF59E0B),fontWeight:FontWeight.w900)), const SizedBox(width:12), Text('${row.tests} tests', style: const TextStyle(fontWeight:FontWeight.w900))])); }
class _Empty extends StatelessWidget { const _Empty({required this.message}); final String message; @override Widget build(BuildContext context)=> Container(width:double.infinity,padding:const EdgeInsets.all(16),decoration:BoxDecoration(borderRadius:BorderRadius.circular(18),color:Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha:.4)), child:Text(message)); }
String _monthName(int m){const n=['January','February','March','April','May','June','July','August','September','October','November','December']; return n[m-1];}
String _shortMonth(int m){const n=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']; return n[m-1];}
